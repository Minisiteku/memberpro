<?php
include_once ('../conn.php');
include_once ('../functions.php');

if (isset ( $_POST['Submit'] )) {
	$c = 0;
	if ($_POST ["txtBody"] == '') {
		$c ++;
		$sb = 1;
	}
	if ($c == 0) {
		$sql = "INSERT INTO tblpromoemailsubject(sSubject, nPromoEmail_ID, nDisplay) VALUES ('" . $dbo->format ( $_POST["txtBody"] ) . "', " . $dbo->format($_POST['nPromoEmail_ID']) . ", 1)";
		if($dbo->insert($sql)){$qs = 'msg=Email subject line has been added successfully';}
		else{$qs = "There was an Error Saving your subject line.<br />{$dbo->error}";}
		header ( "location:email_subject.php?$qs" );
	}
}
?>

<html>
<head>
<title><?php echo $admintitle; ?></title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<?php include('inc-head.php') ?>
<script type="text/javascript">
function cdel(w) {
	if(confirm("Delete Confirmation!..\n\n Are Sure that you want to delete this?.."))
	{
		return true;
	}
	else
	{
		return false;
	}
}
</script>
</head>
<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once ('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
		<?php include_once ('affiliateleft.php'); ?></td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
		<form name="form1" id="form1" method="post" action="<?php echo $_SERVER ['PHP_SELF']; ?>"	>
		<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td class="navRow1" nowrap="nowrap">Add Email Subject Lines</td>
				<td width="100%" align="left">&nbsp;</td>
			</tr>
		</table>
		<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
			<tr>
				<td class="gridHeader" colspan="2">Add Email Subject Lines</td>
			</tr>
			<?php 
			// First we need to check if there are any promo emails in the database
			// You can't add subject lines until some promo emails are entered first
			$sql = "SELECT nPromoEmail_ID, sTitle FROM tblpromoemails WHERE nActive = 1";
			$result = $dbo->select($sql);
			if ($result !== false) {
				$options = '';
				while ($objPromoEmail = $dbo->getobj($result)) {
					$options .= '<option value="' . $objPromoEmail->nPromoEmail_ID . '">' . $objPromoEmail->sTitle . '</option>';
				}
			?>
			<tr>
				<td class="gridrow1" width="250">Promo email that this should belong to <span class="red">*</span></td>
				<td class="gridrow2">
				<select name="nPromoEmail_ID" id="nPromoEmail_ID" class="required" style="width: 300px;">
					<option value="">Please choose</option>
					<?php echo $options ?>
				</select>
				</td>
			</tr>
			<tr>
				<td class="gridrow1">Subject <span class="red">*</span></td>
				<td class="gridRow2"><input name="txtBody" type="text" value="" class="required" style="width: 300px;"></td>
			</tr>
			<tr>
				<td class="gridFooter" colspan="2"><input class="inputSubmit" name="Submit" value="Submit" type="submit"></td>
			</tr>
			<?php } else { ?>
			<tr>
				<td class="gridrow1" colspan="2"><b><span class="red">You must first enter some <a href="promotional_emails.php">Promo Emails</a> before you can insert Subject lines.</span></b></td>
			</tr>
			<?php } ?>
		</table>
		</form>
		</td>
	</tr>
</table>
<?php include_once ('b.php'); ?>
<script type="text/javascript">		
	$(document).ready(function()
	{
		$("#form1").validate();
	});
	</script>
</body>
</html>