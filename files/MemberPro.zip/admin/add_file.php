<?php
	include_once('../conn.php');
	include_once('../functions.php');	
?>
<html>
	<head>
		<title><?php echo $pagetitle ?></title>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<?php include('inc-head.php') ?>		
<style>
#uploader{
	width:600px;
	}
</style>
<!-- Load Queue widget CSS and jQuery -->
<style type="text/css">
@import url(../includes/plupload/js/jquery.plupload.queue/css/jquery.plupload.queue.css);
</style>

<!-- Third party script for BrowserPlus runtime (Google Gears included in Gears runtime now) -->
<script type="text/javascript" src="http://bp.yahooapis.com/2.4.21/browserplus-min.js"></script>

<!-- Load plupload and all it's runtimes and finally the jQuery queue widget -->
<script type="text/javascript" src="../includes/plupload/js/plupload.full.js"></script>
<script type="text/javascript" src="../includes/plupload/js/jquery.plupload.queue/jquery.plupload.queue.js"></script>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
	<?php include_once('top.php'); ?>

	
	<table>		
		<tr>
			<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include "pageleft.php"; ?></td>
			<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
				<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<td width="10%" class="navRow1" nowrap="nowrap"><?php echo $pagetitle ?></td>
						<td class="navRow1" style="padding-left:50px"><?php echo $message ?>&nbsp;</td>
					</tr>
				</table>
				<table class="navTable" border="0" cellpadding="0" cellspacing="0" width="100%">
					<tr><td>
						<a href="file_management.php">
							<img width="24" height="24" border="0" style="vertical-align: middle;" alt="Go Back" src="images/Arrow_Left_24x24.png"/>
						</a>
						<a href="file_management.php">Go Back</a>
					</td></tr>	
					
					<tr><td>
					</td></tr>	
					<tr><td>		
                        
                        <!-- Start PlUpload Code / replaces fancy Upload -->
                       <div id="uploader"> 
        <p>Your browser doesn't have Flash, Silverlight, Gears, BrowserPlus or HTML5 suppor!WOW, Get a new browser.</p>
        
        </div>
        
              <script type="text/javascript">
// Convert divs to queue widgets when the DOM is ready
$(function() {
	var filenames = new Array();
	$("#uploader").pluploadQueue({
		// General settings
		runtimes : 'gears,flash,silverlight,browserplus,html5',
		url : 'ajax/file_upload.php',
		max_file_size : '10000mb',
		chunk_size : '1mb',
		

		// Resize images on clientside if we can
		//resize : {width : 320, height : 240, quality : 90},

		// Specify what files to browse for
		filters : [
			{title : "All", extensions : "zip,pdf,jpg,jpeg,gif,bmp,png,html,htm,flv,mp4,mov"},
			{title : "Image", extensions : "jpg,jpeg,gif,png,bmp"},
			{title : "Document",extensions: "pdf,doc,docx,ppt,pptx,pps,ppsx"},
			{title : "Audio", extensions: "mp3,m4a,ogg,wav"},
			{title : "Video", extensions: "flv,mp4,m4v,mov,wmv,avi,mpg,ogv,3gp,3g2"},
			{title : "Compressed", extensions: "zip"}
			
		],

		// Flash settings
		flash_swf_url : '../includes/plupload/js/plupload.flash.swf',

		// Silverlight settings
		silverlight_xap_url : '../includes/plupload/js/plupload.silverlight.xap',
		
		// PreInit events, bound before any internal events
		preinit : {
		},

		// Post init events, bound after the internal events
		init : {
			FileUploaded: function(up, file, response) {
				// Called when a file has finished uploading
				var obj = jQuery.parseJSON(response.response);
				//console.log("my object: %o", obj);
				filenames.push(obj.name);
			},
			UploadComplete: function (up,file){
				var namestring = '';
				$.each(filenames,function(index,value){namestring +=('<br />'+value)});
				window.location.replace("file_management.php?msg=The Following File(s)Have Been Uploaded Successfully: "+namestring);
					},
			
			Error: function(up, args) {
				// Called when a error has occured
				//alert('[error] '+ args);
			}
		}
	});
});


</script>
                        <!-- End PlUpload -->		
					</td></tr>
					</table>
				</td></tr>
	</table>
	<?php include_once('b.php'); ?>
	</body>
</html>