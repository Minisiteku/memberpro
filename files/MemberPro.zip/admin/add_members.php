<?php 
include_once('../conn.php');
include_once('../functions.php');

if (isset($_GET['action']) && $_GET['action'] == 'add'){
	$c=0;

	if (trim($_POST["sForename"]) == "" )
	{
		$c++;
		$nm=1;
	}

	if (trim($_POST["sSurname"]) == "" )
	{
		$c++;
		$ln=1;
	}

	if(trim($_POST["sEmail"])=="")
	{
		$c++;
		$em=1;
	}

	if (!isValidEmail($_POST["sEmail"]) && $_POST["sEmail"]!="")
	{
		$c++;
		$em=2;
	}

	if (!isValidEmail($_POST["sPaypalEmail"]) && $_POST["sPaypalEmail"]!="")
	{
		$c++;
		$pem=2;
	}

	if (trim($_POST["sPassword"]) == "" )
	{
		$c++;
		$pwd=1;
	}
	if (trim($_POST["sPassword"]) != trim($_POST["sConfirmPass"]) )
	{
		$c++;
		$pwd=2;
	}

	if($c==0)
	{
		
		$today = date("Ymd");
		$time = date("g:i a"); 
		
		$sendConfirm = $_POST['sendConfirm'];
		
		$confirmstatus = ($sendConfirm == '0')?'1':'0';
		
		// insert user record
		$sql="INSERT INTO tblusers (sForename, sSurname, 
		sAddr1, 
		sAddr2, 
		sAddr3, 
		sTown, 
		sCounty, 
		sCountry, 
		sPostcode, 
		sEmail, 
		sTelephone, 
		sMobile, 
		nJoinDate, 
		sJoinTime, 
		sPassword, 
		nAffiliate,
		nAdmin, 
		nActive,
		nUnsubscribe, 
		sPaypalEmail, 
		nAffiliate_ID, 
		nCustomCommission,
		sComments,
		sCustomField1,
		sCustomField2,
		sCustomField3,
		sCustomField4,
		sCustomField5,
		sCustomField6,
		sCustomField7,
		sCustomField8,
		sCustomField9,
		sCustomField10,
		nConfirmed
		) VALUES (
		'" .$dbo->format($_POST["sForename"]) . "', 
		'" .$dbo->format($_POST["sSurname"]) . "', 
		'" .$dbo->format( $_POST["sAddr1"]) . "', 
		'" . $dbo->format($_POST["sAddr2"]) . "', 
		'" . $dbo->format($_POST["sAddr3"]) . "', 
		'" . $dbo->format($_POST["sTown"]) . "', 
		'" . $dbo->format($_POST["sCounty"]) . "', 
		'" . $dbo->format($_POST["sCountry"]) . "', 
		'" . $dbo->format($_POST["sPostcode"]) . "', 
		'" . $dbo->format($_POST["sEmail"]) . "', 
		'" . $dbo->format($_POST["sTelephone"]) . "', 
		'" . $dbo->format($_POST["sMobile"]) . "', 
		'$today', 
		'$time', 
		'" . $dbo->format($_POST["sPassword"]) . "', 
		'" . $dbo->format($_POST["nAffiliate"]) . "', 
		'" .$dbo->format( $_POST["nAdmin"]) . "', 
		'1',
		'".$dbo->format( $_POST["nUnsubscribe"])."', 
		'" . $dbo->format($_POST["sPaypalEmail"]) . "', 
		'" . $dbo->format($_POST["nAffiliate_ID"]) . "', 
		'" . $dbo->format($_POST["nCustomCommission"]) . "',
		'" . $dbo->format($_POST["sComments"]) . "',
		'" . $dbo->format($_POST["sCustomField1"]) . "',
		'" . $dbo->format($_POST["sCustomField2"]) . "',
		'" . $dbo->format($_POST["sCustomField3"]) . "',
		'" . $dbo->format($_POST["sCustomField4"]) . "',
		'" . $dbo->format($_POST["sCustomField5"]) . "',
		'" . $dbo->format($_POST["sCustomField6"]) . "',
		'" . $dbo->format($_POST["sCustomField7"]) . "',
		'" . $dbo->format($_POST["sCustomField8"]) . "',
		'" . $dbo->format($_POST["sCustomField9"]) . "',
		'" . $dbo->format($_POST["sCustomField10"]) . "',
		'".$confirmstatus."')
		";

		$nUser_ID = $dbo->insert($sql);
		if(!$nUser_ID){
			$msg = 'Error Adding Member:<br />'.$dbo->error;
			header("Location:add_members.php?err=$msg");exit;
			}
		
		// Get new user
		$objUser = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID = $nUser_ID");
		
		pluginClass::action("user_Added",$objUser);
		
		if($sendConfirm == '1'){
			
			// Create A Verification Code and send to user.
			
			// Add The Confirm Entry
			$sql = "INSERT INTO `tbluserconfirm` 
			(`nConfirm_ID`, `nUser_ID`, `nAffiliate`, `nPaymentPlan_ID`, `nSignupTime`, `sSignupIp`) 
			VALUES (NULL, '$objUser->nUser_ID', '0', '0', '".time()."', '".$_SERVER['REMOTE_ADDR']."');";
						
			$confCode = md5($dbo->insert($sql));
			
			// Send It Out
			// It requires a global variable $nPaymentPlan_ID
			$nPaymentPlan_ID = '0';
						
			email_member_confirm($objUser,$confCode);
				
		}
		
		// Insert user level
		if (isset($_POST['nLevel_ID']) && is_numeric($_POST['nLevel_ID'])) {
			$sql = "INSERT INTO tbluserlevels (nUser_ID, nLevel_ID, nDateExpires, nDateActive) 
			VALUES ($nUser_ID,{$dbo->format($_POST['nLevel_ID'])},
			".fStoreDate($chkSsettings->nDateFormat,$dbo->format($_POST['nDateExpires'])).",
			 ".date(Ymd).")";
			$dbo->insert($sql);
			;
		}
		
		header("Location:manage_members.php?msg=User Added Successfully!");
	
	}
	else{$message = '<div class="notify-error"><div class="notify-close, error-close" onClick="closeNotify(this)"></div>Please Correct The Following '.$c.' Errors:</div>';}}
?>
<html>
	<head>
	<title><?php echo $admintitle; ?></title>
	<link type="text/css" rel="stylesheet" href="../common/css/jqueryui/redmond/jquery-ui-1.8.24.custom.css">
	<!--<script language='javascript' src='calendar/popcalendar.js'></script> -->
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<?php include('inc-head.php') ?>
	<script language="javascript" src="../js/jquery-ui-1.8.24.custom.min.js"></script>
	<script type="text/javascript">
	$(function() {
		$( "#nDateExpires" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '2012:2032',changeYear: true});
		$( "#nJoinDate" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '2000:2032',changeYear: true});
	});
	
	</script>
	<style>
		.memberInfoBox {
			background-color: #EDEDED;
			padding: 5px;
			/*float: left;
			width: 30%;*/
			margin-left:10px;
		}
		.memberDataRow {
			background-color:#FFF;
		}
		.memberData td, th {
			color: #666666;
			font-family: "Lucida Grande", "Lucida Sans Unicode", Verdana, Arial, sans-serif;
			font-size: 12px;
		}
		input {
			color: #666666;
			font-family: "Lucida Grande", "Lucida Sans Unicode", Verdana, Arial, sans-serif;
			font-size: 12px;
		}
		#col1-3 {
			width:33% !important;
			width:30%;
			float:left;
		}
		#col2-3 {
			width:33% !important;
			width:30%;
			float:left;
		}
		#col3-3 {
			width:33% !important;
			width:30%;
			float:left;
		}
	</style>
	</head>

	<body leftmargin="0" topmargin="0" rightmargin="0">
    <?php include_once('top.php'); ?>
    <div style="padding:10px; width:100%">
      <h1>Add New Member</h1>
	  <?php echo isset($message) ? $message : '' ?>
	  <form name="f" id="f" method="post" action="add_members.php?action=add">
	  <div id="col1-3"><!-- Hidden Edit Details Box -->
			<div class="memberInfoBox" id="profileEdit" style="display:block">
					<div align="center"><strong>Member Profile</strong></div>
					<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
						<tr class="memberDataRow">
							<td width="43%" class="">First name <span class="REQUIRED"><font color="Red"> *</font></span></td>
							<td width="57%" ><input class="required" name="sForename" id="sForename" style="width:90%;" type="text" value="<?php echo ($_SESSION['form']['sForename'])? $_SESSION['form']['sForename']: $objUser->sForename;?>" />
								<?php if($_SESSION['profile']['errors']['nm']==1)	echo '<br /><span class="error">[ REQUIRED ]</span>'; ?></td>
						</tr>
						<tr class="memberDataRow">
							<td>Last name<span class="REQUIRED"><font color="Red"> *</font></span></td>
							<td><input class="required" name="sSurname" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sSurname'])? $_SESSION['form']['sSurname']: $objUser->sSurname;?>" type="text" />
								<?php if($_SESSION['profile']['errors']['ln']==1) echo '<br /><span class="error">[ REQUIRED ]</span>';	?></td>
						</tr>
						<tr class="memberDataRow">
							<td>Email Address<span class="REQUIRED"><font color="Red"> *</font></span></td>
							<td><input class="required email" name="sEmail" style="width:90%;" size="40"  value="<?php echo ($_SESSION['form']['sEmail'])? $_SESSION['form']['sEmail']: $objUser->sEmail;?>" />
								<?php
		if($_SESSION['profile']['errors']['em']==1)	echo "<br /><span class=\"error\">[ REQUIRED ]</span>";
		if($_SESSION['profile']['errors']['em']==2) echo "<br /><span class=\"error\">[ INVALID ]</span>";
		?></td>
						</tr>
						<tr class="memberDataRow">
							<td>Email Confirm</td>
							<td><label>
								<input name="sendConfirm" type="radio" id="RadioGroup1_1" value="0" checked="CHECKED">
Admin Confirmed<br>
<input name="sendConfirm" type="radio" id="RadioGroup1_0" value="1">
								Send Confirm Email</label></td>
						</tr>
						<tr class="memberDataRow">
							<td>Password<span class="REQUIRED"><font color="Red"> *</font></span></td>
							<td><input class="" name="sPassword" style="width:90%;" size="40"  value="<?php echo ($_SESSION['form']['sPassword'])? $_SESSION['form']['sPassword']: $objUser->sPassword;?>" type="password"/>
								<?php if($_SESSION['profile']['errors']['pw']==1) echo '<br /><span class="error">Passwords Do Not Match</span>'; ?></td>
						</tr>
						<tr class="memberDataRow">
							<td>Confirm Password<span class="REQUIRED"><font color="Red"> *</font></span></td>
							<td><input class="" name="sConfirmPass" style="width:90%;" size="40"  value="" type="password"/></td>
						</tr>
						<tr class="memberDataRow">
							<td>Address</td>
							<td><input  name="sAddr1" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sAddr1'])? $_SESSION['form']['sAddr1']: $objUser->sAddr1;?>"type="text" /></td>
						</tr>
						<tr class="memberDataRow">
							<td>&nbsp;</td>
							<td><input  name="sAddr2" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sAddr2'])? $_SESSION['form']['sAddr2']: $objUser->sAddr2;?>"type="text" /></td>
						</tr>
						<tr class="memberDataRow">
							<td>City/Town</td>
							<td><input  name="sTown" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sTown'])? $_SESSION['form']['sTown']: $objUser->sTown;?>" /></td>
						</tr>
						<tr class="memberDataRow">
							<td>State/County</td>
							<td><input  name="sCounty" style="width:90%;" size="40"  value="<?php echo ($_SESSION['form']['sCounty'])? $_SESSION['form']['sCounty']: $objUser->sCounty;?>" type="text" /></td>
						</tr>
						<tr class="memberDataRow">
							<td>Zip/Postcode</td>
							<td><input  name="sPostcode" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sPostcode'])? $_SESSION['form']['sPostcode']: $objUser->sPostcode;?>" /></td>
						</tr>
						<tr class="memberDataRow">
							<td>Country</td>
							<td><?php
		if($_POST['country']=="")
		{
			$co7=$row->sCountry;
		}
		else
		{
			$co7=$_POST['country'];
		}
	
		$Selected = ($country) ? $country : (($_SESSION['form']['sCountry'])? $_SESSION['form']['sCountry']: $objUser->sCountry);
		//$CountryDropMenu = countrydm("sCountry",$Selected);
		//echo $CountryDropMenu;
		echo get_country_list('sCountry',$Selected,0);
		
		?></td>
						</tr>
						<tr class="memberDataRow">
							<td>Telephone</td>
							<td><input  name="sTelephone" style="width:90%;" value="<?php echo ($_SESSION['form']['Telephone'])? $_SESSION['form']['sTelephone']: $objUser->sTelephone;?>" /></td>
						</tr>
						<tr class="memberDataRow">
							<td>Mobile</td>
							<td><input  name="sMobile" style="width:90%;" value="<?php echo ($_SESSION['form']['Mobile'])? $_SESSION['form']['sMobile']: $objUser->sMobile;?>" /></td>
						</tr>
					</table>
					<br />
			</div>
			<!-- End Hidden End --> 
		</div>
		
	  <div id="col2-3">
			
		  <div class="memberInfoBox" id="accountEdit">
				<div align="center"><strong>Account Information</strong></div>
					<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
						<tr class="memberDataRow">
							<td width="123"><label for="nAdmin">Account Type</label></td>
							<td width="255">
								<select name="nAdmin" id="nAdmin">
									<option value="1" <?php echo ($objUser->nAdmin) ? 'selected' :''; ?>>Administrator</option>
									<option value="0" <?php echo (!$objUser->nAdmin) ? 'selected' :''; ?>>Customer</option>
							</select></td>
						</tr>
						<tr class="memberDataRow">
							<td width="123" class=""><label for="nJoinDate">Signup Date</label></td>
							<td width="255" ><input name="nJoinDate" type="text" id="nJoinDate" value="<?php echo fShowDate($chkSsettings->nDateFormat, date("Ymd")) ?>" class="datepicker"></td>
						</tr>
						<tr class="memberDataRow">
							<td><label for="nUnsubscribe">Email Preference</label></td>
							<td>
								<select name="nUnsubscribe" id="nUnsubscribe">
									<option value="0" <?php echo ($objUser->nUnsubscribe == '0') ? 'selected': '' ?>>Receive All</option>
									<option value="1" <?php echo ($objUser->nUnsubscribe == '1') ? 'selected': '' ?>>Receive None</option>
							</select></td>
						</tr>
					</table>
		  </div><br>
          <!-- Hide This Box As Its Handled In The View Member Area Of The SIte -->
<div class="memberInfoBox" style="display:none;">
	<div align="center"><strong>Membership Details</strong></div>
	<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
		<tr class="memberDataRow">
			<td width="123"><label for="nAdmin2">Membership Level</label></td>
			<td width="255"><span class="gridrow1">
				<select name="nLevel_ID" id="nLevel_ID" style="width:98%;">
					<option value="">Assign a level to this member</option>
					<?php 
				// Get all levels which user is not already assigned to
				$sql = "SELECT nLevel_ID, sLevel FROM tblmembershiplevels WHERE nActive=1 ORDER BY sLevel";
				$result = $dbo->select($sql);
				while ($objLevel = $dbo->getobj($result)) {
					echo '<option value="' . $objLevel->nLevel_ID . '">' . $objLevel->sLevel . '</option>';
				}
				?>
				</select>
			</span></td>
		</tr>
		<tr class="memberDataRow">
			<td width="123" class="">Expiration Date</td>
			<td width="255" ><span class="gridrow1">
				<input name="nDateExpires" id="nDateExpires" style="width: 50%;" value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd',strtotime('+1 month')));?>" readonly />
					<?php if($df==1)	echo "<span class=\"required\">Invalid date format (mm/dd/yyyy)</span>"; ?>
			</span></td>
		</tr>
	</table>
</div><br>

<div class="memberInfoBox">
				<div align="center"><strong>Admin Comments</strong></div>
					<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
						<tr class="memberDataRow">
							<td colspan="2" class=""><textarea name="sComments" id="comments" rows="5" style="width:99%" onKeyPress="showEdit('comments','edit')" ><?php echo $objUser->sComments ?></textarea></td>
						</tr>
					</table>
					<div id="commentsEdit" style="display:none" align="center">
						<input type="submit" value="Save Comments" />
						&nbsp;
						<input type="button" value="Cancel" onClick="showEdit('comments','show')" />
					</div>
			</div>
			<div style="clear:both; text-align:center"><br>
			<input name="input" type="submit" value="Add Member">
		  </div> </div>
	  <div id="col3-3">
	  	
	  	<!-- Hidden Edit Field -->
	  	<div class="memberInfoBox" id="affiliateEdit">
	  			<div align="center"><strong>Affiliate Information</strong></div>
	  			<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
	  				<tr class="memberDataRow">
	  					<td width="123" class="">Referred By</td>
	  					<td width="255" ><select name="nAffiliate_ID">
	  						<option value="">No Affiliate</option>
	  						<?php
		$sqlaf="select * from tblusers 
		where naffiliate=1 and nUser_ID != '" . $objUser->nUser_ID . "' 
		order by sforename";

		$resultaf = $dbo->select($sqlaf);
		if ($resultaf) {
			while($rowaf=$dbo->getobj($resultaf))
			{
				echo "<option value=\"" . $rowaf->nUser_ID . "\"";
			
				if($rowaf->nUser_ID==$objUser->nAffiliate_ID) echo "selected";
			
				echo ">" . $rowaf->sForename . " " . $rowaf->sSurname . "</option>";
			}
		}
		?>
  						</select></td>
  					</tr>
	  				<tr class="memberDataRow">
	  					<td width="123" class="">Is Affiliate</td>
	  					<td width="255" ><input name="nAffiliate" type="checkbox" id="nAffiliate" value="1" 
			  <?php if($_SESSION['form']['nAffiliate']){if($_SESSION['form']['nAffiliate'] == 1){echo "checked";}}
			  else{if($objUser->nAffiliate==1) { echo "checked"; }} ?> /></td>
  					</tr>
	  				<tr class="memberDataRow">
	  					<td>Paypal Email</td>
	  					<td><input name="sPaypalEmail" class="inputText" id="sPaypalEmail" style="width:90%;" value="<?php echo ($_SESSION['form']['sPaypalEmail'])?$_SESSION['form']['sPaypalEmail']: $objUser->sPaypalEmail?>" size="40" />
	  						<span class="gridrow1">
	  						<?php 	if($pem==2){ echo "<span class=\"required\">[ INVALID ]</span>"; } ?>
  						</span></td>
  					</tr>
	  				<tr class="memberDataRow">
	  					<td>Custom Commission %</td>
	  					<td><input name="nCustomCommission" class="inputText" id="nCustomCommission" style="width: 50px;" value="<?php echo ($_SESSION['form']['nCustomCommission']) ?$_SESSION['form']['nCustomCommission']:$objUser->nCustomCommission?>" size="40" /></td>
  					</tr>
  				</table>
	  	</div>
	  	<!-- END Hidden Edit Field -->
	  	<br />
	  	
	  	<!-- Hidden Edit Field -->
	  	<div class="memberInfoBox" id="customfieldsEdit" style="display:block;">
	  			<div align="center"><strong>Additional Profile Details</strong></div>
	  			<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
	  				<?php
			$objCustomFieldSettings = $dbo->select("SELECT * FROM tblcustomfieldsettings ORDER BY nSortOrder, sCustomFieldName");
			while($row2 = $dbo->getobj($objCustomFieldSettings)):
			if($row2->nCustomFieldSetting_ID ==1){$v = $objUser->sCustomField1;}
			elseif($row2->nCustomFieldSetting_ID ==2){$v = $objUser->sCustomField2;}
			elseif($row2->nCustomFieldSetting_ID ==3){$v = $objUser->sCustomField3;}
			elseif($row2->nCustomFieldSetting_ID ==4){$v = $objUser->sCustomField4;}
			elseif($row2->nCustomFieldSetting_ID ==5){$v = $objUser->sCustomField5;}
			elseif($row2->nCustomFieldSetting_ID ==6){$v = $objUser->sCustomField6;}
			elseif($row2->nCustomFieldSetting_ID ==7){$v = $objUser->sCustomField7;}
			elseif($row2->nCustomFieldSetting_ID ==8){$v = $objUser->sCustomField8;}
			elseif($row2->nCustomFieldSetting_ID ==9){$v = $objUser->sCustomField9;}
			else{$v = $objUser->sCustomField10;}
	?>
	  				<tr class="memberDataRow">
	  					<td width="136" nowrap="nowrap" ><?php echo $row2->sCustomFieldName ?></td>
	  					<td width="189"><input  name="sCustomField<?php echo $row2->nCustomFieldSetting_ID ?>" id="sCustomField<?php echo $row2->nCustomFieldSetting_ID ?>"style="width:90%;" size="40" type="text" value="<?php echo $v; ?>" /></td>
  					</tr>
	  				<?php endwhile; ?>
  				</table>
	  			<!-- END Hidden Edit Field -->
  		</div>
  	</div>
		<div style="clear:both"></div>
	  </form>
    </div>
    <div style="clear:both;"></div>
    <?php include_once('b.php'); ?>
</body>
</html>