<?php

include_once ('../conn.php');
include_once ('../functions.php');
//die(var_dump($_SESSION['form']));
if($_SESSION['errors']){foreach($_SESSION['errors'] as $k=>$v){$$k = $v;}}
// Lets Build Existing Video List
$sql = "SELECT * FROM tblvideos";
$res = $dbo->select($sql);
if($res){
	while($row = $dbo->getobj($res)){
		$selects .= '<option value="[[video '.$row->nVideo_ID.']]" id="'.$row->sFileName.'">'.$row->sFileName.'</option>'."\n";
		}
	}
?>
<html>
<head>
<meta charset="utf-8" />
<?php include "inc-head.php"; ?>
<title><?php echo $sSitename ?>Admin Panel</title>
<script type="text/javascript" src="common/js/tiny_mce/tiny_mce.js"></script>
<!-- Load Queue widget CSS and jQuery -->
<style type="text/css">
@import url(../includes/plupload/js/jquery.plupload.queue/css/jquery.plupload.queue.css);


</style>


<!-- Third party script for BrowserPlus runtime (Google Gears included in Gears runtime now) -->
<script type="text/javascript" src="http://bp.yahooapis.com/2.4.21/browserplus-min.js"></script>

<!-- Load plupload and all it's runtimes and finally the jQuery queue widget -->
<script type="text/javascript" src="../includes/plupload/js/plupload.full.js"></script>
<script type="text/javascript" src="../includes/plupload/js/jquery.plupload.queue/jquery.plupload.queue.js"></script>
<script type="text/javascript" language="JavaScript">
var IE = false;
</script>
<![if IE]>
<script type="text/javascript"> IE = true;</script>
<![endif]>
<script type="text/javascript">
	function getExistingEmbed(ele){
		var ele2 = document.getElementById('embedCodes');
		document.getElementById('embedTable').style.display = 'block';
		
		var curhtml = ele2.innerHTML;
		if(curhtml.indexOf(ele.options[ele.selectedIndex].id) == -1){
			var newhtml = curhtml+'<span>'+ele.value+' - '+ele.options[ele.selectedIndex].id+'</span><br />';
			if(IE == true){tinyMCE.activeEditor.execCommand("mceInsertRawHTML", false, ele.value);tinyMCE.activeEditor.focus();}
			else{tinyMCE.activeEditor.selection.setContent(ele.value);}
			ele2.innerHTML = newhtml;
		}
		
	}
	function addRemote(){
		var dataString = "sVideoURL=" + $("#sVideoURL").val();
		$.ajax({
			type: "POST",
			url: "ajax/video_remote.php",
			data: dataString,
			success: function(response) {
				console.log( response );
				var obj = jQuery.parseJSON(response);
		  		if(obj.error){
			  		console.log( obj.error);
			  		$('#ajaxError').html(obj.error.message);
			  	}
		  		else{
			  		console.log( obj );
		  			$('#remote').hide()
		  			$('#embedTable').show()
		  			$('#embedCodes').append(obj.data.message+'<br />');
		  			$("#newsel").attr('selectedIndex', 0);
		  			$("#sVideoURL").val('');
		  			if(IE == true){tinyMCE.activeEditor.execCommand("mceInsertRawHTML", false, '[[Video '+obj.id+']]');tinyMCE.activeEditor.focus();}
					else{tinyMCE.activeEditor.selection.setContent('[[Video '+obj.id+']]');}
			  }
			}
		});
		return false;
	}
	function updateLinkName(ele){
		
		document.getElementById('pagename').innerHTML = ele.value.replace(/\s/g, "");
	}

	
	function toggle(ele,set){
		if(set == 'emailoption'){
			if(ele.checked == 1){
				document.getElementById('sendemailtext').style.display = 'block';
				document.getElementById('sendemailbody').style.display = 'block';
			}
			else{
				document.getElementById('sendemailtext').style.display = 'none';
				document.getElementById('sendemailbody').style.display = 'none';
			}
		}
	}
	
	
	function disable_enable_nUnavailableForJoinedAfter(){
		if(document.form1.nUnavailableForJoinedAfter_checkbox.checked){
			document.form1.nUnavailableForJoinedAfter_month.disabled=false;
			document.form1.nUnavailableForJoinedAfter_year.disabled=false;
		}
		else{
			document.form1.nUnavailableForJoinedAfter_month.disabled=true;
			document.form1.nUnavailableForJoinedAfter_year.disabled=true;
		}
	}
	function videoaction(){
		if($('#videoact').val() == "new"){
			$('#newsel').show();
			$('#existingvids').attr('selectedIndex', 0).hide();
		}
		else if($('#videoact').val() == "existing"){
		
			$("#newsel").attr('selectedIndex', 0).hide();
			$('#existingvids').show();
			$('#remote').hide();
			$('#uploader').hide()
		}
		else{
			$("#newsel").attr('selectedIndex', 0).hide();
			$('#existingvids').attr('selectedIndex', 0).hide();
			$('#remote').hide();
			$('#uploader').hide()
		}
	}
	function newVideoOpt(){
		
		if($('#newsel').val() == 'upload'){
			$('#remote').hide();
			$('#uploader').show()
			
			$('#uploader').pluploadQueue({
			// General settings
			runtimes : 'gears,flash,silverlight,browserplus,html5',
			url : 'ajax/video_upload.php',
			max_file_size : '10000mb',
			chunk_size : '1mb',

			// Resize images on clientside if we can
			//resize : {width : 320, height : 240, quality : 90},
	
			// Specify what files to browse for
			filters : [
				{title : "Video files", extensions : "flv,mp4,mov"}
			],
	
			// Flash settings
			flash_swf_url : '../includes/plupload/js/plupload.flash.swf',
	
			// Silverlight settings
			silverlight_xap_url : '../includes/plupload/js/plupload.silverlight.xap',
			
			// PreInit events, bound before any internal events
			preinit : {
			},
	
			// Post init events, bound after the internal events
			init : {
				FileUploaded: function(up, file, response) {
					// Called when a file has finished uploading
					var obj = jQuery.parseJSON(response.response);
					console.log("my object: %o", obj)
					document.getElementById('uploader').style.display = 'none';
					document.getElementById('embedTable').style.display = 'block';
					$("#newsel").attr('selectedIndex', 0);
					var curhtml = document.getElementById('embedCodes').innerHTML;
					var newhtml = '[[video '+obj.id+']] - '+obj.name+'<br />';
					document.getElementById('embedCodes').innerHTML = curhtml+newhtml;
					if(IE == true){tinyMCE.activeEditor.execCommand("mceInsertRawHTML", false, '[[video '+obj.id+']]');tinyMCE.activeEditor.focus();}
					else{tinyMCE.activeEditor.selection.setContent('[[video '+obj.id+']]');}
				},
	
				Error: function(up, args) {
					// Called when a error has occured
					//alert('[error] '+ args);
				}
			}
		});
		return;
			}
		if(document.getElementById('newsel').value=='remote'){
			$('#remote').show();
			$('#uploader').hide();
			}
		else{
			$('#remote').hide();
			$('#uploader').hide()
			}
		
		}
	
</script>

<?php
if(get_option('use_mce') == '1'){
	$doc_base = $chkSsettings->sSiteURL .'/';
	if(usePageLevels($_GET['did'])){$doc_base .= 'member/';}
?>
<script type="text/javascript" src="common/js/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="common/js/tiny_mce/init.php?folder=<?php echo TEMPLATEFOLDER ?>&base=<?php echo $doc_base  ?>&linktype=r"></script>
<?php } ?>
</head>
<body leftmargin="0" topmargin="0" rightmargin="0" onLoad="setMceWidth('inpContent')">
<?php include_once ('top.php'); ?>
<div style="padding:10px;">
<h1>Add New Page</h1>

      <?php echo isset($message) ? $message : '' ?>
<div style="line-height: 1em; margin-bottom: 5px;"> <a href="page_management.php"><img src="images/Arrow_Left_24x24.png" width="24" height="24" alt="Go Back" border="0" style="vertical-align: middle"></a> <a href="page_management.php<?php echo
$_SESSION['page_management_qs'] ?>">Go Back</a> </div>

      <table class="navTable" border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td class="navRow1"><form name="form1" id="form1" method="post" action="actions.php?type=page">
          <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
                  <tr>
                    <td colspan="2" class="gridheader">General Settings</td>
                  </tr>
            <tr>
                    <td width="10%" class="gridrow2">File Name <font color="Red"> *</font></td>
                    <td width="90%" class="gridrow2"><input name="pname" type="text" class="box" style="width:40%" value="<?php echo $_SESSION['form']['pname']; ?>" maxlength="255" onKeyUp="updateLinkName(this)"/>
                      <span class="red">
                      <?php
if ($pn == 1) {echo "[ Required ]";}
if ($lg == 1) {echo "<br>[ The page name length should not exceed 255 characters!... ]";}
if ($al == 1) {echo "<br>[ Page name already exists. Please select new name !... ]";}
?>
                      </span><br>
<?php echo $doc_base ?>index.php?page=<strong><span id="pagename"></span></strong></td>
                  </tr>

            <tr >
              <td class="gridrow2" >Menu Bar Name <font color="Red"> *</font></td>
                    <td class="gridrow2"><input name="vpname" type="text" class="box" value="<?php echo $_SESSION['form']['vpname']; ?>" size="25" />
                      <span class="red">
                      <?php if ($vpn == 1) {
    echo "[ Required ]";
} ?>
                      <?php if ($lgvpn == 1) {
    echo "<br>[ Visible page name should not exceed 255 characters ]";
} ?>
                      </span></td>
                  </tr>
                                    <tr class="gridTable">
                    <td class="gridrow2">Status</td>
                    <td class="gridrow2"><select name="nDisplay" id="nDisplay">
                      <option value="1" selected>Active</option>
                      <option value="0">Inactive</option>
                    </select> 
                      <input type="submit" name="Submit" value="Save" class="inputSubmit" /></td>
            </tr>
            </table>
          <input type="hidden" name="did" value="<?php echo $_GET['did'] ?>"/>
              <input type="hidden" name="act" value="add" />
            <div style="width:65%; float:left; margin: 0 2% 0 0;">
                <textarea id="inpContent" name="inpContent" rows="10" style="height:520px; width:100%;"><?php echo $_SESSION['form']['inpContent']; ?></textarea>
            </div>
              <div style="width:32%; float:left;">
                <?php if (usePageLevels($_GET['did'])){ ?>
                <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
                  <tr class="gridTable">
                    <td colspan="2" class="gridheader">Access Rights</td>
                  </tr>
                  <tr class="gridTable">
                    <td width="265" class="gridrow2">Who can view this page? <font color="Red"> *</font></td>
                    <td width="315" class="gridrow2"><span class="red">
                      <?php if ($pl == 1) {echo "At Least One Level Is Required<br />";} ?>
                      </span>
                      <?php
    $sql = "SELECT * FROM tblmembershiplevels  WHERE nActive='1' ORDER BY nOrder ASC , sLevel ASC";
    $rs = $dbo->select($sql);

    if (!empty($rs))
        while ($row = $dbo->getobj($rs)) {
			if(!$_SESSION['form']['pageLevel']){$_SESSION['form']['pageLevel'] = array();}
			$checked = (in_array($row->nLevel_ID,$_SESSION['form']['pageLevel']))? 'checked':'';
			$boxes .= '<input name="pageLevel[]" type="checkbox" value="'.$row->nLevel_ID.'" '.$checked.'/> '.$row->sLevel;
        }
    echo $boxes ?></td>
                  </tr>
                  <tr class="gridTable">
                    <td class="gridrow2">Unavailable if joined after:</td>
                    <td class="gridrow2"><input name="nUnavailableForJoinedAfter_checkbox" type="checkbox" class="box" onClick="disable_enable_nUnavailableForJoinedAfter()" value="1" 
		<?php if ($_SESSION['form']['nUnavailableForJoinedAfter_checkbox']==1) {
        echo 'checked="checked"';
        $nUnavailableForJoinedAfter_disabled = "";

        $nUnavailableForJoinedAfter_month = $_SESSION['form']['nUnavailableForJoinedAfter_month'];
        $nUnavailableForJoinedAfter_year = $_SESSION['form']['nUnavailableForJoinedAfter_year'];

        ${"nUnavailableForJoinedAfter_month_" . $nUnavailableForJoinedAfter_month .
            "_selected"} = 'selected="selected"';
        ${"nUnavailableForJoinedAfter_year_" . $nUnavailableForJoinedAfter_year .
            "_selected"} = 'selected="selected"';

    } else {
        $nUnavailableForJoinedAfter_disabled = 'disabled="disabled"';
    } ?> />
                      <select name="nUnavailableForJoinedAfter_month" <?php echo $nUnavailableForJoinedAfter_disabled; ?> >
                        <option value=""></option>
                        <option value="01" <?php echo $nUnavailableForJoinedAfter_month_01_selected ?>>January</option>
                        <option value="02" <?php echo $nUnavailableForJoinedAfter_month_02_selected ?>>February</option>
                        <option value="03" <?php echo $nUnavailableForJoinedAfter_month_03_selected ?>>March</option>
                        <option value="04" <?php echo $nUnavailableForJoinedAfter_month_04_selected ?>>April</option>
                        <option value="05" <?php echo $nUnavailableForJoinedAfter_month_05_selected ?>>May</option>
                        <option value="06" <?php echo $nUnavailableForJoinedAfter_month_06_selected ?>>June</option>
                        <option value="07" <?php echo $nUnavailableForJoinedAfter_month_07_selected ?>>July</option>
                        <option value="08" <?php echo $nUnavailableForJoinedAfter_month_08_selected ?>>August</option>
                        <option value="09" <?php echo $nUnavailableForJoinedAfter_month_09_selected ?>>September</option>
                        <option value="10" <?php echo $nUnavailableForJoinedAfter_month_10_selected ?>>October</option>
                        <option value="11" <?php echo $nUnavailableForJoinedAfter_month_11_selected ?>>November</option>
                        <option value="12" <?php echo $nUnavailableForJoinedAfter_month_12_selected ?>>December</option>
                      </select>
                      &nbsp;
                      <select name="nUnavailableForJoinedAfter_year" <?php echo $nUnavailableForJoinedAfter_disabled; ?> >
                        <option value=""></option>
                        <?php
    $i = 0;
    while ($i < 5) {
        $year = date(Y) - $i;
        echo "<option value='$year' " . ${"nUnavailableForJoinedAfter_year_" . $year .
            "_selected"} . ">$year</option>";
        $i++;
    }

?>
                      </select></td>
                  </tr>
                </table>
                <br>
                <table border="0" cellspacing="1" cellpadding="0" class="gridtable">
                  <tr class="gridTable">
                    <td colspan="2" class="gridheader">Drip Feed Settings</td>
                  </tr>
                  <tr class="gridTable">
                    <td width="31%" class="gridrow2">Days Until Available</td>
                    <td width="69%" class="gridrow2"><input name="naccessdays" type="text" class="box digits" value="<?php echo
isset($_SESSION['form']['naccessdays']) ? $_SESSION['form']['naccessdays'] : 0; ?>" size="5" maxlength="5" />
                      <font color="Red">*</font>How many days until user can view this page?<font color="Red">&nbsp; </font></td>
                  </tr>
                  <tr class="gridTable">
                    <td class="gridrow2">Dynamic Menu Bar Name?</td>
                    <td class="gridrow2"><input name="nDynamicPage" type="checkbox" class="box" value="1" <?php echo
    $_SESSION['form']['nDynamicPage'] ? 'checked="checked"' : '' ?> />
                      <small>(This will replace "Menu Bar Name" with a month and year dynamically generated according to the member's join date)</small></td>
                  </tr>
                  <tr class="gridTable">
                    <td valign="top" class="gridrow2">Email member?
                      <div id="sendemailtext" style="display:none">Email content</div></td>
                    <td  class="gridrow2"><input type="checkbox" name="nconfemail" <?php echo isset($_SESSION['form']['nconfemail']) ?
'checked="checked"' : '' ?> value="1" onChange="toggle(this,'emailoption')"/>
                      Send email when page is active?
                      <div id="sendemailbody" style="display:none">
                        <textarea name="sconfemailcontent" cols="40" rows="8" style="width:100px;"><?php echo $_SESSION['form']['sconfemailcontent'] ?></textarea>
                      </div></td>
                  </tr>
                </table>
                <br>
                <?php } ?>
                
              <!--  <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
                  <tr class="gridtable">
                    <td colspan="2" class="gridrow2">Social Media Settings</td>
                  </tr>
                  <tr class="gridTable">
                    <td width="35%" class="gridrow2">Integrate Facebook Comments?</td>
                    <td width="65%" class="gridrow2"><input name="fbcomments" type="checkbox" id="fbcomments" value="1" <?php echo ($_SESSION['form']['fbcomments'] == '1') ? 'checked':''; ?> /></td>
                  </tr>
                </table>
                <br> -->
                <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable" >
                  <tr class="gridtable">
                    <td class="gridheader">Video Settings</td>
                  </tr>
                  <tr class="gridTable">
                    <td class="gridrow2"> Add Video To Post?
                      <select name="videoact" id="videoact" onChange="videoaction()">
                        <option selected>No Video</option>
                        <option value="new">Add New Video</option>
                        <option value="existing">Use Existing Video</option>
                      </select>
                      <select name="existingvids" id="existingvids" onChange="getExistingEmbed(this)" style="display:none;">
                        <option value="">-- Select Video --</option>
                        <?php echo $selects ?>
                      </select>
                      <select name="newsel" id="newsel" onChange="newVideoOpt()" style="display:none;">
                        <option selected>Select A Method</option>
                        <option value="upload">Upload New Video</option>
                        <option value="remote">From Url</option>
                      </select>
                      <div id="uploader" style="display:none"> <?php echo '<form action="ajax/video_upload.php" method="post" id="uploaderForm">' ?>
                        <p>Your browser doesn't have Flash, Silverlight, Gears, BrowserPlus or HTML5 suppor!WOW, Get a new browser.</p>
                        <?php echo '</form>'; ?> </div>
                      <div id="remote" style="display:none;"> URL <span style="color: red">*</span>
                        <input type="text" name="sVideoURL" id="sVideoURL" style="width: 250px;" class="url required" />
                        <small>e.g. http://www.somewebsite.com/uploads/video123.flv</small>
                        <input name="Submit" type="button" value="Add Video" id="remoteVideo" onClick="addRemote();">
                        <span id="ajaxError" class="error"></span> </div></td>
                  </tr>
                </table>
                <br>
                <div id="embedTable" style="display:none">
                  <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
                    <tr class="gridtable">
                      <td class="gridrow2">Video Embed Codes</td>
                    </tr>
                    <tr class="gridTable">
                      <td class="gridrow2"><div id="embedCodes"></div></td>
                    </tr>
                  </table>
                </div>
                <?php echo pluginClass::filter("page_new_sidebar");?>
              </div>
              <div style="clear:both;"></div>
              <?php echo pluginClass::filter("page_new_bottom");?>
            </form></td>
        </tr>
      </table>
</div>
<?php include_once ('b.php'); ?>
<?php 
$_SESSION['form'] = '';
unset($_SESSION['errors']);
?>
</body>
</html>