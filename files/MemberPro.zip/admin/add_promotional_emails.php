<?php
include_once('../conn.php');
include_once('../functions.php');

if(isset($_POST[Submit]))
{
	$c=0;
	if($_POST[txtContent]=="")
	{
		$c++;
		$sb=1;
	}
	if($c==0)
	{
		if ($_POST['nSortOrder'] == '') {
			$nSortOrder = 0;
		} else {
			$nSortOrder = $dbo->format($_POST['nSortOrder']);
		}
		$sql = "INSERT INTO tblpromoemails(sEmailText, sTitle, nSortOrder, nActive) VALUES (
		'" . $dbo->format($_POST["txtContent"]) . "', 
		'" . $dbo->format($_POST['sTitle']) . "', 
		$nSortOrder,1)";
		
		if($dbo->insert($sql)){$msg = 'msg=Email Added Successfully';}
		else{$msg = "err=Database Error:$dbo->error";}
		header("location:promotional_emails.php?$msg");exit;
	}
}
?> 

<html>
<head>
<title><?php echo $admintitle; ?></title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<?php include_once('inc-head.php'); ?>
<link rel="stylesheet" type="text/css" href="common/css/styles.css">
<script type="text/javascript">

// SCRIPT USED TO INSERT THE STRING INTO THE TEXTAREA
function InsertText(input, insTexte)
{
startTag = '';
endTag = '';
	if (input.createTextRange)
	{
		var text;
		input.focus(input.caretPos);
		input.caretPos = document.selection.createRange().duplicate();
		if(input.caretPos.text.length>0)
	{
		input.caretPos.text = startTag + input.caretPos.text + endTag;
	}
	else
	{
		input.caretPos.text = startTag + insTexte +  endTag;
	}
	}
else input.value += startTag + insTexte + endTag;}

</script>
</head>
<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
    
    <tr>
      <td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">        <?php include_once('affiliateleft.php'); ?>      </td>
      <td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;"  valign="top" width="100%">
      <?php echo isset($message) ? $message : '' ?>
      <form name="form1" id="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
		  <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
              <tr>
                <td class="navRow1" nowrap="nowrap">Add Promotional Emails </td>
                <td width="100%" align="left">&nbsp;</td>
              </tr>
          </table>    
		<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
		<tr>
			<td class="gridHeader" colspan="2"> Add Promotional Email </td>
		</tr>
		<tr>
			<td class="gridrow1" width="250">Email Title <span class="red">*</span></td>
			<td class="gridrow2"><input type="text" name="sTitle" class="required" style="width: 250px;"></td>
		</tr>
		<tr>
			<td class="gridrow1">Sort Order</td>
			<td class="gridrow2"><input type="text" name="nSortOrder" style="width: 50px;"></td>
		</tr>
		<tr>
			<td valign="top" class="gridRow1">Email Body <span class="red">*</span></td>
			<td valign="middle" class="gridRow2">
			<input name="button2" type="button"  class="inputSubmitb" onClick="InsertText(document.form1.txtContent,'#AFFILIATE LINK#');"  value="Insert Affiliate Link" />
			<br /><br />
			<textarea name="txtContent" cols="58" rows="12" class="required"></textarea></td>
		</tr>
		<tr>
			<td class="gridFooter" colspan="2"><input class="inputSubmit" name="Submit" value="Submit" type="submit"></td>
		</tr>        
      </table>
  	</form> </td>
      </tr>
</table>
<?php include_once('b.php'); ?>
<script type="text/javascript">		
	$(document).ready(function()
	{
		$("#form1").validate();
	});
</script>
</body></html>