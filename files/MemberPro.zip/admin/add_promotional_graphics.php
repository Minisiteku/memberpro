<?php
include_once('../conn.php');
include_once('../functions.php');

if ( isset($_POST['Submit']) )
{
	$c = 0; // lk - where is this being used?
	$ty = $_FILES['imgfile']['type'];
	$pieces = explode("/", $ty); // lk - what is the 'pieces[]' array used for? maybe ( pieces[0] == 'image' ) ?
	
	if ( ($ty == 'image/jpeg') || ($ty == 'image/pjpeg') || ($ty == 'image/gif') || ($ty == 'image/png') )
	{
		$dbo->insert("INSERT INTO tblpromographics(sdescription) VALUES ('image')",1);
		$rm = $dbo->getrow("SELECT * FROM tblpromographics ORDER BY npromographic_id DESC");
		
		$imgfile = $_FILES['imgfile']['tmp_name'];
		
		if ( $imgfile != '' )
		{
			copy($imgfile, '../promotional_pic/' . $rm['nPromoGraphic_ID'] . '.jpg');
		}
		
		header("location:promotional_graphics.php?act=adsus");
	}
	else
	{
		header("location:promotional_graphics.php?act=a&im=1");
	}}

?>

<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<?php include('inc-head.php') ?>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once('affiliateleft.php'); ?></td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;"  valign="top" width="100%">
			<form name="frm" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>?act=a" enctype="multipart/form-data">
				<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<td class="navRow1" nowrap="nowrap">Add Promotional Graphics </td>
						<td width="100%" align="left">&nbsp;</td>
					</tr>
				</table>
				
				<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
					<tr>
						<td class="gridHeader" colspan="2"> Add  Promotional Graphic</td>
					</tr>
					<tr>
						<td width="81" valign="top" nowrap="nowrap" class="gridLabels2">Graphic  <font color="Red"> *</font></td>
						<td width="851" valign="middle" class="gridRow2">
							<input name="imgfile" type="file" class="submit" size="45" />
							<span class="red"><?php if ($_GET['im'] == 1) { echo "[ Please upload JPG / GIF format images ]"; } ?></span>
						</td>
					</tr>
					<tr>
						<td class="gridFooter" colspan="2"><input class="inputSubmit" name="Submit" value="Submit" type="submit" /></td>
					</tr>
				</table>
			</form>
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>
	</body>
</html>