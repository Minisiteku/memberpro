<?php
	include_once('../conn.php');
	include_once('../functions.php');	
?>
<?php
if(isset($_POST['Add']))
{
	$sql="SELECT sEmail,sForename,sSurname from tblusers where nUser_ID='".$dbo->format($_POST['suggestionsmHidden'])."'";
	$rs=$dbo->select($sql);
	if(!empty($rs))
	{
		$row = $dbo->getobj($rs);
		$memberEmail = $row->sEmail;
		$sForename = $row->sForename;
		$sSurname = $row->sSurname;
	}
	
	$sItemName = $dbo->format($_POST['sItemName']);
	
	$sql="INSERT INTO tblaffiliatepayments (
		nCommission, 
		nDate, 
		nDatePaid, 
		sPaymentStatus, 
		nAffiliate_ID, 
		sUserForename, 
		sUserSurname, 
		sUserEmail, 
		nMemberJoinDate, 
		sItemName, 
		sTransactionNumber
	) VALUES (
		'".$dbo->format($_POST['nCommission'])."',
		'". date('Ymd') ."',
		'0',
		'',
		'".$dbo->format($_POST['suggestionsHidden'])."',
		'".$sForename."',
		'".$sSurname."',
		'".$memberEmail."',
		'".$_POST['nMemberJoinYear'].$_POST['nMemberJoinMonth'].$_POST['nMemberJoinDay']."',
		'".$sItemName."',
		'".$dbo->format($_POST['nTransactionNumber']) . "'
	)";

	if($dbo->insert($sql)){
		$message = 'The new commission was added.';
		$type = 'msg';
		
		}
	else{$message = 'There was an error adding the commission:<br />'.$dbo->error;
		$type = 'err';}
	
	header("Location: unpaid_commissions_add.php?".$type."=".$message);exit;
	}
?>
<html><head><title><?php echo $admintitle; ?></title>
<?php include ('inc-head.php')?>
<link type="text/css" rel="stylesheet" href="../common/css/jqueryui/redmond/jquery-ui-1.8.24.custom.css">
<script language="javascript" src="../js/jquery-ui-1.8.24.custom.min.js"></script>
<script type="text/javascript">
$(function() {
	
	
	$( "#tx_date" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '1970:2032',changeYear: true});
	$( "#level_exp_date" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '1970:2032',changeYear: true});
	
});


function lookup(inputString,file,suggestions,autosuggestionlist) {
    if(inputString.length == 0) {
        // Hide the suggestion box.
        $(suggestions).hide();
        
    } else {
        $.post('ajax/'+file, {queryString: ""+inputString+""}, function(data){
            if(data.length >0) {
                $(suggestions).show();
                $(autosuggestionlist).html(data);
            }
        });
    }
} // lookup

function fill(thisValue,id,suggestions,thisValueId) {
    $(id).val(thisValue);
    $(suggestions+'Hidden').val(thisValueId);
    $(suggestions).hide();
}
function getUserLevels(tx_uid,txn){
	
	var URL = 'ajax/add_transaction.php?query=get_levels_match_txn&tx_uid='+tx_uid+'&txn='+txn;
	var HTML;
	$.ajax({
        type:"GET",
        url: URL,
        contentType:"application/x-www-form-urlencoded; charset=utf-8",
        dataType:"html",
        async:false,    
        success:function(data){
            HTML = data
			console.log(mydata);
			//alert(data);
			
        },
        error:function(data){ //After it fails it goes into here

        }
    });
	
	return HTML;
	}
function show_apply_payment(ele){
	
	if(ele.value == 'new'){
		document.getElementById('existing_level').style.display = 'none';
		document.getElementById('new_level').style.display = 'inline';
	}
	if(ele.value == 'existing'){
		
		var user_id;
		user_id = document.getElementById('suggestionsmHidden').value;
		var txn = document.getElementById('txn').value;
		
		if(!txn){alert('You Must First Enter A Transaction Number.');return;}
		
		if(!user_id){alert('You Must First Choose A Member.');return;}
		
		document.getElementById('existing_level').style.display = 'inline';
		document.getElementById('new_level').style.display = 'none';
		
		//var html;
		HTML = getUserLevels(user_id,txn);
		
		document.getElementById('existing_level').innerHTML = HTML;
		plan_name = document.getElementById('plan_name').value;
		plan_id = document.getElementById('plan_id').value;
		
		document.getElementById('use_plan').innerHTML = plan_name+'<input type="hidden" name="use_plan_id" id="use_plan_id" value="'+plan_id+'" />';
	}
	
}
function updateLevelInfo(data){
	alert(data);
	
	
	
	}

               
</script>

<style type="text/css">

.suggestionsBox {
    position: absolute;
    left: 400px;
    margin: 10px 0px 0px 0px;
    width: 250px;
    background-color: #212427;
    -moz-border-radius: 7px;
    -webkit-border-radius: 7px;
    border: 2px solid #000;
    color: #fff;
}

.suggestionList {
    margin: 0px;
    padding: 5px;
}

.suggestionList li {
    margin: 0px 0px 5px 0px;
    padding: 3px;
    cursor: pointer;
}

.suggestionList li:hover {
    background-color: #659CD8;
}
</style>


</head>


<body leftmargin="0" topmargin="0" rightmargin="0">

<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
<tr>
	<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">&nbsp;</td>
	<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">

	<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td class="navRow1" nowrap="nowrap" width="30%"> Transaction Management-  Add Transaction</td>
	</tr>
	</table>
	
	<?php echo isset($message) ? $message : '' ?>

	<form name="fAddCommission" action="unpaid_commissions_add.php?action=add" method="post" id="form">
	<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
	<tr>
	  <td colspan="2" class="gridheader">Transaction Details</td>
	  </tr>
	<tr>
	  <td width="20%" class="gridrow1">Transaction Type<font color="Red">* </font></td>
	  <td width="80%" class="gridrow1"><select name="tx_processor" id="tx_processor">
	    <?php
	  	// Build Pay Processor Select List ...
		// Transaction records processor name, not id.
		$sql = "SELECT sProcessorName,nPaymentProcessor_ID FROM tblpaymentprocessors WHERE 1;";
		$res1 = $dbo->select($sql);
		
		if($dbo->nr($res1)){
			while($obj = $dbo->getobj($res1)){
				?>
	    <option value="<?php echo $obj->nPaymentProcessor_ID ?>"><?php echo $obj->sProcessorName ?></option>
	    <?php
				}
		}
	  
	  
	  
	  ?>
	    </select>
&nbsp;
<select name="tx_type" id="tx_type">
  <option value="1" selected>Sale</option>
  <option value="2">Refund</option>
</select></td>
	  </tr>
	<tr>
	  <td class="gridrow1">Transaction Date </td>
	  <td class="gridrow1"><input type="text" name="tx_date" id="tx_date"></td>
	  </tr>
    <tr>
      <td class="gridrow1">Transaction Amount <font color="Red"> *</font></td>
      <td class="gridRow1"><input type="text" name="nCommission2"  class="number required"> 
        (ex. 97.00)</td>
    </tr>
    <tr>
      <td class="gridrow1">Transaction Number <font color="Red"> *</font></td>
      <td class="gridRow1"><input name="txn" type="text"  class="required" id="txn"></td>
    </tr>
    </table>
    <table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
    <tr>
      <td colspan="2" class="gridheader">Member / Customer</td>
      </tr>	
	<tr>
	  <td class="gridrow1">Member Name <font color="Red"> *</font></td><td class="gridRow1">	
	  <div>
	    <div>	    	 
	      <input id="mem" name="mem" onKeyUp="lookup(this.value,'mem.php','#suggestionsm','#autoSuggestionsListm');" type="text"  class="required" />		
	      <input type="hidden" id="suggestionsmHidden" name="suggestionsmHidden" />
	      </div>          
	    <div class="suggestionsBox" id="suggestionsm" style="display: none;">
	      <img src="images/upArrow.png" style="position: relative; top: -12px; left: 30px" alt="upArrow" />	
	      <div class="suggestionList" id="autoSuggestionsListm"></div>
	      </div>
	    
	    </div>	
	  </td></tr>
      </table>
      <table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
	<tr>
	  <td colspan="2" class="gridheader">Membership Level / Product</td>
	  </tr>
	<tr>
	  <td class="gridrow1">Apply Payment Towards</td>
	  <td class="gridrow1"><p>
	    <label>
	      <input type="radio" name="apply_payment_to" value="new" id="apply_payment_to_0" onClick="show_apply_payment(this)">
	      New Membership</label>
	    <span id="new_level" style="display:inline"> --> <?php 
		$sql="SELECT sLevel FROM tblmembershiplevels ORDER BY sLevel ";
		
		$rs=$dbo->select($sql);
		?>
        <select name="sItemName">
          <?php if(!empty($rs))while($row=$dbo->getobj($rs))
			echo "<option value='".$row->sLevel."'>".$row->sLevel."</option>";
				
	?>
        </select>
        </span><br>
	    <label>
	      <input type="radio" name="apply_payment_to" value="existing" id="apply_payment_to_1" onClick="show_apply_payment(this)">
	      Existing membership</label>
	    <span id="existing_level" style="display:none;"><?php 
		$sql="SELECT sLevel FROM tblmembershiplevels ORDER BY sLevel ";
		
		$rs=$dbo->select($sql);
		?>
        <select name="sItemName">
          <?php if(!empty($rs))while($row=$dbo->getobj($rs))
			echo "<option value='".$row->sLevel."'>".$row->sLevel."</option>";
				
	?>
        </select></span>
	    <p><br>
	      </p></td>
	  </tr>
	<tr>
	  <td class="gridrow1">Using Payment Plan</td>
	  <td class="gridrow1"><span id="use_plan"><select name="tx_payment_plan" id="tx_payment_plan">
	    </select></span></td>
	  </tr>
	<tr>
	  <td class="gridrow1">Join/Renewal Date <font color="Red"> *</font></td>
	  <td class="gridrow1"><!-- <select name="nMemberJoinDay">
	    <?php
			for ($i=1; $i<=31; $i++) {
				echo '<option value="' .sprintf("%02d", $i) . '">' .  sprintf("%02d", $i) . '</option>';
			}
		?>
	    </select>
	    <select name="nMemberJoinMonth">
	      <?php
			for ($i=1; $i<=12; $i++) {
				echo '<option value="' .sprintf("%02d", $i) . '">' . date('M',mktime(0,0,0,$i,1,2000)) . '</option>';
			}
		?>
	      </select>
	    <select name="nMemberJoinYear">
	      <?php
			for ($i=0; $i<5; $i++) {
				echo '<option value="' . date('Y',mktime(0,0,0,1,1,date('Y')-$i)) . '">' . date('Y',mktime(0,0,0,1,1,date('Y')-$i)) . '</option>';
			}
		?>
	      </select> -->
	    <input type="text" name="level_exp_date" id="level_exp_date"></td>
	  </tr>
	<tr><td class="gridFooter" colspan="2"><input type="submit" value="Add" name="Add"></td></tr>
	</table>
	</form>
	
	</td>
</tr>
</table>

<?php include_once('b.php'); ?>
<script type="text/javascript">		
		$(document).ready(function()
		{
			$("#form").validate(
			{

				onkeyup: false, 
 				rules: {
							
						nCommission: 
									{
									    max:100000
									}
 						}
 					
			
		});
		});
</script>
</body>
</html>