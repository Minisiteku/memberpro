<?php
include_once('../conn.php');
include_once('../functions.php');

// Get total number of records
$sql2 = "SELECT COUNT(*) AS nCount FROM tbladminlogins ";
$number = $dbo->getval($sql2); // Number of records
// Setup Options for Members per Page listing
$aMPP = array('5', '10', '15', '20', '25', '50', '100');
$mpp = (empty($_GET['mpp'])) ? 25 : $_GET['mpp'];			
			// Start Paging
			/*********************************************************/
			include_once('paging.php');
			$objPaging = new Paging();
			
			$start = (empty($_GET['start'])) ? 0 : $_GET['start'];	
			unset($_GET['start']);
		 	
		 	$objPaging->Total_Records_Per_Page = $mpp; 
		 	$objPaging->Total_Records = $number;
		 	$index = $start ;
		 	$indexupto = $index + $objPaging->Total_Records_Per_Page;	 	
		 	$objPaging->prepare_ParameterString($_GET);
		 	$objPaging->set_Start_Item($indexupto); 	 		 	
		 	$objPaging->Has_First_Last = true;	
		 	$navigator = $objPaging->Create_Paging();
		 	$pageinfo = $objPaging->get_PageInfo();	 	
		  	$counter = 0;  
			$sql .= " LIMIT ".$objPaging->Total_Records_Per_Page." OFFSET ".$index;
			/*********************************************************/
//die($sql);
?>

<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<?php include ('inc-head.php')?>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
			<?php include_once('toolsleft.php'); ?>
		</td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			<form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="form">
				<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<td width="10%" nowrap="nowrap" class="navRow1"> Admin Login Log </td>
					</tr>
				</table>
				
				<?php echo isset($message) ? $message : '' ?>
				<table class="gridTable" cellpadding="0" cellspacing="1" width="54%">
				  <tr>
				    <td colspan="4" class="gridFooter">
                    
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" >
				      <tr>
				        <td style='text-align:left'><?php echo $navigator; 	?></td>
				        <td style='text-align:right; padding-right:10px'> Page
				          <?php echo $pageinfo ?></td>
			          </tr>
				      </table></td>
			      </tr>
				  <tr>
				    <!-- FIRST NAME COLUMN -->
				    <td width="122" class="gridHeader"><a href="manage_members.php<?php echo $qs?>&sort=fname&type=desc" class="bluenave">Admin User</a></td>
				    <!-- LAST NAME COLUMN -->
				    <td width="193" align="left" nowrap="nowrap" class="gridHeader">Date / Time</td>
				    <!-- EMAIL COLUMN -->
				    <td width="171" align="left" nowrap="nowrap" class="gridHeader">Ip Address</td>
				    <td width="172" align="left" nowrap="nowrap" class="gridHeader">Browser</td>
			      </tr>
				  <?php 
			$sql = "
SELECT tbladminlogins. * , tblusers.sEmail
FROM tbladminlogins
LEFT JOIN tblusers ON tblusers.nUser_ID = tbladminlogins.nUser_ID
ORDER BY `tbladminlogins`.`nTimestamp` DESC"
;

$result = $dbo->select($sql);
					while ($row = $dbo->getobj($result)){
				?>
				  <!-- MEMBER LISTING -->
				  <tr>
				    <td class="gridrow2"><a class="bluenave" href="view_member.php?id=<?php echo $row->nUser_ID; ?>" title="Member Details"><strong>
				      <?php echo $row->sEmail; ?>
				      </strong></a></td>
				    <td class="gridrow2" align="left"><?php echo date("F j, Y, g:i a",$row->nTimestamp); ?>
				      &nbsp; </td>
				    <td align="left" class="gridrow2"><a href='http://www.ip-tracker.org/locator/ip-lookup.php?ip=<?php echo $row->sIp ?>' target="_blank"><?php echo $row->sIp ?></a></td>
				    <td align="left" class="gridrow2"><?php echo $row->sBrowser ?></td>
			      </tr>
				  <?php 
					}
				
				?>
				  <tr>
				    <td colspan="4" class="gridFooter"><table width="100%" border="0" cellspacing="0" cellpadding="0">
				      <tr>
				        <td style='text-align:left'><?php echo $navigator; 	?></td>
				        <td style='text-align:right; padding-right:10px'> Page
				          <?php echo $pageinfo ?></td>
			          </tr>
				      </table></td>
			      </tr>
			  </table>
			</form>
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>
	</body>
</html>