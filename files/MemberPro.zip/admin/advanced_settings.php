<?php
	include_once('../conn.php');
	include_once('../functions.php');
	include_once('../includes/functions-time.php');
	// Check for pear
	
	$use_mce = get_option('use_mce');
	$usepath = get_option('protected_usepath');
	
	if ( isset($_POST['Update']) ){
		if($use_mce != $_POST['use_mce'])  update_option('use_mce',$_POST['use_mce']); $use_mce = $_POST['use_mce'];
		
		if($_POST['usepath'] && $_POST['usepath'] == '1'){
			if(is_option('protected_usepath')){update_option('protected_usepath',$_POST['usepath']);}
			else{add_option('protected_usepath',$_POST['usepath']);}
			
		}
		else{
			if(is_option('protected_usepath')){remove_option('protected_usepath');}
		}
		
		// Error checking on smtp settings
		$err = 0;
	}

?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php include ('inc-head.php')?>
        <script type="text/javascript">
        	function toggleSmtp(radio){
				
				if(radio.value == 'smtp'){
					document.getElementById('smtp_settings').style.display = 'block'
				}
				else{
					document.getElementById('smtp_settings').style.display = 'none'
				}
			}
        </script>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
			<?php include_once('settingsleft.php'); ?>
		</td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			<form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="form">
				<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<td width="10%" nowrap="nowrap" class="navRow2"> Advanced Settings</td>
					</tr>
				</table>
				
				<?php echo isset($message) ? $message : '' ?>
				
			  <table class="gridtable" cellpadding="0" cellspacing="1" width="100%">
				  <tr>
				    <td colspan="2"  class="gridheader">Editor Options</td>
			    </tr>
				  <tr>
				    <td class="gridrow2" width="184">Use TinyMce Editor<font style="color:red">&nbsp;</font></td>
				    <td width="1028" class="gridrow2"><p>
				      <label>
				        <input name="use_mce" type="radio" id="use_mce_0" value="1" <?php echo ($use_mce == '1') ? ' checked="CHECKED"' : '' ?> />
				        Yes</label>
				      &nbsp;
				      <label>
				        <input type="radio" name="use_mce" value="0" id="use_mce_1" <?php echo ($use_mce == '0') ? ' checked="CHECKED"' : '' ?> />
				        No</label>
				      <br>
			        </p></td>
			    </tr>
				  <tr>
				    <td colspan="2" class="gridrow2">Video And File Protection</td>
			    </tr>
				  <tr>
				    <td class="gridrow2">Location Type</td>
				    <td width="1028" class="gridrow2"><p>
				      <label>
				        <input name="usepath" type="radio" id="usepath_0" value="0" <?php if(!is_option('protected_usepath'))echo 'checked="CHECKED"'; ?>>
				        Site Url</label>
				      &nbsp;
				      <label>
				        <input type="radio" name="usepath" value="1" id="usepath_1" <?php if(is_option('protected_usepath') || get_option('protected_usepath') == '1')echo 'checked="CHECKED"'; ?>>
				        Site Path</label>
				      <br>
			        </p></td>
		        </tr>
				  <tr>
				    <td colspan="2" class="gridheader"><table width="100%" border="0" cellspacing="0" cellpadding="0">
				      <tr>
				        <td valign="top"><input type="submit" name="Update" value="Save Changes" class="inputSubmitb" /></td>
			          </tr>
				      </table></td>
			    </tr>
			  </table>
			</form>
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>

	</body>
</html>