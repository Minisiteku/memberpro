<?php
include_once('../conn.php');
include_once('../functions.php');

// Validate amounts entered

if ( isset($_POST['Update']) )
{
	$c = 0;
	
	// VALIDATION FOR PERCENTAGE
	
	if (isset($_POST['nPercentage']) && $_POST['nPercentage'] > 100)
	{
		$c++;
		$gpnp1 = 1;
	}
	
	if (isset($_POST['nPercentage']) && !is_numeric($_POST['nPercentage']))
	{
		$c++;
		$gpnp2 = 1;
	}
	
	if ($_POST['paypal'] == "" && $_POST['check'] == '')
	{
		$c++;
		$op = 1;
	}
	if (!is_numeric($_POST['nCookieExpiry']) && $_POST['nCookieExpiry'] != '' && !$_POST['nCookieNeverExpires']) {
		$c++;
		$ce = 1;
	}
	
	if ($c == 0)
	{
		$chkPaypal = ($_POST['paypal'] == 1) ? 1 : 0;
		$chkCheck = ($_POST['check'] == 1) ? 1 : 0;
		$chkHideAffiliateProgram = ($_POST['hideAffiliateProgram'] == 1) ? 1 : 0;
		$chkHideCustomerData = ($_POST['hideCustomerData'] == 1) ? 1 : 0;
		$chkAutoEnroll = ($_POST['nAutoEnroll'] == 1) ? 1 : 0;
		
		$sql = "UPDATE tblaffiliatesettings SET 
		scommissiontype='Percentage', 
		npercentage=" . $dbo->format($_POST['nPercentage']) . ", 
		npaypal=$chkPaypal, 
		ncheck=$chkCheck,
		nHideAffiliateProgram=$chkHideAffiliateProgram,
		nHideCustomerData=$chkHideCustomerData,
		nAutoEnroll = $chkAutoEnroll";
		
		$dbo->update($sql);
		
		$sql = "UPDATE tblsitesettings SET 		
					ncookieexpiry='".$dbo->format($_POST['nCookieExpiry'])."', 
					ncookieneverexpires='".$dbo->format($_POST['nCookieNeverExpires'])."'";
		$dbo->update($sql);

		// Deactivate / Reactivate the affiliates page
		$sqlTakeAffiliateFolderID="SELECT nDirectory_ID FROM tbldirectories WHERE sDirectoryName = 'Affiliates'";		
		$rsTakeAffiliateFolderID = $dbo->select($sqlTakeAffiliateFolderID);
		if(!empty($rsTakeAffiliateFolderID)) {
			$rwTakeAffiliateFolderID = $dbo->getobj($rsTakeAffiliateFolderID);
		}		
		
		if(isset($_POST['hideAffiliateProgram'])) {
			$sql = "UPDATE tblpages SET nDisplay = 0 WHERE nDirectory_ID = $rwTakeAffiliateFolderID->nDirectory_ID";
		} else {
			$sql = "UPDATE tblpages SET nDisplay = 1 WHERE nDirectory_ID = $rwTakeAffiliateFolderID->nDirectory_ID";
		}			
	
		$dbo->update($sql);
		$message = '<p class="success">Affiliate settings have been updated.</p>';
	}
}

$objAffiliateSettings = $dbo->getrow("SELECT * FROM tblaffiliatesettings");
$rw = $dbo->getobject("SELECT * FROM tblsitesettings");
?>

<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php include('inc-head.php') ?>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" rowspan="2" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
			<?php include_once('affiliateleft.php'); ?>
		</td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td class="navRow1" nowrap="nowrap">Affiliate Options</td>
				</tr>
			</table>
			
			<?php echo isset($message) ? $message : '' ?>
			
		</td>
	</tr>
	<tr>
		<td style="padding-left: 8px; padding-right: 8px; " valign="top" width="100%">
			<form action="affiliate_management.php" name="form" method="post">				
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td valign="top">
							<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
								<tr>
									<td valign="top" class="gridHeader">
										<b>Affiliate Program</b>
									</td>
								</tr>
								<tr>
									<td class="gridrow2">
										<label for="hideAffiliateProgram" >Disable Affiliate Program:</label>
										<input type="checkbox" value="1" name="hideAffiliateProgram" id="hideAffiliateProgram" <?php if ($objAffiliateSettings['nHideAffiliateProgram'] == 1) { echo 'checked="checked"'; } ?> style="margin-left:3px;margin-bottom:0px" />
									</td>
								</tr>
								<tr>
								  <td class="gridrow2">Auto Enroll Members: 
								    <input name="nAutoEnroll" type="checkbox" id="nAutoEnroll" value="1" <?php if ($objAffiliateSettings['nAutoEnroll'] == 1) { echo 'checked="checked"'; } ?> >
							      <label for="nAutoEnroll"></label></td>
							  </tr>
<!-- added ability to Hide Customers Name and Email Address from Commisions Repport -->
								<tr>
									<td class="gridrow2">
										<label for="hideCustomerData" >Hide Member's Email Address from Affiliate Commissions and Referrals Report:</label>
										<input type="checkbox" value="1" name="hideCustomerData" id="hideCustomerData" <?php if ($objAffiliateSettings['nHideCustomerData'] == 1) { echo 'checked="checked"'; } ?> style="margin-left:3px;margin-bottom:0px" />
									</td>
								</tr>
								<tr>
								  <td class="gridrow2">Enable Export Of Affiliate Referrals 
								    <input name="export_affiliates" type="checkbox" id="export_affiliates" value="1" disabled>
							      <label for="export_affiliates">Coming Soon ...</label></td>
							  </tr>
								<tr>
									<td class="gridrow2">Affiliate Cookie Expiry: &nbsp;
										<?php 
											if($_POST['nCookieNeverExpires'] == 1 || $rw->nCookieNeverExpires == 1){ 
												$checked =  "checked";
												$disabled = "disabled";
											} 
										?>								  
								  <input <?php echo $disabled?> name="nCookieExpiry" id="nCookieExpiry" type="text" value="<?php echo ($_POST['nCookieExpiry'] ? $_POST['nCookieExpiry'] : $rw->nCookieExpiry);?>" size="10" />
									Days
								    <input  <?php echo $checked?> id="nCookieNeverExpires" name="nCookieNeverExpires" type="checkbox" id="nCookieNeverExpires" value="1" onClick="if(this.checked==true){document.getElementById('nCookieExpiry').value=90;document.getElementById('nCookieExpiry').disabled=true}else{ document.getElementById('nCookieExpiry').disabled=false}"/>
								    <label for="nCookieNeverExpires">Cookie Never Expires</label> 
									<?php if ($ce == 1) { ?><span class="red">[ INVALID ] (Numbers only.)</span><?php } ?>
									</td>
								</tr>								
							</table>
							
							<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
						
								<tr>
									<td class="gridHeader">
										<b>Percentage of each sale <font color="Red"> *</font></b>
									</td>
								</tr>
								<tr>
									<td class="gridrow2">
										<input name="nPercentage" type="text" size="10" value="<?php echo $objAffiliateSettings['nPercentage']; ?>" />
%										<?php if ($gpnp1 == 1) { echo '<span class="error">[ Percentage value must not exceed 100 ]</span><br />'; } ?>
										<?php if ($gpnp2 == 1) { echo '<span class="error">[ Only numeric values are allowed ]</span>'; } ?>
									</td>
								</tr>
							</table>
							
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td valign="top">
										<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
											<tr>
												<td class="gridHeader">
													<b> Payment Methods  <font color="Red"> *</font><?php if ($op == 1) { echo '<span class="error">[ Please select a payment method ]</span>'; } ?></b>
												</td>
											</tr>
											<tr>
												<td class="gridrow2">
													<input type="checkbox" name="paypal" value="1" <?php if ($objAffiliateSettings['nPaypal'] == 1) { echo 'checked="checked"'; } ?> />
													Paypal
												</td>
											</tr>
											<tr>
												<td class="gridrow2">
													<input type="checkbox" name="check" value="1" <?php if ($objAffiliateSettings['nCheck'] == 1) { echo 'checked="checked"'; } ?> />
													Check
												</td>
											</tr>
											<tr>
												<td class="gridFooter">
													<table width="100%" border="0" cellspacing="0" cellpadding="0">
														<tr>
															<td width="85%" valign="top">&nbsp;</td>
															<td width="15%" align="right" valign="top">
																<input type="submit" name="Update" value="Save Changes" class="inputSubmitb" />
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							
						</td>
					</tr>
				</table>
			</form>
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>
	</body>
</html>