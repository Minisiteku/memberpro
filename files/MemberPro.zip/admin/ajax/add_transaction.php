<?php
	include_once('../../conn.php');
	include_once('../../functions.php');
	
	
	if($_GET['query'] == 'get_levels_match_txn'){
				$txn = $_GET['txn'];
		$userid = $_GET['tx_uid'];
	
		$sql = "SELECT tbluserlevels.*, tblmembershiplevels.sLevel,tblpaymentplans.sPlanName FROM tbluserlevels INNER JOIN tblmembershiplevels ON tblmembershiplevels.nLevel_ID = tbluserlevels.nLevel_ID INNER JOIN tblpaymentplans ON tblpaymentplans.nPaymentPlan_ID = tbluserlevels.nPaymentPlan_ID WHERE tbluserlevels.nUser_ID = '{$dbo->format($userid)}' ";
		$res = $dbo->select($sql);
		$select = '<select>';
		//die($sql);
		if($dbo->nr($res)){			
			while($row = $dbo->getassoc($res)){
				// If we have a transaction number match, return that level only.
				if($row['sTransactionNumber'] == $txn){$select .='<option value="'.$row['nLevel_ID'].'" >Level '.$row['sLevelName'].' </option>';}
				else{
					
					$select .='<option value="'.$row['nLevel_ID'].'" >'.$row['sLevel'].' </option>';
					$planid = '<input type="hidden" id="plan_id" name="plan_id" value="'.$row['nPaymentPlan_ID'].'" />';
					$planname = '<input type="hidden" id="plan_name" name="plan_name" value="'.$row['sPlanName'].'" />';
					
					
					
					}
			}
			$select .='</select>';
				
		}
		else{die('user has no levels');}
		
		echo $select.$planid.$planname;
		
	}
	
	
	
?>