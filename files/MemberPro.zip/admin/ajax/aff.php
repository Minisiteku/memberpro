<?php
	include_once('../../conn.php');
	include_once('../../functions.php');	
	

		// Is there a posted query string?
		if(isset($_POST['queryString'])) {
			$queryString =  $_POST['queryString'];
			
			// Is the string length greater than 0?
			
			if(strlen($queryString) >0) {
				// Run the query: We use LIKE '$queryString%'
				// The percentage sign is a wild-card, in my example of countries it works like this...
				// $queryString = 'Uni';
				// Returned data = 'United States, United Kindom';
				
				// YOU NEED TO ALTER THE QUERY TO MATCH YOUR DATABASE.
				// eg: SELECT yourColumnName FROM yourTable WHERE yourColumnName LIKE '$queryString%' LIMIT 10
				$sql = "SELECT sForename,sSurname,nUser_ID FROM tblusers where nActive='1' and nAffiliate='1' and sForename LIKE '$queryString%' and nUser_ID!='1'";
				$rs = $dbo->select($sql);
		
				if(!empty($rs)) {
					// While there are results loop through them - fetching an Object (i like PHP5 btw!).
					while ($row = $dbo->getobj($rs)) {
						// Format the results, im using <li> for the list, you can change it.
						// The onClick function fills the textbox with the result.
						
						// YOU MUST CHANGE: $result->value to $result->your_colum
	         			echo '<li onClick="fill(\''.$row->sForename." ".$row->sSurname .'\',\'#aff\',\'#suggestions\',\''.$row->nUser_ID.'\');">'.$row->sForename." ".$row->sSurname .'</li>';
	         		}
				} else {
					echo '<li>No results found</li>';
				}
			} else {
				// Dont do anything.
			} // There is a queryString.
		} else {
			echo 'There should be no direct access to this script!';
		}
	
?>