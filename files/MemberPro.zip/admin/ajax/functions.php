<?php
	//error_reporting(0);
	
	// This is a centralized ajax function file, used to process all ajax queries from admin control.
	
	// THis is used to update the current server time section in the admin control panel.
	// returns text time version.
	if($_GET['act'] =='server_time'){
		
		@session_start();
		@date_default_timezone_set($_SESSION['options']['timezone']);
		die( date("F j, Y, g:i a") );
	}
	
	// This is used to manage the admin session timeouts.
	// returns json object
	if($_GET['act'] == 'keep-alive'){
		session_start();
		if(isset($_GET['v']) &&  $_GET['v'] == 'false'){
			// This var is passed as url encoded
			$refpage = urlencode($_GET['redirect']);
			unset($_SESSION['admin']);
			if($_GET['type'] == 'expired') $redirect = 'index.php?redirect='.$refpage.'&warn=Your Session Has Expired Due To Inactivity.<br /> Please Login Again.';
			else $redirect = 'index.php?redirect='.$refpage.'&msg=You have successfully logged out!';
			echo json_encode($redirect);	
	}
		else{
			
			include_once('../../conn.php');
			include_once('../../functions.php');
			$res = new stdClass();
			$res->lastActivity = $_SESSION['admin']['LAST_ACTIVITY'];
			$res->maxIdle = intval(get_option('security_timeout')*60);
			echo json_encode($res);
		}
		
	}
	
	// THis is used to sent a test email to the admin from the broadcast area of the script.
	if($_GET['act'] =='test_email'){
		
		include_once('../../conn.php');
		include_once('../../functions.php');
		
		$result = new stdClass();
		$result->error = false;
		$objAdmin = get_user_by_id($_SESSION['admin']['nUser_ID']);
		
		$to = $objAdmin->sEmail;
		
		$subject = $_POST['subject'];
		$textBody = $_POST['txtBody'];
		$htmlBody = stripslashes($_POST['htmlBody']);
					
		// Subject
		$subject = str_replace("[[FIRSTNAME]]", $objAdmin->sForename, $subject);
					
		// Message
			
		// Find - Replace [MERGE CODES]
		$find = array('[[FIRSTNAME]]', '[[LAST NAME]]', '[[PASSWORD]]', '[[EMAIL]]','[[JOINDATE]]', '[[EXPIREDATE]]', '[[USERNAME]]');
		$repl = array($objAdmin->sForename, $objAdmin->sSurname, $objAdmin->sPassword, $objAdmin->sEmail,date('m/d/Y', strtotime($member->nJoinDate)), date('m/d/Y', strtotime($objAdmin->nDateExpires)), $objAdmin->sEmail);
		
		$textBody = str_replace($find, $repl, $textBody);
		$htmlBody = str_replace($find, $repl, $htmlBody);
			
		// Wrap lines longer than 70 characters
		$textBody = wordwrap($textBody, 70);
		
		$textBody .= $chkSsettings->sEmailFooter.getCanSpam($objAdmin->nUser_ID).getPoweredByEmail();
		$htmlBody .= $chkSsettings->sHtmlEmailFooter.stripslashes(getCanSpam($objAdmin->nUser_ID,'html')).getPoweredByEmail('html');
		
		$mailError	= 0;
		// Instead of sending out the mail now, we store it in the database.
		// Check Mail Method
		if(get_option('mail_method') == 'php'){
			$from = $chkSsettings->sSupportEmail;
			$mailResponse = multipart_email($to, $from, $subject, $htmlBody, $textBody);
			
			if($mailResponse === FALSE) {$result->error = true; $result->message = 'Error: Failed To Send Email to '.$objAdmin->sEmail.' ';}
			else $result->message = 'Success: Test Email Sent To '.$objAdmin->sEmail.' ';	
		}
		else{
						
			// New SMTP
			// Call PEARMAIL
			require_once "Mail.php";
			require_once('Mail/mime.php');
			
			$host = get_option('smtp_host');
			$port = get_option('smtp_port');
			$username = get_option('smtp_user');
			$password = get_option('smtp_password');
			$from = "$sSitename <".$chkSsettings->sSupportEmail.">";
			$headers = array ('From' => $from,'To' => $to,'Subject' => $subject);
			
			// Creating the Mime message
			$mime = new Mail_mime();
					
					// Setting the body of the email
			$mime->setTXTBody($textBody);
			$mime->setHTMLBody($htmlBody);
			$body = $mime->get();
			$headers = $mime->headers($headers);
			
					
			$smtp = @Mail::factory('smtp',array ('host' => $host,'port' => $port,'auth' => true,'username' => $username,'password' => $password));
						
			$mail = @$smtp->send($to, $headers, $body);
			 
			if (@PEAR::isError($mail)) {
				$result->error = true;
				$code = $mail->getCode();
				if($code == '10001') {$result->message = 'Connection Error: Check your SMTP host/port details and try again.';}
				elseif($code == '10002') {$result->message = 'Authentication Error: Check your SMTP settings and try again.';}
				else{$result->message = 'Unknown Error: SMTP Server';}
			}	
			else $result->message = 'Success: Test Email Sent To '.$objAdmin->sEmail.' ';
		}
		echo json_encode($result);
		
	}
	
	if($_GET['act'] =='check_itemnumber'){
		
		$sItemNumber = $dbo->format(trim($_GET['sItemNumber']));

		if(isset($_GET['nPaymentPlan_ID']) && is_numeric($_GET['nPaymentPlan_ID'])) {
	
			$nPaymentPlan_ID = $dbo->format($_GET['nPaymentPlan_ID']);

			$sql = "SELECT 1 FROM tblpaymentplans WHERE nPaymentProcessor_ID IN 
			(SELECT MAX(nPaymentProcessor_ID) AS nProcessor_ID FROM tblpaymentplans WHERE nPaymentPlan_ID=" . $nPaymentPlan_ID . " ) AND 
			sItemNumber = '" . $sItemNumber . "'";
		}
		elseif (isset($_SESSION['nPaymentProcessor_ID'])) {

			$sql = "SELECT 1 FROM tblpaymentplans WHERE nPaymentProcessor_ID = " . $_SESSION['nPaymentProcessor_ID'] . " 
			AND sItemNumber = '" . $sItemNumber . "'";
		} 
		else {die ("Invalid Payment Processor ID");}

		$result = $dbo->getval($sql);

		if($result !== false) echo (isset($_GET['sCurrentNum']) && $_GET['sCurrentNum'] == $sItemNumber)? 'true' : 'false';
		else echo 'true';
	}
	// Quick Start Functions ...
	if($_GET['act'] == 'qs'){
		include_once('../../conn.php');
		include_once('../../functions.php');
		$funct = $_GET['funct'];
		$step = $_GET['step'];
		
		if($funct == 'complete'){
			if(is_option('QS_'.$step)) update_option('QS_'.$step,'1');
			else add_option('QS_'.$step,'1');
			echo '<img src="images/Confirm_24x24.png" />';
		}
		if($funct == 'reset'){
			if(is_option('QS_'.$step)) remove_option('QS_'.$step);
			echo '<img src="images/Delete_24x24.png" />';
		}
		if($funct == 'hide'){
			if(!is_option('QS_hide')) add_option('QS_hide','1');
		}
		
	}
	
	if($_GET['act'] == 'broadcasts_sent'){
		include_once('../../conn.php');
		include_once('../../functions.php');
		$id = $_GET['id'];
		
		$sql = "SELECT COUNT(*) as count from tblemails WHERE nStatus = '1' AND `nBroadcast_ID` = '$id'";
		$sentCount = $dbo->getval($sql);
		echo intval($sentCount);
	}
	
	if($_GET['act'] == 'clearLicenseData'){
		
		include_once('../../conn.php');
		include_once('../../functions.php');
		
		remove_option('licenseData');
		
	}
	
	if($_GET['act'] == 'getPaymentPlansByLevel'){
		
		include_once('../../conn.php');
		include_once('../../functions.php');
		global $dbo;
		$level = $_GET['level'];
		$result = $_GET['result'];
		$plandata = array();
		$sql = "SELECT * FROM tblpaymentplans WHERE nMembershipLevel_ID = '".$level."';";
		$rs = $dbo->select($sql);
		while($row = $dbo->getassoc($rs)){
			$plandata[] = $row;
		}
		echo json_encode($plandata);	
	}
	if($_GET['act'] == 'loadMemberFiltersTable'){
		
		
		include_once('../../conn.php');
		//include_once('....//functions.php');
	
		$sql = "SELECT * FROM `tbloptions` WHERE `sName` LIKE 'mqf_%' ";
		$res = $dbo->select($sql);
		$count = 0;
		$total = $dbo->nr($res);
		ob_start();
		?>
        <table width="95%" border="0" align="center" cellpadding="0" cellspacing="1" class="gridtable">
   <tr>
        <td class="gridheader">Filter Name</td>
        <td class="gridheader">Resulting Members</td>
        <td class="gridheader">Actions</td>
      </tr>
      <tr>
      <?php
	  while($row = $dbo->getobj($res)){
	  ?>
        <td class="gridrow1"><?php echo str_replace('mqf_','',$row->sName) ?></td>
        <td class="gridrow1"><?php echo intval($dbo->num_rows($row->sValue)) ?></td>
        <td class="gridrow1"><?php 
		if($_SESSION['admin']['current_mqf_title'] == $row->sName){?>
        <a href="#" onclick="clearFilter()">Clear</a><?php }else{?>
        <a href="#" onclick="applyFilter('<?php echo $row->sName?>')">Apply</a>
        <?php } ?> | <a href="#" onclick="deleteFilter('<?php echo $row->sName ?>')">Delete</a>
        </td>
     </tr>
      
      <?php } ?>
      <tr><td colspan="3" class="gridfooter"></td></tr>
    </table>
    <?php
		$table = ob_get_clean();
		
		echo $table;
		
		
		
		
	}
	if($_GET['act'] == 'deleteFilter'){
		
		include_once('../../conn.php');
		include_once('../../functions.php');
		
		remove_option($_POST['filterName']);
	}
	if($_GET['act']  == 'saveFilter'){
		//die(var_dump($_POST));
		
		include_once('../../conn.php');
		include_once('../../functions.php');
		
		$filterConditions = array();
		$conditionAddedCount = 0;
		
		// Build Query
		
		// Select Fields
		$sql = "
		SELECT tblusers.*,
		tblaffiliates.sForename AS sAffForename,
		tblaffiliates.sSurname AS sAffSurname ";
		
		if(isset($_POST['login']) && $_POST['loginFilterCompare'] !='never'){
			$sql .=',MAX(tbluserlogins.nTimestamp) as lastLogin ';
		}
		
		// Joins
		$sql .="
		FROM tblusers 
		LEFT JOIN tblusers AS tblaffiliates ON tblusers.nAffiliate_ID = tblaffiliates.nUser_ID ";
		// Add Needed Inner Joins
		if(isset($_POST['level'])){
			// Add The Level Inner Join
			$sql .= 'INNER JOIN tbluserlevels ON tbluserlevels.nUser_ID = tblusers.nUser_ID ';
		}
		if(isset($_POST['login']) && $_POST['loginFilterCompare'] !='never'){
			$sql .= 'INNER JOIN tbluserlogins ON tbluserlogins.nUser_ID = tblusers.nUser_ID ';
		}
		
		// Where Clause
		$sql .= "WHERE ";
		// Level Filter
			// levelFilter Value (the level id)
			// Level Filter Compair
			if(isset($_POST['level'])){
				if($conditionAddedCount > 0){$sql .=' AND ';}
				$sql .= "tbluserlevels.nLevel_ID ".$_POST['levelFilterCompare']." ('".$_POST['levelFilterValue']."') ";
				$conditionAddedCount++;
			}
			if(isset($_POST['affiliate'])){
				if($conditionAddedCount > 0){$sql .=' AND ';}
				$sql .= "tblusers.nAffiliate = '".$_POST['affiliateFilterValue']."' ";
				$conditionAddedCount++;
			}
			if(isset($_POST['login'])){
				$date1 = $_POST['loginFilterValue'];
				$date2 = $_POST['loginFilterValue2'];
					
					$mdate1 = fMysqlTimestamp($chkSsettings->nDateFormat,$date1);
					$mdate2 = fMysqlTimestamp($chkSsettings->nDateFormat,$date2);
					
					$time1 = strtotime($mdate1);
					$time1a = $time1 + (60*60*24);
					$time2 = strtotime($mdate2);
					$time2a = $time2 + (60*60*24);
				
				if($conditionAddedCount > 0){$sql .=' AND ';}
				
				if($_POST['loginFilterCompare'] == '><'){
					
					$sql .= "tbluserlogins.nTimeStamp BETWEEN '$time1' AND '$time2a' ";
				}
				elseif($_POST['loginFilterCompare'] == 'never'){
					$sql .= "tblusers.nUser_ID NOT IN (SELECT nUser_ID FROM tbluserlogins) ";
				}
				elseif($_POST['loginFilterCompare'] == '>'){
					$sql .= "tbluserlogins.nTimeStamp '>' '".$time1a."' ";
				}
				elseif($_POST['loginFilterCompare'] == '<'){
					$sql .= "tbluserlogins.nTimeStamp '<' '".$time1."' ";
				}
				elseif($_POST['loginFilterCompare'] == '='){
					$sql .= "tbluserlogins.nTimeStamp BETWEEN '".$time1."' AND '".$time1a."' ";
				}
				else{}
				$conditionAddedCount++;
			}
			if(isset($_POST['emailStatus'])){
				if($conditionAddedCount > 0){$sql .=' AND ';}
				$sql .= "tblusers.nConfirmed = '".$_POST['emailStatusFilterValue']."' ";
				$conditionAddedCount++;
			}
			if(isset($_POST['optin'])){
				if($conditionAddedCount > 0){$sql .=' AND ';}
				$sql .= "tblusers.nUnsubscribe = '".$_POST['optinFilterValue']."' ";
				$conditionAddedCount++;
			}
			if(isset($_POST['join'])){
				if($conditionAddedCount > 0){$sql .=' AND ';}
				$date1 = $_POST['joinFilterValue'];
				$date2 = $_POST['joinFilterValue2'];
				
				$mdate1 = fStoreDate($chkSsettings->nDateFormat,$date1);
				$mdate2 = fStoreDate($chkSsettings->nDateFormat,$date2);
				
				if($_POST['joinFilterCompare'] == '><'){
					$sql .= "tblusers.nJoinDate BETWEEN '$mdate1' AND '$mdate2' ";
				}
				else{
					$sql .= "tblusers.nJoinDate ".$_POST['joinFilterCompare']." '$mdate1' ";
				}
				
				$conditionAddedCount++;
			}
			
			$sql .= "GROUP BY nUser_ID ";
			
			$newFilterName = $_POST['newFilterName'];
			
			//add_option('mqf_'.$newFilterName,$sql);
			
			if(!is_option('mqf_'.$newFilterName)){
				add_option('mqf_'.$newFilterName,$dbo->format($sql));
				$_SESSION['admin']['current_mqf_title'] = $newFilterName;
				$_SESSION['admin']['current_mqf_sql'] = $sql;
			}
			
	}
	if($_GET['act'] == 'loadFilter'){
		
		include_once('../../conn.php');
		include_once('../../functions.php');
		
		$filter = $_POST["loadFilter"];
		
		$query = get_option($filter);
		if($query){
			$_SESSION['admin']['current_mqf_title'] = $filter;
			$_SESSION['admin']['current_mqf_sql'] = $query;
			echo str_replace('mqf_','',$filter);
		}
		else{$err = 'Failed To Load Query Filter "'.str_replace('mqf_','',$filter).'"';}
	}
	if($_GET['act'] == 'clearFilter'){
		session_start();
		unset($_SESSION['admin']['current_mqf_title']);
		unset($_SESSION['admin']['current_mqf_sql']);
	}
	// Load Email
	if($_GET['act'] == 'loadRecentEmail'){
		include_once('../../conn.php');
		include_once('../../functions.php');
		$id = $dbo->format($_GET['id']);
		
		$sql = "SELECT * FROM tblemails where nEmail_ID = $id LIMIT 1;";
		$res = $dbo->select($sql);
		$objEmail = $dbo->getobj($res);
		
		// Sent it out.
		header('Content-Type: application/json');
		die( json_encode($objEmail));
	}
	
	
	if($_GET['act'] == 'upload_plugin'){
		// This file takes an uploaded file, moves it to the assets dir and adds it to the database<br />
		// This is done via ajax
	
		require_once('../../conn.php');
	
		// Settings
		$targetDir = '..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'plugins';
	
		$cleanupTargetDir = true; // Remove old files
		$maxFileAge = 5 * 3600; // Temp file age in seconds
	
		// 5 minutes execution time
		@set_time_limit(5 * 60);
	
		// Uncomment this one to fake upload time
		// usleep(5000);
	
		// Get parameters
		$chunk = isset($_REQUEST["chunk"]) ? intval($_REQUEST["chunk"]) : 0;
		$chunks = isset($_REQUEST["chunks"]) ? intval($_REQUEST["chunks"]) : 0;
		$fileName = isset($_REQUEST["name"]) ? $_REQUEST["name"] : '';
	
		// Clean the fileName for security reasons
		$fileName = preg_replace('/[^\w\._]+/', '_', $fileName);
	
		// Make sure the fileName is unique but only if chunking is disabled
		if (file_exists($targetDir . DIRECTORY_SEPARATOR . $fileName)) {
			$ext = strrpos($fileName, '.');
			$fileName_a = substr($fileName, 0, $ext);
			$fileName_b = substr($fileName, $ext);
	
			$count = 1;
			while (file_exists($targetDir . DIRECTORY_SEPARATOR . $fileName_a . '(' . $count . ')'. $fileName_b)) $count++;
	
			$fileName = $fileName_a . '(' . $count .')'. $fileName_b;
		}
	
		$filePath = $targetDir . DIRECTORY_SEPARATOR . $fileName;
	
		// Remove old temp files	
		if ($cleanupTargetDir && is_dir($targetDir) && ($dir = opendir($targetDir))) {
			while (($file = readdir($dir)) !== false) {
				$tmpfilePath = $targetDir . DIRECTORY_SEPARATOR . $file;
	
				// Remove temp file if it is older than the max age and is not the current file
				if (preg_match('/\.part$/', $file) && (filemtime($tmpfilePath) < time() - $maxFileAge) && ($tmpfilePath != "{$filePath}.part")) 
					@unlink($tmpfilePath);
			}
			closedir($dir);
		} 
		else{die('{"jsonrpc" : "2.0", "error" : {"code": 100, "message": "Failed to open temp directory."}, "id" : "id"}');}
		
	
		// Look for the content type header
		if (isset($_SERVER["HTTP_CONTENT_TYPE"])) $contentType = $_SERVER["HTTP_CONTENT_TYPE"];
	
		if (isset($_SERVER["CONTENT_TYPE"])) $contentType = $_SERVER["CONTENT_TYPE"];
	
		// Handle non multipart uploads older WebKit versions didn't support multipart in HTML5
		if (strpos($contentType, "multipart") !== false) {
			if (isset($_FILES['file']['tmp_name']) && is_uploaded_file($_FILES['file']['tmp_name'])) {
				
				// Open temp file
				
				$out = fopen("{$filePath}.part", $chunk == 0 ? "wb" : "ab");
				
				if ($out) {
					// Read binary input stream and append it to temp file
					$in = fopen($_FILES['file']['tmp_name'], "rb");
		
					if ($in) while ($buff = fread($in, 4096)) fwrite($out, $buff);
					else die('{"error" : "Failed to open input stream."}');
					fclose($in);
					fclose($out);
					@unlink($_FILES['file']['tmp_name']);
				}
				else die('"error" : "Failed to open output stream."}');}
			else
				die('{"error" : "Failed to move uploaded file."}');
		}
		else {
			// Open temp file
			$out = fopen("{$filePath}.part", $chunk == 0 ? "wb" : "ab");
			if ($out) {
				// Read binary input stream and append it to temp file
				$in = 0;fopen("php://input", "rb");
		
				if ($in) while ($buff = fread($in, 4096)) fwrite($out, $buff);
				else die('{"error" :"Failed to open input stream."}');
		
				fclose($in);
				fclose($out);
			} 
			else die('{"error" : "Failed to open output stream."}');
		}
	
		// Check if file has been uploaded & // Strip the temp .part suffix off 
		if (!$chunks || $chunk == $chunks - 1) rename("{$filePath}.part", $filePath);
	
		// File Uploaded Successfully!
		
		$zip = new ZipArchive;
		$hasHeaderFile = 0;
		$headerFile = substr($fileName, 0, strrpos($fileName, '.')).'.php';
		if ($zip->open($filePath) === TRUE) {
			
			for( $i = 0; $i < $zip->numFiles; $i++ ){ 
    			$stat = $zip->statIndex( $i );
				if(basename( $stat['name'] ) == $headerFile) $hasHeaderFile = 1;
			}
			
			if($hasHeaderFile){
				
				$zip->extractTo($targetDir);
				$zip->close();
				@unlink($filePath);
			}
			else{
				@unlink($filePath);
				die('{"error" : "Upload Failed: Not a valid plugin file."}');
			}
		}
		else { 
			@unlink($filePath);
			die('{"error" : "Upload Failed: Failed To Open Zip File."}');
		}
	
		// Return JSON-RPC response
		//die('{"jsonrpc" : "2.0", "result" : null, "id" : "id"}');
		die('{"success" :  "Plugin Installed Successfully!"}');
		
	}

?>