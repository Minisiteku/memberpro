<?php
	include_once('../../conn.php');
	include_once('../../functions.php');	
	
	// Is there a posted query string?
	if(isset($_POST['queryString']) && strlen($_POST['queryString']) >0) {
		$queryString =  $_POST['queryString'];
		
		// Run the query: We use LIKE '$queryString%'
		// The percentage sign is a wild-card, in my example of countries it works like this...
		// $queryString = 'Uni';
		// Returned data = 'United States, United Kindom';

		$sql = "SELECT sTransactionNumber FROM tbltransactions WHERE sTransactionNumber LIKE '$queryString%'; ";
		$rs = $dbo->select($sql);
		
		if(!empty($rs)) {
					// While there are results loop through them - fetching an Object (i like PHP5 btw!).
					while ($row = $dbo->getobj($rs)) {
					// Format the results, im using <li> for the list, you can change it.
					// The onClick function fills the textbox with the result.
						
	         			echo '<li onClick="fill(\''.$row->sTransactionNumber.'\',\'#Txn\',\'.suggestionsm\',\''.$row->nUser_ID.'\');">'.$row->sTransactionNumber .'</li>';
	         		}
				}
		else {echo '<li>No results found</li>';}
		
	}
	else {echo 'There should be no direct access to this script!';}
	
?>