<?php
// This file takes an uploaded file, moves it to the assets dir and adds it to the database<br />
// This is done via ajax

include_once('../../conn.php');
include_once('../../includes/functions-videos.php');
include_once('../mime.php');


// HTTP headers for no cache etc
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
// Settings
if(isset($_POST)){
	
	if(!$_POST['sVideoURL'] || $_POST['sVideoURL'] == ''){die('{"jsonrpc" : "2.0", "error" : {"code": 1, "message": "You Must Enter A Url To The Video."}, "id" : "0"}');}
	$url = trim($_POST['sVideoURL']);
	$video = $dbo->getobject("Select * From tblvideos WHERE sURL = '".$url."'");
	if($video){die('{"jsonrpc" : "2.0", "data" : {"message": "[[Video '.$video->nVideo_ID.']] - '.$url.'"}, "id" : "'.$video->nVideo_ID.'"}');}
	
	$id = addRemoteVideoToDb($url);
	
	if(!$id){die('{"jsonrpc" : "2.0", "error" : {"code": 3, "message": "Failed To Add Video To Database"}, "id" : "0"}');}
	
	die('{"jsonrpc" : "2.0", "data" : {"message": "[[Video '.$id.']] - '.$url.'"}, "id" : "'.$id.'"}');
	
	}

?>