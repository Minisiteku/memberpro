<?php
include_once('../conn.php');
include_once('../functions.php');
$objAutoresponder = $dbo->getobject("SELECT * FROM tblautoresponders LIMIT 1;");
if ( isset($_POST['Update']) )
{
	$active = ($_POST['nActive'] == 1)?1:0;
	if($objAutoresponder){
		$sql = "UPDATE tblautoresponders SET 
				sAutoresponderName='".$dbo->format($_POST['sAutoresponderName'])."', 
				sAutoresponderURL='".$dbo->format($_POST['sAutoresponderURL'])."', 
				sHiddenFields='".htmlentities($_POST['sHiddenFields'])."', 
				sFormName='".$dbo->format($_POST['sFormName'])."', 
				sFormEmail='".$dbo->format($_POST['sFormEmail'])."',
				nActive='".$dbo->format($active)."'
				WHERE nAutoresponder_ID=".$objAutoresponder->nAutoresponder_ID.";";
				$dbo->update($sql);
	}else{
		$sql = "INSERT INTO tblautoresponders (
					sAutoresponderName, sAutoresponderURL, sHiddenFields, sFormName, sFormEmail, nActive 
			)VALUES('".$dbo->format($_POST['sAutoresponderName'])."', 
					'".$dbo->format($_POST['sAutoresponderURL'])."',
					'".htmlentities($_POST['sHiddenFields'])."',
					'".$dbo->format($_POST['sFormName'])."',
					'".$dbo->format($_POST['sFormEmail'])."',
					'".$dbo->format($active)."');";
					$dbo->insert($sql);
	}
	
	$message = "<p class='success'>Auto responder settings have been updated successfully</p>";
}
$objAutoresponder = $dbo->getobject("SELECT * FROM tblautoresponders LIMIT 1;");
?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<?php include ('inc-head.php')?>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
	<?php include_once('settingsleft.php'); ?>
    </td>
    <td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
    <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<td width="10%" nowrap="nowrap" class="navRow2">3rd Party Autoresponder Settings</td>
					</tr>
				</table>
				
				<?php echo isset($message) ? $message : '' ?>
    
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="form">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td align="center" valign="top">
  <table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
    <tr>
      <td class="gridrow2" width="250">Autoresponder Name:<font color="Red"> *</font></td>
      <td class="gridrow2"><input type="text" name="sAutoresponderName" value="<?php echo ($objAutoresponder)?$objAutoresponder->sAutoresponderName:''; ?>" size="35" class="required"></td>
    </tr>
    <tr>
      <td class="gridrow2" width="250" >Autoresponder Post URL:<font color="Red"> *</font></td>
      <td class="gridrow2"><input type="text" name="sAutoresponderURL" value="<?php echo ($objAutoresponder)?$objAutoresponder->sAutoresponderURL:''; ?>" size="35" class="required url"></td>
    </tr>
    <tr valign="top">
      <td class="gridrow2" width="250" >Hidden Form Fields:</td>
      <td class="gridrow2"><textarea name="sHiddenFields" cols="50" rows="10"><?php echo ($objAutoresponder)?html_entity_decode($objAutoresponder->sHiddenFields):''; ?></textarea></td>
    </tr>
    <tr>
      <td class="gridrow2" width="250" >Name Field Name:<font color="Red"> *</font></td>
      <td class="gridrow2"><input type="text" name="sFormName" value="<?php echo ($objAutoresponder)?$objAutoresponder->sFormName:''; ?>" size="35" class="required"> 
      &lt;input type=&quot;text&quot; name=&quot;<strong>name</strong>&quot;</td>
    </tr>
    <tr>
      <td class="gridrow2" width="250" >Email Field Name:<font color="Red"> *</font></td>
      <td class="gridrow2"><input type="text" name="sFormEmail" value="<?php echo ($objAutoresponder)?$objAutoresponder->sFormEmail:''; ?>" size="35" class="required"> 
        &lt;input type=&quot;text&quot; name=&quot;<strong>email</strong>&quot;</td>
    </tr>
    <tr>
      <td class="gridrow2" width="250" >Active:</td>
      <td class="gridrow2"><input type="checkbox" name="nActive" value="1" size="20" <?php echo ($objAutoresponder)?$objAutoresponder->nActive?'checked="checked"':'':''; ?>></td>
    </tr>
    <tr>
      <td colspan="2" class="gridHeader"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td valign="top"><input type="submit" name="Update" value="Save Settings" class="inputSubmitb" /></td>
          </tr>
        </table></td>
    </tr>
  </table>
</td>
					</tr>
				</table>
</form>
</td>
  </tr>
</table>
<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%"><?php echo isset($message) ? $message : '' ?>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center" valign="top"></td>
    </tr>
  </table>	
<?php include_once('b.php'); ?>
<script type="text/javascript">		
		$(document).ready(function()
		{
			$("#form").validate(
			{
				onkeyup: false 		 					
			
			});
		});
</script>
	</body>
</html>
