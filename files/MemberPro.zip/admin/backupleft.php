<table class="sideTable" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td class="sideHeader">&nbsp;Database Options</td>
  </tr>
  <tr>
    <td class="sideRow"><a class="black" href="manage_database.php"><img src="../common/images/icons/database_gear.png" alt="" align="absmiddle" border="0" /></a>&nbsp; <a class="opt" href="manage_database.php">Manage Database</a></td>
  </tr>
  <tr>
    <td class="sideRow"><a class="black" href="restore_database.php"><img src="../common/images/icons/database_refresh.png" alt="" align="absmiddle" border="0" /></a>&nbsp; <a class="opt" href="restore_database.php">Restore Database</a></td>
  </tr>
  <tr>
    <td class="sideRow"><a class="black" href="delete_database.php"><img src="../common/images/icons/database_delete.png" alt="" align="absmiddle" border="0" /></a><a class="black" href="restore_database.php"></a><a class="opt" href="delete_database.php" style="margin-left:3px"> Delete Backups</a></td>
  </tr>
</table>
