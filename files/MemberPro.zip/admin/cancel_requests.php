<?php
include_once('../conn.php');
include_once('../functions.php');

// Get updated site data
$chkSsettings = $dbo->getobj($dbo->select("SELECT * FROM tblsitesettings"));

function cancelType($i){
	switch ($i) {
    case 0:
        return "Admin Approved";
        break;
    case 1:
        return "Member Auto Cancel";
        break;
}
	}
// Setup Options for Members per Page listing
$aMPP = array('5', '10', '15', '20', '25', '50', '100');
$mpp = (empty($_GET['mpp'])) ? 10 : $_GET['mpp'];

// Main query
$mainquery = "SELECT tblcancellations. * , tblusers.sForename, tblusers.sSurname, tblusers.sSurname,tbluserlevels.nLevel_ID, tblmembershiplevels.sLevel
FROM tblcancellations
LEFT JOIN tblusers ON tblusers.nUser_ID = tblcancellations.nUser_ID
LEFT JOIN tbluserlevels ON tbluserlevels.nUserLevel_ID = tblcancellations.nUserLevel_ID
LEFT JOIN tblmembershiplevels ON tblmembershiplevels.nLevel_ID = tbluserlevels.nLevel_ID";
		
if($_GET['act'] == 'p'){
	// process the cancellation
	admin_cancel_level($_GET['lid'],$_GET['id']);
	header("Location: cancel_requests.php");
	exit;
	}
if($_GET['act'] == 'd'){
	
	$sql = "DELETE FROM `tblcancellations` WHERE `tblcancellations`.`nCancellation_ID` = ".$_GET['id']." LIMIT 1";
	$dbo->Delete($sql);
	header("Location: cancel_requests.php?msg=Request Deleted Successfully");
	exit;
	}		
		
		
		
?>		


<html>
<head>
	<title><?php echo $admintitle; ?></title>
	<?php include('inc-head.php') ?>
	<script type="text/javascript"> 
		function updateMPP(oList) {
			var mpp = oList.options[oList.selectedIndex].value;
			var qs = '?start=0';
			qs += '&sort=<?php echo $_GET['sort'] ?>';
			qs += '&type=<?php echo $_GET['type'] ?>';
			qs += '&mpp=' + mpp;
			document.location = '<?php echo $_SERVER['PHP_SELF']?>' + qs;
		}
	
      
      function toggle(id){
		var ele = document.getElementById(id);
		if(ele.style.display == 'none'){ele.style.display = 'block'}
		else{ele.style.display = 'none'}
		}
    </script>
</head>
<body>
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
		  <?php include_once('memberleft.php'); ?>
		</td>
		<td width="100%" align="left" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">
		  <h1>Pending Cancellation Requests</h1>
		 <div style="width:100%; margin-bottom:10px;"> 
         <table align="left" cellpadding="5" cellspacing="0" class="gridTable" width="100%">
				<tr>
					<td class="gridHeader" nowrap="nowrap">First name</td>
					<td class="gridHeader">Last Name</td>
					<td class="gridHeader">Membership</td>
                    <td class="gridHeader">Request Date</td>
					<td class="gridHeader">Comment</td>
					<td class="gridHeader" colspan="2">Actions</td>
				</tr>
                <?php
				$sql = $mainquery . " WHERE nStatus = '0';";
				//die($sql);
				$result = $dbo->select($sql);
				$nr = $dbo->nr($result);
				if($nr){
					while($objPending = $dbo->getobj($result)){ ?>
						<tr>
                        <td class="gridrow2"><a href="view_member.php?id=<?php echo $objPending->nUser_ID?>"><?php echo $objPending->sForename?></a></td>
						<td class="gridrow2"><a href="view_member.php?id=<?php echo $objPending->nUser_ID?>"><?php echo $objPending->sSurname?></a></td>
						<td class="gridrow2"><?php echo $objPending->sLevel?></td>
						<td class="gridrow2"><?php echo fShowDate($chkSsettings->nDateFormat,date('Ymd',$objPending->nRequest_date))?></td>
						<td class="gridrow2"><?php echo $objPending->sComment?></td>
						<td class="gridrow2"><a href="cancel_requests.php?act=p&id=<?php echo $objPending->nCancellation_ID?>&lid=<?php echo $objPending->nUserLevel_ID?>">Process</a></td>
						<td class="gridrow2"><a href="cancel_requests.php?act=d&id=<?php echo $objPending->nCancellation_ID?>">Delete</a></td>
						</tr>
						<?php
						}
					}
				else{?><tr class="gridrow2"><td colspan="7">No Pending Requests ...</td></tr><?php }
				?>
                <tr class="gridfooter"><td colspan="7">&nbsp;</td></tr>
            </table>
         </div>
             <br>
<br>
<br>
<br>
<h1>Completed Cancellations</h1>
<div style="margin-top:10px;"><table align="left" cellpadding="5" cellspacing="0" class="gridTable" width="100%">
				<tr>
					<td class="gridHeader" nowrap="nowrap">First name</td>
					<td class="gridHeader">Last Name</td>
					<td class="gridHeader">Membership</td>
					<td class="gridHeader">Cancel Date</td>
                    <td class="gridHeader">Cancel Type</td>
					<td class="gridHeader" colspan="2">Comment</td>
			</tr>
                <?php
				$sql = $mainquery . " WHERE nStatus != '0';";
				//die($sql);
				$result = $dbo->select($sql);
				$nr = $dbo->nr($result);
				if($result){
					if(!$nr){?>
                    	<tr><td colspan="7" class="gridRow2">No Completed Cancellations ...</td></tr>
					<?php }
					else{
						
						while($objPending = $dbo->getobj($result)){ ?>
						<tr>
                        <td class="gridrow2"><a href="view_member.php?id=<?php echo $objPending->nUser_ID?>"><?php echo $objPending->sForename ?></a></td>
						<td class="gridrow2"><a href="view_member.php?id=<?php echo $objPending->nUser_ID?>"><?php echo $objPending->sSurname?></a></td>
						<td class="gridrow2"><?php echo $objPending->sLevel?></td>
						<td class="gridrow2"><?php echo fShowDate($chkSsettings->nDateFormat,date('Ymd',$objPending->nProcess_date))?></td>
						<td class="gridrow2"><?php echo cancelType($objPending->nProcess_type)?></td>
						<td class="gridrow2"><?php echo $objPending->sComment ?></td>
						</tr>
						<?php
						}
						}
					}
				?>
                </tr>
                <tr class="gridfooter"><td colspan="7">&nbsp;</td></tr>
          </table></div>
		  
			</td>
	</tr>
</table>
<?php include_once('b.php'); ?>
	</body>
</html>