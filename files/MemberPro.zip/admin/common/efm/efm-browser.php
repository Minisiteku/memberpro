<?php
	// Make Sure This Script Is Secured!!!!
	include_once('../../../conn.php');
	include_once('../../../functions.php');
	include_once('efm-functions.php');
	
	//upload class (see file for credits)
	require('class.upload.php');
	error_reporting(0);
	header("Content-type: text/html; charset=utf-8");
	///////////////////////////////////////////
	
	// This is what is actually used to read the file structure ex. /home/public_html, 'C:\xampp\htdocs' ...
	// This will be the starting point of browsing, and cannot go higher
	$file_root = rtrim(UPLOADPATH, '/');
	
	//path from webroot to storage folder, without trailing slash.
	$root_path = str_replace('common/efm/efm-browser.php','',$_SERVER['PHP_SELF']).'assets'; 
	//die($root_path);
	
	// Used For Tree Display Only
	$string = explode('/',$file_root);
	$n = (count($string) - 1);
	
	$file_root_dir = $string[$n];
	
	$mce_path = '../js/tiny_mce/';
	$jquery_path = '../../../js/jquery-1.8.3.min.js';
	
	$thmb_size = 600;       	//max size of preview thumbnail
	$no_script = false;       //true/false - turns scripts into text files
	
	////////////////////////////////////////////////////////////////////////////////
	
	
	//array of known file types (used for icons)
	$file_class = array(
			'swf',
			'txt',
			'htm',
			'html',
			'zip',
			'gz',
			'rar',
			'cab',
			'tar',
			'7z',
			'deb',
			'rpm',
			'php',
			'mp3',
			'ogg',
			'mid',
			'avi',
			'mpg',
			'flv',
			'mpeg',
			'pdf',
			'ttf',
			'exe'
			);
			
			
	// Filter Results By Insert Type
	$filter = $_GET['type'];
	
	$img_files = array('gif','png','jpg','jpeg');
	$media_files = array('flv','mp4','ogv','mov','mpeg','mpg','avi','mp3','ogg','swf');
	
	
	
	//stand alone or tynimce?
	$mode = 'mce';
	if(isset($_GET['mode'])) $mode = $_GET['mode'];
	if(isset($_GET['type'])) $filter = $_GET['type'];
	
	$uploadstatus = 0;
	if(isset($_GET['status'])) { $uploadstatus = $_GET['status']; }
	
	//handles file uploads
	if(isset($_FILES['new_file']) && isset($_POST['return'])) {
		if(is_dir($_POST['return'])) {
			$handle = new upload($_FILES['new_file']);
		  if ($handle->uploaded) {
		  $handle->file_new_name_body   = format_filename(substr($_FILES['new_file']['name'],0,-4));
		  //resize image. more options coming soon.
		  if(isset($_POST['new_resize']) && $_POST['new_resize'] > 0) {
			  $handle->image_resize         = true;
			  $handle->image_x              = (int)$_POST['new_resize'];
			  $handle->image_ratio_y        = true;
		  }
		  if(isset($_POST['new_greyscale']) && $_POST['new_greyscale']) {
					$handle->image_greyscale      = true;
				}
		  if(isset($_POST['new_rotate']) && $_POST['new_rotate'] == 90 or $_POST['new_rotate'] == 180 or $_POST['new_rotate'] == 270) {
					$handle->image_rotate      		= $_POST['new_rotate'];
				}
				$handle->mime_check = $no_script;
				$handle->no_script = $no_script;
		  $handle->process($_POST['return'] . '/');
		  if ($handle->processed) {
			$handle->clean();
			$uploadstatus = 1;
		  } else {
					//uncomment for upload debugging
			//echo 'error : ' . $handle->error;
			$uploadstatus = 2;
		  }
		  }
		} else {
			$uploadstatus = 3;
		}
	}
	
	//remove unnecessary folder
	if(isset($_GET['deletefolder'])) {
	  $deldir = $_GET['deletefolder'];
	
		//fix by Arpad SZUCS Jul 6, 2011
		$block = false;
		if (strstr($_SERVER['SERVER_SOFTWARE'], "Win32")) {
			// windows is case insesitive:
			$block = ! strcasecmp($deldir, $file_root);
		} else {
			$block = ! strcmp($deldir, $file_root);
		}
	
		if(is_dir($_GET['deletefolder'])) {
			if(!$block && delete_directory($deldir)) {
		  header('Location: efm-browser.php?status=4');
			} else {
		  $uploadstatus = 5;
			}
		} else {
		$uploadstatus = 6;
		}
	}
	
	//display only directory tree for ajax
	if(isset($_GET['viewtree'])) {
	?>
			<ul class="dirlist">
				<li><a href="<?php echo $root_path . '/' . $file_root; ?>/" onClick="load('efm-browser.php?viewdir=<?php echo $file_root; ?>&type=<?php echo $filter ?>','view-files'); return false;"><?php echo $file_root_dir; ?></a> <a href="#" onClick="load('efm-browser.php?viewtree=true','view-tree'); return false;" id="refresh-tree">Refresh</a>
				<?php display_tree($file_root); ?>
				</li>
			</ul>
	<?php
		exit;
	}
	
	//display file list for dynamic requests
	if(isset($_GET['viewdir'])) {
		//die(var_dump($_GET));
	?>
			<ul id="browser-toolbar">
				<li class="file-new"><a href="#" title="Upload New File" onClick="toggle_visibility('load-file'); return false;">Upload File</a></li>
				<li class="folder-new"><a href="#" title="Create New folder" onClick="create_folder('<?php echo $_GET['viewdir']; ?>'); return false;">New folder</a></li>
				<li class="folder-delete"><a href="#" title="Remove Current Folder" onClick="delete_folder('<?php echo $_GET['viewdir']; ?>');">Delete Folder</a></li>
				<li class="file-refresh"><a href="#" title="Refresh File List" onClick="load('efm-browser.php?viewdir=<?php echo $_GET['viewdir']; ?>&type=<?php echo $filter ?>','view-files'); return false;">Refresh</a></li>
			</ul>
			
			<div id="current-loction">
			  <?php echo htmlspecialchars( $_GET['viewdir'] . '/'); ?>
			</div>
			
			<form style="display: none;" id="load-file" action="" class="load-file" method="post" enctype="multipart/form-data">
	<br />
				<fieldset>
				  <legend>Upload New File</legend>
					<input type="hidden" value="<?php echo $_GET['viewdir']; ?>" name="return" />
					<label>File<input type="file" name="new_file" /></label>
				</fieldset>
				<!--
				<fieldset>
				  <legend>Modify Image File</legend>
				  <table>
						<tr>
							<td><label for="new_resize">Change Width</label></td>
							<td><input type="text" class="number" maxlength="4" id="new_resize" name="new_resize" value="" /> px</td>
						</tr>
						<tr>
							<td><label for="new_rotate">Rotate</label></td>
							<td>
								<select id="new_rotate" name="new_rotate">
								  <option value="0"></option>
								  <option value="90">90</option>
								  <option value="180">180</option>
								  <option value="270">270</option>
								</select>
							</td>
						</tr>
						<tr>
							<td></td>
							<td><input type="checkbox" class="checkbox" id="new_greyscale" name="new_greyscale" /><label for="new_greyscale">Convert To Grey Scale</label></td>
						</tr>
				  </table>
				</fieldset>
				-->
				<input type="submit" id="insert" value="Upload" />
				<br /><br />
			</form>
			
	<?php
	
		//create directory and show results
		if(isset($_GET['newdir'])) {
		$new_title = format_filename($_GET['newdir']);
		  if(!is_dir($_GET['viewdir'] . '/' . $new_title)) {
				if(mkdir($_GET['viewdir'] . '/' . $new_title, 0777)) {
					echo '<p class="successful">"' . $new_title . '" - folder created!</p>';
				} else {
					echo '<p class="failed">Cannot create folder "' . $new_title . '"!<br />Check that you have permission to create folders!</p>';
				}
			} else {
				echo '<p class="failed">Cannot create folder "' . $new_title . '"!<br />Folder already exists!</p>';
			}
		}
		
		//remove unnecessary files
		if(isset($_GET['deletefile'])) {
			if(!file_exists($_GET['viewdir'] . '/' . $_GET['deletefile'])) {
				echo '<p class="failed">Cannot Delete File. File does not exist!</p>';
			} else {
				if(unlink($_GET['viewdir'] . '/' . $_GET['deletefile'])) {
					echo '<p class="successful">File deleted successfully!</p>';
				} else {
					echo '<p class="failed">Cannot Delete File!</p>';
				}
			}
		}
		
		
		//show status messages by code
		if(isset($_GET['status'])) {
			
			switch ($_GET['status']) {
				case 1:
					echo '<p class="successful">File Uploaded Successfully!</p>';
					break;
				case 2:
					echo '<p class="failed">Error: cannot upload file :(</p>';
					break;
				case 3:
					echo '<p class="failed">Error: destination directory does not exist!</p>';
					break;
				case 4:
					echo '<p class="successful">Directory does not exist!</p>';
					break;
				case 5:
					echo '<p class="failed">Error: unable to delete directory!</p>';
					break;
				case 6:
					echo '<p class="failed">Error: no such directory!</p>';
					break;
			}
		}
	
		//finally show file list
		
		
		display_files($filter,$_GET['viewdir']);
		exit;
	}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <meta http-equiv="content-language" content="en" />
  <title>EMP File Manager</title>
  <link rel="stylesheet" href="style.css" type="text/css" />
  <link rel="stylesheet" href="<?php  echo $mce_path ?>/themes/advanced/skins/default/dialog.css" type="text/css" />
  <script type="text/javascript" src="<?php  echo $mce_path ?>/tiny_mce_popup.js"></script>
  <script type="text/javascript" src="<?php echo $jquery_path ?>"></script>
<script type="text/javascript">
		//<![CDATA[
		
		function ajax(url, target)
		{
			$("#"+target).html('<img src="images/loading.gif" alt="" /> Loading ...');
			$.ajax({  
  				type: "GET",  
  				url: url,
  				success: function(text) {
					$("#"+target).html(text);
				}
			});  
			return false;  	
		}
		
			
		function load(name, div, callback) {
			//ahah(name,div,callback);
			ajax(name, div);
			return false;
		}
	
		//ask for folder title and request it's creation
		function create_folder(viewdir) {
			var name=prompt("New folder name:","new_folder");
			if (name!=null && name!=""){
				load('efm-browser.php?viewdir=' + viewdir + '&newdir=' + name + '','view-files', create_folder_done);
			}
		}

		//reload directory tree after folder creation
		function create_folder_done() {
			load( '?mfm=1&viewtree=true', 'view-tree' );
		}

		<?php
			//first one for inserting file name into given field, second for working as tinyMCE plugin
			if ($mode == 'standalone' && isset($_GET['field'])) {
		?>
		function submit_url(URL) {
			window.opener.document.getElementById('<?php echo $_GET['field']; ?>').value = URL;
			self.close();
		}
		<?php
			}
			else {
		?>
			function submit_url(URL) {
			var win = tinyMCEPopup.getWindowArg("window");
			win.document.getElementById(tinyMCEPopup.getWindowArg("input")).value = URL;
			if (typeof(win.ImageDialog) != "undefined" && document.URL.indexOf('type=image') != -1)
   {
   if (win.ImageDialog.getImageData) win.ImageDialog.getImageData();
   if (win.ImageDialog.showPreviewImage) win.ImageDialog.showPreviewImage(URL);
   }
			tinyMCEPopup.close();
			
		}
    <?php } 
	?>
    
		//confirm and delete file
		function delete_file(dir,file) {
			var answer = confirm("Are you sure you want to delete this file?");
			if (answer){
		  	load('efm-browser.php?viewdir=' + dir + '&deletefile=' + file,'view-files');
			} 
		}

		//confirm and delete folder
		function delete_folder(dir) {
			var answer = confirm("Are you sure you want to delete this directory?");
			if (answer){
		  	location.href = 'efm-browser.php?deletefolder=' + dir;
			}
		}

		//show/hide element (for file upload form)
		function toggle_visibility(id) {
			var e = document.getElementById(id);
			if(e != null) {
				if(id == 'load-file'){
					if(e.style.display == 'none') {
						e.style.display = 'block';
						$('#file-list').hide();
						
					}
					else {
					e.style.display = 'none';
					$('#file-list').show();
					
					}
				}
				else{
					if(e.style.display == 'none') {
						e.style.display = 'block';
					}
					else {
					e.style.display = 'none';
					}
				}
				
				
			}
		}
		//]]>
	</script>
</head>

<?php
	$return = $file_root;
	if(isset($_REQUEST['return'])) {$return = $_REQUEST['return'];}
?>

<body onLoad="load('efm-browser.php?status=<?php echo $uploadstatus; ?>&amp;viewdir=<?php echo $return; ?>&type=<?php echo $filter ?>','view-files');">
<div id="header"><img src="images/emp-fm-header-logo.jpg" width="546" height="106"></div>
	<div id="browser-wrapper">
    <div id="view-tree">
		<a href="#" title="Refresh Directory Tree" onClick="load('efm-browser.php?viewtree=true','view-tree'); return false;" id="refresh-tree">
			Refresh
		</a>
			<ul class="dirlist">
				<li>
					<a href="<?php echo $root_path; ?>/" onClick="load('efm-browser.php?viewdir=<?php echo $file_root; ?>&type=<?php echo $filter ?>','view-files'); return false;">
						<?php echo $file_root_dir; ?>
					</a>
					
				  <?php display_tree($file_root); ?>
				</li>
			</ul>
	</div>
    <div id="view-files">
    </div>
	<div style="clear:both; padding:5px;"></div>
  </div>
<div style="clear:both; padding:5px;">Created with thanks to <a href="http://sourceforge.net/projects/tinyfilemanager/" target="_blank" rel="nofollow">Mad File Manager</a></div>
</body>

</html>
