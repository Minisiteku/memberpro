<?php
	//replaces special characters for latvian and russian lang., and removes all other
	function format_filename($filename) {
		$bads = array(' ','ā','č','ē','ģ','ī','ķ','ļ','ņ','ŗ','š','ū','ž','Ā','Č','Ē','Ģ','Ī','Ķ','Ļ','Ņ','Ŗ','Š','Ū','Ž','$','&','А','Б','В','Г','Д','Е','Ё','Ж','З','И','Й','К','Л','М','Н','О','П','Р','С','Т','У','Ф','Х','Ц','Ч','Ш','Щ','Ъ','ЫЬ','Э','Ю','Я','а','б','в','г','д','е','ё','ж','з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х','ц','ч','шщ','ъ','ы','ь','э','ю','я');
		$good = array('-','a','c','e','g','i','k','l','n','r','s','u','z','A','C','E','G','I','K','L','N','R','S','U','Z','s','and','A','B','V','G','D','E','J','Z','Z','I','J','K','L','M','N','O','P','R','S','T','U','F','H','C','C','S','S','T','T','E','Ju','Ja','a','b','v','g','d','e','e','z','z','i','j','k','l','m','n','o','p','r','s','t','u','f','h','c','c','s','t','t','y','z','e','ju','ja');
		$filename = str_replace($bads,$good,trim($filename));
		$allowed = "/[^a-z0-9\\.\\-\\_\\\\]/i";
		$filename = preg_replace($allowed,'',$filename);
		return $filename;
	}
	
	//convert file size to human readable format
	function byte_convert($bytes) {
	  $symbol = array('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
	  $exp = 0;
	  $converted_value = 0;
	  
	  if( $bytes > 0 ) {
		$exp = floor( log($bytes)/log(1024) );
		$converted_value = ( $bytes/pow(1024,floor($exp)) );
	  }
	  return sprintf( '%.2f '.$symbol[$exp], $converted_value );
	}
	
	//show recursive directory tree
	function display_tree($dir = '.') {
		global $root_path;
		echo '<ul class="dirlist">';
		$d = opendir($dir);
		while($f = readdir($d)) {
			if(strpos($f, '.') === 0) continue;
			$ff = $dir . '/' . $f;
		
			if(is_dir($ff)) {
				$url = 'efm-browser.php?viewdir=' . $ff . '\&type='.$filter;
				echo '<li><a href="" onclick="load(\' '.$url.'  \',\'view-files\'); return false;">' . $f . '</a>';
				display_tree($ff);
				echo '</li>';
			}
	  }
	  echo '</ul>';
	}
	
	//show file list of given directory
	function display_files($filter,$c = '.') {
		//die(var_dump($filter));
		global $file_root,$root_path, $mode, $thmb_size, $file_class, $img_files, $lng;
	  	echo('<table id="file-list">');
		echo ('
		<tr class="dark">
		<td><strong>File Name</strong></td>
		<td><strong>File Size</strong></td>
		<td><strong>Actions</strong></td>
		</tr>');
		$i = 0;
		try
    {
        /*** class create new DirectoryIterator Object ***/
        foreach ( new DirectoryIterator($c) as $f )
        {
            if(strpos($f, '.') === 0) continue;
			if($f == 'index.php') continue;
			$ff = $c . '/' . $f;
			$ext = strtolower(substr(strrchr($f, '.'), 1));
			
			if($filter == 'image'){
				//die('run filter');
				if(!in_array($ext,$img_files)) continue;
				//echo $ext;
				
			}
			elseif($filter == 'media'){
				if(!in_array($ext,$media_files)) continue;
				
				
			}
			else{}
			
			
			if(!is_dir($ff)) {
				echo '<tr' . ($i%2 ? ' class="light"' : ' class="dark"') .'>';
				$admin_path = str_replace('assets','',$file_root);
				$admin_url = str_replace('/assets','',$root_path);
				$subdirs =  str_replace($admin_path,'',$c);
				$this_file_url = $admin_url .'/'.$subdirs.'/'.$f;
				
				$imageinfo = @getimagesize($ff);
				if($imageinfo && $imageinfo[2] > 0 && $imageinfo[2]< 4) {
						// We have an image
						
						$resize = '';
						if($imageinfo[0] > $thmb_size or $imageinfo[1] > $thmb_size) {
							if($imageinfo[0] > $imageinfo[1]) {
									$resize = ' style="width: ' . $thmb_size . 'px;"';
								} else {
									$resize = ' style="height: ' . $thmb_size . 'px;"';
								}
							}
							if ($imageinfo[2] == 1) {
								$imagetype = "image_gif";
							} elseif ($imageinfo[2] == 2) {
								$imagetype = "image_jpg";
							} elseif ($imageinfo[2] == 3) {
								$imagetype = "image_jpg";
							} else {
								$imagetype = "image";
							}
							
							//die($admin_url);
							echo '<td><a class="file thumbnail ' . $imagetype . '" href="#" onclick="submit_url(\'' . $this_file_url . '\');">' . $f . '<span>
							<img' . $resize . ' src="'  .$this_file_url . '" /></span></a>'; echo '</td>';
						//known file types
						} 
				
				elseif(in_array($ext,$file_class)) {
					echo '<td><a class="file file_' . $ext . '" href="#" onclick="submit_url(\'' . $this_file_url . '\');">' . $f . '</a>'; echo '</td>';
				//all other files
				}
				else {
					echo '<td><a class="file unknown" href="#" onclick="submit_url(\'' . $this_file_url . '\');">' . $f . '</a>'; echo '</td>';
			}
			
			
			
			
			
			
			//show preview and different icon, if file is image
			
			
				echo '<td>' . byte_convert(filesize($ff)) . '</td>';
				echo '<td class="delete"><a href="#" title="Delete file" onclick="delete_file(\'' . $c . '\',\'' . $f . '\');"></a></td>';
			echo '</tr>';
			$i++;
		}
			
			
			
        }
    }
    /*** if an exception is thrown, catch it here ***/
    catch(Exception $e)
    {
        echo 'No files Found!<br />';
    }
	
	echo('</table>');
		
		
		
		
		
		
		
		
		
		
	
	  
	}
	
	function delete_directory($dirname) {
		if (is_dir($dirname))
			$dir_handle = opendir($dirname);
			if (!$dir_handle)
				return false;
				while($file = readdir($dir_handle)) {
			if ($file != "." && $file != "..") {
				if (!is_dir($dirname."/".$file))
					unlink($dirname."/".$file);
				else
					delete_directory($dirname.'/'.$file);
				}
			}
		closedir($dir_handle);
		rmdir($dirname);
		return true;
	}

?>