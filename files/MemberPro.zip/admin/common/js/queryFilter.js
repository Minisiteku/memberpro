// JavaScript Document
// Query Filter
	function showFilterFields(field){
		if(field.checked === true){
			$('#'+field.id+'Filter').show();
		}
		else{
			$('#'+field.id+'Filter').hide();
		}
		
	}
	function showFilterChoices(opt){
		console.log(opt);
		if(opt.id == 'filterOptions_new'){
			$('#newFilterForm').show();
			$('#filterList').hide();
			
		}
		else{
			$('#newFilterForm').hide();
			$('#filterList').show();
		}
	}
	function hideFilterChoices(){
		$('#newFilterForm').hide();
		$('#filterList').hide();
	}
	function toggleFilterValue2(e){
		console.log(e);
		if(e.id == 'joinFilterCompare'){
			if(e.options[e.selectedIndex].value == '><'){
			$('#joinFilterBetween').show();
		}
			else{$('#joinFilterBetween').hide();}

		}
		if(e.id == 'loginFilterCompare'){
			if(e.options[e.selectedIndex].value == '><'){
			$('#loginFilterBetween').show();
		}
			else{$('#loginFilterBetween').hide();}

			
			
		}
		
		
		
		
			}
	function getFilterTable(){
		$.ajax({
			type: "POST",
			url: "ajax/functions.php?act=loadMemberFiltersTable",
			data: {
				'variable1': 'content var1',
					'variable2': 'content var2'
			},
			success: function (response) {
			   $('#tableRows').html(response);
			}
		});
		
	}
	function deleteFilter(name){
		if(confirm('Are you sure you want to delete this filter?')){
			$.ajax({
			type: "POST",
			url: "ajax/functions.php?act=deleteFilter",
			data: {
				'filterName': name
			},
			success: function (response) {
			   getFilterTable();
			}
		});
		}
		
	}
	function clearFilter(){
		$.post("ajax/functions.php?act=clearFilter" , {},function(){
			$("#activeFilterDisplay").html('None - <a href="#" id="filterLink" onClick="showManageFilters()"> Manage Filters</a>');
			$("#filterName").val('');
			$("#manageFilters").dialog("close");
		});
	}
	function applyFilter(filtername){
		$.post("ajax/functions.php?act=loadFilter" , { loadFilter: filtername },function(response){
			$("#activeFilterDisplay").html(response+'- <a href="#" id="filterLink" onClick="showManageFilters()"> Manage Filters</a>');
			$("#filterName").val('mqf_'+response);
			$("#manageFilters").dialog("close");
		});
	}
	function openFilters(){
		$('#manageFilters').dialog();
	}
	function showAddNew(){
		$("#tableContainer").hide();
		$("#manageFilters_addNew").show();
		return false;
		
	}
	function hideAddNew(){
		$("#tableContainer").show();
		$("#manageFilters_addNew").hide();
		$("#addNewForm")[0].reset();
		$("#levelFilter").hide();
		$("#affiliateFilter").hide();
		$("#loginFilter").hide();
		$("#emailStatusFilter").hide();
		$("#optinFilter").hide();
		$("#joinFilter").hide();
	}
	function submitAddNew(){
		$.ajax({
           type: "POST",
           url: 'ajax/functions.php?act=saveFilter',
           data: $("#addNewForm").serialize(), // serializes the form's elements.
           success: function(data){
			   getFilterTable();
			   hideAddNew();   
           }
         });
		
	}
	function showManageFilters(){
		getFilterTable();
		$("#manageFilters").dialog("open");
	}
	
	$(function() {
		$( "#manageFilters" ).dialog({
            autoOpen: false,
            show: "explode",
            hide: "explode",
			modal: true,
			width: '650',
			height:'auto'
        });
		$('#filterLink').click(function() {
			$("#manageFilters").dialog("open");
        	return false;
    });
		getFilterTable();
    });	