<?php
include_once('../../../../conn.php');
error_reporting(0);

// This is the init file to load the tinymce file editor.
// Some things must be set here to function properly.

// $folder is the layout folder. Used To Load Css Into The Editor.
$folder = $_GET['folder'];

// Becuase the editor resides in the admin dir, we need to set a base url.
// The base url defines where the particular editor content will be displayed.
// This is important when setting links, and images, ect ...
$base = $_GET['base']; 

// Basetype is used to define whether to use absolute links, or relative links.
// Relative Links are good for webpages, while absolute links must be used for html emails.
$basetype = $_GET['linktype']; // a for absolute, or r for relative
// This is used to turn off css inclusion.
$css = $_GET['css'];

if($_GET['css'] == 'no'){$css = 'no';}
else{$css = 'yes';}

header("content-type: application/x-javascript");
if(!isset($base) || $base == ''){echo "alert('error: no document base specified. Please Contact Support.');";}
?>
// JavaScript Document
tinyMCE.init({
        // General options
        mode : "textareas",
        theme : "advanced",
        valid_elements : '*[*]',
        width: "100%",
        relative_urls : <?php echo ($basetype == 'r')?'true':'false' ?>,
        remove_script_host : <?php echo ($basetype == 'r')?'true':'false' ?>,
        document_base_url : '<?php echo $base ?>',
        
        editor_deselector : "mceNoEditor",
        plugins : "autolink,lists,spellchecker,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,inlinepopups",
dialog_type : "modal",
        // Theme options
        theme_advanced_buttons1 : "undo,redo,|,styleprops,styleselect,formatselect,fontselect,fontsizeselect,|,bold,italic,underline,strikethrough",
        theme_advanced_buttons2 : "spellchecker,preview,|,justifyleft,justifycenter,justifyright,justifyfull,ltr,rtl,|,forecolor,backcolor,| ,bullist,numlist,|,outdent,indent,blockquote,blockquote,sub,sup,",
        theme_advanced_buttons3 : "fullscreen,code,|,link,unlink,anchor,|,image,media,|,emotions,iespell,insertdate,inserttime,charmap,nonbreaking,hr",
        theme_advanced_buttons4 : "attribs,|,insertlayer,moveforward,movebackward,absolute,|,tablecontrols,|,removeformat,visualaid,|,advhr,|,",
        theme_advanced_buttons5 : "search,replace,|,cut,copy,paste,pastetext,pasteword,,cleanup|,cite,abbr,acronym,del,ins,|,visualchars,template",
        theme_advanced_toolbar_location : "top",
        theme_advanced_toolbar_align : "left",
        theme_advanced_statusbar_location : "bottom",
        theme_advanced_resizing : true,
		
		//EMP File Manager
		
		relative_urls : false,
		convert_urls:false,
		file_browser_callback : EMPFileBrowser,

        // Skin options
        skin : "o2k7",
        skin_variant : "silver",
<?php if($css == 'yes'){ ?>
        // Example content CSS (should be your site CSS)
        content_css : "<?php echo str_replace( 'members/','',$base ) ?>common/css/styles.css, <?php if($folder){?><?php echo str_replace( 'members/','',$base ) ?>layout/<?php echo $folder ?>/style.css",<?php echo PHP_EOL;} ?>
		theme_advanced_font_sizes: "10px,12px,13px,14px,16px,18px,20px,22px,24px,26px,28px,30px,32px,34px,36px",
		font_size_style_values : "10px,12px,13px,14px,16px,18px,20px,22px,24px,26px,28px,30px,32px,34px,36px",
<?php } ?>

        // Replace values for the template plugin
        template_replace_values : {
                username : "Some User",
                staffid : "991234"
        }});

function toggleEditor(id) {
    if (!tinyMCE.get(id))
        tinyMCE.execCommand('mceAddControl', false, id);
    else
        tinyMCE.execCommand('mceRemoveControl', false, id);
}
function setMceWidth(id){
	document.getElementById(id+'_ifr').style.width='100%';
	document.getElementById(id+'_tbl').style.width='100%';
	
	}
	
	function EMPFileBrowser(field_name, url, type, win) {
	  var width = $(document).width();
	  var height = screen.height;
	  
	  var popwidth = (width * 0.8);
	  var popheight = (height * 0.6);
	  tinyMCE.activeEditor.windowManager.open({
	      
		  file : "<?php echo $chkSsettings->sSiteURL ?>/admin/common/efm/efm-browser.php?field=" + field_name + "&url=" + url + "&type=" + type +"",
	      title : 'EMP File Manager',
	      width : popwidth,
	      height : popheight,
	      resizable : "yes",
	      inline : "yes",
	      close_previous : "yes"
	  }, {
	      window : win,
	      input : field_name
	  });
	  return false;
	}