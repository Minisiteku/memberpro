<?php
	include_once ('../../../conn.php');
	include_once ('../../../functions.php');
	
	 
	$sql = " SELECT * FROM `tblfiles` WHERE stype = 'image/jpeg' OR stype = 'jpeg' OR stype = 'gif' OR stype = 'png'";
	$res = $dbo->select($sql);
	$js = 'var tinyMCEImageList = new Array(';
		
	while ($obj = $dbo->getobj($res)) {
			$js .= '
		["'.$obj->sFilename.'", "'.$sSiteURL.'/admin/assets'.$obj->sPath.$obj->sFilename.'"],';
	}
	$js = rtrim($js, ',').');';
	
	// Make output a real JavaScript file!
	header('Content-type: text/javascript'); // browser will now recognize the file as a valid JS file
	
	// prevent browser from caching
	header('pragma: no-cache');
	header('expires: 0'); // i.e. contents have already expired
	echo $js;
?>