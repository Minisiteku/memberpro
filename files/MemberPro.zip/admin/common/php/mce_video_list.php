<?php
	include_once ('../../../conn.php');
	include_once ('../../../functions.php');
	
	 
	$sql = " SELECT * FROM `tblvideos`;";
	$res = $dbo->select($sql);
	$js = 'var tinyMCEMediaList = new Array(
		// Name, URL';
	while ($obj = $dbo->getobj($res)) {
			$js .= '
		["'.$obj->sFileName.'", "'.$sSiteURL.'/videoprotect.php?id='.$obj->nVideo_ID.'"],';
	}
	$js = rtrim($js, ',').');';
	
	// Make output a real JavaScript file!
	header('Content-type: text/javascript'); // browser will now recognize the file as a valid JS file
	
	// prevent browser from caching
	header('pragma: no-cache');
	header('expires: 0'); // i.e. contents have already expired
	echo $js;
?>