<?php
include_once '../conn.php';
include_once '../functions.php';

// Add Coupon to database
if ( isset($_POST['add']) ) {
	
	$nExpiryDate = explode('/', $_POST['nExpiryDate']);
	$nExpiryDate = $nExpiryDate[2] . $nExpiryDate[0] . $nExpiryDate[1];

	$sql = "INSERT INTO tblcoupons (
	sCouponCode,
	nExpiryDate,
	nQtyAvailable,
	bActive
	) VALUES (
	'" . $dbo->format($_POST['sCouponCode']) . "',
	" . $nExpiryDate . ",
	" . $dbo->format($_POST['nQtyAvailable']) . ", 
	1
	)";		

	$dbo->insert($sql);
	
	$message = '<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>The coupon code was added successfully</div>';}

// Update Member Levels
if ( isset($_POST['Update']) ) {
	
	foreach ($_POST as $key=>$value) {
		if (substr($key, 0, 12) == 'sCouponCode_') {
			$sql = "UPDATE tblcoupons SET sCouponCode='" . $dbo->format($value) . "' WHERE nCoupon_ID=" . substr($key, 12);
			$dbo->update($sql);
		}
		if (substr($key, 0, 12) == 'nExpiryDate_') {
			$nExpiryDate = explode('/', $value);
			$nExpiryDate = $nExpiryDate[2] . $nExpiryDate[0] . $nExpiryDate[1];
			$sql = "UPDATE tblcoupons SET nExpiryDate='" . $dbo->format($nExpiryDate) . "' WHERE nCoupon_ID=" . substr($key, 12);
			$dbo->update($sql);
		}
		if (substr($key, 0, 14) == 'nQtyAvailable_') {
			$sql = "UPDATE tblcoupons SET nQtyAvailable='" . $dbo->format($value) . "' WHERE nCoupon_ID=" . substr($key, 14);
			$dbo->update($sql);
		}
	}
	
		// Update active/not active
		$sql = "UPDATE tblcoupons SET bActive=0";
		$dbo->update($sql);
		
		if (sizeof(($_POST['bActive']))) {	
			$values = implode(",", $_POST['bActive']);		
	
			$sql = "UPDATE tblcoupons SET bActive=1 WHERE nCoupon_ID IN (" . $values . ")";
			$dbo->update($sql);
			
			$message = '<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>Coupon codes have been updated successfully</div>';
		}
	}

?>


<html>
<head>
    <title>Coupon Codes</title>
	<?php include ('inc-head.php') ?>
	<!-- =========Added calendar in order to choose a date range -->
	<link type="text/css" rel="stylesheet" href="calendar/popcalendar.css">
	<script language="javascript" src="calendar/popcalendar.js"></script>
</head>

<body leftmargin="0" topmargin="0" rightmargin="0">
    <?php include_once 'top.php'; ?>

    <table cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once 'settingsleft.php'; ?></td>

            <td width="100%" align="left" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">

                <!-- NAVIGATION -->

                <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td class="navRow1" nowrap="nowrap">Coupons</td>
                    </tr>
                </table>
                
                <?php echo isset($message) ? $message : '' ?>

                <!-- ADD COUPON -->

                <form name="form1"  id="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                    <table class="gridTable" border="0" cellpadding="0" cellspacing="1" width="100%">
                    	<tr>
                            <td class="gridHeader" colspan="2">Add New Coupon</td>
                    	</tr>
                    	<tr>
                    		<td class="gridRow1" width="200">Coupon Code <font color="Red"> * </font> </td>
                    		<td class="gridRow1">
                    				<table cellspacing="0" cellspacing="0" border="0">
										<tr>
											<td><input type="text" name="sCouponCode" id="sCouponCode" class="required uppercase_number"  style="width: 200px;" maxlength="10" /></td><td><small>Must be capital letters and/or numbers only. Max of 10 characters. E.g. COUPON123</small></td>
										</tr>
									</table>
                    		</td>
						</tr>
						<tr>
                    		<td class="gridRow1" width="200">Expiry Date</td>
                    		<td class="gridRow1">
                    				<input type="text" name="nExpiryDate" id="nExpiryDate" class="date" style="width: 100px;" value="<?php echo date("m/d/Y", strtotime("+1 year")) ?>" />&nbsp;<small></small>
										<img src="calendar/images/calendar2.gif" border="0" onClick="popUpCalendar(this, document.getElementById('nExpiryDate'), 'mm/dd/yyyy')" style="cursor:pointer;" align="absmiddle" />
                    		</td>
						</tr>
						<tr>
                    		<td class="gridRow1" width="200">Qty Available <font color="Red"> * </font></td>
                    		<td class="gridRow1">
                    				<input type="text" name="nQtyAvailable" id="nQtyAvailable" style="width: 50px;" class="required digits" maxlength="4" value="0" /> <small>0 = Unlimited</small>
                    		</td>
						</tr>
					    <tr>
                     		<td colspan="2" class="gridFooter">
                         		<input type="submit" name="add" value="Add Coupon Code" class="inputSubmitb">
                     		</td>
                		</tr>
						</table>
                </form>
                
                <!-- Existing Member Level -->
                
                <form name="form2" id="form2" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <table class="gridTable" border="0" cellpadding="0" cellspacing="1" width="100%">
                <tr>
                	<td class="gridHeader" colspan="4">Existing Coupons</td>
                </tr>
                <tr>
                	<td class="gridHeader">Coupon Code</td>
					<td class="gridHeader" width="110" align="center">Expiry Date</td>    
    	        	<td class="gridHeader" width="100" align="center">Qty Available</td>
                	<td class="gridHeader" width="50" align="center">Active?</td>
                </tr>
				<?php
				$sql = "SELECT * FROM tblcoupons ORDER BY sCouponCode";
				$result = $dbo->select($sql);
				if ($result) {
					while ($row = $dbo->getobj($result)) {
						
						$checked = ($row->bActive) ? 'checked="checked"' : '';
						
						echo '
						<tr>
							<td class="gridrow1"><input type="text" name="sCouponCode_' . $row->nCoupon_ID . '" value="' . $row->sCouponCode . '" style="width: 200px;" class="required" /></td>
							<td class="gridrow1"><input type="text" name="nExpiryDate_' . $row->nCoupon_ID . '" id="nExpiryDate_' . $row->nCoupon_ID . '" value="' . substr($row->nExpiryDate, 4, 2) . '/' . substr($row->nExpiryDate, 6, 2) . '/' . substr($row->nExpiryDate, 0, 4) . '" style="width: 80px;" class="date" /> 
							<img src="calendar/images/calendar2.gif" border="0" onClick="popUpCalendar(this, document.getElementById(\'nExpiryDate_' . $row->nCoupon_ID . '\'), \'mm/dd/yyyy\')" style="cursor:pointer;" align="absmiddle" />
							</td>
							<td class="gridrow1"><input type="text" name="nQtyAvailable_' . $row->nCoupon_ID . '" value="' . $row->nQtyAvailable . '" style="width: 50px" class="digits" /></td>
							<td class="gridrow1" align="center"><input type="checkbox" name="bActive[]" value="' . $row->nCoupon_ID . '" ' . $checked . ' /></td>
						</tr>
						';
					}
					echo '<tr><td class="gridFooter" colspan="4"><input type="submit" name="Update" value="Update Coupon Codes" class="inputSubmitb"></td></tr>';
				}
				?>
                </table>
                </form>

            </td>
        </tr>
    </table><?php include_once 'b.php'; ?>
    <script type="text/javascript">

		jQuery.validator.addMethod("uppercase_number", function(value, element) { 
		  return /^[A-Z0-9]*$/.test(value); 
		}, "Coupon code must contain capital letters and numbers only");
		
		$(document).ready(function()
		{
			$("#form1").validate();
		});
		
		$(document).ready(function()
		{
			$("#form2").validate();
		});
	</script>
</body>
</html>
