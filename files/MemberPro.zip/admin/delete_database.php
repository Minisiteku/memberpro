<?php
	include_once('../conn.php');
	include_once('../functions.php');
	//include_once('inc_config.php');
	//include_once('inc_functions.php');
	
	if (isset($_POST['btnDelete'])) {
		if (!empty($_POST['del'])) {
			foreach ($_POST['del'] as $item) {
				unlink ('dump/'.$item);
			}
			$message = "<p class='success'>".count($_POST['del'])." file(s) deleted successfully</p>";
		}
	}
	
	function getBackupList() {
		$list = '';
		if ($handle = opendir('dump')) {
		    while (false !== ($file = readdir($handle))) {
		        if ($file != "." && $file != ".." && substr($file, strrpos($file,'.')+1) == 'gz') {
		            $list[] = $file;
		        }
		    }
		    closedir($handle);
		}
		if (!empty($list)) arsort($list);
		return $list;
	}

	
?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php include('inc-head.php') ?>
		<style>
			LABEL {cursor:pointer}	
		</style>
		<script language="javascript" type="text/javascript" >
			function confirmDelete() {
				// Make sure something is checked
				oEl = document.getElementsByTagName('input');
				var bSelect = false;
				for (i=0; i<oEl.length; i++) {
					if (oEl[i].type == 'checkbox' && oEl[i].id != 'checkAll') bSelect |= oEl[i].checked;
				}
				
				if (bSelect) return confirm("Are you sure you want to delete the selected files?");	
				else return false;
			}
			
			function setChecks() {
				var bCheck = document.getElementById('checkAll').checked;
				oEl = document.getElementsByTagName('input');
				for (i=0; i<oEl.length; i++) {
					if (oEl[i].type == 'checkbox') oEl[i].checked = bCheck;
				}				
			}
			
		</script>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0" onLoad="isReady=true">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
			<?php include_once('backupleft.php'); ?>
		</td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			<table class="navTable" width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="navRow1" width="100px"><span>Delete Backups</span></td>
				</tr>
			</table>
			
			<?php echo isset($message) ? $message : '' ?>
			
			<!-- START TABLE LISTING -->
			<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
				<tr>
					<td class="gridHeader">Available Database Backups</td>
				</tr>
				<tr>
					<td class="gridRow1">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<form method="post" action="delete_database.php" onSubmit="return confirmDelete()">
							<?php
								// Get the list of all tables from the database '$dbName'
								$back = getBackupList();	
								$cells = 4;							// Cells across (need to change cell width accordingly)
								if (!empty($back)) {	
									$i = 0;								
									foreach ($back as $item) {
										if ($i++ % $cells == 0) {
											if ($i == 1) 	echo "<tr>";
											else echo "</tr><tr>";
										}
										echo sprintf("<td class='gridRow1' style='width:25%%'><input type='checkbox' name='del[]' value='%s' id='%s' style='margin-bottom:0px; margin-right:5px'><label for='%s'>%s</label></td>", $item, $item, $item, $item);
									}	
									// Fill in missing table cells								 
									$start = ($i - intval($i / $cells) * $cells);
									if ($start > 0)
										for ($j = $start + 1; $j < $cells+1; $j++) echo "<td class='gridRow1'>&nbsp;</td>";
									echo "</tr>";									
								} else {
									echo "<div class='success' style='text-align:center; padding-top:5px; padding-bottom:8px'>No Backups Found.</div>";
								}
							?>
							<tr>
								<td colspan="4" class="gridHeader">
									<input type="submit" name="btnDelete" value="Delete">
									<input type="checkbox" id="checkAll" style="margin-left:10px" onClick="setChecks()">
									<label for="checkAll" style="padding-left:3px">Select All</label>
								</td>
							</tr>
							</form>
						</table>
					</td>
				</tr>
				<tr>
					<td class="gridFooter">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td valign="top"></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>
	</body>
</html>