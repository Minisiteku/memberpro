<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	function getRootFolder($folderId){
					
					if($folderId == '0' || $folderId == '1') return $folderId;
					
					// This is a sub folder.
					$parentId = $dbo->getval("SELECT nParent_ID FROM tbldirectories WHERE nDirectory_ID = '$folderId';");
					
					if($parentId == '0' || $parentId == '1') return $parentId;
					
					// This is a second sub folder
					$subparentId = $dbo->getval("SELECT nParent_ID FROM tbldirectories WHERE nDirectory_ID = '$parentId';");
					
					if($subparentId == '0' || $subparentId == '1') return $subparentId;
					else{
						
						// Something went wrong!
						die('something went wrong.');
						
						
					}
						
				}

	$ipp = (!empty($_GET['ipp'])) ? $_GET['ipp'] : 10;							// Items per Page
	$sort = (!empty($_GET['sort'])) ? $_GET['sort'] : 'nDirectory_ID';
	$sortdir = (!empty($_GET['sortdir'])) ? $_GET['sortdir'] : 'ASC';
	$start = (!empty($_GET['start'])) ? $_GET['start'] : 0;	

	// Set QueryString Values after post
	if (isset($_POST['Update'])) {
		$ipp = $_POST['ipp'];
		$sort = $_POST['sort'];
		$sortdir = $_POST['sortdir'];
		$start = $_POST['start'];
	}

	// Setup Options for Items per Page listing
	$aIPP = array('5', '10', '15', '20', '25', '50', '100');

	// Get Membership Levels
	$sql = "SELECT * FROM tblmembershiplevels ORDER BY nOrder ASC , sLevel ASC";
	$rs = $dbo->select($sql);
	if(!empty($rs)){
		while ($row = $dbo->getarray($rs)){$aLevel[] = $row;}
	}

	// Set directories that can't be deleted
	$nodelete = array('member');

 	$nopay = array('home', 'support', 'affiliates', 'profile-edit', 'affiliateemails', 'creport', 'graphics', 'sendemail', 'faq', 'contact', 'changepassword');


	/***************************/
	/*     Process Folder Actions		*/
	/***************************/
	//Add New Folder 
	if(isset($_POST['add_new_folder']))
	{
		// Process newFolder data, and remove invalid characters
		$invalids = '\'';
		
		$newFolder = str_replace($invalids,'',$_POST['newFolder']);
		
		
		$sql = "SELECT nLevel_ID FROM tbldirectories WHERE nDirectory_ID='" . $dbo->format($_POST["parentFolder"]) . "'";
		$rs = $dbo->select($sql);		
		$row = $dbo->getobj($rs);
		
		$sql2 = "SELECT nDirectory_ID FROM tbldirectories WHERE sDirectoryName = '".$dbo->format($newFolder)."' and nParent_ID='" . $dbo->format($_POST["parentFolder"]) . "'";
		$rs2 = $dbo->select($sql2);
		if (!empty($rs2)) 
			$message = "<span class='error'>Folder name already exists.  Please specify a new name.</span>";
		else {
		$sql = "insert into tbldirectories values('','" . $dbo->format($newFolder) . "','" . $dbo->format($newFolder) . "','" . ($row->nLevel_ID+1) . "','1','0','" . $dbo->format($_POST["parentFolder"]) . "')";
		$dbo->insert($sql, 1);
		$message = "<p class='success'>Folder has been added.</p>";
		}
	}
	
	// Update Folder
	if (isset($_POST['edit_folder']) && $_GET['act']=='modify' && isset($_GET['folderID'])) {
		
		if($_POST["parentFolder"]== $_GET['folderID']) $message = "<p class='success'>You can not add a folder to its own.</p>";
		else {
			
			// Update Directory Name
			$sql = "SELECT nLevel_ID FROM tbldirectories WHERE nDirectory_ID='" . $dbo->format($_POST["parentFolder"]) . "'";
			$rs = $dbo->select($sql);		
			$row = $dbo->getobj($rs);
			
			// Process newFolder data, and remove invalid characters
			$invalids = '\'';
		
			$newFolder = str_replace($invalids,'',$_POST['newFolder']);
				
			// hate this sprintf .. unnessessary. mysql uses its own type casting!
			/*$sql = sprintf("
			UPDATE tbldirectories 
			SET sDirectoryName = '%s', sDirectoryPath = '%s', nParent_ID = '%d' , nLevel_ID='%d'
			WHERE nDirectory_ID = '%s'", $dbo->format($newFolder), strtolower(str_replace(" ", "", $dbo->format($newFolder))),$dbo->format($_POST["parentFolder"]) ,($row->nLevel_ID+1),$dbo->format($_GET['folderID'])); */
				
			$sql = "
			UPDATE tbldirectories
			SET sDirectoryName = '".$dbo->format($newFolder)."', 
			sDirectoryPath = '".strtolower(str_replace(" ", "", $dbo->format($newFolder)))."', 
			nParent_ID = '".$dbo->format($_POST["parentFolder"])."' , 
			nLevel_ID='".($row->nLevel_ID + 1) ."' 
			WHERE nDirectory_ID = '".$dbo->format($_GET['folderID'])."'
			";
			//die($sql);
			$dbo->update($sql);
				
			// Need To Check If Directory Was Moved From Member to Main.
			// If so, any pages contained inside need to have level access rights removed.
				
			// Dont Forget Folders Go 3 Deep so we need to check parents up to 3 levels.
			// Main Id = 0, Member Id = 1 Both have parent of -1

			// New Folder Parent
			$newParent = $dbo->format($_POST["parentFolder"]);
				
				
			// Looking to see if new parent is associated with main or member.
				
			//die(var_dump(getRootFolder($newParent)));
				
			if(getRootFolder($newParent) == '0')
			{
					
					// This folder is going to the main directory!
					// Remove The Rights!
					$pids = '';
					
					$sql = "SELECT nPage_ID from tblpages WHERE nDirectory_ID = '".$dbo->format($_GET['folderID'])."';";
					$res = $dbo->select($sql);
					
					if($dbo->nr($res) >= 1)
					{
						
						while($row = $dbo->getobj($res)) $pids .= ' '.$row->nPage_ID.',';
						
						// Remove last comma.
						
						$pids = substr_replace($pids ,"",-1);
						
						// Lets Delete Em!
						$sql = "DELETE FROM tblpagelevels WHERE nPage_ID IN (".$pids." )";
						//die($sql);
						$dbo->delete($sql);
					}
					
				}
				
			$message = "<p class='success'>Folder has been updated.</p>";
		}
	}
	
	// DELETE FOLDER
	if ($_GET['act'] == 'del') {
		
		$sql = "SELECT nLevel_ID FROM tbldirectories WHERE nDirectory_ID='" . $dbo->format($_GET["did"]) . "'";
		$rs = $dbo->select($sql);		
		if(!empty($rs))
		$row = $dbo->getobj($rs);
		
		//if this directory has level 1
		if($row->nLevel_ID=='1')
		{		
				//Take the id of his childs folders , level 2
				$sql2 = "SELECT nDirectory_ID FROM tbldirectories WHERE nParent_ID='" . $dbo->format($_GET["did"]) . "' and nLevel_ID='2'";
				
				$rs2 = $dbo->select($sql2);		
				if(!empty($rs2))
				while($row2 = $dbo->getobj($rs2))
					$childFolders[]=$row2->nDirectory_ID;
				
				//delete childs pages for child folders
				$childFoldersId=implode(',',$childFolders);
				$sql3 = "delete FROM tblpages WHERE nDirectory_ID in (".$childFoldersId.")";
				$rs3 = $dbo->delete($sql3);						
				
				//delete his child folder , level2
				$sql4 = "DELETE FROM tbldirectories WHERE nDirectory_ID in (".$childFoldersId.")";
				$rs4 = $dbo->select($sql4);		

							
		}

		
		//delete childs pages for main folder
		$sql5 = "DELETE FROM tblpages WHERE nDirectory_ID ='".$dbo->format($_GET['did'])."'";
		$rs5 = $dbo->delete($sql5);	
		
		//delete main folder
		$sql = sprintf("DELETE FROM tbldirectories WHERE nDirectory_ID = '%s'", $dbo->format($_GET['did']));
		$dbo->delete($sql);
		$message = "<p class='success'>Folders and pages have been removed.</p>";
	}
	
	// UPDATE DIRECTORY DISPLAY
	if ($_GET['act'] == 'display') {
		$sql = sprintf("UPDATE tbldirectories SET bDisplay= '%s' WHERE nDirectory_ID = '%s'", $dbo->format($_GET['display']), $dbo->format($_GET['did']));		
		$dbo->update($sql);
	}
	
	// UPDATE MEMBERSHIP LEVEL
	if ( isset($_POST['Update']) ) {
		$dd = $_POST['dd'];				// nPage_ID
		$disp = $_POST['disp'];
		$mLvl = $_POST['mlevel'];		// nLevel_ID
		for ($i = 0; $i < count($_POST['dd']); $i++) {
			$sql = sprintf("UPDATE tbldirectories 
									SET nSortOrder = '%s'
									WHERE nDirectory_ID = '%s'", $dbo->format($disp[$i]), $dbo->format($dd[$i]));
			$dbo->update($sql);
		}
	}		

?>
<html>
		<head>
		<title><?php echo $admintitle; ?></title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" type="text/css" href="common/css/styles.css" />
		<style>
.iconspacing {
	margin-right:2px
}
</style>
		<?php include("inc-head.php"); ?>
		<script type="text/javascript">
			function show(id)
			{
				if(document.getElementById(id))
						document.getElementById(id).style.display="";
				oForm = document.forms.formNewFolder;
				oForm.action="";
				oForm.submitBut.value="Add";
				oForm.parentFolder.selectedIndex='0';
				oForm.newFolder.value = "";
				document.getElementById('add_new_folder').name="add_new_folder";
			}
			function cdel(w) {
				var sMsg = "Are you sure you want to DELETE the directory\""+w+"\" \nand all the pages in it?";
				return confirm(sMsg);
			}
			
			function editDirectory(nID, sName,parentID) {
				if(document.getElementById('new_folder_div'))					
					document.getElementById('new_folder_div').style.display="";
				oForm = document.forms.formNewFolder;
				
				oForm.newFolder.value = sName;	
				for (opt in oForm.parentFolder.options)
				{
					
					if(oForm.parentFolder.options[opt].value==parentID)
					{
						rightindex=opt;
						break;
					}
				}		
				oForm.parentFolder.selectedIndex=rightindex;
				oForm.submitBut.value="Update";
				oForm.action="directory_management.php?act=modify&folderID="+nID;				
				document.getElementById('add_new_folder').name="edit_folder";
				oForm.newFolder.focus();
				
			}

			function openPopup(page) {	
				window.open(page,'','height=265,width=650,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=yes');
			}
			
			function MM_openBrWindow(theURL,winName,features) {
				window.open(theURL,winName,features);
			}
			
			function updateIPP(oList) {
				var ipp = oList.options[oList.selectedIndex].value;
				var qs = '?start=0';
				qs += '&sort=<?php echo $sort ?>';
				qs += '&sortdir=<?php echo $sortdir ?>';
				qs += '&ipp=' + ipp;
				document.location = 'page_management.php' + qs;
			}
		</script>
		</head>
		<body leftmargin="0" topmargin="0" rightmargin="0">
<!-- Include Navigation -->
<?php include_once('top.php'); ?>

<!-- Start Content -->
<table cellpadding="0" cellspacing="0" width="100%">
			<tr> 
		<!-- START LEFT SIDE -->
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once('pageleft.php'); ?></td>
		<!-- START RIGHT SIDE -->
		<?php
			$option=getFolders();
			//Put together QueryString
			$qs = sprintf("?start=%s&ipp=%s", $start, $ipp);			
		?>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%"><table class="navTable" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td width="10%" nowrap="nowrap" class="navRow1">Folder Management</td>
				</tr>
			</table>
					<?php echo isset($message) ? $message : '' ?> 
					<!-- Version 3 Table Clean Up And Rebuild. Previous verion messy ... -->
					
					<div style="color:navy">NOTE: Any active folder with at least 1 active page will appear in the menu as a drop-down</div>
					
					<!-- Folder New / Edit Form -->
					
					<div id="new_folder_div" style="display:none">
				<form action="" method="POST" id="formNewFolder">
							<table class="gridTable" width="100%" cellpadding="0" cellspacing="1">
						<tr >
									<td class="gridHeader" colspan="2">&nbsp;</td>
								</tr>
						<tr>
									<td class="gridRow1" width="20%"> Folder Name : </td>
									<td class="gridRow1"><input type="text" name="newFolder" class="required" /></td>
								</tr>
						<tr>
									<td class="gridRow1">Folder Parent : </td>
									<td class="gridRow1"><select name="parentFolder">
											<?php echo generateTreeFolder('','disabled');?>
										</select></td>
								</tr>
						<tr>
									<td class="gridRow1" colspan="2"><input type="submit" name="submitBut" id="submitBut" value="Add" />
								<input type="hidden" name="add_new_folder" id="add_new_folder" /></td>
								</tr>
					</table>
						</form>
			</div>
					<form name="form1" method="post" action="directory_management.php">
				<input type="hidden" name="ipp" value="<?php echo $ipp?>" />
				<input type="hidden" name="sort" value="<?php echo $sort?>" />
				<input type="hidden" name="sortdir" value="<?php echo $sortdir?>" />
				<input type="hidden" name="start" value="<?php echo $start?>" />
				<input type="hidden" name="Update" value="1" />
				<table class="gridTable" cellpadding="0" cellspacing="1px" width="100%">
							<tr>
						<td class="gridHeader">Folder <a href="javascript:void(0)" onClick="show('new_folder_div')" > <img  style="margin-bottom:-9px;" src="images/folder_add.png" alt="Add Folder" title="Add Folder" border="0"/> </a></td>
						<td class="gridHeader">Page Count</td>
						<td class="gridHeader">Sort Order</td>
						<td class="gridHeader">Actions</td>
					</tr>
							<?php foreach ($option as $row  ){ ?>
							<tr>
						<td class="gridrow1"><?php
	if($row['nLevel_ID']=='1')echo "<img src='images/line.png' />";
	elseif($row['nLevel_ID']=='2')echo "<img src='images/line2.png' />"; ?>
									<a href='page_management.php?did=<?php echo $row['nDirectory_ID']?>&start=0'><?php echo $row['sDirectoryName']?></a></td>
						<td class="gridrow1"><?php echo $row['pagecount'] ?></td>
						<td class="gridrow1"><span class="blue">
							<input name="disp[]" type="text" class="box" size="3" value="<?php echo $row['nSortOrder'] ?>" />
							<input type="hidden" name="dd[]" value="<?php echo $row['nDirectory_ID']; ?>" />
							</span></td>
						<td class="gridrow1"><!-- Display -->
									
									<?php if ($row['bDisplay']) : ?>
									<a href="directory_management.php<?php echo $qs ?>&display=0&did=<?php echo $row['nDirectory_ID'] ?>&act=display" class="bluenew" title="Display Page"> <img src="images/disp.jpg" alt="Display Page" width="16" height="16" border="0" class="iconspacing"></a>
									<?php else : ?>
									<a href="directory_management.php<?php echo $qs ?>&display=1&did=<?php echo $row['nDirectory_ID'] ?>&act=display" class="bluenew"  title="Don't Display"><img src="images/ddisp.jpg" alt="Don't Display" width="16" height="16" border="0" class="iconspacing"></a>
									<?php endif; ?>
									
									<!-- Delete -->
									
									<?php if ($row['nDirectory_ID'] <= 4){ ?>
									<img src="images/dropd.gif" alt="Cannot Delete this Page" width="16" height="16" border="0" />
									<?php }else{?>
									<a href="directory_management.php<?php echo $qs ?>&did=<?php echo $row['nDirectory_ID'] ?>&act=del" class="bluenew" OnClick="return cdel('<?php echo $row['sDirectoryName'] ?>');" title="Delete Directory"><img src="images/drop.jpg" alt="Delete Page" width="16" height="16" border="0" class="iconspacing"></a>
									<?php } ?>
									
									<!-- Edit -->
									
									<?php if($row['nLevel_ID']!='0'){?>
									<a href="#" title="Edit Directory" onClick="editDirectory(<?php echo $row['nDirectory_ID']?>, '<?php echo $row['sDirectoryName'] ?>','<?php echo $row['nParent_ID']?>')"> <img src="images/edit.jpg" alt="Edit Directory" width="16" height="16" border="0" class="iconspacing"></a>
									<?php } ?></td>
					</tr>
							<?php } ?>
							<tr>
						<td class="gridFooter" colspan="4"><input type="submit" value="Update Sort" /></td>
					</tr>
						</table>
			</form>
					<?php /*    
                            <tr valign="top"> 
                                      <!-- Directory Name -->
                                      <td style="height:25px; line-height:25px; text-align:left; vertical-align:middle" class="gridHeader"><?php $sd = ($sort=='sDirectoryName' && $sortdir=='ASC') ? 'DESC' : 'ASC'; ?>
                                Folder Name &nbsp;&nbsp; 
                        
                        <form name="directoryadd" method="post" action="directory_management.php">
                                  <a href="javascript:void(0)" onClick="show('new_folder_div')" > <img  style="margin-bottom:-9px;" src="images/folder_add.png" alt="Add Folder" title="Add Folder" border="0"/> </a>
                                </form></td>
                              <!-- Action -->
                              <td style="text-align:left; padding-left:20px; vertical-align:middle" class="gridHeader">Action</td>
                              <!-- Sort Order -->
                              <td align="center" valign="middle" class="gridHeader"><?php $sd = ($sort=='nSortOrder' && $sortdir=='ASC') ? 'DESC' : 'ASC'; ?>
                        <a href="directory_management.php<?php echo $qs?>&sort=nSortOrder&sortdir=<?php echo $sd?>" class="bluenave">Sort Order</a></td>
                              <!-- PageCount -->
                              <td align="center" valign="middle" class="gridHeader"><?php $sd = ($sort=='pagecount' && $sortdir=='ASC') ? 'DESC' : 'ASC'; ?>
                        <a href="directory_management.php<?php echo $qs?>&sort=pagecount&sortdir=<?php echo $sd?>" class="bluenave">Page Count</a></td>
                              <!--
																<td align="center" valign="middle" class="gridHeader">
																	<?php $sd = ($sort=='nLevel_ID' && $sortdir=='ASC') ? 'DESC' : 'ASC'; ?>
																	<a href="directory_management.php<?php echo $qs?>&sort=nLevel_ID&sortdir=<?php echo $sd?>" class="bluenave">Membership Level</a>
																</td>
																--> 
                            </tr>
                    <?
																// Add Sort to QueryString
																$qs .= sprintf("&sort=%s&type=%s", $_GET['sort'], $_GET['sortdir']);
															?>
                    <?php foreach ($option as $row  ){ ?>
                    
                    <!-- DIRECTORY LISTING -->
                    <tr valign="top"> 
                              <!-- Directories -->
                              <td style="height:25px; vertical-align:middle" class="gridRow1">
							  
							  <?php
					if($row['nLevel_ID']=='1')echo "<img src='images/line.png' />";
					elseif($row['nLevel_ID']=='2')echo "<img src='images/line2.png' />"; ?>
																	
					<a href='page_management.php?did=<?php echo $row['nDirectory_ID']?>"&start=0'><?php echo $row['sDirectoryName']?></a>
					</td>
                              <!-- Actions -->
                              <td  style="text-align:left; padding-left:20px"  class="gridRow1"><!-- Edit -->
                        
                        <?php if($row['nLevel_ID']!='0'){?>
                        <a href="#" title="Edit Directory" onClick="editDirectory(<?php echo $row['nDirectory_ID']?>, '<?php echo $row['sDirectoryName']?>','<?php echo $row['nParent_ID']?>')"><img src="images/edit.jpg" alt="Edit Directory" width="16" height="16" border="0" class="iconspacing"></a>
                        <?php }else {echo "&nbsp;&nbsp;&nbsp;&nbsp;";}?>
                        
                        <!-- Delete -->
                        
                        <?php if (in_array($row['sDirectoryName'], $nodelete)) : ?>
                        <img src="images/dropd.gif" alt="Cannot Delete this Page" width="16" height="16" border="0" />
                        <?php else : ?>
                        <a href="directory_management.php<?php echo $qs ?>&did=<?php echo $row['nDirectory_ID'] ?>&act=del" class="bluenew" OnClick="return cdel('<?php echo $row->sDirectoryName?>');" title="Delete Page"><img src="images/drop.jpg" alt="Delete Page" width="16" height="16" border="0" class="iconspacing"></a>
                        <?php endif; ?>
                        
                        <!-- Display -->
                        
                        <?php if ($row['bDisplay']) : ?>
                        <a href="directory_management.php<?php echo $qs ?>&display=0&did=<?php echo $row['nDirectory_ID'] ?>&act=display" class="bluenew" title="Display Page"> <img src="images/disp.jpg" alt="Display Page" width="16" height="16" border="0" class="iconspacing"></a>
                        <?php else : ?>
                        <a href="directory_management.php<?php echo $qs ?>&display=1&did=<?php echo $row['nDirectory_ID'] ?>&act=display" class="bluenew"  title="Don't Display"><img src="images/ddisp.jpg" alt="Don't Display" width="16" height="16" border="0" class="iconspacing"></a>
                        <?php endif; ?></td>
                              <!-- SORT ORDER -->
                              <td align="center" valign="middle" class="gridRow1"><span class="blue">
                                <input name="disp[]" type="text" class="box" size="3" value="<?php echo $row['nSortOrder'] ?>" />
                                <input type="hidden" name="dd[]" value="<?php echo $row['nDirectory_ID']; ?>" />
                                </span></td>
                              <!-- Pagecount -->
                              <td style="height:25px; text-align:center; vertical-align:middle" class="gridRow1"><?php echo $row['pagecount'] ?></td>
                              <!-- MEMBERSHIP LEVEL --> 
                              <!--
																<td align="center" valign="middle" class="gridRow1">
																	<span class="blue">
																		<select name="mlevel[]">
																			<?php
																				foreach ($aLevel as $item) {
																					$selected = ($row->nLevel_ID == $item['nLevel_ID']) ? 'selected' : '';
																					echo sprintf("<option value='%d' %s>%s</option>", $item['nLevel_ID'], $selected, $item['sDescr']);
																				}		
																			?>
																		</select>
																		<input type="hidden" name="dd[]" value="<?php echo $row->nDirectory_ID; ?>" />
																	</span>
																</td>
																--> 
                            </tr>
                    <?php } ?>
                    <tr><td colspan="4"><input type="submit" name="Update" value="Save Changes" class="inputSubmitb" ></td></tr>
                  </table> */ ?></td>
	</tr>
		</table>
<?php include_once('b.php'); ?>
<script type="text/javascript">				
$(document).ready(function() {
	$("#formNewFolder").validate();
});
</script>
</body>
</html>