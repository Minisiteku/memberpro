<?php
require_once '../conn.php';
require_once '../functions.php';

if (!isset($_GET["id"]) || !is_numeric($_GET["id"]) || !isset($_GET['did']) || !is_numeric($_GET['did'])) {die("Invalid page or directory ID");}

if($_SESSION['errors']){foreach($_SESSION['errors'] as $k=>$v){
	if($k == 'pagelevels'){$sessionpagelevels = $v;}
	else{$$k = $v;}
//die(var_dump($_SESSION['form']));	
	}}
// Get Page Content
$sql = pluginClass::filter("page_edit_page_query","SELECT * FROM tblpages WHERE nPage_ID = '" . $dbo->format($_GET['id']) . "';");
$rw1 = $dbo->getobject($sql);
if (is_object($rw1)) {
    // Get membership levels
	if(!isset($sessionpagelevels)){
		$res = $dbo->select("SELECT nLevel_ID FROM tblpagelevels WHERE nPage_ID = '".$rw1->nPage_ID."'; ");
	if(!empty($res)){
		while($rw2 = $dbo->getobj($res)){$pagelevels[] = $rw2->nLevel_ID;}
		}
	else{$pagelevels[] = '';}
		}
	
	//die(var_dump($pagelevels));
	//die("SELECT nLevel_ID FROM tblpagelevels WHERE nPage_ID = '".$rw1->nPage_ID."'; ".var_dump($pagelevels));
	if ($rw1->nDirectory_ID != 0) {
        $rwd = $dbo->getobject("SELECT * FROM tbldirectories WHERE ndirectory_id = '" .
            $rw1->nDirectory_ID . "';");
        $path = '../' . $rwd->sDirectoryPath;
    } 
	else {$path = '../';
    }
    $_POST["sType"] = explode(",", $rw1->sType);}
// Lets Build Existing Video List
$sql = "SELECT * FROM tblvideos";
$res = $dbo->select($sql);
if($res){
	while($row = $dbo->getobj($res)){
		$selects .= '<option value="[[video '.$row->nVideo_ID.']]" id="'.$row->sFileName.'">'.$row->sFileName.'</option>'."\n";
		}
	}
$tplFolder = TEMPLATEFOLDER;
?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
        <meta charset="utf-8" />
		<?php include "inc-head.php"; ?>
		<style>
.iconspacing {
	margin-right:2px
}
</style>
		<script type="text/javascript">
		
		function insMergeCode() {
			oList = document.getElementById('category');
			if (oList.selectedIndex == 0) return;
			var sCode = oList.options[oList.selectedIndex].value;
		    oUtil.obj.insertHTML(sCode)
		}
		function disable_enable_nUnavailableForJoinedAfter() {

if(document.form1.nUnavailableForJoinedAfter_checkbox.checked)
{
document.form1.nUnavailableForJoinedAfter_month.disabled=false;
document.form1.nUnavailableForJoinedAfter_year.disabled=false;
}

else
{
document.form1.nUnavailableForJoinedAfter_month.disabled=true;
document.form1.nUnavailableForJoinedAfter_year.disabled=true;
}}
		function toggle(ele,set){
		
			if(set == 'emailoption'){
				if(ele.checked == 1){
					document.getElementById('sendemailtext').style.display = 'block';
					document.getElementById('sendemailbody').style.display = 'block';
				}
				else{
					document.getElementById('sendemailtext').style.display = 'none';
					document.getElementById('sendemailbody').style.display = 'none';
				}
			}
		}
		function setDirectoryAction(sAction) {
			oForm = document.forms.form1;
		 	oList = document.getElementById('directory');
		 	if (oList.selectedIndex == 0 || oList.options[oList.selectedIndex].value == <?php echo
$_GET['did']; ?>) {
		 		alert ("Nothing to do!");
		 		return;
		 	}
		 	oForm.directoryaction.value = sAction;
		 	oForm.directorynew.value = oList.options[oList.selectedIndex].value;
		 	oForm.submit();
		}
	</script>
    <script type="text/javascript" src="common/js/tiny_mce/tiny_mce.js"></script>
<!-- Load Queue widget CSS and jQuery -->
<style type="text/css">
@import url(../includes/plupload/js/jquery.plupload.queue/css/jquery.plupload.queue.css);
</style>


<!-- Third party script for BrowserPlus runtime (Google Gears included in Gears runtime now) -->
<script type="text/javascript" src="http://bp.yahooapis.com/2.4.21/browserplus-min.js"></script>

<!-- Load plupload and all it's runtimes and finally the jQuery queue widget -->
<script type="text/javascript" src="../includes/plupload/js/plupload.full.js"></script>
<script type="text/javascript" src="../includes/plupload/js/jquery.plupload.queue/jquery.plupload.queue.js"></script>
<script type="text/javascript" language="JavaScript">
var IE = false;
</script>
<![if IE]>
<script type="text/javascript"> IE = true;</script>
<![endif]>
<script type="text/javascript">
function disable_enable_nUnavailableForJoinedAfter(){
	if(document.form1.nUnavailableForJoinedAfter_checkbox.checked){
		document.form1.nUnavailableForJoinedAfter_month.disabled=false;
		document.form1.nUnavailableForJoinedAfter_year.disabled=false;
	}
	else{
		document.form1.nUnavailableForJoinedAfter_month.disabled=true;
		document.form1.nUnavailableForJoinedAfter_year.disabled=true;}
	}
function videoaction(){
	
	if($('#videoact').val() == "new"){
		$('#newsel').show();
		$('#existingvids').attr('selectedIndex', 0).hide();
		}
	else if($('#videoact').val() == "existing"){
		
		$("#newsel").attr('selectedIndex', 0).hide();
		$('#existingvids').show();
		$('#remote').hide();
		$('#uploader').hide()
		}
	else{
		$("#newsel").attr('selectedIndex', 0).hide();
		$('#existingvids').attr('selectedIndex', 0).hide();
		$('#remote').hide();
		$('#uploader').hide()
		// Clear Select Values
		
		}
	}
function newVideoOpt(){
	
	if($('#newsel').val() == 'upload'){
		//document.getElementById('uploader').style.display = 'block';
		$('#remote').hide();
		$('#uploader').show()
		
		$('#uploader').pluploadQueue({
		// General settings
		runtimes : 'gears,flash,silverlight,browserplus,html5',
		url : 'ajax/video_upload.php',
		max_file_size : '10000mb',
		chunk_size : '1mb',
		

		// Resize images on clientside if we can
		//resize : {width : 320, height : 240, quality : 90},

		// Specify what files to browse for
		filters : [
			{title : "Video files", extensions : "flv,mp4,mov"}
		],

		// Flash settings
		flash_swf_url : '../includes/plupload/js/plupload.flash.swf',

		// Silverlight settings
		silverlight_xap_url : '../includes/plupload/js/plupload.silverlight.xap',
		
		// PreInit events, bound before any internal events
		preinit : {
		},

		// Post init events, bound after the internal events
		init : {
			FileUploaded: function(up, file, response) {
				// Called when a file has finished uploading
				var obj = jQuery.parseJSON(response.response);
				console.log("my object: %o", obj)
				document.getElementById('uploader').style.display = 'none';
				document.getElementById('embedTable').style.display = 'block';
				var curhtml = document.getElementById('embedCodes').innerHTML;
				var newhtml = '[[video '+obj.id+']] - '+obj.name+'<br />';
				document.getElementById('embedCodes').innerHTML = newhtml;
				if(IE == true){tinyMCE.activeEditor.execCommand("mceInsertRawHTML", false, ele.value);tinyMCE.activeEditor.focus();}
				else{tinyMCE.activeEditor.selection.setContent(ele.value);}
			},

			Error: function(up, args) {
				// Called when a error has occured
				//alert('[error] '+ args);
			}
		}
	});
	
		// Client side form validation
		$('#uploaderForm').submit(function(e) {
        var uploader = $('#uploader').pluploadQueue();
		
		uploader.init();
		uploader.bind('FilesAdded', function(up, files) {
});

        // Files in queue upload them first
        if (uploader.files.length > 0) {
            // When all files are uploaded submit form
            uploader.bind('StateChanged', function() {
                if (uploader.files.length === (uploader.total.uploaded + uploader.total.failed)) {
					$('form')['name'].submit();
                }
            });
			uploader.start();
        } else {
            alert('You must queue at least one file.');
        }

        return false;
    });
	return;
		}
	if(document.getElementById('newsel').value=='remote'){
		$('#remote').show();
		$('#uploader').hide();
		}
	else{
		$('#remote').hide();
		$('#uploader').hide()
		}
	
	}	
function getExistingEmbed(ele){
	var ele2 = document.getElementById('embedCodes');
	document.getElementById('embedTable').style.display = 'block';
	
	var curhtml = ele2.innerHTML;
	if(curhtml.indexOf(ele.options[ele.selectedIndex].id) == -1){
		var newhtml = curhtml+'<span>'+ele.value+' - '+ele.options[ele.selectedIndex].id+'</span><br />';
	if(IE == true){tinyMCE.activeEditor.execCommand("mceInsertRawHTML", false, ele.value);tinyMCE.activeEditor.focus();}
	else{tinyMCE.activeEditor.selection.setContent(ele.value);}
	ele2.innerHTML = newhtml;}}
function addRemote(){
	//var dataString = 'sVideoURL='+ remoteVideo.elements["sVideoURL"].value;
    var dataString = "sVideoURL=" + $("#sVideoURL").val();
  $.ajax({
    type: "POST",
    url: "ajax/video_remote.php",
    data: dataString,
    success: function(response) {
      console.log( response );
	  var obj = jQuery.parseJSON(response);
	  if(obj.error){
		  console.log( obj.error);
		  $('#ajaxError').html(obj.error.message);
		  }
	  else{
		  console.log( obj );
	  $('#remote').hide()
	  $('#embedTable').show()
	  $('#embedCodes').append(obj.data.message+'<br />');
	  $("#newsel").attr('selectedIndex', 0);
	  $("#sVideoURL").val('');
	  if(IE == true){tinyMCE.activeEditor.execCommand("mceInsertRawHTML", false, '[[video '+obj.id+']]');tinyMCE.activeEditor.focus();}
	else{tinyMCE.activeEditor.selection.setContent('[[video '+obj.id+']]');}
		  }
	  
	  
    }
  });
  return false;
	}
function updateLinkName(ele){
	
	document.getElementById('pagename').innerHTML = ele.value.replace(/\s/g, "");
}	
</script>
<?php
	if(get_option('use_mce') == '1'){
		$doc_base = $chkSsettings->sSiteURL .'/';
		if(usePageLevels($_GET['did'])){$doc_base .= 'member/';}
?>
<script type="text/javascript" src="common/js/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="common/js/tiny_mce/init.php?folder=<?php echo $tplFolder ?>&base=<?php echo $doc_base  ?>&linktype=r"></script>
<?php } ?>
</head>
<body leftmargin="0" topmargin="0" rightmargin="0" onLoad="setMceWidth('txtContent')">
<?php include_once 'top.php'; ?>
<div style="padding:10px;">
  <h1>Edit Page</h1>
  <?php echo isset($message) ? $message : '' ?>
  <div style="line-height: 1em; margin-bottom: 5px;"> <a href="page_management.php"><img src="images/Arrow_Left_24x24.png" width="24" height="24" alt="Go Back" border="0" style="vertical-align: middle"></a> <a href="page_management.php<?php echo
$_SESSION['page_management_qs'] ?>">Go Back</a><br>
    <br>
  </div>
  <table class="navTable" border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td class="navRow1">
  <form name="form1" id="form2" method="post" action="actions.php?type=page">
   <table width="100%"  border="0" cellspacing="1" cellpadding="0" class="gridtable">
     <tr class="gridtable">
       <td colspan="2" class="gridheader">General Settings</td>
     </tr>
     <tr class="gridtable">
       <td class="gridrow2">Page Name <font color="Red"> *</font></td>
       <td class="gridrow2"><input name="sFileName" value="<?php echo isset($_SESSION['form']['sFileName']) ? $_SESSION['form']['sFileName'] : $rw1->sFileName; ?>" style="width: 40%;" class="required" maxlength="255" onKeyUp ="updateLinkName(this)" 
<?php if ($rw1->cre == 0) { echo 'readonly="readonly"';} ?> />
         &nbsp;<span class="red">
           <?php
if ($pn == 1) { echo "[ Required ]";}
if ($lg == 1) {echo "<br>[ The page name length should not exceed 50 characters!... ]";}
if ($al == 1) {echo "<br>[ Page name already exists. Please select new name !... ]";}
?>
         </span><br>
         <?php echo $doc_base ?>index.php?page=<strong><span id="pagename"><?php echo isset($_SESSION['form']['sFileName']) ? $_SESSION['form']['sFileName'] : $rw1->sFileName; ?></span></strong></td>
     </tr>
     <tr class="gridtable">
       <td width="14%" class="gridrow2" >Menu Bar Name <font color="Red"> *</font></td>
       <td width="86%" class="gridrow2"><input id="sPageName" name="sPageName" value="<?php echo isset($_SESSION['form']['sPageName']) ? $_SESSION['form']['sPageName'] : $rw1->sPageName; ?> " style="width: 40%;" class="required" maxlength="255" />
         <span class="red">
           <?php if ($vpn == 1) {
    echo "[ Required ]";
} ?>
           <?php if ($lgvpn == 1) {
    echo "<br>[ Visible page name should not exceed 35 characters ]";
} ?>
         </span></td>
     </tr>
     <?php 
	 $varvar = 'nDisplay_'.$rw1->nDisplay;
	 $$varvar = 'selected';
	 //die($rw1->nDisplay);
	 ?>
     <tr class="gridtable">
       <td class="gridrow2">Status</td>
       <td class="gridrow2"><label for="nDisplay"></label>
         <select name="nDisplay" id="nDisplay">
           <option value="1" <?php echo $nDisplay_1?>>Active</option>
           <option value="0" <?php echo $nDisplay_0 ?>>Inactive</option>
         </select>
         <input type="hidden" name="cre" value="<?php  echo $rw1->cre ?>" />
         <input type="submit" name="Submit2" value="Save" class="inputSubmit" /></td>
     </tr>
   </table>
   <input type="hidden" name="did" value="<?php echo $_GET['did'] ?>"/>
<input type="hidden" name="act" value="edit" />
<input type="hidden" name="id" value="<?php echo $_GET['id'] ?>"/>
<div style="width:65%; float:left; margin: 0 2% 0 0;">
  <textarea id="txtContent" name="txtContent" rows="10" style="height:520px; width:100%;">
	  <?php 
	  //echo htmlentities($_SESSION['form']['txtContent']) ? htmlentities($_SESSION['form']['txtContent']) :htmlentities($rw1->sContent);Bugged - Shows Bad Characters
	  echo ($_SESSION['form']['txtContent']) ? htmlspecialchars_decode($_SESSION['form']['txtContent']) :htmlspecialchars_decode($rw1->sContent); // Fix For Above
	  ?>
      </textarea>
      </p>
</div>
    <div style="width:32%; float:left;">
    <?php 
		if (usePageLevels($_GET['did'])&& $rw1->cre == '1'){
			
			 ?>
    <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
      <tr class="gridtable">
        <td colspan="2" class="gridheader">Access Rights</td>
      </tr>
      <tr class="gridtable">
        <td width="265" class="gridrow2">Who can view this page? <font color="Red"> *</font></td>
        <td width="315" class="gridrow2"><?php if ($ar == 1) {echo '<span class="red">[You must choose at least one  level]</span><br />';}?>
          <?php
    $sql = "SELECT * FROM tblmembershiplevels  WHERE nActive='1' ORDER BY nOrder ASC , sLevel ASC";
    $rs = $dbo->select($sql);
	$levels = $sessionpagelevels ? $sessionpagelevels : $pagelevels;
    if (!empty($rs))
        while ($row = $dbo->getobj($rs)) {
			$checked = '';
			if(in_array($row->nLevel_ID,$levels)){$checked = 'checked';}
			$boxes .= '<input name="pageLevel[]" type="checkbox" value="'.$row->nLevel_ID.'" '.$checked.' /> '.$row->sLevel;
        }
    echo $boxes ?></td>
      </tr>
      <tr class="gridtable">
        <td class="gridrow2">Unavailable to members that join after:</td>
        <td class="gridrow2"><input name="nUnavailableForJoinedAfter_checkbox" type="checkbox" class="box" id="nUnavailableForJoinedAfter_checkbox" onClick="disable_enable_nUnavailableForJoinedAfter()" value="1" 
		<?php if ($rw1->nUnavailableForJoinedAfter) {
        echo 'checked="checked"';
        $nUnavailableForJoinedAfter_disabled = "";
		if(isset($_SESSION['form']['nUnavailableForJoinedAfter_month']) && isset($_SESSION['form']['nUnavailableForJoinedAfter_year'])){
			$date = $_SESSION['form']['nUnavailableForJoinedAfter_year'].'-'.$_SESSION['form']['nUnavailableForJoinedAfter_month'].'01';
		}
		else{$date = $rw1->nUnavailableForJoinedAfter;}
        
		$pieces = explode('-',$date);
		//die(var_dump($pieces));
		$nUnavailableForJoinedAfter_month = $pieces[1];
        $nUnavailableForJoinedAfter_year = $pieces[0];
		$vvar = "nUnavailableForJoinedAfter_month_" . $nUnavailableForJoinedAfter_month ."_selected";
        $$vvar = 'selected="selected"';
		$vvar2 = "nUnavailableForJoinedAfter_year_" . $nUnavailableForJoinedAfter_year ."_selected";
        $$vvar2 = 'selected="selected"';

    } else {
        $nUnavailableForJoinedAfter_disabled = 'disabled="disabled"';
    } ?> />
          <select name="nUnavailableForJoinedAfter_month" id="nUnavailableForJoinedAfter_month" <?php echo $nUnavailableForJoinedAfter_disabled; ?> >
            <option value=""></option>
            <option value="01" <?php echo $nUnavailableForJoinedAfter_month_01_selected ?>>January</option>
            <option value="02" <?php echo $nUnavailableForJoinedAfter_month_02_selected ?>>February</option>
            <option value="03" <?php echo $nUnavailableForJoinedAfter_month_03_selected ?>>March</option>
            <option value="04" <?php echo $nUnavailableForJoinedAfter_month_04_selected ?>>April</option>
            <option value="05" <?php echo $nUnavailableForJoinedAfter_month_05_selected ?>>May</option>
            <option value="06" <?php echo $nUnavailableForJoinedAfter_month_06_selected ?>>June</option>
            <option value="07" <?php echo $nUnavailableForJoinedAfter_month_07_selected ?>>July</option>
            <option value="08" <?php echo $nUnavailableForJoinedAfter_month_08_selected ?>>August</option>
            <option value="09" <?php echo $nUnavailableForJoinedAfter_month_09_selected ?>>September</option>
            <option value="10" <?php echo $nUnavailableForJoinedAfter_month_10_selected ?>>October</option>
            <option value="11" <?php echo $nUnavailableForJoinedAfter_month_11_selected ?>>November</option>
            <option value="12" <?php echo $nUnavailableForJoinedAfter_month_12_selected ?>>December</option>
          </select>
          &nbsp;
          <select name="nUnavailableForJoinedAfter_year" id="nUnavailableForJoinedAfter_year" <?php echo $nUnavailableForJoinedAfter_disabled; ?> >
            <option value=""></option>
            <?php
    $i = 0;
    while ($i < 5) {
        $year = date(Y) - $i;
        echo "<option value='$year' " . ${"nUnavailableForJoinedAfter_year_" . $year ."_selected"} . ">$year</option>";
        $i++;
    }

?>
          </select></td>
      </tr>
    </table>
    <br>
    <table border="0" cellspacing="1" cellpadding="0" class="gridtable">
      <tr class="gridtable">
        <td colspan="2" class="gridheader">Drip Feed Settings</td>
      </tr>
      <tr class="gridtable">
        <td width="31%" class="gridrow2">Days Until Available</td>
        <td width="69%" class="gridrow2"><input name="naccessdays" type="text" class="box digits" id="naccessdays" value="<?php echo
isset($_SESSION['forms']['naccessdays']) ? $_SESSION['forms']['naccessdays'] : $rw1->nAccessDays; ?>" size="5" maxlength="5" />
          <font color="Red">*</font>How many days until user can view this page?<font color="Red">&nbsp; </font></td>
      </tr>
      <tr class="gridtable">
        <td class="gridrow2">Dynamic Menu Bar Name?</td>
        <td class="gridrow2"><input name="nDynamicPage" type="checkbox" class="box" id="nDynamicPage" value="1" <?php 
    (isset($_SESSION['form']['nDynamicPage']) ==1) ? $dpage = 1 : $rw1->nDynamicPage; echo ($dpage == 1)?' checked':'' ?> />
          <small>(This will replace "Menu Bar Name" with a month and year dynamically generated according to the member's join date)</small></td>
      </tr>
      <tr class="gridtable">
        <td valign="top" class="gridrow2">Email member?
          <div id="sendemailtext" style="display:none">Email content</div></td>
        <td  class="gridrow2"><input name="nconfemail" type="checkbox" id="nconfemail" onChange="toggle(this,'emailoption')" value="1" <?php 
			$_SESSION['form']['nconfemail'] ? $cemchecked=1 : $cemchecked = $rw1->nConfEmail;
			echo $cemchecked ? 'checked="checked"' : '' ?>/>
          Send email when page is active? </td>
      </tr>
    </table>
    <div id="sendemailbody" style="display:<?php echo $rw1->nConfEmail ?'block' : 'none' ?>">
      <table border="0" cellspacing="1" cellpadding="0" class="gridtable" width="100%">
        <tr class="gridtable">
          <td class="gridheader">Email Content</td>
        </tr>
        <tr>
          <td class="gridrow2"><textarea name="sconfemailcontent" rows="8" style="width:100%;" class="mceNoEditor"><?php echo
    isset($_SESSION['form']['sConfEmailContent'])  ? $_SESSION['form']['sConfEmailContent'] : $rw1->sConfEmailContent ?></textarea></td>
        </tr>
      </table>
    </div><br>
    <?php } ?>
   <!-- <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
      <tr class="gridtable">
        <td colspan="2" class="gridrow2">Social Media Settings</td>
      </tr>
      <tr class="gridtable">
        <td width="35%" class="gridrow2">Integrate Facebook Comments?</td>
        <td width="65%" class="gridrow2"><input name="fbcomments" type="checkbox" id="fbcomments" value="1" <?php 
			isset($_SESSION['form']['fbcomments']) ? $fbchecked = $_SESSION['form']['fbcomments'] : $fbchecked = $rw1->nFacebookComments;
			echo
    $fbchecked ? 'checked="checked"' : '' ?>></td>
      </tr>
    </table> -->
    
    <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
    <tr class="gridtable">
      <td class="gridrow2">Video Settings</td>
    </tr>
    <tr class="gridtable">
      <td class="gridrow2"> Add Video To Post?
        <select name="videoact" id="videoact" onChange="videoaction()">
          <option selected>No Video</option>
          <option value="new">Add New Video</option>
          <option value="existing">Use Existing Video</option>
        </select>
        <select name="existingvids" id="existingvids" onChange="getExistingEmbed(this)" style="display:none;">
          <option value="">-- Select Video --</option>
          <?php echo $selects ?>
        </select>
        <select name="newsel" id="newsel" onChange="newVideoOpt()" style="display:none;">
          <option selected>Select A Method</option>
          <option value="upload">Upload New Video</option>
          <option value="remote">From Url</option>
        </select>
        <div id="uploader" style="display:none">
        <?php echo '<form action="ajax/video_upload.php" method="post" id="uploaderForm">' ?>
        <p>Your browser doesn't have Flash, Silverlight, Gears, BrowserPlus or HTML5 suppor!WOW, Get a new browser.</p>
  <?php echo '</form>'; ?>
</div>
<div id="remote" style="display:none;">
  <?php echo '<form id="remoteVideo" name="remoteVideo" method="post" action="#">';?>
    <table width="100%" cellspacing="1" cellpadding="0" border="0" class="gridtable">
      <tr>
        <td colspan="2" class="gridHeader">Add Remote Video</td>
      </tr>
      <tr>
        <td class="gridrow2" width="150">URL <span style="color: red">*</span></td>
        <td class="gridrow2"><input type="text" name="sVideoURL" id="sVideoURL"style="width: 250px;" class="url required" />
          <small>e.g. http://www.somewebsite.com/uploads/video123.flv</small></td>
      </tr>
      <tr>
        <td class="gridFooter" colspan="2"><input name="Submit" type="button" value="Add Video" id="remoteVideo" onClick="addRemote();">
          <span id="ajaxError" class="error"></span></td>
      </tr>
    </table>
 <?php echo '</form>'; ?>
</div>
</td>
</tr>
</table>
<br>
<div id="embedTable" style="display:none">
  <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
    <tr class="gridtable">
      <td class="gridrow2">Video Embed Codes</td>
    </tr>
    <tr class="gridtable">
      <td class="gridrow2"><div id="embedCodes"></div></td>
    </tr>
  </table>
</div>
<?php echo pluginClass::filter("page_edit_sidebar");?>
</div>
<div style="clear:both;"></div>
<?php echo pluginClass::filter("page_edit_bottom");?>
</form>
</td>
        </tr>
      </table>
</div>

<?php include_once 'b.php'; ?>
<?php
unset($_SESSION['form']);
$_SESSION['errors']= "";
?>
</body>
</html>