<?php
include_once('../conn.php');
include_once('../functions.php');

if (isset($_POST['Update']) )
{
	$c = 0;
	if ($_POST['txtContent'] == '')
	{
		$c++;
		$sb = 1;
	}
	if ($c == 0)
	{
		if ($_POST['nSortOrder'] == '') {
			$nSortOrder = 0;
		} else {
			$nSortOrder = $dbo->format($_POST['nSortOrder']);
		}
		
		$sql = "UPDATE tblpromoemails SET 
		sEmailText = '" . $dbo->format($_POST['txtContent']) . "',
		sTitle = '" . $dbo->format($_POST['sTitle']) . "', 
		nSortOrder = " . $nSortOrder . "
		WHERE nPromoEmail_ID = '" . $dbo->format($_POST['dd'])."'";
		$dbo->update($sql);
		
		header("location:promotional_emails.php?act=upsus");
	}
}

$rw = $dbo->getobject("SELECT * FROM tblpromoemails WHERE nPromoEmail_ID = " . $dbo->format($_GET['id']));

?> 
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
<?php include("inc-head.php"); ?>
		<script type="text/javascript">
		// SCRIPT USED TO INSERT THE STRING INTO THE TEXTAREA
		function InsertText(input, insTexte)
		{
			startTag = '';
			endTag = '';
			if (input.createTextRange)
			{
				var text;
				input.focus(input.caretPos);
				input.caretPos = document.selection.createRange().duplicate();
				if(input.caretPos.text.length>0)
				{
					input.caretPos.text = startTag + input.caretPos.text + endTag;
				}
				else
				{
					input.caretPos.text = startTag + insTexte +  endTag;
				}
			}
			else input.value += startTag + insTexte + endTag;
		}
		</script>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once('affiliateleft.php'); ?></td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			<form name="form1" id="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>?id=<?php echo $_GET['id']; ?>">
				<span style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">      </span>
				<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<td class="navRow1" nowrap="nowrap">Edit Promotional Emails </td>
						<td width="100%" align="left">&nbsp;</td>
					</tr>
				</table>
				<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
					<tr>
						<td class="gridHeader" colspan="2">Edit Promotional Email</td>
					</tr>
					<tr>
						<td class="gridrow1" width="250">Email Title <span class="red">*</span></td>
						<td class="gridrow2"><input type="text" name="sTitle" value="<?php echo $rw->sTitle ?>" class="required" style="width: 250px;"></td>
					</tr>
					<tr>
						<td class="gridrow1">Sort Order</td>
						<td class="gridrow2"><input type="text" name="nSortOrder" value="<?php echo $rw->nSortOrder ?>" style="width: 50px;"></td>
					</tr>
					<tr>
						<td valign="top" class="gridRow1">Email Body <span class="red">*</span></td>
						<td class="gridRow2">
							<input name="button2" type="button"  class="inputSubmitb" onClick="InsertText(document.form1.txtContent,'#AFFILIATE LINK#');"  value="Insert Affiliate Link" />
							<br /><br />
							<textarea  name="txtContent" style="width: 100%; height: 500px;" class="required"><?php echo $rw->sEmailText; ?></textarea>
							<input type="hidden" name="dd" value="<?php echo $rw->nPromoEmail_ID; ?>" />
						</td>
					</tr>
					<tr>
						<td class="gridFooter" colspan="2"><input class="inputSubmitb" name="Update" value="Save Changes" type="submit" /></td>
					</tr>
				</table>
			</form>
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>
<script type="text/javascript">		
	$(document).ready(function()
	{
		$("#form1").validate();
	});
</script>
</body>
</html>