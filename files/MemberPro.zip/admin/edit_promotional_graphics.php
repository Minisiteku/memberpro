<?php
include_once('../conn.php');
include_once('../functions.php');

if ( isset($_POST['Update']) )
{
	$ty = $_FILES['imgfile']['type'];
	
	if ( ($ty == 'image/jpeg') || ($ty == 'image/pjpeg') || ($ty == 'image/gif') || ($ty == 'image/png') )
	{
		$imgfile = $_FILES['imgfile']['tmp_name'];
		
		if ( $imgfile != '' )
		{
			copy($imgfile, '../promotional_pic/' . $_POST['dd'] . '.jpg');
		}
		
		header("location:promotional_graphics.php?act=upsus");
	}
	else
	{
		header("location:promotional_graphics.php?act=a&im=1");
	}
}
$rw = $dbo->getobject("SELECT * FROM tblpromographics WHERE nPromoGraphic_ID=  '" . $dbo->format($_GET['id']) . "';" );

?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php include("inc-head.php"); ?>
		<script type="text/javascript"><!--//
			function cdel(w)
			{
				if ( confirm("Delete Confirmation!..\n\n Are Sure that you want to delete this?..") )
				{
					return true;
				}
				else
				{
					return false;
				}
			}

			var cX = 0; var cY = 0;
			function UpdateCursorPosition(e){ cX = e.pageX; cY = e.pageY;}
			function UpdateCursorPositionDocAll(e){ cX = event.clientX; cY = event.clientY;}
			if (document.all) { document.onmousemove = UpdateCursorPositionDocAll; }
			else { document.onmousemove = UpdateCursorPosition; }
			function AssignPosition(d) {
				d.style.left = (cX+10) + "px";
				d.style.top = (cY+10) + "px";
			}
			function HideContent(d) {
				if(d.length < 1) { return; }
				document.getElementById(d).style.display = "none";
			}
			function ShowContent(d) {
				if(d.length < 1) { return; }
				var dd = document.getElementById(d);
				AssignPosition(dd);
				dd.style.display = "block";
			}
			function ReverseContentDisplay(d) {
				if(d.length < 1) { return; }
				var dd = document.getElementById(d);
				AssignPosition(dd);
				if(dd.style.display == "none") { dd.style.display = "block"; }
				else { dd.style.display = "none"; }
			}
		//-->
		</script>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once('affiliateleft.php'); ?></td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			<form name="frm" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
				<span style="padding-left: 8px; padding-top: 8px; padding-right: 8px;"></span>
				<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<td class="navRow1" nowrap="nowrap">Edit Promotional Graphics</td>
						<td width="100%" align="left">&nbsp;</td>
					</tr>
				</table>
				<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
					<tr>
						<td class="gridHeader" colspan="2">Edit Promotional Graphic</td>
					</tr>
					<tr>
						<td width="94" valign="top" nowrap="nowrap" class="gridLabels2">
							Graphic
							<a onMouseOver="ShowContent('uniquename3'); return true;" onMouseOut="HideContent('uniquename3'); return true;" href="javascript:ShowContent('uniquename3')"><span class="red"> <img src="images/preview.jpg" width="21" height="16" border="0" alt="Preview Page"> </span></a>
							<div id="uniquename3" style="display:none;position:absolute;background-color:white;padding:1px;">
								<img src="../promotional_pic/<?php echo $rw->nPromoGraphic_ID; ?>.jpg" />
							</div>
						</td>
						<td width="838" valign="middle" class="gridRow2">
							<input name="imgfile" type="file" class="submit" size="45" />
							<input type="hidden" name="dd" value="<?php echo $rw->nPromoGraphic_ID; ?>" />
						</td>
					</tr>
					<tr>
						<td class="gridFooter" colspan="2"><input class="inputSubmitb" name="Update" value="Save Changes" type="submit" /></td>
					</tr>
				</table>
			</form>
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>
	</body>
</html>