<?php
	include_once ('../conn.php');
	include_once ('../functions.php');
	
	// Get Level Select
	// GET Membership Levels
	$sql = "SELECT * FROM tblmembershiplevels";
	$levelRes = $dbo->select($sql);
	
	$levelsel = "<select name='levelFilterValue' id='levelFilterValue'> onChange='getPaymentPlansByLevel(this)'>\n\t
	<option value = '0'>--- Choose Membership Level ---</option>\n\t";
	
	while($row = $dbo->getobj($levelRes)){
		$levelsel .= '<option value="'.$row->nLevel_ID.'">'.$row->sLevel.'</option>\n\t';
	}
	
	$levelsel .='</select>';
	
?>
<html>
<head>
<title><?php echo $admintitle; ?></title>
<?php include('inc-head.php');
if(get_option('use_mce') == '1'){
			 $doc_base = $chkSsettings->sSiteURL .'/'; ?>
             <script type="text/javascript" src="common/js/tiny_mce/tiny_mce.js"></script>
    		<script type="text/javascript" src="common/js/tiny_mce/init.php?css=no&base=<?php echo $doc_base  ?>"></script>
    	<?php }
 ?>

<script language="javascript" src="../js/jquery-ui-timepicker-addon.js"></script>
<script language="javascript" src="common/js/queryFilter.js"></script>
<script type="text/javascript">
	// Set Global Variables
	var useQuery = false;
	function modelClose(){
		// Clear All Model Form Element Values
		$('#newBody').val('');
		$('#newHtmlBody').val('');
		$('#newSubject').val('');
		$('#newTitle').val('');
		$('#act').val('');
		$('#nBroadcast_ID').val();
		$('#schedule_0').prop('checked', true);
		$('#scheduleDateTime').val('');
	}
	function sendTestEmail(){
    		button = this;
			button.value = 'Sending Test Email ...';
			$("#testEmailResult").html('');
			tinyMCE.triggerSave();
			data = $('#Broadcast').serialize();
			
			jQuery.ajax({url: 'ajax/functions.php?act=test_email',type: 'POST',data: data})
			.done(function (response) {
    			result = jQuery.parseJSON(response);
				button.value = 'Resend Test Email';
				if(result.error){
					$("#testEmailResult").html('<span class=\'error\'>'+result.message+'</span>');
				}
				else{
					$("#testEmailResult").html('<span class=\'success\'>'+result.message+'</span>');
				}
				
			}).fail(function () {
    // Whoops; show an error.
			});
  		}
	
	$(function() {
		$( ".datetimepicker" ).datetimepicker({ 
			dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',
			timeFormat: "HH:mm:ss",
			yearRange: '<?php echo date('Y') ?>:2037',
			changeYear: true });
			
		$( "#newBroadcast" ).dialog({
            autoOpen: false,
            show: "explode",
            hide: "explode",
			modal: true,
			width:'auto',
			height:600,
			close: modelClose,
			closeOnEscape: true
			
			
			
        });
		
	 });
	
	function focusDateTime(){
		$("#scheduleDateTime").focus();
	}
	function checkthis() {
		var bValid = true;
		var re = /^\s*$/;
		var oForm = document.forms.frm;
		var n = 0;
		
		// use global var useQuery
		if(useQuery == true){
			if(!oForm.filterName.value.search(re)){
				alert("You Must Choose A Filter");
				return false;
			}
		}
		
		if (!oForm.subject.value.search(re)) {
			alert("Please enter a Subject");
			oForm.subject.focus();
			return false;
		}
		
		if (!oForm.txtBody.value.search(re)) {
			alert("Please fill in the body section");
			oForm.txtBody.focus();
			return false;
		}
		return true;	
	}
	function showQueryBox(){
		$("#broadcastQuery").show();
		$("#broadcastQuerySet").hide();
		$("#queryType").val('filter');
		useQuery = true;
		
	}
	function hideQueryBox(){
		$("#broadcastQuery").hide();
		$("#broadcastQuerySet").show();
		$("#queryType").val('saved');
		useQuery = false;
	}
	
	function addBroadcast(){
		var title = 'Add New Broadcast Email';
		$('#act').val('add');
		$('#newBody').val('');
		$('#newSubject').val('');
		$('#newTitle').val('');
		$('#schedule_0').prop('checked', true);
		$('#scheduleDateTime').val('');
		showQueryBox();
		$( "#newBroadcast" ).dialog('option','title',title).dialog( "open" );
		$( "#newBroadcast" ).dialog( "open" );
		// Test Email
		$("#testEmail").click(sendTestEmail);
	}
	function cloneBroadcast(id){
		
		var title = 'Add New Broadcast Email';
		$('#act').val('add');
		$( "#newBroadcast" ).dialog('option','title',title).dialog( "open" );
		
		$('#newSubject').val($('#broadcastSubject_'+id).val());
		$('#newBody').val($('#broadcastBody_'+id).val());
		$('#newHtmlBody').val($('#broadcastBodyHtml_'+id).val());
		
		tinyMCE.activeEditor.setContent($('#broadcastBodyHtml_'+id).val());
		$( "#newBroadcast" ).dialog( "open" );
		// Test Email
		$("#testEmail").click(sendTestEmail);
	}
	function editBroadcast(id){
		// set global variable useQuery
		useQuery = true;
		$('#act').val('edit');
		$('#nBroadcast_ID').val(id);
		
		var title = 'Edit Broadcast Email';
		var sendTime = $('#broadcastTime_'+id).val();
		
		$("#broadcastQuerySet").show();
		$("#broadcastQuery").hide();
		
		if(sendTime == '0000-00-00 00:00:00') $('#schedule_0').prop('checked', true);
		
		else{
			$('#schedule_1').prop('checked', true);
			
			$('#scheduleDateTime').val(sendTime);
		}
		$( "#newBroadcast" ).dialog('option','title',title).dialog( "open" );
		$('#newBody').val($('#broadcastBody_'+id).val());
		$('#newHtmlBody').val($('#broadcastHtmlBody_'+id).val());
		$('#newSubject').val($('#broadcastSubject_'+id).val());
		
		tinyMCE.activeEditor.setContent($('#broadcastHtmlBody_'+id).val());
		
		$( "#newBroadcast" ).dialog( "open" );
		// Test Email
		$("#testEmail").click(sendTestEmail);
		
		
	}
	function updateSentCount(id){
		// This function will check to see how many emails have been sent, and update the field every 60 seconds
		$.ajax({
      		url: "ajax/functions.php?act=broadcasts_sent&id="+id,
      			type:"get",
      			success: function(data){
       				$('#sentCount_'+id).html(data);
      			}
			
	})
	}
	
	function confirmDelete(type){
		return confirm('Are you sure you want to delete this '+type+' broadcast?\nThis action cannot be reversed!');
		
	}
</script>
<link rel="stylesheet" type="text/css" href="common/css/styles.css">
</head>

<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once ('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td width="180" height="350" rowspan="2" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once ('memberleft.php'); ?></td>
    <td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%"><?php if (isset($message))  echo $message ?>
      <?php echo (time() - get_option('emailCron_LastRun') > (60*60*24) )?'<div class="notify-warning"><div class="notify-close warning-close" onClick="closeNotify(this)"></div>Email Cron Has Not Run In 24 hours. Make sure your cron is setup correctly. <br/><a href="manage_crons.php">Manage Cron Jobs</a></div>':''?> 
      <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td class="navRow1" nowrap="nowrap">Email Members</td>
        </tr>
      </table>
      <?php 
	  		/// Inprogress Broadcasts
			
	$sql2 = "SELECT * FROM tblbroadcasts WHERE tblbroadcasts.nStatus = '1'";
	$res_progress = $dbo->select($sql2);
			if($dbo->nr($res_progress) > 0){
			$inProgress = true;
			?>
      <table width="100%" cellpadding="0" cellspacing="1" class="gridtable">
        <tr>
          <td colspan="4" class="gridheader">Broadcasts in Progress</td>
        </tr>
        <tr>
          <td width="21%" class="gridheader">Subject</td>
          <td class="gridheader">Start Date/Time</td>
          <td width="24%" class="gridheader">Email Count</td>
          <td width="27%" class="gridheader">Actions</td>
        </tr>
        <?php
			
			while($row = $dbo->getobj($res_progress)){
				$ajaxCalls[] = $row->nBroadcast_ID;
				$row->sentCount = $dbo->getval("SELECT COUNT(*) FROM tblemails WHERE nBroadcast_ID = '".$row->nBroadcast_ID."' AND nStatus = '1';");
				
				?>
        <tr>
          <td class="gridrow2"><?php echo $row->sSubject?></td>
          <td class="gridrow2"><?php echo $row->dStartTime?></td>
          <td class="gridrow2"><span id="sentCount_<?php echo $row->nBroadcast_ID ?>"><?php echo $row->sentCount ?></span>/<?php echo $dbo->num_rows($row->sMemberQuery)?></td>
          <td class="gridrow2"><form name="form1" method="post" action="actions.php?type=broadcast">
          <input type="hidden" name="act" value="restart">
            <input type="submit" name="button5" id="button5" value="Restart">
          </form></td>
        </tr>
        <?php }
			  ?>
        <tr>
          <td colspan="4" class="gridfooter">&nbsp;</td>
        </tr>
      </table>
      <?php
	  	if(isset($ajaxCalls)){
			echo '<script type="text/javascript">';
			foreach($ajaxCalls as $BID){
				echo 'setInterval(\'updateSentCount('.$BID.')\',15000);';	
			}
			echo '</script>';
		}
	   }
	   if(!$inProgress && is_option('email_broadcasting')){?>
       <div class="notify-warning"><div class="notify-close warning-close" onClick="closeNotify(this)"></div>
       There is a broadcast lock in effect!<br/>
       <form action="actions.php?type=broadcast" method="post"><input type="hidden" name="act" value="unlock" /><input type="submit" value="Unlock Broadcasts"></form></div>
       
       
       <?php }
	    ?>
      <table width="100%" cellpadding="0" cellspacing="1" class="gridtable">
        <tr>
          <td colspan="4" class="gridheader">Pending Broadcasts - <a href="javascript:addBroadcast();">Add New</a></td>
        </tr>
        <tr>
          <td width="21%" class="gridheader">Subject</td>
          <td width="20%" class="gridheader">Delivery Date/Time</td>
          <td width="24%" class="gridheader">Member Count</td>
          <td width="35%" class="gridheader">Actions</td>
        </tr>
        <?php
			// Load Pending Broadcasts
			$sql = "SELECT * FROM tblbroadcasts WHERE (nStatus = '0' OR nStatus = '-1') ORDER BY dScheduleTime ASC";
			$res = $dbo->select($sql);
			if($dbo->nr($res)){
			while($row = $dbo->getobj($res)){?>
        <tr>
          <td class="gridrow2"><?php echo $row->sSubject?></td>
          <td class="gridrow2"><?php echo ($row->dScheduleTime == '0000-00-00 00:00:00')?'Next Run':$row->dScheduleTime?></td>
          <td class="gridrow2"><?php echo $dbo->num_rows($row->sMemberQuery)?></td>
          <td class="gridrow2">
          	<form name="form1" method="post" action="actions.php?type=broadcast" onSubmit="return confirmDelete('pending')">
              <input type="button" name="button2" id="button2" value="Edit" onClick="editBroadcast('<?php echo $row->nBroadcast_ID?>');">
              <input type="hidden" name="nBroadcast_ID" value="<?php echo $row->nBroadcast_ID?>" >
              <input type="hidden" name="act" value="del" >
              <input type="submit" name="button" id="button" value="Delete">
            </form>
             <div style="display:none;">
              <input type="hidden" id="broadcastSubject_<?php echo $row->nBroadcast_ID?>" value="<?php echo $row->sSubject?>" >
              <textarea id="broadcastBody_<?php echo $row->nBroadcast_ID?>" ><?php echo $row->sBody?></textarea>
              <textarea id="broadcastHtmlBody_<?php echo $row->nBroadcast_ID?>" style="display:none"> <?php echo $row->sBodyHtml?></textarea>
              <input type="hidden" id="broadcastTime_<?php echo $row->nBroadcast_ID?>" value="<?php echo $row->dScheduleTime?>" >
            </div>
            </td>
        </tr>
        <?php }}
			else{ ?>
        <tr>
          <td colspan="4" class="gridrow2">No Pending Broadcasts</td>
        </tr>
        <?php }
			 ?>
        <tr>
          <td colspan="4" class="gridfooter">&nbsp;</td>
        </tr>
      </table>
      
      <table width="100%" cellpadding="0" cellspacing="1" class="gridtable">
        <tr>
          <td colspan="4" class="gridheader">Completed Broadcasts</td>
        </tr>
        <tr>
          <td width="21%" class="gridheader">Subject</td>
          <td class="gridheader">Completed Date/Time</td>
          <td width="17%" class="gridheader">Sent Count</td>
          <td width="36%" class="gridheader">Actions</td>
        </tr>
        <?php
			// Load Completed Broadcasts
			$sql3 = "SELECT * FROM tblbroadcasts WHERE tblbroadcasts.nStatus = '2'";
			//die($sql2);
			$res_complete = $dbo->select($sql3);
			if($dbo->nr($res_complete)){
				while($row = $dbo->getobj($res_complete)){
					$row->sentCount = $dbo->getval("SELECT COUNT(*) FROM tblemails WHERE nBroadcast_ID = '".$row->nBroadcast_ID."' AND nStatus = '1';");
					?>
        <tr>
          <td class="gridrow2"><?php echo $row->sSubject?></td>
          <td class="gridrow2"><?php echo $row->dSentTime?></td>
          <td class="gridrow2"><?php echo $row->sentCount ?>/<?php echo $dbo->num_rows($row->sMemberQuery)?></td>
          <td class="gridrow2"><form name="form1" method="post" action="actions.php?type=broadcast" onSubmit="return confirmDelete('completed')">
              <input type="button" name="button3" id="button3" value="Copy" onClick="cloneBroadcast('<?php echo $row->nBroadcast_ID?>');">
              <input name="nBroadcast_ID" type="hidden" value="<?php echo $row->nBroadcast_ID?>" >
              <input name="act" value="del" type="hidden" >
              <input type="submit" name="button3" id="button4" value="Delete">
            </form>
            <div style="display:none;">
              <input type="hidden" id="broadcastSubject_<?php echo $row->nBroadcast_ID?>" value="<?php echo $row->sSubject?>" >
              <textarea id="broadcastBody_<?php echo $row->nBroadcast_ID?>" ><?php echo $row->sBody?></textarea>
               <textarea id="broadcastBodyHtml_<?php echo $row->nBroadcast_ID?>"><?php echo readHtmlFromDb($row->sBodyHtml)?></textarea>
            </div></td>
        </tr>
        <?php }
			}
			else{ ?>
        <tr>
          <td colspan="4" class="gridrow2">No Completed Broadcasts</td>
        </tr>
        <?php }
			  ?>
        <tr>
          <td colspan="4" class="gridfooter">&nbsp;</td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td style="padding-left: 8px; padding-right: 8px; " valign="top" width="100%">
    <div id="newBroadcast" style="overflow:auto; width:680px;">
<form name="frm" method="post" action="actions.php?type=broadcast"  onSubmit="return checkthis()" id="Broadcast">
  <table class="gridTable" border="0" cellpadding="0" cellspacing="1">
    <tr>
      <td colspan="2" class="gridheader">&nbsp;</td>
      <td class="gridheader">Available Merge Codes</td>
    </tr>
    <tr>
      <td class="gridrow2">Email To: <font color="Red"> *</font></td>
      <td class="gridrow2"><div id="broadcastQuery" style="display:block">
          <hr>
          <p> <span style="color:#C00">Active Filter:</span> 
          <span id="activeFilterDisplay">
          <?php
				if(isset($_SESSION['admin']['current_mqf_sql'])){
					echo str_replace('mqf_','',$_SESSION['admin']['current_mqf_title']).' - <a href="#" id="filterLink"> Manage Filters</a>';?>
          <?php }
				else{ echo 'None - <a href="#" id="filterLink"> Manage Filters</a>';}	
				 ?>
          <p><a href="javascript:void();" onClick="hideQueryBox()">Cancel</a></p>
          </span>
          <hr>
        </div>
        <div id="broadcastQuerySet">
          <p> Member Query Set - <a href="javascript:void();" onClick="showQueryBox()">Clear Query</a></p>
        </div></td>
      <td rowspan="6" valign="top" class="gridrow2">First Name = [[FIRSTNAME]]<br />
        <br />
        Last Name = [[LAST NAME]]<br />
        <br />
        Username = [[USERNAME]] <br />
        <br />
        Password = [[PASSWORD]]<br /></td>
    </tr>
    <tr>
      <td nowrap="nowrap" class="gridrow2">Send Email</td>
      <td class="gridrow2"><p>
          <label>
            <input name="schedule" type="radio" id="schedule_0" value="0" checked="checked" />
            Immediately</label>
          &nbsp;
          <label>
            <input type="radio" name="schedule" value="1" id="schedule_later" onClick="focusDateTime()"/>
            Send @ </label>
          <span id="scheduleDate">
          <input name="scheduleDateTime" type="text" id="scheduleDateTime" class="datetimepicker" />
          </span></p>
        <label for="title"></label></td>
    </tr>
    <tr>
      <td class="gridrow2">Subject: <font color="Red"> *</font></td>
      <td class="gridrow2"><input name="subject" id="newSubject" type="text" size="75" style="width:485px;" value="<?php echo $_POST["subject"]; ?>" /></td>
    </tr>
    <tr>
      <td class="gridrow2">Text Body <font color="Red">*</font></td>
      <td class="gridrow2"><textarea name="txtBody" rows="24" class="mceNoEditor" style="width:485px;" id="newBody"><?php echo $_POST["txtBody"] ?></textarea></td>
    </tr>
    <tr>
      <td class="gridrow2">Html Body <font color="Red">*</font></td>
      <td class="gridrow2"><textarea name="htmlBody" cols="50" rows="24" id="newHtmlBody" class="mceEditor" style="width:485px;"><?php echo $_POST["htmlBody"];?></textarea></td>
    </tr>
    <tr>
      <td colspan="2" class="gridrow2"><div id="testEmailResult"></div>
        <input name="act" type="hidden" id="act" />
        <input name="nBroadcast_ID" type="hidden" id="nBroadcast_ID" value="0" />
        <input name="filterName" type="hidden" id="filterName" value="<?php echo $_SESSION['admin']['current_mqf_title']?>" />
        <input name="queryType" type="hidden" id="queryType" value="saved" />
        <input class="inputSubmitb" name="Submit2" value="Send Test Email" type="button" id="testEmail" />
        <input class="inputSubmitb" name="Submit" value="Save Broadcast" type="submit" /></td>
    </tr>
  </table>
</form>
</div>
      
      <br />
      <br />
      <div id="manageFilters" title="Manage Member Query Filters">
    	<div id="manageFilters_addNew" style="display:none;">
        <hr>
		<form name="f1" method="post" action="actions.php?type=queryFilter" onSubmit="return checkthis()" id="addNewForm">
					<strong>New Filter Name</strong>
                    <input name="newFilterName" type="text" id="newFilterName" size="55">
                  <p><strong>Filter Fields</strong><br>
                    <input name="level" type="checkbox" id="level" value="1" onClick="showFilterFields(this)">
                    <label for="level"></label>
                    <label>Membership Level</label>
                    <input name="affiliate" type="checkbox" id="affiliate" value="1" onClick="showFilterFields(this)">
                    <label>Affiliate</label>
                    <input name="login" type="checkbox" id="login" value="1" onClick="showFilterFields(this)">
                    Last Login
                    <input name="emailStatus" type="checkbox" id="emailStatus" value="1" onClick="showFilterFields(this)">
                    Email Status
                    <input name="optin" type="checkbox" id="optin" value="1" onClick="showFilterFields(this)">
                    Opt-In Status 
                    <input name="join" type="checkbox" id="join" value="1" onClick="showFilterFields(this)">
                    Join Date</p>
                  <p>View Members Where
                  <div id="filterContainer" style="margin-left:15px;">
                    <div id="levelFilter" style="display:none;"> Membership Level
                      
                      <?php echo $levelsel ?>
                      <select name="levelFilterCompare" id="levelFilterCompare">
                        <option value="IN">Is Assigned</option>
                        <option value="NOT IN">Not Assigned</option>
                      </select>
                      <label for="levelFilterValue"></label>
                    </div>
                    <div id="affiliateFilter" style="display:none;">Is Affiliate
                      <label for="affiliateFilterValue"></label>
                      <select name="affiliateFilterValue" id="affiliateFilterValue">
                        <option value="1">True</option>
                        <option value="0">False</option>
                      </select>
                    </div>
                    <div id="loginFilter" style="display:none;">Last Login
                      <label for="loginFilterCompare"></label>
                      <select name="loginFilterCompare" id="loginFilterCompare" onChange="toggleFilterValue2(this);">
                        <option value=">">After</option>
                        <option value="<">Before</option>
                        <option value="=">On</option>
                        <option value="><">Between</option>
                        <option value="never">Never</option>
                      </select>
                      <input name="loginFilterValue" type="text" size="8" readonly class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, date("Ymd")) ?>">
                      <span id="loginFilterBetween" style="display:none;"> And <input name="loginFilterValue2" type="text" size="8" readonly class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, date("Ymd")) ?>"></span></div>
                    <div id="emailStatusFilter" style="display:none;"> Account Status
                      <label for="emailStatusFilterValue"></label>
                      <select name="emailStatusFilterValue" id="emailStatusFilterValue">
                        <option value="1">Confirmed</option>
                        <option value="0">Unconfirmed</option>
                      </select>
                    </div>
                    <div id="optinFilter" style="display:none;">Optin Status
                      <label for="optinFilterValue"></label>
                      <select name="optinFilterValue" id="optinFilterValue">
                        <option value="0">Receive All</option>
                        <option value="1">Receive None</option>
                      </select>
                    </div>
                    <div id="joinFilter" style="display:none;">Joined
                      <label for="joinFilterCompare"></label>
                      <select name="joinFilterCompare" id="joinFilterCompare" onChange="toggleFilterValue2(this)">
                        <option value=">">After</option>
                        <option value="<">Before</option>
                        <option value="=">On</option>
                        <option value="><">Between</option>
                      </select>
                      <input name="joinFilterValue" type="text" size="8" readonly class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, date("Ymd")) ?>">
                      <span id="joinFilterBetween" style="display:none;"> And <input name="joinFilterValue2" type="text" size="8" readonly class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, date("Ymd")) ?>"></span>
                     </div>
                  </div>
                  </p>
                  <input name="act" type="hidden" id="act2" value="saveFilter">
                  <p>&nbsp;</p>
                  <p>
                    <input class="inputSubmit" name="submit2" value="Apply Filter" type="button" onClick="submitAddNew()">
                &nbsp;
                    <input class="inputSubmit" name="cancel" value="Cancel" type="button" onClick="hideAddNew()">
                  </p>
                </form>    
    </div>
    	<div id="tableContainer" >
        	<div align="right" style="padding:5px;"><a href="#" onClick="showAddNew()">Add New Filter</a></div>  
			<div id="tableRows">Loading Filters ...</div>
    	</div>
	</div>
<?php include_once ('b.php'); ?>
</body>
</html>