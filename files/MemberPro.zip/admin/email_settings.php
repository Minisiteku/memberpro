<?php
	include_once('../conn.php');
	include_once('../functions.php');
	include_once('../includes/functions-time.php');
	
	// Check for pear
	@include_once ('System.php');
	@include('Mail.php');
	
	if ( isset($_POST['Update']) ){
		
		
		// Error checking on smtp settings
		$err = 0;
		if($_POST['mail_method'] == 'smtp'){
			if($_POST['smtp_host'] == ''){
				$err++;
				$errmsg[] = 'You must enter an Smtp Hostname';
			}
			if($_POST['smtp_port'] == ''){
				$err++;
				$errmsg[] = 'You must enter an Smtp Port';
			}
			if($_POST['smtp_user'] == ''){
				$err++;
				$errmsg[] = 'You must enter an Smtp Username';
			}
			if($_POST['smtp_password'] == ''){
				$err++;
				$errmsg[] = 'You must enter an Smtp Password';
			}
			
			if($err == 0){
				// Lets test the SMTP connection.
				
				$smtp = @Mail::factory('smtp',array ('host' => $_POST['smtp_host'],'port' => $_POST['smtp_port'],'auth' => true,'username' => $_POST['smtp_user'],'password' => $_POST['smtp_password']));
 				$conn_res = @$smtp->getSMTPObject();
 				if (@PEAR::isError($conn_res)) {
					$err++;
					$errmsg[] = $conn_res->getMessage();
				}
			}
			
		}
		
		if (!isValidEmail ($_POST['sAdminEmail']) && $_POST['sAdminEmail'] == '') {
			$err++;
			$em = 1;
		}
		if (!isValidEmail ($_POST['sSupportEmail']) && $_POST['sSupportEmail'] == '') 	{
			$err++;
			$sem = 1;
		}
		
		if($err == 0){
			
			update_option('mail_method',$_POST['mail_method']);
			update_option('mail_seconds',$_POST['mail_seconds']);
			update_option('sEmailCanSpam',$_POST['sEmailCanSpam']);
			update_option('sHtmlEmailCanSpam',$_POST['sHtmlEmailCanSpam']);
			
			$email_powered_by = ($_POST['email_powered_by'] == '1')?1:0;
			
			if(get_option('email_powered_by') != $email_powered_by) update_option('email_powered_by',$dbo->format($_POST['email_powered_by']));
			
			if($_POST['mail_method'] == 'smtp'){
				
				update_option('smtp_host',$_POST['smtp_host']);
				update_option('smtp_port',$_POST['smtp_port']);
				update_option('smtp_user',$_POST['smtp_user']);
				update_option('smtp_password',$_POST['smtp_password']);
			}
			$sql = "UPDATE tblsitesettings SET 
			
			sAdminEmail = '".$dbo->format($_POST['sAdminEmail'])."', 
			sSupportEmail = '".$dbo->format($_POST['sSupportEmail'])."',
			sEmailFooter='".$_POST['sEmailFooter']."', 
			sHtmlEmailFooter='".$_POST['sHtmlEmailFooter']."';";
			if(!$dbo->update($sql)){$message = "Database Error: ".$dbo->error;}
			else{$message = "Email settings have been updated successfully";}
			
			header("Location: email_settings.php?msg=".urlencode($message));
		}
	}
	
	$rw = $chkSsettings;
	

?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php 
		include ('inc-head.php');
		if(get_option('use_mce') == '1'){
			 $doc_base = $chkSsettings->sSiteURL .'/'; ?>
             <script type="text/javascript" src="common/js/tiny_mce/tiny_mce.js"></script>
    		<script type="text/javascript" src="common/js/tiny_mce/init.php?css=no&base=<?php echo $doc_base  ?>"></script>
    	<?php }
		?>
        <script type="text/javascript">
        	function toggleSmtp(radio){
				
				if(radio.value == 'smtp'){
					//document.getElementById('smtp_settings').style.display = 'block'
					$("#smtp_settings").show(1000);
				}
				else{
					//document.getElementById('smtp_settings').style.display = 'none'
					$("#smtp_settings").hide(1000);
				}
			}
        </script>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
			<?php include_once('settingsleft.php'); ?>
		</td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			<form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="form">
				
				<?php echo isset($message) ? $message : '' ?>
				
			  <table class="gridtable" cellpadding="0" cellspacing="1" width="100%">
				  <tr>
				    <td colspan="2"  class="gridheader"><strong>Email Details</strong></td>
			    </tr>
				  <tr>
				    <td  class="gridrow2">System Email Address <font style="color:red"> * </font></td>
				    <td  class="gridrow2"><input name="sAdminEmail" type="text" style="width: 350px;" value="<?php echo $rw->sAdminEmail;?>" class="email required" />
				      <?php if ($em == 1) { ?>
				      <span class="red">[ INVALID ]</span>
				      <?php } ?></td>
			    </tr>
				  <tr>
				    <td  class="gridrow2">Support Email Address <font style="color:red">* </font></td>
				    <td  class="gridrow2"><input name="sSupportEmail" type="text" style="width: 350px;" value="<?php echo $rw->sSupportEmail; ?>"  class="email required"/>
				      <?php if ($sem == 1) { ?>
				      <span class="red">[ INVALID ]</span>
				      <?php } ?></td>
			    </tr>
				  <tr>
				    <td colspan="2"  class="gridheader"><strong>Email Configuration</strong></td>
			    </tr>
				  <tr>
				    <td width="184" class="gridrow2">Send Email Using</td>
				    <td width="1028" class="gridrow2"><p>
				      <label>
				        <input name="mail_method" type="radio" id="php" value="php" <?php echo (get_option('mail_method') == 'php')?'checked="CHECKED"':''?> onChange="toggleSmtp(this)">
				        PHP Mail</label>
				      <label>
				        <input type="radio" name="mail_method" value="smtp" id="smtp" <?php echo (class_exists('Mail', false))?'':' disabled title="This feature is not installed on this server. Ask your webhost to install this for you."' ?> 
                        <?php echo (get_option('mail_method') == 'smtp')?'checked="CHECKED"':''?>
                         onChange="toggleSmtp(this)">
				        Pear Mail</label>
				      </p>
				      <div id="smtp_settings" style="margin-left:90px; display:<?php echo (get_option('mail_method') == 'smtp')?'block':'none'?>">
				        <?php if($err){?>
				        <div id="smtp_errors" class="error" >
				          <p>Please Correct The Following Issues</p>
				          <?php foreach ($errmsg as $v) {echo "$v <br />"; }
						?>
			            </div>
				        <?php
						
						
						 } ?>
				        <table border="0" cellspacing="0" cellpadding="2">
				          <tr>
				            <td>SMTP Host</td>
				            <td><label for="smtp_host"></label>
				              <input name="smtp_host" type="text" id="smtp_host" value="<?php echo (isset($_POST['smtp_host']))?$_POST['smtp_host']:get_option('smtp_host')?>" size="50"></td>
			              </tr>
				          <tr>
				            <td>SMTP Port</td>
				            <td><input name="smtp_port" type="text" id="smtp_port" value="<?php echo (isset($_POST['smtp_port']))?$_POST['smtp_port']:get_option('smtp_port')?>" size="6"></td>
			              </tr>
				          <tr>
				            <td>SMTP Username</td>
				            <td><input name="smtp_user" type="text" id="smtp_user" value="<?php echo (isset($_POST['smtp_user']))?$_POST['smtp_user']:get_option('smtp_user')?>" size="50"></td>
			              </tr>
				          <tr>
				            <td>SMTP Password</td>
				            <td><input name="smtp_password" type="text" id="smtp_user" value="<?php echo (isset($_POST['smtp_password']))?$_POST['smtp_password']:get_option('smtp_password')?>" size="50"></td>
			              </tr>
			            </table>
			          </div></td>
			    </tr>
				  <tr>
				    <td class="gridrow2">Throttle Emails To </td>
				    <td width="1028" class="gridrow2"><label for="mail_seconds"></label>
			        Send Every 
			           <input name="mail_seconds" type="text" id="mail_seconds" value="<?php echo get_option('mail_seconds')?>" size="3"> 
			        Seconds (0 for Unlimited [Not Recommended] )</td>
		        </tr>
				  <tr>
				    <td class="gridrow2">Use Powered By Link?</td>
				    <td class="gridrow2"><input name="email_powered_by" type="checkbox" id="email_powered_by" value="1" <?php echo (get_option('email_powered_by'))?'checked':'' ?>></td>
			    </tr>
				  <tr>
				    <td colspan="2" class="gridheader">Email Footers</td>
			    </tr>
				  <tr>
				    <td colspan="2" class="gridrow2">The text you enter here will be appended to all outgoing emails, use it to add details of how to contact <br/>support or promotional links for example. </td>
			    </tr>
				  <tr>
				    <td class="gridrow2">Plain Text Footer</td>
				    <td width="1028" class="gridrow2"><textarea rows="10" cols="80" value="" name="sEmailFooter" class="mceNoEditor"><?php echo $rw->sEmailFooter ?></textarea></td>
		        </tr>
				  <tr>
				    <td class="gridrow2">Html Footer</td>
				    <td width="1028" class="gridrow2"><textarea name="sHtmlEmailFooter" cols="80" rows="10" id="sHtmlEmailFooter" value="" class="mceEditor"><?php echo $rw->sHtmlEmailFooter ?></textarea></td>
		        </tr>
				  <tr>
				    <td colspan="2" class="gridheader">Can Spam Message / Unsubscribe</td>
			    </tr>
				  <tr>
				    <td colspan="2" class="gridrow2">The message you enter here will be appended to all broadast emails, use it to add canspam compliance and unsubscribe informaiton.<br>
				      Use [[UNSUB_LINK]] to use the unsubscribe system. </td>
			    </tr>
				  <tr class="gridTable">
				    <td  class="gridRow1">Plain Text Message</td>
				    <td  class="gridRow1"><textarea name="sEmailCanSpam" cols="80" rows="10" class="mceNoEditor" id="sEmailCanSpam" value=""><?php echo get_option('sEmailCanSpam'); ?></textarea></td>
			    </tr>
				  <tr class="gridTable">
				    <td  class="gridRow1">Html Message</td>
				    <td  class="gridRow1"><textarea name="sHtmlEmailCanSpam" cols="80" rows="10" id="sHtmlEmailCanSpam" value="" class="mceEditor"><?php echo get_option('sHtmlEmailCanSpam'); ?></textarea></td>
			    </tr>
				  <tr>
				    <td class="gridrow2">&nbsp;</td>
				    <td width="1028" class="gridrow2">&nbsp;</td>
		        </tr>
				  <tr>
				    <td colspan="2" class="gridheader"><table width="100%" border="0" cellspacing="0" cellpadding="0">
				      <tr>
				        <td valign="top"><input type="submit" name="Update" value="Save Changes" class="inputSubmitb" /></td>
			          </tr>
				      </table></td>
			    </tr>
			  </table>
			</form>
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>

	</body>
</html>