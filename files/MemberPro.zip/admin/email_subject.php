<?php
include_once('../conn.php');
include_once('../functions.php');

if ($_GET['status'] != '')
{
	$sql = "UPDATE tblpromoemailsubject SET ndisplay='" . $dbo->format($_GET['status']) . "' WHERE npromoemailsubject_id = '" . $dbo->format($_GET['projid'])."'";
	$dbo->update($sql);
}


if($_GET['act'] == 'd')
{
	$dbo->delete("DELETE FROM tblpromoemailsubject WHERE npromoemailsubject_id = '" . $dbo->format($_GET['id'])."'");
	header("location:email_subject.php?act=dsus");
}


?>
<html>
<head>
<title><?php echo $admintitle; ?></title>
<?php include("inc-head.php"); ?>
<script type="text/javascript">
function cdel(w) {
if(confirm("Are you sure that you want to delete this email subject line?"))
{
	return true;
}
else
{
return false;
}
}
</script>
</head>
<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
    
    <tr>
      <td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">        <?php include_once('affiliateleft.php'); ?>      </td>
      <td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;"  valign="top" width="100%">
  	
  	    <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
          
            <tr>
              <td class="navRow1" nowrap="nowrap">Email Subject Lines - <a href="add_email_subject.php"><strong>Add New</strong></a></td>
              <td width="100%" align="left">&nbsp;</td>
            </tr>
          
        </table>
        <?php echo isset($message) ? $message : '' ?>
  	    <span class="success">
        <?php if($_GET[act]=="upsus") { echo "Email subject line has been updated successfully<br><br>"; }?>
        <?php if($_GET[act]=="dsus") { echo "Email subject line has been deleted successfully <br><br>"; }?>
        </span>
  	    <table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
        
          <tr>
            <td class="gridHeader">Subject Line</td>
            <td class="gridHeader" width="250">Email This Is Linked To</td>
            <td colspan="3" align="center" nowrap="nowrap" class="gridHeader" width="30">Actions</td>
            <?php
				$sqlcs="SELECT * FROM tblpromoemailsubject order by npromoemailsubject_id";
				$resultcs=$dbo->select($sqlcs);
				if(!empty($resultcs)) $n=$dbo->nr($resultcs);
				
				$number = $n;                // record results selected from database 
				$displayperpage="10";                // record displayed per page 
				$pageperstage="10";                // page displayed per stage 
				$allpage=ceil($number/$displayperpage);        
				$allstage=ceil($allpage/$pageperstage);        // how many page will it be ? 
				if(trim($startpage)==""){$startpage=1;} 
				if(trim($_GET[nowstage])==""){$_GET[nowstage]=1;} 
				if(trim($_GET[nowpage])==""){$_GET[nowpage]=$startpage;} 
				$StartRow = 0;
				if (empty($_GET[nowpage])){
    				if($StartRow == 0){
        				$_GET[nowpage] = $StartRow + 1;
    				}
				}else{
    				$nowpage = $_GET[nowpage];
					$StartRow = ($nowpage - 1) * $displayperpage;
				}
				$c=1;
				$sql="SELECT P1.*, P2.sTitle FROM tblpromoemailsubject P1
				INNER JOIN tblpromoemails P2 ON P1.nPromoEmail_ID = P2.nPromoEmail_ID
				ORDER BY P1.sSubject limit $StartRow,$displayperpage";

				$result=$dbo->select($sql);
				if(!empty($result)){
					$num1 = $number = $dbo->nr($result);
				}
				if(!empty($result)){
					while($row=$dbo->getobj($result)){
			?>
          <tr>
            <td class="gridRow1"><?php echo $row->sSubject;?></td>
            <td class="gridRow1" width="250"><?php echo $row->sTitle;?></td>
            <td class="gridActions1" align="center" width="10"><?php if ($row->nDisplay==0) { ?>
                <a href="<?php echo $_SERVER['PHP_SELF']; ?>?status=1&projid=<?php echo $row->nPromoEmailSubject_ID?>" class="black"> <img src="images/adult_r.gif" alt="Not Active" width="16" height="16" border="0"></a>
                <?php } else { ?>
                <a href="<?php echo $_SERVER['PHP_SELF']; ?>?status=0&projid=<?php echo $row->nPromoEmailSubject_ID?>" class=black> <img src="images/adult_off.gif" alt="Active" width="16" height="16" border="0"></a>
                <?php }?>            </td>
            <td class="gridActions1" align="center" width="10"><a class="grid" href="edit_email_subject.php?act=e&amp;id=<?php echo $row->nPromoEmailSubject_ID;?>" title="Edit Email Subject"> <img src="images/edit.gif" alt="Edit Email Subject" border="0"></a> </td>
            <td class="gridActions1" align="center" width="10"><a class="grid" href="email_subject.php?act=d&amp;id=<?php echo $row->nPromoEmailSubject_ID;?>" title="Delete Email Subject"  OnClick="return cdel('employer');"> <img src="images/delete.gif" alt="Delete Email Subject" border="0"></a> </td>
          </tr>
          <?php }
}
else{?>
<tr>
            <td colspan="5" class="gridrow2"><strong>No Subject Lines Exist! - <a href="add_email_subject.php"><strong>Add New Subject Line </strong></a></strong></td>
          </tr>

<?php }
?>
          <tr>
            <td colspan="5" class="gridFooter"><a href="add_email_subject.php"> &nbsp;</a></td>
          </tr>
        
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td>Page
            <?php
			if($number==0)
			{
			echo "0 of 0";
			}
			else
			{
			echo $nowpage." of ".$allpage;
			}			
			?>
            <?php
			
if($_GET[nowstage]==1 and $_GET[nowpage]==1) 
{
$links="<span class=gridFaded>&laquo; Back&nbsp;|</span>";
}
else
{
$links="<a href='" . $_SERVER['PHP_SELF'] . "?nowstage=".($_GET[nowstage]-1)."&nowpage=".($_GET[nowstage]-1)."'>&laquo; Back</a>&nbsp;|";
}
if($allpage==$_GET[nowstage] and $allpage==$_GET[nowpage]) 
{
$links=$links."<span class=gridFaded> Next &raquo;</span";
}
elseif($number==0)
{
$links=$links."<span class=gridFaded> Next &raquo;</span";
}
else
{
$links=$links."<a href='" . $_SERVER['PHP_SELF'] . "?nowstage=".($_GET[nowstage]+1)."&nowpage=".($_GET[nowstage]+1)."'> Next &raquo;</a>";
}

print $links; 

?></td>
          <td align="right">No of records found :
            <?php echo $n;?></td>
        </tr>
      </table>
      <br></td>
      </tr>
</table>
<?php include_once('b.php'); ?>
</body></html>