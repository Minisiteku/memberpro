<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	if ( isset($_POST['Update']) ){
		$c = 0;
		if (empty($_POST["sSubject"])){
			$c++;
			$es = 1;
		}
		if (empty($_POST["sBody"])){
			$c++;
			$eb = 1;
		}
		if (empty($_POST["sBodyHtml"])){
			$c++;
			$ebh = 1;
		}
		if ($c == 0)
		{
			$sql = sprintf("UPDATE tblemailtemplates SET 
	sSubject='%s', sBody = '%s',sBodyHtml = '%s' WHERE nEmail_ID = '%s';", $dbo->format($_POST["sSubject"]), $dbo->format($_POST["sBody"]), $_POST["sBodyHtml"],$dbo->format($_POST["nEmail_ID"]) );
			$dbo->update($sql);
			header("location:email_templates.php?nEmail_ID=".$_POST["nEmail_ID"].'&msg=Email Template Updated Successfuly!');
		}}
	 
	if(!is_numeric($_REQUEST["nEmail_ID"])) $_REQUEST["nEmail_ID"] = 5;
	
	$rw = $dbo->getobject("SELECT sSubject, sBody, sBodyHtml,sTags FROM tblemailtemplates WHERE nEmail_ID = '".$dbo->format($_REQUEST["nEmail_ID"])."';");
	
	// Some email templates are not in use, lets block them.
	$noload = '"MEMBER_UPGRADE", "MEMBER_SUBSCRIPTION_RENEWAL", "ADMIN_UPGRADE"';
	
	$query = "SELECT nEmail_ID, sTitle FROM tblemailtemplates WHERE sType NOT IN ($noload) ORDER BY sTitle";
	$res = $dbo->select($query);
	//die($query);
	$rwEmail = $chkSsettings;

?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php include("inc-head.php"); 
		if(get_option('use_mce') == '1'){
			 $doc_base = $chkSsettings->sSiteURL .'/'; ?>
             <script type="text/javascript" src="common/js/tiny_mce/tiny_mce.js"></script>
    		<script type="text/javascript" src="common/js/tiny_mce/init.php?css=no&base=<?php echo $doc_base  ?>"></script>
    	<?php } ?>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once('settingsleft.php'); ?></td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			
				<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<td width="10%" nowrap="nowrap" class="navRow1">Email Templates </td>
						<td width="90%" align="center" class="navRow2">&nbsp;</td>
					</tr>
				</table>
				
				<?php if ($message) { echo $message; } ?>
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td align="center" valign="top">
						<form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="f1">
						<input type="hidden" name="nEmail_ID" value="<?php echo $_REQUEST["nEmail_ID"]?>">
							<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
								<tr>
									<td width="250" class="gridRow1">Email Type</td>
									<td class="gridRow1">
									<select name="nEmail_ID" id="nEmail_ID" onChange="window.location.href='?nEmail_ID='+this.value">
									<?php
										while( $row = $dbo->getobj($res)){
											$selected = "";
											if($_REQUEST["nEmail_ID"] == $row->nEmail_ID){
												$selected = "selected";
											}
									?>
										<?php 
										$noUseEmails = array('1','2','3','4','8','11','16');
										if(!in_array($row->nEmail_ID,$noUseEmails )){?><option <?php echo $selected ?> value="<?php echo $row->nEmail_ID ?>"><?php echo $row->sTitle ?></option>
									<?php	
										}}
									?>
								</select></tr>
								<tr>
                                  <td  class="gridRow1">Subject <font color="Red"> * </font></td>
								  <td  class="gridRow1"><input name="sSubject" type="text" value="<?php echo stripslashes($rw->sSubject);?>" size="50">
                                      <?php if ($es == 1) { ?>
								    <span class="red">[ INVALID ]</span>
								    <?php } ?>                                  </td>
							  </tr>
								<tr valign="top">
									<td  class="gridRow1">Text Body <font color="Red"> * </font></td>
									<td  class="gridRow1">
										<textarea name="sBody" cols="50" rows="10" class="mceNoEditor"><?php echo stripslashes($rw->sBody);?></textarea>
								  <?php if ($eb == 1) { ?><span class="red">[ INVALID ]</span><?php } ?>									</td>
								</tr>
								<tr valign="top">
								  <td  class="gridRow1">Html Body <font color="Red"> * </font></td>
								  <td  class="gridRow1"><textarea name="sBodyHtml" cols="50" rows="10" id="sBodyHtml" class="mceEditor"><?php echo stripslashes($rw->sBodyHtml);?></textarea>
                                  <?php if ($ebh == 1) { ?><span class="red">[ INVALID ]</span><?php } ?></td>
						      </tr>
								<tr valign="top">
								  <td  class="gridRow1">Available Tags</td>
								  <td  class="gridRow1">
								  <?php 
								  $tags = unserialize($rw->sTags);
								  foreach($tags as $k=>$v){echo '<p><strong>'.$k.'</strong> - '.$v.'</p>';}
								  ?>
                                  </td>
						      </tr>
								<tr>
									<td colspan="2" class="gridHeader">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr>
												<td valign="top"><input type="submit" name="Update" value="Save Changes" class="inputSubmitb" /></td>
											</tr>
										</table>									</td>
								</tr>
								
						  </table>
						  </form>
						</td>
					</tr>
				</table>
			
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>
	</body>
</html>