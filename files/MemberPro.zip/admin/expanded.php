<?php
require_once '../conn.php';
require_once '../functions.php';
?>
<html>
  <head>
	<title><?php echo $admintitle; ?></title>
	<?php include("inc-head.php"); ?>
	</head>
<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once 'top.php'; ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
		<?php include_once 'plugin-sidebar.php'; ?></td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
        <?php echo isset($message) ? $message : '' ?>
        
        <?php 
		$k = $_GET['plugin'];
		$v = pluginClass::get_page($_GET['plugin']);
		if(is_callable(array($k,$v))){echo call_user_func(array($k,$v));}
		else{echo '<h1>Error: The Requested Page Could Not Be Loaded ...</h1>';}
		
		?>
        
        </td>
    </tr>
    </table>
    <?php include_once 'b.php'; ?>
	</body>
    </html>