<?php
include_once ('../conn.php');
include_once ('../functions.php');

// Permanently expire a user
if (isset($_GET['action']) && $_GET['action']=='expire') {
	
	
	if ( isset($_GET['userid']) && is_numeric($_GET['userid']) && isset($_GET['levelid']) && is_numeric($_GET['levelid']))  {
		
	
			$nToday = date('Ymd');
			$sql = 'UPDATE tbluserlevels SET nActive = 0 WHERE nUser_ID=' . $_GET['userid'] . ' AND nLevel_ID=' . $_GET['levelid'];
			$dbo->update($sql);
			
			// Send email to user
		    email_member_expiry($_GET['userid'], $_GET['levelid']);
	
			$bExpireSuccess = 1;
	}}

// Setup Options for Members per Page listing
$aMPP = array('5', '10', '15', '20', '25', '50', '100');
$mpp = (empty($_GET['mpp'])) ? 10 : $_GET['mpp'];

// Check If Expirations Are Handled Manually.
$autoprocess = get_option('auto_process_expired');
?>
<html>
<head>
<title><?php echo $admintitle; ?></title>
<?php include("inc-head.php"); ?>
<script language="javascript" type="text/javascript"> 
		function cdel(w) {
			return confirm("Are you sure that you want to delete this member?");
		}
		
		function updateMPP(oList) {
			var mpp = oList.options[oList.selectedIndex].value;
			var qs = '?start=<?php echo empty($_GET['start']) ? 0 : $_GET['start'] ?>';
			qs += '&sort=<?php echo $_GET['sort'] ?>';
			qs += '&type=<?php echo $_GET['type'] ?>';
			qs += '&mpp=' + mpp;
			document.location = '<?php echo $_SERVER['PHP_SELF']?>' + qs;
		}

		function expireUser(id, levelid, name) {
			var qs = '?start=<?php echo empty($_GET['start']) ? 0 : $_GET['start'] ?>';
			qs += '&sort=<?php echo $_GET['sort'] ?>';
			qs += '&type=<?php echo $_GET['type'] ?>';
			
			if (confirm("Are you sure you want to expire user " + name + " permanently?")) {
				document.location.href = "expired_members.php" + qs + "&action=expire&userid=" + id + "&levelid=" + levelid;
			}	
		}
		function changeExpire(act,levelid){
			
			if(act == 'show'){
				$("#changeExpire_"+levelid).show();
				$("#showExpire_"+levelid).hide();
			}
			else{
				$("#changeExpire_"+levelid).hide();
				$("#showExpire_"+levelid).show();
			}
			
			
		}
		$(function(){
			$( ".datepicker" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '2000:2037',changeYear: true});
		});
	</script>
</head>

<body leftmargin="0" topmargin="0" rightmargin="0">

<?php include_once ('top.php'); ?>

<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" rowspan="2" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">        
			<?php include_once ('memberleft.php'); ?>      
		</td>
			
<?php 
$nDateToday = date("Ymd");

$sql = "SELECT U.sForename 
FROM tblusers U 
INNER JOIN tbluserlevels UL ON U.nUser_ID = UL.nUser_ID
INNER JOIN tblmembershiplevels M ON M.nLevel_ID = UL.nLevel_ID
WHERE U.nUser_ID > 1 AND UL.nDateExpires <= $nDateToday AND UL.nActive = 1;
";

$number = ($dbo->num_rows($sql)) ? $dbo->num_rows($sql) : 0; // Number of records
			
// Start Paging
/*********************************************************/
include_once('paging.php');
$objPaging = new Paging();

$start = (empty($_GET['start'])) ? 0 : $_GET['start'];	
unset($_GET['start']);
	
$objPaging->Total_Records_Per_Page = $mpp; 
$objPaging->Total_Records = $number;
$index = $start ;
$indexupto = $index + $objPaging->Total_Records_Per_Page;	 	
$objPaging->prepare_ParameterString($_GET);
$objPaging->set_Start_Item($indexupto); 	 		 	
$objPaging->Has_First_Last = true;	
$navigator = $objPaging->Create_Paging();
$pageinfo = $objPaging->get_PageInfo();	 	
$counter = 0;  

$sql = "SELECT 
U.nUser_ID,
U.sForename,
U.sSurname,
U.nJoinDate,
UL.nDateExpires,
UL.nUserLevel_ID,
M.nLevel_ID,
M.sLevel,
P.sPlanName
FROM tblusers U 
INNER JOIN tbluserlevels UL ON U.nUser_ID = UL.nUser_ID
INNER JOIN tblmembershiplevels M ON M.nLevel_ID = UL.nLevel_ID
INNER JOIN tblpaymentplans P ON P.nPaymentPlan_ID = UL.nPaymentPlan_ID
WHERE U.nUser_ID > 1 AND UL.nDateExpires < $nDateToday AND UL.nActive = 1 
";

switch ($_GET['sort']) {
	case 'fname':
		$sortfield = 'U.sForename';
		break;
	case 'lname':
		$sortfield = 'U.sSurname';
		break;
	case 'joindate':
		$sortfield = 'U.nJoinDate';
		break;
	case 'expirydate':
		$sortfield = 'UL.nDateExpires';
		break;
	case 'level':
		$sortfield = 'M.sLevel';
		break;
	case 'plan':
		$sortfield = 'P.sPlanName';
		break;
	default:
		$sortfield = 'UL.nDateExpires,U.sSurname';
}

$sql .= sprintf("ORDER BY %s %s ", $sortfield, $dbo->format($_GET['type'])); // Adding order by to main query

$sql .= "LIMIT ".$objPaging->Total_Records_Per_Page." OFFSET ".$index;
/*********************************************************/

$result = $dbo->select($sql);

$qs = sprintf("?start=%s&mpp=%s", $start, $mpp);

// Set Total Members Display
$total_members = "Total Expired Members: <b>".$number."</b>";
?>
		
		<td width="100%" align="left" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">
			<?php if (isset($message))  echo $message ?>			
            <table class="navTable" border="0" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td width="183" class="navRow1" nowrap="nowrap">Expired Memberships</td>
					<td width="1036" class="navRow2" style="text-align:right; padding-right:20px">
						Memberships per page&nbsp;
						<select id='mpp' style='height:1.5em' onChange="updateMPP(this)">
							<?php
								foreach ($aMPP as $val) {
									$selected = ($val == $mpp) ? 'selected' : '';;
									echo "<option value='$val' $selected>$val</option>";
								}
							?>
						</select>
					</td>
				</tr>
			</table>
			This page allows you to view all expired memberships that HAVE NOT been deactivated.<br>
<div class="notify-warning">
<?php if($autoprocess == '1'){
	echo 'Automatic Expiration Processing is On! All Expired memberships will be deactivated the next time your daily cron job runs';
}
else{echo 'Automatic Expiration Processing is Off! All Expired Memberships Must Be Deactivated Manually, Below.';}?></div>
			<!-- LISTING HEADER -->
			<table class="gridTable" cellpadding="0" cellspacing="1">
				<tr>
					<td colspan="8" class="gridFooter">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td style='text-align:left'>
									<?php echo $navigator; 	?>
								</td>
								<td style='text-align:right; padding-right:10px'>
									Page <?php echo $pageinfo ?>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<!-- FIRST NAME COLUMN -->
					<td class="gridHeader">
					<?php 	if ($_GET['sort'] == 'fname' && $_GET['type'] == 'asc') { ?>
						<a href="expired_members.php<?php echo $qs?>&sort=fname&type=desc" class="bluenave">First</a>
					<?php } else { ?>
						<a href="expired_members.php<?php echo $qs?>&sort=fname&type=asc" class="bluenave">First </a>
					<?php } ?>/
					
					<?php 	if ($_GET['sort'] == "lname" && $_GET['type'] == "asc") { 	?>
						<a href="expired_members.php<?php echo $qs?>&sort=lname&type=desc" class="bluenave">Last Name</a>
					<?php } else { ?>
						<a href="expired_members.php<?php echo $qs?>&sort=lname&type=asc" class="bluenave">Last Name</a>
					<?php } ?>
					</td>
					<td class="gridHeader"><?php if ($_GET['sort'] == "level" && $_GET['type'] == "asc") { 	?>
                      <a href="expired_members.php<?php echo $qs?>&sort=level&type=desc" class="bluenave">Membership Level</a>
                      <?php } else { ?>
                      <a href="expired_members.php<?php echo $qs?>&sort=level&type=asc" class="bluenave">Membership Level</a>
                    <?php } ?></td>
					<!-- LAST NAME COLUMN -->
					<!-- EMAIL COLUMN -->
					<td align="left" nowrap="nowrap" class="gridHeader">
					<?php 	if ($_GET['sort'] == "plan" && $_GET['type'] == "asc") { 	?>
						<a href="expired_members.php<?php echo $qs?>&sort=plan&type=desc" class="bluenave">Payment Plan</a>
					<?php } else { ?>
						<a href="expired_members.php<?php echo $qs?>&sort=plan&type=asc" class="bluenave">Payment Plan</a>
					<?php } ?>
					</td>
					<!-- JOIN DATE COLUMN -->
					<td class="gridHeader" nowrap="nowrap">
					<?php if ($_GET['sort'] == "joindate" && $_GET['type'] == "asc") { 	?>
					<a href="expired_members.php<?php echo $qs?>&sort=joindate&type=desc" class="bluenave">Join Date</a>
					<?php } else { ?>
					<a href="expired_members.php<?php echo $qs?>&sort=joindate&type=asc" class="bluenave">Join Date</a>
					<?php } ?>
					</td>
					<!-- EXPIRY DATE COLUMN -->
					<td class="gridHeader" nowrap="nowrap">
					<?php if ($_GET['sort'] == "expirydate" && $_GET['type'] == "asc") { 	?>
					<a href="expired_members.php<?php echo $qs?>&sort=expirydate&type=desc" class="bluenave">Expiry Date</a>
					<?php } else { ?>
					<a href="expired_members.php<?php echo $qs?>&sort=expirydate&type=asc" class="bluenave">Expiry Date</a>
					<?php } ?>
					</td>
					<!-- LEVEL NAME COLUMN -->
					<td class="gridHeader"  nowrap="nowrap"><?php if ($_GET['sort'] == "expirydate" && $_GET['type'] == "asc") { 	?>
					<a href="expired_members.php<?php echo $qs?>&sort=expirydate&type=desc" class="bluenave">Days Expired</a>
					<?php } else { ?>
					<a href="expired_members.php<?php echo $qs?>&sort=expirydate&type=asc" class="bluenave">Days Expired</a>
					<?php } ?></td>
					<!-- AFFILIATE -->
					<td colspan="2"  nowrap="nowrap" class="gridHeader">Actions</td>
				</tr>

				<?php
					// Add Sort to QueryString
					$qs .= sprintf("&sort=%s&type=%s", $_GET['sort'], $_GET['type']);
				?>
				
					
				<?php 
				if ($result) {
					while ($row = $dbo->getobj($result)) {
						
     					
						$exptime = strtotime(fShowDate('4',$row->nDateExpires));
						$datediff = time() - $exptime;
						$daysExp =  floor($datediff/(60*60*24));
				?>

				<!-- MEMBER LISTING -->
				<tr>
					<td class="gridrow2">
					<a class="bluenave" href="view_member.php?id=<?php echo $row->nUser_ID ?> " title="View Member Details"><?php echo $row->sForename; ?></a>					<a class="bluenave" href="view_member.php?id=<?php echo $row->nUser_ID ?> " title="View Member Details"><?php echo $row->sSurname; ?></a></td>
				  <td class="gridrow2"><?php echo $row->sLevel; ?></td>
					<td class="gridrow2" align="left"><?php echo $row->sPlanName ?></td>
					<td class="gridrow2" align="center"><?php echo fShowDate($chkSsettings->nDateFormat, $row->nJoinDate); ?>&nbsp;</td>
					<td class="gridrow2" align="center">
						<div id="showExpire_<?php echo $row->nUserLevel_ID ?>"><?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); ?></div>
                        <div style="display:none" id="changeExpire_<?php echo $row->nUserLevel_ID ?>"><form action="actions.php?type=member" method="post">
                        <input name="newExpire" type="text" readonly size="10" class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); ?>"><input type="hidden" name="userLevelId" value="<?php echo $row->nUserLevel_ID ?>" />
                        <input type="hidden" name="act" value="changeExpiredDate" />
                        <br>
                        <input type="button" name="button2" id="button2" value="Cancel" onClick="changeExpire('hide','<?php echo $row->nUserLevel_ID ?>')">
<input type="submit" name="button" id="button" value="Update">
                        </form></div>
                   	</td>
					<td class="gridrow2" align="center"><?php echo $daysExp ?></td>
					<td align="center" valign="top" class="gridrow2">
					  <form action="actions.php?type=member" method="post">
					    <input type="submit" class="inputsubmitb" value="Deactivate" onClick="return confirm('Are you sure you want to Deactivate This Level?');">
					    <input type="hidden" name="act" value="deactivateExpired" />
                        <input type="hidden" name="userLevelId" value="<?php echo $row->nUserLevel_ID ?>" />
                      </form>				    </td>
					<td align="center" valign="top" class="gridrow2">
						<input type="button" class="inputsubmitb" value="Change Expiry Date" onClick="changeExpire('show','<?php echo $row->nUserLevel_ID ?>')">
					</td>

				</tr>
				<?php 
					} 
				}
				else{?>
                <tr>
                <td colspan="8" class="gridrow2">No Expired Memberships
                  <?php include_once ('b.php'); ?></td>
                </tr>
                
                <?php }
				?>
				<tr>
					<td colspan="8" class="gridFooter">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td style='text-align:left'>
									<?php echo $navigator; 	?>
								</td>
								<td style='text-align:right; padding-right:10px'>
									Page <?php echo $pageinfo ?>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>  
			<br />
		</td>
	</tr>
</table>
</body>
</html>