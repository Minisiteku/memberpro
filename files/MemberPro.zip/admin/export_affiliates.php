<?php
include_once('../conn.php');
include_once('../functions.php');

$sFilename="affiliatelist-" . date("Ymd") . ".csv"; // file name for CSV

// Select all affiliates
$sQuery = 	"SELECT * FROM tblusers WHERE nadmin=0 AND naffiliate=1 AND nactive=1 ORDER BY sforename";
				
$sResult = $dbo->select($sQuery,1);
$rowcount = $dbo->nr($sResult);
// Lets include the custom fields into the export file. /////////////////////////////////// MDP - 3-9-12
$cfields = "";
$sql = "SELECT `sCustomFieldName`
FROM `tblcustomfieldsettings`
ORDER BY nCustomFieldSetting_ID LIMIT 0 , 30;";
$result = $dbo->select($sql);
//$row = mysql_fetch_array($result);

while($row = $dbo->getarray($result)){
	$cfields .= $row[0] .",";
}
$sql = "";$result = "";$row = "";
/////////////////////////////////////////////////////////////////////////////////////
if ($rowcount != 0)
{

	$sCSVRow = "First Name, Last Name, Email, Address 1, Address 2, Address3, City/Town, State/County, ZIP/Postcode, Country, ".$cfields."\n";
	
	while ($sRow = $dbo->getarray($sResult)) 
	{
		$sCSVRow .= '"' . $sRow[sForename] . '","' . $sRow[sSurname] .  '","' . $sRow[sEmail]. '","' . $sRow[sAddr1] . '","' . $sRow[sAddr2] . '","' . $sRow[sAddr3] . '","' . $sRow[sTown] . '","' . $sRow[sCounty] . '","' . $sRow[sPostcode] . '","' . $sRow[sCountry] . '"' . "\n";
	}
	
}
else
{
	$sCSVRow = "There were no records found";	
}

// Generate CSV file
header('Content-type:text/csv');
header('Content-disposition:attachment;filename='.$sFilename);
echo $sCSVRow;
exit();
?>