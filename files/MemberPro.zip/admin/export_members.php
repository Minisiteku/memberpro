<?php
error_reporting(0);
include_once ('../conn.php');
include_once ('../functions.php');

$sFilename = "memberlist-" . date("Ymd") . ".csv"; // file name for CSV

// Select all affiliates
$sQuery = "SELECT * FROM tblusers WHERE nadmin=0 AND nactive=1 ORDER BY sforename";
//die($sQuery);
$sResult = $dbo->select($sQuery);
$rowcount = $dbo->nr($sResult);
// Lets include the custom fields into the export file. /////////////////////////////////// MDP - 3-9-12
$cfields = "";
$sql = "SELECT `sCustomFieldName`
FROM `tblcustomfieldsettings`
ORDER BY nCustomFieldSetting_ID LIMIT 0 , 30;";
$result = $dbo->select($sql);
//$row = mysql_fetch_array($result);

while($row = $dbo->getarray($result)) $cfields .= $row[0] .",";

$sql = "";$result = "";$row = "";
/////////////////////////////////////////////////////////////////////////////////////
if ($rowcount != 0) {

    $sCSVRow = "First Name, Last Name, Email, Address 1, Address 2, Address3, City/Town, State/County, ZIP/Postcode, Country, phone, cell, Password,".$cfields." Join Date, subscription,".PHP_EOL;
$cfields = "";
    while ($sRow = $dbo->getarray($sResult)) {
        // select all membership levels and expiry dates for that user
        $query = "SELECT * FROM tbluserlevels WHERE nUser_ID=" . $sRow['nUser_ID'];
        $result = $dbo->select($query);
        $subscription = "";
        while ($row = $dbo->getarray($result)) {
            if ($subscription == "") {
                $subscription = $row['nLevel_ID'] . "-" . $row['nDateExpires']."-" . $row['nDateActive'];
            } else {
                $subscription .= ", " . $row['nLevel_ID'] . "-" . $row['nDateExpires']."-" . $row['nDateActive'];
            }
        }
        //-----------------------------------


        $sCSVRow .= $sRow['sForename'] . ',' . $sRow['sSurname'] . ',' . $sRow['sEmail'] .',' . $sRow['sAddr1'] . ',' . $sRow['sAddr2'] . ',' . $sRow['sAddr3'] . ',' .$sRow['sTown'] . ',' . $sRow['sCounty'] . ',' . $sRow['sPostcode'] . ',' . $sRow['sCountry'] .',' . $sRow['sTelephone'] . ',' . $sRow['sMobile'] . ',' . $sRow['sPassword']. ','.$sRow['sCustomField1'].',' .$sRow['sCustomField2'].','.$sRow['sCustomField3'].','.$sRow['sCustomField4'].','.$sRow['sCustomField5'].','.$sRow['sCustomField6'].','.$sRow['sCustomField7'].','.$sRow['sCustomField8'].','.$sRow['sCustomField9'].','.$sRow['sCustomField10'].','. $sRow['nJoinDate']  . ',' . $subscription . ',' .PHP_EOL;
    }

} else {
    header("Location:manage_members.php?err=No Members To Export");
	exit;
}


// Generate CSV file
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header('Content-type:text/csv');
header('Content-disposition:attachment;filename=' . $sFilename);
echo $sCSVRow;
exit();
?>