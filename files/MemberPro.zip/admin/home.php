<?php 
	include_once('../conn.php');
	include_once('../functions.php');
	$VERSION = checkversion();
	
	if($licenseData->type == 'single') $displayLicenseType = 'Single Domain';
	elseif ($licenseData->type == 'unlimited') $displayLicenseType = 'Unlimited Domains';
	elseif ($licenseData->type == 'trial') $displayLicenseType = 'Free Trial (Single)';
	elseif ($licenseData->type == 'developer') $displayLicenseType = 'Developer Provided';

// Total Counts

	$nActiveMembers = $dbo->getval("SELECT COUNT(*) FROM tblusers WHERE nActive = 1 AND nUser_ID > 1");
	$nCancelledMembers = $dbo->getval("SELECT COUNT(*) FROM (SELECT nUser_ID FROM tbluserlevels WHERE nDateCancelled > 0 GROUP BY nUser_ID) AS tmp1");
	$nFreeOnlyMembers = $dbo->getval("SELECT COUNT(*) FROM (
						SELECT tblusers.nUser_ID FROM tblusers 
						WHERE tblusers.nUser_ID NOT IN (
							SELECT tblusers.nUser_ID FROM tblusers
							INNER JOIN tbluserlevels ON tbluserlevels.nUser_ID = tblusers.nUser_ID 
							INNER JOIN tblpaymentplans ON tblpaymentplans.nPaymentPlan_ID = tbluserlevels.nPaymentPlan_ID
							INNER JOIN tblpaymentprocessors ON tblpaymentprocessors.nPaymentProcessor_ID = tblpaymentplans.nPaymentProcessor_ID
							WHERE NOT tblpaymentprocessors.sProcessorName = 'Free' AND tblusers.nActive = 1
						)
						AND nUser_ID > 1 AND tblusers.nActive = 1
						GROUP BY tblusers.nUser_ID
					) AS tmp1");
	$nPaidOnlyMembers = $dbo->getval("SELECT COUNT(*) FROM (
						SELECT tblusers.nUser_ID FROM tblusers 
						WHERE tblusers.nUser_ID IN (
							SELECT tblusers.nUser_ID FROM tblusers
							INNER JOIN tbluserlevels ON tbluserlevels.nUser_ID = tblusers.nUser_ID 
							INNER JOIN tblpaymentplans ON tblpaymentplans.nPaymentPlan_ID = tbluserlevels.nPaymentPlan_ID
							INNER JOIN tblpaymentprocessors ON tblpaymentprocessors.nPaymentProcessor_ID = tblpaymentplans.nPaymentProcessor_ID
							WHERE NOT tblpaymentprocessors.sProcessorName = 'Free' AND tblusers.nActive = 1
						)
						AND nUser_ID > 1 AND tblusers.nActive = 1
						GROUP BY tblusers.nUser_ID
					) AS tmp1");
	$nActiveAffiliates = $dbo->getval("SELECT COUNT(*) FROM tblusers WHERE nActive = 1 AND nUser_ID > 1 AND nAffiliate = 1");

?>
<html>
         <head>
         <title>Admin Control Panel - Easy Member Pro</title>
         <meta charset="utf-8" />
         <?php include("inc-head.php"); ?>
         <script type="text/javascript" language="JavaScript" src="common/js/wrapscript.js"></script>
         <script type="text/javascript" src="../js/swfobject.js"></script>
         <script type="text/javascript">
			var params = {};
			params.wmode = "transparent"; 
			swfobject.embedSWF("common/open-flash-chart.swf", "admin_chart_membership", "100%", "200", "9.0.0", "expressInstall.swf", {"data-file":"chart_data.php?data=membership"},params );
			swfobject.embedSWF("common/open-flash-chart.swf", "admin_chart_revenue", "100%", "200", "9.0.0", "expressInstall.swf", {"data-file":"chart_data.php?data=revenue"},params );
			
			</script>
         <style type="text/css">
.columntype2 {
	width: 48%;
	margin: 5px;
	float: left;
}
.widget {
	width: 100%;
	margin: 10px 0;
	float: left;
	border: thin solid #000;
}
.widget_handle {
}
.widget_content {
	padding: 2px 5px;
}
.qs_image {
	width: 24px;
	height: 24px;
	float: left;
	margin: -5px 5px 0 0;
}
</style>
         </head>
         <body leftmargin="0" topmargin="0" rightmargin="0">
         <?php include_once('top.php'); ?>
         <table cellpadding="0" cellspacing="0" width="100%">
           <tr>
             <td width="100%" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;"><table cellpadding="0" cellspacing="0" width="100%">
                 <tr>
                 <td class="gridFaded"><?php 
					// Check for successful cron run within past 25 hours.
					$sql = "SELECT * FROM tblcronlog ORDER BY timestamp DESC LIMIT 1";
					$result = $dbo->select($sql);
					$row = $dbo->getarray($result);
					//var_dump($row);
					$now = time();
					$lastrun = $now - intval($row['timestamp']);
					$lasthours = floor($lastrun / 60/60);
					if($lasthours > 36){
						$lastdays = floor($lasthours / 24);
						}
						
					/*
					more stable - use later, if at all.
					$date1 = "2000-01-01";
					$date2 = "2011-03-14";

					$diff = abs(strtotime($date2) - strtotime($date1));
					$years = floor($diff / (365 * 60 * 60 * 24));
					$months = ceil(($diff - ($years * 365 * 60 * 60 * 24)) / ((365 * 60 * 60 * 24) / 12));
					$months2 = floor(($diff - ($years * 365 * 60 * 60 * 24)) / ((365 * 60 * 60 * 24) / 12));
					$days = floor(($diff - $years * 365 * 60 * 60 * 24 - $months2 * 30 * 60 * 60 * 24)/ (60 * 60 * 24));
					
					*/
					///
					if($lastrun > 60*60*24){
						?>
                     <div class="notify-warning"><div class="notify-close, warning-close" onClick="closeNotify(this)"></div>
                       Your Daily Cron Job Has Not Run In
<?php if($lastdays!=0){echo $lastdays.' days.';}else{echo $lasthours.' Hours';} ?><br /><a href="manage_crons.php">Manage Cron Jobs</a></div>
                     <?php
						}
					?>
                     <p>Welcome <?php echo $objAdmin->sForename; ?> to your <?php echo $admintitle; ?> control panel</p></td>
               </tr>
               </table>
               <br />
               <?php if ( function_exists('mysql_fetch_scalar_query') ) : ?>
               <?php
						$stat_today = date('Ymd');
						$stat_last7 = date('Ymd', strtotime('-7 days'));
						$stat_last30 = date('Ymd', strtotime('-1 month'));
					?>
               <div id="column_1" class="columntype2">
                 <div class="widget">
                   <div class="widget_handle gridheader">New Members Chart</div>
                   <div align="center" id="admin_chart_membership" class="widget_content" ></div>
                 </div>
                 <?php if(!is_option('QS_hide')){?>
                 <div class="widget" id="quickStartList">
                   <div class="widget_handle gridheader">Quick Start Checklist</div>
                   <div class="widget_content">
                     <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
                       <tr>
                         <td valign="middle" class="gridrow2"><span id="QS_settings" class="qs_image"> <img src="<?php echo (!is_option('QS_settings') || get_option('QS_settings') == '0')?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" /> </span> Review and Modify Site Settings</td>
                         <td class="gridrow2"><span id="QS_settings_go" style="display:<?php echo (!is_option('QS_settings') || get_option('QS_settings') == '0')?'inline':'none' ?>">
                           <input type="button" name="Button" value="Go" onClick="doQS('settings')">
                           <input type="button" name="settings" value="Mark Completed" onClick="completeQs(this)">
                           </span> <span id="QS_settings_done" style="display:<?php echo (get_option('QS_settings') == '1')?'inline':'none' ?>">
                           <input type="button" name="settings" value="Reset" onClick="resetQs(this)">
                           </span></td>
                       </tr>
                       <tr>
                         <td class="gridrow2"><span id="QS_email" class="qs_image"> <img src="<?php echo (!is_option('QS_email'))?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" /> </span> Setup Email Settings and Templates</td>
                         <td class="gridrow2"><span id="QS_email_go" style="display:<?php echo (!is_option('QS_email'))?'inline':'none' ?>">
                           <input type="button" name="Button" value="Go" onClick="doQS('email')">
                           <input type="button" name="email" value="Mark Completed" onClick="completeQs(this)">
                           </span> <span id="QS_email_done" style="display:<?php echo (get_option('QS_email') == '1')?'inline':'none' ?>">
                           <input type="button" name="email" value="Reset" onClick="resetQs(this)">
                           </span></td>
                       </tr>
                       <tr>
                         <td class="gridrow2"><span id="QS_levels" class="qs_image"> <img src="<?php echo (!is_option('QS_levels') || get_option('QS_levels') == '0')?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" /> </span> Define Membership Level(s)</td>
                         <td class="gridrow2"><span id="QS_levels_go" style="display:<?php echo (!is_option('QS_levels'))?'inline':'none' ?>">
                           <input type="button" name="Button" value="Go" onClick="doQS('levels')">
                           <input type="button" name="levels" value="Mark Completed" onClick="completeQs(this)">
                           </span> <span id="QS_levels_done" style="display:<?php echo (get_option('QS_levels') == '1')?'inline':'none' ?>">
                           <input type="button" name="levels" value="Reset" onClick="resetQs(this)">
                           </span></td>
                       </tr>
                       <tr>
                         <td class="gridrow2"><span id="QS_processors" class="qs_image"> <img src="<?php echo (!is_option('QS_processors'))?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" /> </span> Setup Payment Processor(s)</td>
                         <td class="gridrow2"><span id="QS_processors_go" style="display:<?php echo (!is_option('QS_processors'))?'inline':'none' ?>">
                           <input type="button" name="Button" value="Go" onClick="doQS('processors')">
                           <input type="button" name="processors" value="Mark Completed" onClick="completeQs(this)">
                           </span> <span id="QS_processors_done" style="display:<?php echo (get_option('QS_processors') == '1')?'inline':'none' ?>">
                           <input type="button" name="processors" value="Reset" onClick="resetQs(this)">
                           </span></td>
                       </tr>
                       <tr>
                         <td class="gridrow2"><span id="QS_plans" class="qs_image"> <img src="<?php echo (!is_option('QS_plans'))?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" /> </span> Define Payment Plans</td>
                         <td class="gridrow2"><span id="QS_plans_go" style="display:<?php echo (!is_option('QS_plans'))?'inline':'none' ?>">
                           <input type="button" name="Button" value="Go" onClick="doQS('plans')">
                           <input type="button" name="plans" value="Mark Completed" onClick="completeQs(this)">
                           </span> <span id="QS_plans_done" style="display:<?php echo (get_option('QS_plans') == '1')?'inline':'none' ?>">
                           <input type="button" name="plans" value="Reset" onClick="resetQs(this)">
                           </span></td>
                       </tr>
                       <tr>
                         <td class="gridrow2"><span id="QS_pages" class="qs_image"> <img src="<?php echo (!is_option('QS_pages') || get_option('QS_pages') == '0')?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" /> </span> Create Home/Sales Pages</td>
                         <td class="gridrow2"><span id="QS_pages_go" style="display:<?php echo (!is_option('QS_pages'))?'inline':'none' ?>">
                           <input type="button" name="Button" value="Go" onClick="doQS('pages')">
                           <input type="button" name="pages" value="Mark Completed" onClick="completeQs(this)">
                           </span> <span id="QS_pages_done" style="display:<?php echo (get_option('QS_pages') == '1')?'inline':'none' ?>">
                           <input type="button" name="pages" value="Reset" onClick="resetQs(this)">
                           </span></td>
                       </tr>
                       <tr>
                         <td class="gridrow2"><span id="QS_content" class="qs_image"> <img src="<?php echo (!is_option('QS_content'))?'images/Delete_24x24.png':'images/Confirm_24x24.png' ?>" /> </span> Add Member Content / Upload Products</td>
                         <td class="gridrow2"><span id="QS_content_go" style="display:<?php echo (!is_option('QS_content'))?'inline':'none' ?>">
                           <input type="button" name="Button" value="Go" onClick="doQS('content')">
                           <input type="button" name="content" value="Mark Completed" onClick="completeQs(this)">
                           </span> <span id="QS_content_done" style="display:<?php echo (get_option('QS_content') == '1')?'inline':'none' ?>">
                           <input type="button" name="content" value="Reset" onClick="resetQs(this)">
                           </span></td>
                       </tr>
                     </table>
                     <div align="right">
                       <input type="button" name="QS_Close" id="QS_Close" value="Disable Quickstart" onClick="disableQS()">
                     </div>
                   </div>
                 </div>
                 <?php }
				 if($licenseData->type != 'developer' || (isset($DEVOPTS['SYSINFO']) && $DEVOPTS['SYSINFO'] == 1)){
				  ?>
                 <div class="widget">
                   <div class="widget_handle gridheader">System Information</div>
                   <div class="widget_content">
                     <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
                        <?php if($licenseData->type != 'developer' || (isset($DEVOPTS['SYSINFO_KEY']) && $DEVOPTS['SYSINFO_KEY'] == 1)){?>
                       <tr>
                         <td class="gridrow2">License Key</td>
                         <td class="gridrow2"><a href="license.php?action=update" title="Click Here To Change Your License Key"><?php echo $licenseData->key ?></a></td>
                       </tr>
                       <?php
						}
						if($licenseData->type != 'developer' || (isset($DEVOPTS['SYSINFO_REGISTERED']) && $DEVOPTS['SYSINFO_REGISTERED'] == 1)){?>
                       <tr>
                         <td class="gridrow2">Registered To</td>
                         <td class="gridrow2"><?php echo $licenseData->Customer ?></td>
                       </tr>
                       <?php
						}
						if($licenseData->type != 'developer' || (isset($DEVOPTS['SYSINFO_LTYPE']) && $DEVOPTS['SYSINFO_LTYPE'] == 1)){?>
                       <tr>
                         <td class="gridrow2">License Type</td>
                         <td class="gridrow2"><?php echo $displayLicenseType ?>
                           <?php 
						  
						  if ($displayLicenseType == 'trial') 
						  echo " - <a href='http://easymemberpro.com/index.php?page=trial-upgrade' target='_blank'>Purchase Full License</a>";
                          
                          elseif($displayLicenseType == 'single')
						  echo " - <a href='http://www.easymemberpro.com/index.php?page=join&plan=46' target='_blank'>Upgrade To Unlimited</a>";
						  
						  ?></td>
                       </tr>
                       <?php 
						}
						if($licenseData->type != 'developer') {?>
                       <tr>
                         <td class="gridrow2"><?php echo ($licenseData->type == 'trial')?'Trial Expires':'Support/Upgrade Expires' ?></td>
                         <td class="gridrow2"><span class="<?php echo ($licenseData->updates_expires <= time())?'error':'green'?>" > <?php echo fShowDate($chkSsettings->nDateFormat,date('Ymd',$licenseData->updates_expires)) ?> </span></td>
                       </tr>
                       <?php
					   if($licenseData->updates_expires >= time()){ ?>
                       <tr>
                         <td class="gridrow2">Support Email</td>
                         <td class="gridrow2"><input id="license_support_email" name="license_support_email" type="text" value="<?php echo $licenseData->support_email ?>" size="40"> <input type="button" name="update_support_email" id="update_support_email" value="Update" onClick="updateSupportEmail('license_support_email','<?php echo $licenseData->key ?>')"><div id="license_support_email_message"></div></td>
                       </tr>
                       
                       <?php
					   } }
					   if($licenseData->type != 'developer' 
					   || (isset($DEVOPTS['SYSINFO_VERSION']) && $DEVOPTS['SYSINFO_VERSION'] == '1')){
					   ?>
                       <tr>
                         <td class="gridrow2">Installed Version</td>
                         <td class="gridrow2"><span class="<?php echo ($VERSION!=false)?'error':'green'?>" ><?php echo get_emp_version() ?> <?php echo ($VERSION!=false)?' - '.$VERSION:''; ?></span></td>
                       </tr>
                       <?php } ?>
                     </table>
                   </div>
                 </div>
                 <?php } ?>
               </div>
               <div class="columntype2" id="column_2">
                 <div class="widget">
                   <div class="widget_handle gridheader">Revenue Chart</div>
                   <div align="center" id="admin_chart_revenue"  class="widget_content"></div>
                 </div>
                 <div class="widget">
                   <div class="widget_handle gridheader">Total Counts (depreciated)</div>
                   <div class="widget_content">
                     <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
                       <tr>
                         <td class="gridrow2">Total Active Members:</td>
                         <td class="gridrow2"><?php echo $nActiveMembers ?></td>
                       </tr>
                       <tr>
                         <td class="gridrow2">Total Free Only Members:</td>
                         <td class="gridrow2"><?php echo $nFreeOnlyMembers ?></td>
                       </tr>
                       <tr>
                         <td class="gridrow2">Total Paid Members:</td>
                         <td class="gridrow2"><?php echo $nPaidOnlyMembers ?></td>
                       </tr>
                       <tr>
                         <td class="gridrow2">Total Active Affiliates:</td>
                         <td class="gridrow2"><?php echo $nActiveAffiliates ?></td>
                       </tr>
                       <tr>
                         <td class="gridrow2">Total Cancelled Members:</td>
                         <td class="gridrow2"><?php echo $nCancelledMembers ?></td>
                       </tr>
                     </table>
                   </div>
                 </div>
               </div>
               <?php endif; // if ( function_exists('mysql_fetch_scalar_query') ) ?></td>
           </tr>
         </table>
         <?php include_once('b.php'); ?>
</body>
</html>