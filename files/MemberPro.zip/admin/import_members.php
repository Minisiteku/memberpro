<?php
include_once ('../conn.php');
include_once ('../functions.php');

define('FIRST', 0);
define('LAST', 1);
define('EMAIL', 2);
define('ADDR1', 3);
define('ADDR2', 4);
define('ADDR3', 5);
define('CITY', 6);
define('STATE', 7);
define('ZIP', 8);
define('COUNTRY', 9);
define('PHONE', 10);
define('CELL', 11);
define('PASSWORD', 12);
define('JOINDATE', 13);
define('SUBSCRIPTION', 14);

define('USER_ADDED', 1);
define('USER_ALREADY_EXISTS', 2);


//-----------------we generate an array with all membership levels
$result = $dbo->select("SELECT * FROM tblmembershiplevels WHERE nLevel_ID>1");
$membershipLevelsArray = array();
while ($row = $dbo->getarray($result)) {
    array_push($membershipLevelsArray, array($row['nLevel_ID'], $row['sLevel']));
}


function import_user($info){
    // Check if User already Exists
    global $dbo, $membershipLevelsArray;
    $sql = sprintf("SELECT nUser_ID FROM tblusers WHERE sEmail = '%s' ", $dbo->format($info[EMAIL]));
    $rs = $dbo->select($sql);
    if ($dbo->nr($rs) > 0)
        return USER_ALREADY_EXISTS;

    // Add User to tblusers
    if (empty($info[JOINDATE]))
        $info[JOINDATE] = date("Ymd");
    if (empty($info[PASSWORD])) //$info[PASSWORD] = genpassword(6);

        $info[PASSWORD] = "123456";
    $sql = sprintf("INSERT INTO tblusers (sForename, sSurname, sAddr1, sAddr2, sAddr3, sTown, sCounty, sPostcode, sCountry, sEmail, sTelephone, sMobile, sPaymentStatus, sPassword, nJoinDate, nActive)
								VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', 1)",
        $info[FIRST], $info[LAST], $info[ADDR1], $info[ADDR2], $info[ADDR3], $info[CITY],
        $info[STATE], $info[ZIP], $info[COUNTRY], $info[EMAIL], $info[PHONE], $info[CELL],
        '', $info[PASSWORD], $info[JOINDATE]);
    $dbo->insert($sql);


    //--------- we now add the membership levels to the last inserted member-------------------------------
    if ($info[SUBSCRIPTION] != "") {
        $membership_levels_array = explode(",", $info[SUBSCRIPTION]);

        foreach ($membership_levels_array as $membership_level) {

            $query = "SELECT nUser_ID FROM tblusers WHERE sEmail='" . $info[EMAIL] . "'";
            $result = $dbo->select($query);
            $row = $dbo->getarray($result);
            $user_id = $row['nUser_ID'];


            $membership_level = explode("-", $membership_level);
            $membership_level_id = $membership_level[0];
            $membership_level_expires = $membership_level[1];
            $nDateActive = $membership_level[2];

            $query = "INSERT INTO tbluserlevels (nUser_ID, nLevel_ID, nDateExpires, nActive, nDateActive) 
		VALUES 
		('$user_id', '$membership_level_id', '$membership_level_expires', '1', $nDateActive)";
            $dbo->insert($query) or die($dbo->error);
        }
    }
    //-----------------------------------------------------------------------------------------------


    return USER_ADDED;}

if (!empty($_POST)) {
    $file = $_FILES['importfile'];

    if ($file['error'] == UPLOAD_ERR_OK) {
        $filename = $file['tmp_name'];
        $delimiter = ($_POST['delimiter'] == 'comma') ? ',' : '\t';
        $cnt = (isset($_POST['header'])) ? 0 : 1; // If we have a header we'll skip the first line
        $aExists = array();
        $cnt_import = 0;
        $cnt_exists = 0;


        //======generates subscription levels string if any level is checked
        $nDateExpires = str_replace("-", "", $_POST['dtEnd']);
        $nDateActive = date(Ymd);

        foreach ($membershipLevelsArray as $membersipLevel) {
            if ($_POST['level_' . $membersipLevel[0]]) {

                if ($levelsString == "") {
                    $levelsString = $membersipLevel[0] . "-" . $nDateExpires . "-" . $nDateActive;
                } else {
                    $levelsString .= ", " . $membersipLevel[0] . "-" . $nDateExpires . "-" . $nDateActive;
                    ;
                }
            }

        }

        // Process File

        if (($handle = fopen($filename, "r")) !== false) {
            while (($info = fgetcsv($handle, 1000, ",")) !== false) {

                if ($levelsString != "") {
                    $info[SUBSCRIPTION] = $levelsString;
                }
                if ($cnt > 0) {
                    $status = import_user($info);
                    if ($status == USER_ALREADY_EXISTS) {
                        $info['line'] = $cnt;
                        $aExists[] = $info;
                        $cnt_exists++;
                    } else
                        $cnt_import++;
                }
                $cnt++;

            }
            fclose($handle);
        }

        $total = $cnt_import + $cnt_exists;
        $message = "<p class='success'>$total Record(s) processed &mdash; $cnt_import Member(s) successfully imported </p>";
        if ($cnt_exists != 0)
            $message .= "<p class='error'>&mdash; $cnt_exists Member(s) already exist in database</p>";
    } elseif ($file['error'] == UPLOAD_ERR_NO_FILE) {
        $message = "<p class='error'>Please select an import file</p>";
    }
}
?>
<html>
<head>
	<title><?php echo $admintitle; ?></title>
	<?php include("inc-head.php"); ?>
	
	<link type="text/css" rel="stylesheet" href="calendar/popcalendar.css"/>
	<script language='javascript' src='calendar/popcalendar.js'></script>
</head>

<body leftmargin="0" topmargin="0" rightmargin="0">

<?php include_once ('top.php'); ?>

<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" rowspan="2" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
			<?php include_once ('memberleft.php'); ?>      
		</td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
					
			<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
				<tr>
				<td nowrap="nowrap" class="navRow1"><span class="navRow2">Import Members </span></td>
				</tr>
			</table>                
			
			<?php echo isset($message) ? $message : '' ?>
			
			<form name="info" method="post"  enctype="multipart/form-data" action="import_members.php" style="margin-top:10px">
				<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
					<tr><td class="gridHeader" colspan="2">Import Members</td></tr>
					<tr>
						<td class="gridLabels1" nowrap="nowrap" width="120">Import File<font color="Red"> *</font></td>
						<td class="gridRow1">
							<input type="file" name="importfile" size="40">
						</td>
					</tr>
					<tr>
						<td class="gridLabels1" nowrap="nowrap" width="120">Field Delimiter</td>
						<td class="gridRow1">
							<input type="radio" name="delimiter" id="comma" value="comma" checked><label for="comma">Comma Delimited</label>
							<input type="radio" name="delimiter" id="tab" value="tab"><label for="tab">Tab Delimited</label>
						</td>
					</tr>
					<tr>
						<td class="gridLabels1" nowrap="nowrap" width="120">First Row</td>
						<td class="gridRow1">
							<input type="checkbox" name="header" id="header" checked><label for="header">First row contains headers (First Name, Last Name, Email etc)</label>
						</td>
					</tr>
					<tr>
						<td class="gridLabels1">Data format</td>
						<td class="gridRow1">
							<span style="color:navy; font-size:8pt">First, Last, Email, Addr1, Addr2, Addr3, City, State, Zip, Country, Phone, Cell, Password, JoinDate, nLevel_ID-nDateExpires-nDateActive</span>
						</td>						
					</tr>
					<tr>
						<td class="gridLabels1" nowrap="nowrap" width="120">Assign members to levels:</td>
						<td class="gridRow1">
<table><tr><td>						
<!-- LIST WITH ALL LEVELS generated dynamically-->					 
<?php
$nrOfColumns = 5;
echo "<table>";
$td = 1;
$i = 1;
foreach ($membershipLevelsArray as $membersipLevel) {
    if ($td == 1) {
        echo "
		<tr>";
    }


    ($_REQUEST['level_' . $membersipLevel[0]]) ? $checked = 'checked="checked"' : $checked =
        '';
    echo "<td><input type='checkbox' $checked name='level_" . $membersipLevel[0] .
        "' />" . $membersipLevel[1] . "</td>";

    if ($i == count($membershipLevelsArray)) {

        $requiredNrOfTd = $nrOfColumns - $td;
        $j = 0;
        while ($j < $requiredNrOfTd) {
            echo "<td></td>";
            $j++;
        }
        echo "</tr>
		";
        break;
    }


    if ($td == $nrOfColumns) {
        echo "</tr>
		";
        $td = 0;
    }

    $td++;
    $i++;
}
echo "</table>";
?>								
</td><td>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Levels will expire on:
<?php
$dtEnd = $_POST['dtEnd'];

if ($dtEnd == "") {
    $dtEnd = date("Y-m-d", strtotime("+1 month"));
}
?>
<input type="text" id="dtEnd" name="dtEnd" value="<?php echo $dtEnd ?>" size="10" />
	<img src="calendar/images/calendar2.gif" border="0" onClick="popUpCalendar(this, document.getElementById('dtEnd'), 'yyyy-mm-dd')" style="cursor:pointer;" align="absmiddle" />	
</td></tr></table>	
						</td>
					</tr>					
					<tr>
						<td class="gridFooter">&nbsp;</td>
						<td class="gridFooter"><input class="inputSubmit" name="submit" value="Import" type="submit"></td>
					</tr>		
				</table>
			</form>
			
			<?php if (!empty($aExists)): ?>
				<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
					<tr><td class="gridHeader" colspan="2">Members Already in the Database </td></tr>
					<?php foreach ($aExists as $item): ?>
						<tr>
							<td class="gridLabels1" nowrap="nowrap" width="120">Line: <?php echo $item['line'] ?></td>
							<td class="gridRow1">
								<table>
									<tr>
										<td width="380px"><span><?php echo $item[EMAIL] ?></span></td>
										<td><span><?php echo $item[FIRST] . ' ' . $item[LAST] ?></span></td>
									</tr>
								</table>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			<?php endif; ?>
		
		</td>
	</tr>
		

	<tr><td style="padding-left: 8px; padding-right: 8px; " valign="top" width="100%"><br></td></tr>
</table>

<?php include_once ('b.php'); ?>

</body>
</html>