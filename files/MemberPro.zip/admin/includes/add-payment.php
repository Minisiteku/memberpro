
<div id="addPayment" class="mydialog" title="Add New Payment For <?php echo $objUser->sForename ?> <?php echo $objUser->sSurname ?>">
     <div id="recurring-instructions" style="display:none;width:500px;">
       <p>This feature will allow you to manually add a failed recurring payment, or reinstate the level using a new subscription id.   </p>
       <p> If adding a received subscription payment that was not recorded by the script, the subscription number should remain the same.</p>
       <p> If linking this membership to a new subscription payment, than enter the new subscription id in the field below.         </p>
       <p>This is an expermental process, that will eventually allow users to reinstate a previously assigned membership level, instead of creating a new one.
         <br>
         This will also allow for pick up where you left off, functionality. </p>
     </div>
     <div id="onetime-instructions" style="width:500px;">
       <p>This feature will allow you to manually process payments to extend expiration periods, where an automatic recurring payment system is not in place.         </p>
       <p>This is an expermental process, that will eventually allow users to reinstate a previously assigned membership level, instead of creating a new one.
         <br>
         This will also allow for pick up where you left off, functionality. </p>
     </div>
     <form action="actions.php?type=member" method="post" name="newPayment">
     <table width="500" border="0" cellpadding="0" cellspacing="1" class="gridtable">
       <tr>
         <td width="208" class="gridrow2">Membership Level</td>
         <td width="289" class="gridrow2"><span id="payment_LevelName">&nbsp;</span></td>
       </tr>
       <tr>
         <td class="gridrow2">Payment Plan</td>
         <td class="gridrow2"><span id="payment_PlanName">&nbsp;</span></td>
       </tr>
       <tr>
         <td class="gridrow2">Current <span id="payment_LevelIdentifier">Transaction</span> Number</td>
         <td class="gridrow2"><span id="payment_LevelIdentifierValue"></span></td>
       </tr>
       <tr>
         <td class="gridrow2">New <span id="payment_LevelIdentifier2">Transaction</span> Number</td>
         <td class="gridrow2">
           <input type="text" name="payment_transactionnumber" id="payment_transactionnumber" />
         </td>
       </tr>
       <tr>
         <td class="gridrow2">Date / Time</td>
         <td class="gridrow2">
           <input type="text" name="payment_datetime" id="payment_datetime" class="datetimepicker" 
		value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd')); echo ' '.date('H:i:s');?> " readonly />
         </td>
       </tr>
       <tr>
         <td class="gridrow2">Expire <span id="expirePeriod"></span> From:</td>
         <td class="gridrow2">
           
             <input type="radio" name="setExpire" value="payment" id="RadioGroup1_0" />
             <label>Payment Date</label>
           <br />
           
             <input type="radio" name="setExpire" value="expire" id="RadioGroup1_1" />
             <label>Current Expire Date (<span id="currentExpireDate"></span> )</label>
           <br />
           <input type="radio" name="setExpire" value="lesser" id="RadioGroup1_2" />
         <label>Lesser</label><br />
         <input name="setExpire" type="radio" id="RadioGroup1_3" value="greater" checked="checked" />
         <label>Greater</label></td>
       </tr>
     </table>
     <input type="hidden" name="act" value="addPaymentByLevel">
     <input type="hidden" name="userId" value="<?php echo $_GET['id']  ?>" />
     <input type="hidden" id="paymentPlanId" name="planId" value="" />
     <input type="hidden" name="userLevelId" id="payment_userLevelId" value="" />
	<input type="submit" value="Process Payment" />
     
     </form>
     </div>