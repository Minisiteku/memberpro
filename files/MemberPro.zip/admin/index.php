<?php
############################################################
##                        WARNING!                        ##
##                                                        ##
## This script is copyrighted to EasyMemberPro.com        ##
## Duplication, selling, or transferring of this script   ##
## is a violation of the copyright and purchase agreement.##
## Alteration of this script in any way voids any         ##
## responsibility EasyMemberPro.com has towards the       ##
## functioning of the script. Altering the script in an   ##
## attempt to bypass licensing or unlock other functions  ##
## of the program that have not been purchased is a       ##
## violation of the purchase agreement and forbidden by   ##
## EasyMemberPro.com.                                     ##
## By modifying/running this script you agree to the      ##
## terms and conditions of EasyMemberPro.com located at   ##
## http://www.easymemberpro.com/terms.php                 ##
############################################################
	if(isset($_POST['destruct'])){
		@session_start();
		if(isset($_SESSION['install']['nOnce'])){
			
			$nOnce = $_SESSION['install']['nOnce'];
			if($nOnce == $_POST['destruct']){
			// Attempt To Delete Install Dir.
			// If Exists - It Should, But Just Incase
			if(is_dir('../install')){
				
				if (version_compare(PHP_VERSION, '5.3.0') >= 0) {
					foreach(
					new RecursiveIteratorIterator(
						new RecursiveDirectoryIterator('../install', FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $path) {
						$path->isFile() ? @unlink($path->getPathname()) : @rmdir($path->getPathname());
					}
					@rmdir('../install');
				}
				else{
					  
					$iterator = new RecursiveDirectoryIterator('../install');  
					foreach (new RecursiveIteratorIterator($iterator, RecursiveIteratorIterator::CHILD_FIRST) as $file) {  
						if ($file->isDir()) @rmdir($file->getPathname());
						else @unlink($file->getPathname());   
					}
					@rmdir('../install');
				}
				
			}
		}
			unset($_SESSION['install']);
		}
	}
	include_once ('../conn.php');
	include_once ('../functions.php');
	
	include_once ('../includes/encrypt.php');


	// Lets check to see if logged in alredy. If already logged in than redirect to home
	if($secure->checkAuth('admin',false)){header("Location:home.php");exit;}

	if (isset($_COOKIE['adm_u'])) {
		$encrypt = new Encrypt();
		$user = $encrypt->decode($_COOKIE['adm_u']);
		$pass = $encrypt->decode($_COOKIE['adm_p']);
		$checked = 'checked';
	}
	else {
		$user = '';
		$pass = '';
		$checked = '';}

?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php include("inc-head.php"); ?>
		
        <script>
		  $(document).ready(function(){
			$("#adm_login").validate({
				errorPlacement: function(error, element) {
					error.appendTo( element.parent("td") );
				},
				 highlight: function(element){
						//$(element).css({"border": "2px solid #CC0000"});
						$(element).removeClass("textinput");
						$(element).removeClass("successHighlight");
						$(element).addClass("errorHighlight");
				 },
				 unhighlight: function(element){
						//$(element).css({"border": "2px solid #CC0000"});
						//$(element).removeClass("errorHighlight");
						//$(element).addClass("textinput");
						$(element).removeClass("textinput");
						$(element).removeClass("errorHighlight");
						$(element).addClass("successHighlight");
				 },
				 
				success: function(label,element) {
				   
				   
					var name = label.attr('for');
					var span = name + '_success';
					
					var span = document.getElementById(span);
		
					
					//label.selector='label.success';
					//label.text('<img src="images/ed_format_underline.gif" />');
					//alert(JSON.stringify(label, null, 4));
				},
				rules: {
					password: {
						required: true,
						minlength: 6
					},
					user: {
						required: true,
						email: true
					}
				}
			});
		  });
  		</script>
  <style>.errorHighlight { border: 2px solid #CC0000; } .textinput {border: 1px silver solid;}.successHighlight { border: 2px solid  #090; }</style>
	</head>
	<body onLoad="javascript:document.adm_login.user.focus();">
		<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" class="">
		  <!--DWLayoutTable-->
			<tr>
			  <td class="header-bg">
				<table border="0" align="left" cellpadding="0" cellspacing="0" width="100%">
			    <tr>
			      <td width="20">&nbsp;</td>
			      <td width="569" height="99"><img src="images/emp-cp-header-logo.jpg" width="546" height="106"></td>
				  <td width="100%"></td>
		        </tr>
		      </table>
			</td>
		  </tr>
		</table>
		<table width="775" border="0" align="center" cellpadding="0" cellspacing="0" class="font">
			<tr>
				<td height="55"><br /><?php echo isset($message) ? $message.'<br />' : ''.'<br />' ?></td>
			</tr>
		
			<tr>
				<td class="whitebold">&nbsp;</td>
			</tr>
			<tr>
				<td align="center">
				
				
			<?php
			$redirect = (isset($_GET['redirect']))?'?redirect='.urlencode($_GET['redirect']):'';
			?>
					<form method="POST" action="verify.php<?php echo $redirect ?>" name="adm_login" id="adm_login">
						<p>Please enter your login details below to authenticate.</p>
						<table class="gridTable" cellpadding="0" cellspacing="1">
							<tr>
								<td class="gridheader" colspan="2" nowrap="nowrap"> Login </td>
							</tr>
							<tr>
								<td class="gridrow2" nowrap="nowrap"> Username </td>
								<td class="gridrow2"><input size="30" name="user" value="<?php echo $user ?>" class="textinput" type="text"/><br>
</td>
							</tr>
							<tr>
								<td class="gridrow2" nowrap="nowrap"> Password </td>
								<td align="center" class="gridrow2"><input size="30" name="password" value="<?php echo $pass ?>" class="textinput" type="password" /><br>
</td>
							</tr>
							
							<tr>
								<td colspan="2" class="gridfooter" align="right">&nbsp;
									<input type="checkbox" name="rememberme" value="1" <?php echo $checked ?>><span style="padding-right:75px; padding-left:3px;">Remember Me</span>
									<input name="Submit" value="Login" class="inputSubmit" type="submit" />
									<input name="islogin" value="1" type="hidden" />
								</td>
							</tr>
						</table>
						<p>Secure Area - Your Ip Address (<?php echo $_SERVER['REMOTE_ADDR'] ?>) will be recorded</p>
                    </form>
				</td>
			</tr>
		</table>
	</body>
</html>
