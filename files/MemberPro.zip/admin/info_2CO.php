<div style="font:12pt arial; width:700px">
<p>
	The 2Checkout Secret Word provides an additional level of security for your transactions.
During the purchasing process, 2Checkout encodes some of the transactions details with the 
Secret Word you set in your 2Checkout account.  When these parameters are passed back to your site, 
they are decoded using the secret word you set on the Payment Options page and if they are
correct, the transaction is completed.
</p>
<p>
If you decide to use the Secret Word feature <span style='background-color:#FFFF80'>it is very important
that the Secret Word you set on the Payment Options page exactly matches the Secret Word you 
set in your 2Checkout Account.</span>
</p>
<p>
<span style="color:red"><b>Failure to exactly match the Secret Word</b> on the Payment Options page with the 
	Secret Word in your 2Checkout Account <b>will result in your transactions not being processed.</b></span>
</p>
<p>
<b>If you don't want to use the 2Checkout Secret Word feature,<br>leave the Secret Word
field on the Payment Options page blank.</b>
</p>
<p>
How to set the Secret Word in your 2Checkout Account:
<ol>
   <li>Login to your 2Checkout account.</li>
   <li>Click on �Look and Feel� found on your account homepage.</li>
   <li>Enter your secret word into the data field labeled, �Your Secret Word
      (16 Character Limit)�. As labeled, the only limit is that it must be
      16 characters or less.
      The secret word should be a single or compound word or group of letters 
      and numbers with no spaces. Examples: Monkey1mouse, 4smal3phone, gooblyWbubze.</li>
   <li>Click �Save Changes� when you are finished.</li>
</ol>

</div>