<div style="font:12pt arial; width:700px">
<p>
	The ClickBank Secret Key provides an additional level of security for your transactions.
During the purchasing process, ClickBank encodes some of the transactions details with the 
Secret Key you set in your ClickBank account.  When these parameters are passed back to your site, 
they are decoded using the Secret Key you set on the Payment Options page and if they are
correct, the transaction is completed.
</p>
<p>
If you decide to use the Secret Key feature <span style='background-color:#FFFF80'>it is very important
that the Secret Key you set on the Payment Options page exactly matches the Secret Key you 
set in your ClickBank Account.</span>
</p>
<p>
<span style="color:red"><b>Failure to exactly match the Secret Key</b> on the Payment Options page with the 
	Secret Key in your ClickBank Account <b>will result in your transactions not being processed.</b></span>
</p>
<p>
<b>If you don't want to use the ClickBank Secret Key feature,<br>leave the Secret Key
field on the Payment Options page blank.</b>
</p>
<p>
How to set the Secret Key in your ClickBank Account:
<ol>
   <li>Login to your ClickBank account.</li>
   <li>Click on the �Account Settings� tab from your account homepage.</li>
   <li>Click on the �My Site� link</li>
   <li>Enter your Secret Key into the data field labeled, �Secret Key�. The
   	Secret Key can be up to 16 letters or digits and must be in ALL CAPS.</li>      
   <li>Click �Save Changes� when you are finished.</li>
</ol>

</div>