<?php
include_once('../conn.php');
include_once('../functions.php');
global $language;
if ( isset($_POST) )
{
	
	// Check user exists
	$sql = "SELECT * FROM tblusers WHERE sEmail = '" . $dbo->format($_POST['user']) . "';";
	$objUser = $dbo->getobject($sql);
	if ($objUser->nUser_ID) {

		
			// Save User info
			$user = $_POST['user'];
			$user_id = $objUser->nUser_ID;

			set_user_level_privileges($user_id);
			$secure->setAuth('user',$objUser);
			
			$redirect_url = '../member/index.php';
			
		// Closing Bracket for disabled feature - max ips.	
		}
	else 
	// User doesn't exist, so redirect back to login page and display error
	{
		
		die('User Not Found!');
	}
		
	} 
	else{die('No Post');}
?>

<html>
<head>
	<title>Redirecting...</title>
	<link type="text/css" href="common/css/styles.css" rel="stylesheet">
</head>
<meta http-equiv="refresh" content="0; URL=<?php echo $redirect_url ?>" />
<body>

<table cellspacing="0" cellpadding="0" border="0" height="100%" width="100%">
	<tr><td height="100%" width="100%">
		<p align="center" style="font-family: arial; font-size: 18px; font-weight: bold;"><?php echo $language['login_checking_login'] ?></p>
		<p align="center"><img src="../common/images/loading.gif"></p>
	</td></tr>
</table>

</body>
</html>