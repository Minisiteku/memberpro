<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	ob_start();
	phpinfo(INFO_GENERAL);
	$out = ob_get_contents();
	ob_end_clean();
	//die($out);	
	$nStart = strpos($out, "Server API") + strlen("Server API");
	$nEnd = strpos($out, "\n", $nStart);
	$phpinstall = (strip_tags(substr($out, $nStart, $nEnd-$nStart)));
	
	$WINDOWS = false;
	if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') $WINDOWS = true;
	
	// Check for successful cron run within past 25 hours.
	$sql = "SELECT * FROM tblcronlog ORDER BY timestamp DESC LIMIT 1";
	$result = $dbo->select($sql);
	$row = $dbo->getobj($result);
	$now = time();
	$lastrun = $now - intval($row->timestamp);
	$lasthours = floor($lastrun / 60/60);
	//die(var_dump($row->timestamp)); 
	
	//die($phpinstall);
	$dailyCron = new stdClass;
	$dailyCron->urlPath = dirname(dirname(__FILE__)).DIRECTORY_SEPARATOR."cron.php";
	$dailyCron->serverPath = $chkSsettings->sRootPath.DIRECTORY_SEPARATOR."cron.php";
	$dailyCron->lastRun = date('m-d-Y H:i',$row->timestamp);
	$dailyCron->isExecutable = is_executable($dailyCron->serverPath);
	
	//$executable = is_executable();
	$broadcastCron = new stdClass;
	$broadcastCron->urlPath = dirname(dirname(__FILE__)).DIRECTORY_SEPARATOR."cron-email.php";
	$broadcastCron->serverPath = $chkSsettings->sRootPath.DIRECTORY_SEPARATOR."cron-email.php";
	$broadcastCron->isExecutable = is_executable($broadcastCron->serverPath);
	
	$broadcastCron->lastRun = (get_option('emailCron_LastRun') )?date('m-d-Y H:i',get_option('emailCron_LastRun')):0;
	
	if($WINDOWS){
		$dailyCron->command = $dailyCron->urlPath;
		$broadcastCron->command = $broadcastCron->urlPath;
	}
	else{
		if(strpos($phpinstall,'Apache')){
			$dailyCron->command = 'lynx -dump '.$dailyCron->urlPath;
			$broadcastCron->command = 'lynx -dump '.$broadcastCron->urlPath;
		}
		else{
			$dailyCron->command = 'php '.$dailyCron->serverPath;
			$broadcastCron->command = 'php-cli '.$broadcastCron->urlPath;
			$useCli = 1;
		}
	}
	

?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php include ('inc-head.php')?>
        <script type="text/javascript">
        	$(function() {
				
				$( "#cronInstructions" ).dialog({
					autoOpen: false,
					show: "explode",
					hide: "explode",
					modal: true,
					width:'auto',
					height:'auto',
					closeOnEscape: true
				});
		
			})
			
			function showInstructions(OS,type){
				$('#cronInstructions').html('');
				$('#cronInstructions').html($('#'+type+'_'+OS+'_instructions').html());
				if(OS == 'linux'){
					$("#showBroadcastWindows").click(function() {
  						showInstructions('windows','broadcast')
				});}
				$('#cronInstructions').dialog("open");
			}
			
        </script>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
			<?php include_once('settingsleft.php'); ?>
		</td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			<form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="form">
				<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<td width="10%" nowrap="nowrap" class="navRow2"> Cron Job Manager</td>
					</tr>
				</table>
				
				<?php echo isset($message) ? $message : '' ?>
				
			  <table class="gridtable" cellpadding="0" cellspacing="1" width="100%">
				  <tr>
				    <td colspan="2"  class="gridheader">Daily Cron -  <a onClick="showInstructions('<?php echo ($WINDOWS)?'windows':'linux'  ?>','daily')">Setup Instructions</a></td>
			    </tr>
				  <tr>
				    <td class="gridrow2" width="184">Command</td>
				    <td width="1028" class="gridrow2"><p>
				      <label for="textfield"></label>
				      <input name="textfield" type="text" id="textfield" value="<?php echo $dailyCron->command; ?>" size="100">
				      <br>
			        </p></td>
			    </tr>
				  <tr>
				    <td class="gridrow2">Last Run</td>
				    <td width="1028" class="gridrow2"><?php echo $dailyCron->lastRun ?></td>
		        </tr>
				  <tr>
				    <td colspan="2" class="gridheader">Broadcast Cron - 
                    <a onClick="showInstructions('<?php echo ($WINDOWS)?'windows':'linux'  ?>','broadcast')">Setup Instructions</a></td>
			    </tr>
				  <tr>
				    <td class="gridrow2">Command</td>
				    <td width="1028" class="gridrow2"><input name="textfield2" type="text" id="textfield2" value="<?php echo $broadcastCron->command ?>" size="100">
</td>
		        </tr>
				  <tr>
				    <td class="gridrow2">Last Run</td>
				    <td width="1028" class="gridrow2">
						<?php echo ($broadcastCron->lastRun)?$broadcastCron->lastRun:'Never' ?>
                   </td>
		        </tr>
				  <tr>
				    <td colspan="2" class="gridheader"><table width="100%" border="0" cellspacing="0" cellpadding="0">
				      <tr>
				        <td valign="top"><input type="submit" name="Update" value="Save Changes" class="inputSubmitb" /></td>
			          </tr>
				      </table></td>
			    </tr>
			  </table>
			</form>
		</td>
	</tr>
</table>
<div id="daily_windows_instructions" style="display:none;">
  <h1>Configuring Daily Cron Job on Windows</h1>
  <p>To setup a Windows machine to run Easy Member Pro Cron Jobs at a specific time, follow the instructions below.<br />
    This can be useful if your web host does not offer the ability to run cron jobs; or are using a windows server.</p>
  <p>Note: These instructions were written for Windows XP but should be similar in other versions of Windows.</p>
  <p> <strong>Creating a Scheduled Task</strong></p>
  <ol>
    <li>Open Scheduler</li>
    <li>Go to <strong>Start &gt; Programs &gt; Accessories &gt; System Tools &gt; Scheduled Tasks</strong></li>
    <li>Double-click <strong>Add Scheduled Task</strong></li>
    <li>The Scheduled Task Wizard will appear. Click <strong>Next</strong>.</li>
    <li>Select the program to run. Choose your <strong><em>browser</em></strong> from the list (for example, Internet Explorer or Mozilla Firefox). Click <strong>Next</strong>.</li>
    <li>Give the task a <strong>Name</strong>, such as <em>EMP  Daily Cron Job</em>, and choose <strong>Daily</strong> for the Frequency. Click <strong>Next</strong>.</li>
    <li>Choose specific <strong>date and time options</strong>. Typically users will set this to midnight. When finished, click <strong>Next</strong>.</li>
    <li>Enter your <strong>password</strong> if prompted. Change the <strong>username</strong> if required (for example, you'd like the task to run under a user with fewer privileges security reasons). Click <strong>Next</strong>.</li>
    <li>On the final page, select the checkbox <strong>Open advanced properties for this task when I click Finish</strong> and click <strong>Finish</strong>.</li>
  </ol>
  <p><strong>Configuring the task</strong></p>
  <ol>
    <li>Go to the task's setting page either by checking the checkbox at the end of the last step, or by double-clicking on the task.</li>
    <li>In the <strong>Run</strong> box, after the text that is there now (for example, <em>C:\PROGRA~1\MOZILL~1\firefox.exe</em>), <br>
    enter a space and then copy and paste the <strong>Cron Command</strong>  at the end of the text.<br>
    (for example, <strong>C:\PROGRA~1\MOZILL~1\firefox.exe <?php echo $dailyCron->urlPath ?></strong></li>
    <li>When all settings have been configured to your liking, click <strong>Apply</strong> and <strong>OK</strong> (note: you may be prompted for your password)</li>
  </ol>
</div>
<div id="broadcast_windows_instructions" style="display:none;">
  <h1>Configuring Broadcast Cron Job on Windows</h1>
  <p>To setup a Windows machine to run Easy Member Pro Cron Jobs at a specific time, follow the instructions below.<br />
    This can be useful if your web host does not offer the ability to run cron jobs; or are using a windows server.</p>
  <p>Note: These instructions were written for Windows XP but should be similar in other versions of Windows.</p>
  <p> <strong>Creating a Scheduled Task</strong></p>
  <ol>
    <li>Open Scheduler</li>
    <li>Go to <strong>Start &gt; Programs &gt; Accessories &gt; System Tools &gt; Scheduled Tasks</strong></li>
    <li>Double-click <strong>Add Scheduled Task</strong></li>
    <li>The Scheduled Task Wizard will appear. Click <strong>Next</strong>.</li>
    <li>Select the program to run. Choose your <strong><em>browser</em></strong> from the list (for example, Internet Explorer or Mozilla Firefox). Click <strong>Next</strong>.</li>
    <li>Give the task a <strong>Name</strong>, such as <em><strong>EMP  Broadcast Cron Job</strong></em>, and choose <strong>Daily</strong> for the Frequency. Click <strong>Next</strong>.</li>
    <li>Choose specific <strong>date and time options</strong>. Typically users will set this to midnight. When finished, click <strong>Next</strong>.</li>
    <li>Enter your <strong>password</strong> if prompted. Change the <strong>username</strong> if required (for example, you'd like the task to run under a user with fewer privileges security reasons). Click <strong>Next</strong>.</li>
    <li>On the final page, select the checkbox <strong>Open advanced properties for this task when I click Finish</strong> and click <strong>Finish</strong>.</li>
  </ol>
  <p><strong>Configuring the task</strong></p>
  <ol>
    <li>Go to the task's setting page either by checking the checkbox at the end of the last step, or by double-clicking on the task.</li>
    <li>In the <strong>Run</strong> box, after the text that is there now (for example, <em><strong>C:\PROGRA~1\MOZILL~1\firefox.exe</strong></em><strong>)</strong>, <br>
    enter a space and then copy and paste the <strong>Cron Command</strong>  at the end of the text.<br>
    (for example, <strong>C:\PROGRA~1\MOZILL~1\firefox.exe <?php echo $dailyCron->urlPath ?></strong></li>
    <li>Click the <strong>Schedule Tab</strong>.</li>
    <li>Click the <strong>Advanced Button.</strong></li>
    <li>Check the <strong>Repeat Task</strong> option.</li>
    <li>Set this option to repeat <strong>Every 5 Minutes</strong> (or however often you want to look for pending email broadcasts.)</li>
    <li>When all settings have been configured to your liking, click <strong>Apply</strong> and <strong>OK</strong> (note: you may be prompted for your password)</li>
  </ol>
</div>
<div id="broadcast_linux_instructions" style="display:none;">
  <h1>Configuring Cron Jobs on Linux </h1>
  <p>To setup a Linux machine to run the Easy Member Pro Cron Jobs at a specific time, follow the instructions below.</p>
  <p>Note: These instructions were written for cPanel, but should be similar in other hosting control panels.<br>
    If your webhost does not support cron jobs, see <a id='showBroadcastWindows' href="#">Windows Instructions</a>.
  </p>
  <p> <strong>Creating a Cron Job</strong></p>
  <ol>
    <li>Login to your site's cPanel</li>
    <li>Click the Cron jobs icon</li>
    <li> Click Advanved for the experience level</li>
    <li>Enter <strong>* * * * * 
      <?php  echo $broadcastCron->command  ?>
    </strong> in the Command to Run ﬁeld.<br>
     That schedules the cron to run every minute of every day. 
     <br>
    Some webhosts require your crons cannot run less than every 15 minutes.<br>
    If this is the case, change <strong>* * * * *</strong> , to <strong>*/15 * * * *</strong> </li>
    <li>Click Save Crontab</li>
  </ol>
</div>
<div id="daily_linux_instructions" style="display:none;">
  <h1>Configuring Cron Jobs on Linux</h1>
  <p>To setup a Linux machine to run the Easy Member Pro Cron Jobs at a specific time, follow the instructions below.</p>
  <p>Note: These instructions were written for cPanel, but should be similar in other hosting control panels.<br />
   If your webhost does not support cron jobs, see <a href="#" onClick="showInstructions('windows','daily')">Windows Instructions</a>.</p>
  
  <p> <strong>Creating a Cron Job</strong></p>
  <ol>
    <li>Login to your site's cPanel</li>
    <li>Click the Cron jobs icon</li>
    <li> Click Advanved for the experience level</li>
    <li>Enter <strong>0 0 * * * 
      <?php  echo $dailyCron->command  ?>
    </strong> in the Command to Run ﬁeld.<br>
     That schedules the cron to run at midnight, every day. 
     <br>
    If you want to run it at 11:45 PM, you would change <strong>0 0 * * *</strong> , to <strong>23 45 * * *</strong> </li>
    <li>Click Save Crontab</li>
  </ol>
</div>
<div id="cronInstructions"></div>
<?php

 include_once('b.php'); ?>

	</body>
</html>