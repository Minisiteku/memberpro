<?php
	include_once('../conn.php');
	include_once('../functions.php');
	global $db_name;
	
	// Get Table Data
	$sql = "SHOW TABLE STATUS FROM `".$db_name."`;";
	
	$result = $dbo->select($sql);
	$tnr = $dbo->nr($result);
	$nr = $tnr - 1;
	$i = 0;
	while ($array = $dbo->getassoc($result)) {
		foreach($array as $k=>$v){
			$key = $k;
			$tables[$i][$key] = $v;
		}
		$i++;
	}
?>
<html>
        <head>
        <title><?php echo $admintitle; ?></title>
        <?php include ('inc-head.php')?>
        <script type="text/javascript">
        function toggle(id){
			var ele = document.getElementById(id).style.display;
			
			if(ele == 'none'){document.getElementById(id).style.display = 'block'}
			else{document.getElementById(id).style.display = 'none';}
			}
function checkAll(frm, checkedOn) {
    // have we been passed an ID
    if (typeof frm == "string") {
        frm = document.getElementById(frm);
    }

    // Get all of the inputs that are in this form
    var inputs = frm.getElementsByTagName("input");

    // for each input in the form, check if it is a checkbox
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].type == "checkbox") {
            inputs[i].checked = checkedOn;
        }
    }
}
        </script>
        </head>
        <body leftmargin="0" topmargin="0" rightmargin="0">
        <?php include_once('top.php'); ?>
        <table cellpadding="0" cellspacing="0" width="100%">
          <tr>
            <td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once('backupleft.php'); ?></td>
            <td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
            <h1>Database Management System</h1>
<?php echo isset($message) ? $message : '' ?>
<div>
  <form action="actions.php?type=db" method="post" id="dbtables" name="dbtables">
    <div style="width:100%;">
    <table width="45%" cellpadding="0" cellspacing="1" class="gridTable" style="float:left; margin-right:2.5%">
  <tr>
    <td class="gridHeader"></td>
    <td class="gridHeader">Table Name</td>
    <td class="gridHeader">Total Rows</td>
    <td class="gridHeader">Table Size</td>
    <td class="gridHeader">Actions</td>
  </tr>
  <?php 
  $row = 0;
  while($row <= $nr){
	$ttext = ' KB';
	$total = ($tables[$row]['Data_length'] + $tables[$row]['Index_length']) / 1024;
	if($total > '512'){$total = $total / 1024; $fstext = ' MB';}
	if(($row+1) >floor($tnr / 2)){
			?>
  <tr>
    <td class="gridrow1"><input name="<?php echo $tables[$row]['Name']?>" type="checkbox" value="1"></td>
    <td class="gridrow1"><?php echo $tables[$row]['Name']?></td>
    <td class="gridrow1"><?php echo $tables[$row]['Rows'] ?></td>
    <td class="gridrow1"><?php echo round($total,2).$ttext ?></td>
    <td class="gridrow1">
    <form action="actions.php?type=db" method="post" style="margin:0px; padding:0px;">
        <?php
						if($tables[$row]['Name'] == 'tbladminlogins' || $tables[$row]['Name'] == 'tbluserlogins' || $tables[$row]['Name'] == 'tblcronlog' || $tables[$row]['Name'] == 'tblquerylog'|| $tables[$row]['Name'] == 'tblipnlog'){ ?>
        <input type="hidden" value="clear" name="act" />
        <input name="" type="image" src="images/log_delete.png" title="Clear Logs">
        <input type="hidden" value="<?php echo $tables[$row]['Name']?>" name="table" />
        <?php } ?>
      </form>
      </td>
  </tr>
  <?php }
  	$row++;}	?>
</table>
    
<table width="45%" cellpadding="0" cellspacing="1" class="gridTable" style="float:left">
  <tr>
    <td class="gridHeader"></td>
    <td class="gridHeader">Table Name</td>
    <td class="gridHeader">Total Rows</td>
    <td class="gridHeader">Table Size</td>
    <td class="gridHeader">Actions</td>
  </tr>
  <?php	
  $row = 0;
  while($row <=$nr){$therow = $row;
	$ttext = ' KB';
	$total = ($tables[$row][Data_length]+$tables[$row][Index_length]) / 1024;
	if($total > '512'){$total = $total / 1024; $fstext = ' MB';}
	if(($row+1)<=floor($tnr / 2)){?>
  <tr>
    <td class="gridrow1"><input name="<?php echo $tables[$row]['Name']?>2" type="checkbox" value="1"></td>
    <td class="gridrow1"><?php echo $tables[$row]['Name'] ?></td>
    <td class="gridrow1"><?php echo $tables[$row]['Rows'] ?></td>
    <td class="gridrow1"><?php echo round($total,2).$ttext ?></td>
    <td class="gridrow1"><form action="actions.php?type=db" method="post" style="margin:0px; padding:0px;">
        <?php
if($tables[$row]['Name'] == 'tbladminlogins' || $tables[$row]['Name'] == 'tbluserlogins' || $tables[$row]['Name'] == 'tblcronlog' || $tables[$row]['Name'] == 'tblquerylog'|| $tables[$row]['Name'] == 'tblipnlog'){ ?>
        <input type="image" src="images/log_delete.png" title="Clear Logs">
        <input type="hidden" value="clear" name="act" />
        <input type="hidden" value="<?php echo $tables[$row]['Name']?>" name="table" />
        <?php } ?>
      </form></td>
  </tr>
  <?php
			
			
			}
	$row++;
		}
?>
</table>
     </div>
     
      <div style="clear:both; padding:5px; background-color:#369; color:#FFFFFF"><a style="color:#FFFFFF" href="javascript:checkAll('dbtables', true);">Check All</a> / <a href="javascript: checkAll('dbtables', false);" style="color:#FFFFFF" >Uncheck All --&gt;</a> <em>With selected:</em>
        <select name="act">
          <option value="backup">Backup</option>
          <option value="optlist">Optimize</option>
        </select>
        <input type="submit" name="button2" id="button2" value="Go &gt;&gt;">
      </div>
  </form>
</div>
                
            </td>
          </tr>
        </table>
        <?php include_once('b.php'); ?>
        <script type="text/javascript">		
		$(document).ready(function()
		{
			$("#form").validate(
			{
				onkeyup: false 		 					
			
			});
		});
</script>
</body>
</html>