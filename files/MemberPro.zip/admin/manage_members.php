<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	function stripmessage($ref){
	
		$refmsg = explode('&msg=',$ref);
	
		if(count($refmsg) > 1) $cleanref = $refmsg[0];
		else{
			$refmsg = explode('?msg=',$ref);
			
			if(count($refmsg) > 1){$cleanref = $refmsg[0];}
			
		}

	$refmsg = explode('&err=',$ref);
	//die(var_dump($refmsg));
	if(count($refmsg) > 1) $cleanref .= $refmsg[0];
	else{$refmsg = explode('?err=',$ref);if(count($refmsg) > 1){$cleanref .= $refmsg[0];}}
	
	if($cleanref !=''){$ref = $cleanref;}
	
	return $ref;}
	
	$currentUrl = $_SERVER['SCRIPT_NAME'];
	if($_SERVER['QUERY_STRING']){
		$currentUrl .= '?'.$_SERVER['QUERY_STRING'];
	}
	
	$phpself = stripmessage($currentUrl);
	
	$hasQueryString = 0;
	if(strpos($phpself,'?')!==FALSE) $hasQueryString = 1;
	
	$clearLink = ($hasQueryString)?$phpself.'&clearFilter=1':$phpself.'?clearFilter=1';
	$clearSearchLink = ($hasQueryString)?$phpself.'&clearSearch=1':$phpself.'?clearSearch=1';
	
	// If Set Clear Current Query Filter
	// And Redirect To Remove get string.
	if($_GET['clearFilter']){
		unset($_SESSION['admin']['current_mqf_sql']);
		unset($_SESSION['admin']['current_mqf_title']);
		
		//
		$phpself = str_replace('?clearFilter=1','',$phpself);
		$phpself = str_replace('&clearFilter=1','',$phpself);
		//die($phpself);
		if(strpos($phpself,'?')!==false){$msg = '&msg=Filter Cleared Successfully';}
		else{$msg = '?msg=Filter Cleared Successfully';}
		header("Location: $phpself$msg");
	}
	if($_GET['clearSearch']){
		unset($_SESSION['admin']['member_search']);
		
		//
		$phpself = str_replace('?clearSearch=1','',$phpself);
		$phpself = str_replace('&clearSearch=1','',$phpself);
		//die($phpself);
		if(strpos($phpself,'?')!==false){$msg = '&msg=Member Search Cleared Successfully';}
		else{$msg = '?msg=Member Search Cleared Successfully';}
		header("Location: $phpself$msg");
	}
	
	// Check For Search Request
	if(isset($_POST['srchval'])){
		
		$_SESSION['admin']['member_search'] = $dbo->format($_POST['srchval']);
		// If a filter is set, we need to unset it.
		if(isset($_SESSION['admin']['current_mqf_sql'])){
			unset($_SESSION['admin']['current_mqf_sql']);
			unset($_SESSION['admin']['current_mqf_title']);
		}
		header("Location: $phpself");
	}
	
	
	
	
	function getCurrentMemberships($id){
		global $chkSsettings,$dbo;
				$selbox .="";
				// Get only levels this user belongs to
				$sql = "SELECT tblmembershiplevels.nLevel_ID, sLevel, nDateExpires FROM tblmembershiplevels 
				INNER JOIN tbluserlevels ON tbluserlevels.nLevel_ID = tblmembershiplevels.nLevel_ID
				WHERE tbluserlevels.nActive=1 AND 
				tblmembershiplevels.nActive=1 AND 
				tbluserlevels.nUser_ID = " . $id . "  AND
				tbluserlevels.nDateExpires >= " . date("Ymd") . "  
				ORDER BY sLevel";
				$result = $dbo->select($sql);
				$nr = $dbo->nr($result);
				//$objLevel = mysql_fetch_object($result);
				if ($nr) {
					
					if($nr == 1){
						
						$objLevel = $dbo->getobj($result);
						$memberlevel = $objLevel->sLevel . ' (Expires on ' . fShowDate($chkSsettings->nDateFormat, $objLevel->nDateExpires) . ')';}
					else{$memberlevel = '';$selbox .= '<select name="nAssignedLevel_ID" id="nAssignedLevel_ID" style="width: 250px;">';
					while ($objLevel = $dbo->getobj($result)) {
						if($objLevel->sLevel == ''){$selbox .='<option value="">None</option>';}
						else{$selbox .='<option value="' . $objLevel->nLevel_ID .'">' . $objLevel->sLevel . ' (Expires on ' . fShowDate($chkSsettings->nDateFormat, $objLevel->nDateExpires) . ')</option>';}
					}}
					
					
				}
				else{$selbox .='<option value="">None</option>';}
				$selbox .='</select>';
			
			if($memberlevel){return $memberlevel;}
			else{return $selbox;}
	}

	// Setup Options for Members per Page listing
	$aMPP = array('5', '10', '15', '20', '25', '50', '100');
	$mpp = (empty($_GET['mpp'])) ? 10 : $_GET['mpp'];
	
	// Only Filter or Search can be Used, not both.
	// Filter takes presidence
	
	if(isset($_SESSION['admin']['current_mqf_sql'])){
		if(isset($_SESSION['admin']['member_search'])) unset($_SESSION['admin']['member_search']);
	}
	
	// If Using A Filter, Show Filter Box
	$filterFormDisplay = (isset($_SESSION['admin']['current_mqf_sql']))?'block':'none';
	// If Using A Search, Show Search Box
	$searchFormDisplay = (isset($_SESSION['admin']['member_search']))?'block':'none';
	
	// Get Level Select
	// GET Membership Levels
	$sql = "SELECT * FROM tblmembershiplevels";
	$levelRes = $dbo->select($sql);
	
	$levelsel = "<select name='levelFilterValue' id='levelFilterValue'> onChange='getPaymentPlansByLevel(this)'>\n\t
	<option value = '0'>--- Choose Membership Level ---</option>\n\t";
	
	while($row = $dbo->getobj($levelRes)){
		$levelsel .= '<option value="'.$row->nLevel_ID.'">'.$row->sLevel.'</option>\n\t';
	}
	
	$levelsel .='</select>';

?>
<html>
    <head>
    <title><?php echo $admintitle; ?></title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <?php include('inc-head.php');
	if(get_option('use_mce') == '1'){
			 $doc_base = $chkSsettings->sSiteURL .'/'; ?>
    <script type="text/javascript" src="common/js/tiny_mce/tiny_mce.js"></script>
    <script type="text/javascript" src="common/js/tiny_mce/init.php?css=no&base=<?php echo $doc_base  ?>"></script>
    <?php } ?>
    <script type="text/javascript">
	function cdel(w) {return confirm("Are you sure that you want to delete this member?\n\r This Action Cannot Be Undone!");}
	function updateMPP(oList) {
			var mpp = oList.options[oList.selectedIndex].value;
			var qs = '?start=0';
			qs += '&sort=<?php echo $_GET['sort'] ?>';
			qs += '&type=<?php echo $_GET['type'] ?>';
			qs += '&mpp=' + mpp;
			document.location = '<?php echo $_SERVER['PHP_SELF']?>' + qs;
		}
    function toggle(id,id2){
		var ele1 = document.getElementById(id);
		var ele2 = document.getElementById(id2);
		if(ele1.style.display == 'none'){ele1.style.display = 'block';ele2.style.display = 'none';}
		else{ele1.style.display = 'none';}
		}
	function goto($url){
		location.href=$url;
	}
		
		
	
	function openSendEmail(id){
		$( "#sendEmailToId" ).val(id);
		$( "#sendEmail" ).dialog( "open" );
            return false;
			
	}
	function setEmailType(){
		checked = $('input[name=emailType]:checked', '#sendEmailModal').val()
		
		if(checked == 'html'){tinymce.execCommand('mceAddEditor',true,'email_message');}
		else{tinymce.execCommand('mceRemoveEditor',true,'email_message');}
	}
	
	// Query Filter
	function showFilterFields(field){
		if(field.checked === true){
			$('#'+field.id+'Filter').show();
		}
		else{
			$('#'+field.id+'Filter').hide();
		}
		
	}
	function showFilterChoices(opt){
		console.log(opt);
		if(opt.id == 'filterOptions_new'){
			$('#newFilterForm').show();
			$('#filterList').hide();
			
		}
		else{
			$('#newFilterForm').hide();
			$('#filterList').show();
		}
	}
	function hideFilterChoices(){
		$('#newFilterForm').hide();
		$('#filterList').hide();
	}
	function toggleFilterValue2(e){
		console.log(e);
		if(e.id == 'joinFilterCompare'){
			if(e.options[e.selectedIndex].value == '><'){
			$('#joinFilterBetween').show();
		}
			else{$('#joinFilterBetween').hide();}

		}
		if(e.id == 'loginFilterCompare'){
			if(e.options[e.selectedIndex].value == '><'){
			$('#loginFilterBetween').show();
		}
			else{$('#loginFilterBetween').hide();}

			
			
		}
		
		
		
		
			}
	function getFilterTable(){
		$.ajax({
			type: "POST",
			url: "ajax/functions.php?act=loadMemberFiltersTable",
			data: {
				'variable1': 'content var1',
					'variable2': 'content var2'
			},
			success: function (response) {
			   $('#tableRows').html(response);
			}
		});
		
	}
	function deleteFilter(name){
		if(confirm('Are you sure you want to delete this filter?')){
			$.ajax({
			type: "POST",
			url: "ajax/functions.php?act=deleteFilter",
			data: {
				'filterName': name
			},
			success: function (response) {
			   getFilterTable();
			}
		});
		}
		
	}
	function clearFilter(){
		location='<?php echo $clearLink ?>';
	}
	function applyFilter(filtername){
		$.post("ajax/functions.php?act=loadFilter" , { loadFilter: filtername },function(){location.reload()});
	}
	function openFilters(){
		$('#manageFilters').dialog();
	}
	function showAddNew(){
		$("#tableContainer").hide();
		$("#manageFilters_addNew").show();
		return false;
		
	}
	function hideAddNew(){
		$("#tableContainer").show();
		$("#manageFilters_addNew").hide();
		$("#addNewForm")[0].reset();
		$("#levelFilter").hide();
		$("#affiliateFilter").hide();
		$("#loginFilter").hide();
		$("#emailStatusFilter").hide();
		$("#optinFilter").hide();
		$("#joinFilter").hide();
	}
	function submitAddNew(){
		$.ajax({
           type: "POST",
           url: 'ajax/functions.php?act=saveFilter',
           data: $("#addNewForm").serialize(), // serializes the form's elements.
           success: function(data){
			   getFilterTable();
			   hideAddNew();   
           }
         });
		
	}
	// Document Ready
	$(function() {
		$( ".datepicker" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '2000:2037',changeYear: true});
		$( "#sendEmail" ).dialog({
            autoOpen: false,
            show: "explode",
            hide: "explode",
			modal: true,
			width: '650',
			height:'auto'
        });
		$( "#manageFilters" ).dialog({
            autoOpen: false,
            show: "explode",
            hide: "explode",
			modal: true,
			width: '650',
			height:'auto'
        });
		$('#filterLink').click(function() {
			$("#manageFilters").dialog("open");
        	return false;
    });
	
		checked = $('input[name=emailType]:checked', '#sendEmailModal').val()
		
		if(checked == 'html'){$('#email_message').removeClass("mceNoEditor").addClass("mceEditor");}
		else{$('#email_message').removeClass("mceEditor").addClass("mceNoEditor");}
		// Load Filter table
		getFilterTable()
    });	
    </script>
    </head>
    <body>
    <?php include_once('top.php'); ?>
    <table cellpadding="0" cellspacing="0" width="100%">
      <tr>
        <td width="150" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once('memberleft.php'); ?></td>
        <?php
			
			// We have three options for displaying members
			// Standard Display All
			// Search for
			// Query Filters
			
			// Lets build the proper query 
			// Load The Active Query Filter		
			if($_SESSION['admin']['current_mqf_sql']){
				$sql = $_SESSION['admin']['current_mqf_sql'];
			}
			else{
				// Main query
				$sql = "SELECT tblusers.*, tblaffiliates.sForename AS sAffForename, tblaffiliates.sSurname AS sAffSurname 
				FROM tblusers LEFT JOIN tblusers AS tblaffiliates ON tblusers.nAffiliate_ID = tblaffiliates.nUser_ID ";
				
				if (isset($_SESSION['admin']['member_search'])) {
					$sql .= sprintf("WHERE tblusers.sForename LIKE '%s%%' OR tblusers.sSurname LIKE '%s%%' OR tblusers.sEmail 
					LIKE '%s%%' ", $dbo->format($_SESSION['admin']['member_search']), $dbo->format($_SESSION['admin']['member_search']), $dbo->format($_SESSION['admin']['member_search']));			
				}
			}
			
			// Get total number of results
			$sql2 = $sql;
			// Apply Field Sorting
			switch ($_GET['sort']) {
				case 'fname':
					$sortfield = 'tblusers.sForename';
					break;
				case 'lname':
					$sortfield = 'tblusers.sSurname';
					break;
				case 'email':
					$sortfield = 'tblusers.sEmail';
					break;
				case 'joindate':
					$sortfield = 'tblusers.nJoinDate';
					break;
				case 'referrer':
					$sortfield = 'sAffSurname';
					break;
				default:
					$sortfield = 'tblusers.nUser_ID';
			}						
			
			$sql .= sprintf(" ORDER BY %s %s ", $sortfield, $_GET['type']); // Adding order by to main query
			
			if(isset($_GET['debug']) && $_GET['debug'] == '1') echo($sql);
			$number = $dbo->num_rows($sql2); // Number of records
			
			// Start Paging
			/*********************************************************/
			include_once('paging.php');
			$objPaging = new Paging();
			
			$start = (empty($_GET['start'])) ? 0 : $_GET['start'];	
			unset($_GET['start']);
		 	
		 	$objPaging->Total_Records_Per_Page = $mpp; 
		 	$objPaging->Total_Records = $number;
		 	$index = $start ;
		 	$indexupto = $index + $objPaging->Total_Records_Per_Page;	 	
		 	$objPaging->prepare_ParameterString($_GET);
		 	$objPaging->set_Start_Item($indexupto); 	 		 	
		 	$objPaging->Has_First_Last = true;	
		 	$navigator = $objPaging->Create_Paging();
		 	$pageinfo = $objPaging->get_PageInfo();	 	
		  	$counter = 0;  
			$sql .= "LIMIT ".$objPaging->Total_Records_Per_Page." OFFSET ".$index;
			/*********************************************************/

			$result = $dbo->select($sql);
			
			// Set Total Members Display
			if (isset($_SESSION['admin']['member_search']) || $_SESSION['admin']['current_mqf_sql'])
				$total_members = "Resulting Members: <b>".$number."</b>";
			else
				$total_members = "Total Members: <b>".$number."</b>";
			
			// Put together QueryString
			$qs = sprintf("?start=%s&mpp=%s",$start, $mpp);
		?>
        <td width="100%" align="left" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;"><?php echo isset($message) ? $message : '' ?>
          <table class="navTable" border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
              <td width="125" class="navRow1" nowrap="nowrap">Manage Members</td>
              <td class="navRow2" style="text-align:right; padding-right:20px"> Members per page&nbsp;
                <select id='mpp' style='height:1.5em' onChange="updateMPP(this)">
                  <?php
								foreach ($aMPP as $val) {
									$selected = ($val == $mpp) ? 'selected' : '';;
									echo "<option value='$val' $selected>$val</option>";
								}
							?>
                </select></td>
            </tr>
          </table>
          <div style="text-align:left;  margin-left:2px; margin-bottom:5px"> <span style="padding-right:20px"><?php echo $total_members ?></span> </div>
          
          <!-- LISTING HEADER -->
          
          <div class="gridheader" style="border:thin solid #A9B8C2"> <a href="javascript: toggle('searchForm','filterForm');">Search Members</a> | <a href="javascript: toggle('filterForm','searchForm');">Filter Results</a>
            <div id="searchForm" style="width:auto;display:<?php echo $searchFormDisplay ?>"> <br>
              <form name="f1" method="post" action="manage_members.php" onSubmit="return checkthis()">
                <input class="inputText" name="srchval" style="width: 300px;" size="40" maxlength="255" value="<?php echo $_SESSION['admin']['member_search']?>" type="text">
                <input class="inputSubmit" name="submit" value="Search" type="submit">
                <?php if(isset($_SESSION['admin']['member_search'])){?><input class="inputSubmit" name="clear" value="Clear" type="button" onClick="goto('<?php echo $phpself; echo ($hasQueryString)?'&clearSearch=1':'?clearSearch=1' ?>');"><?php } ?>
                <br>
                <span style="margin-top:3px; font-size:8pt; color:navy">(You can search by first name, last name or email)</span>
                <input type='hidden' name='qry' value='search'>
              </form>
            </div>
            <div id="filterForm" style="display:<?php echo $filterFormDisplay ?>;">
              <div id="filterOptions">
              <hr>
                  <p> <span style="color:#C00">Active Filter:</span> 
                    <?php
				if(isset($_SESSION['admin']['current_mqf_sql'])){
					echo str_replace('mqf_','',$_SESSION['admin']['current_mqf_title']).' 
					- <a href="#" id="filterLink"> Manage Filters</a>';?>
                    <?php }
				else{ echo 'None - <a href="#" id="filterLink"> Manage Filters</a>';}	
				 ?>
                 <hr>
              </div>
              </div>
            </div>
          </div>
          <br>
          <table cellpadding="0" cellspacing="1" class="gridtable">
            <tr>
              <td colspan="10" class="gridFooter"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                  <td style='text-align:left'><?php echo $navigator; 	?></td>
                  <td style='text-align:right; padding-right:10px'> Page <?php echo $pageinfo ?></td>
                </tr>
                </table></td>
            </tr>
            <tr> 
              <!-- FIRST NAME COLUMN -->
              <td class="gridHeader"><?php 	if ($_GET['sort'] == 'fname' && $_GET['type'] == 'asc') { ?>
                <a href="manage_members.php<?php echo $qs?>&sort=fname&type=desc" class="bluenave">First </a>
                <?php } else { ?>
                <a href="manage_members.php<?php echo $qs?>&sort=fname&type=asc" class="bluenave">First </a>
                <?php } ?>
                -
                <?php 	if ($_GET['sort'] == "lname" && $_GET['type'] == "asc") { 	?>
                <a href="manage_members.php<?php echo $qs?>&sort=lname&type=desc" class="bluenave">Last Name</a>
                <?php } else { ?>
                <a href="manage_members.php<?php echo $qs?>&sort=lname&type=asc" class="bluenave">Last Name</a>
                <?php } ?></td>
              <!-- LAST NAME COLUMN -->
              <td align="left" nowrap="nowrap" class="gridHeader"><?php 	if ($_GET['sort'] == "email" && $_GET['type'] == "asc") { 	?>
                <a href="manage_members.php<?php echo $qs?>&sort=email&type=desc" class="bluenave">Email Address</a>
                <?php } else { ?>
                <a href="manage_members.php<?php echo $qs?>&sort=email&type=asc" class="bluenave">Email Address</a>
                <?php } ?></td>
              <!-- EMAIL COLUMN -->
              <td align="left" nowrap="nowrap" class="gridHeader">Email Status</td>
              <td align="left" nowrap="nowrap" class="gridHeader"><a href="manage_members.php<?php echo $qs?>&sort=level&type=desc">Membership Levels</a></td>
              <td align="center" nowrap="nowrap" class="gridHeader"><?php if ($_GET['sort'] == "joindate" && $_GET['type'] == "asc") { 	?>
                <a href="manage_members.php<?php echo $qs?>&sort=joindate&type=desc" class="bluenave">Join Date</a>
                <?php } else { ?>
                <a href="manage_members.php<?php echo $qs?>&sort=joindate&type=asc" class="bluenave">Join Date</a>
                <?php } ?></td>
              <td align="center" nowrap="nowrap" class="gridHeader"><?php if ($_GET['sort'] == "referrer" && $_GET['type'] == "asc") { 	?>
                <a href="manage_members.php<?php echo $qs?>&sort=referrer&type=desc" class="bluenave">Referrer</a>
                <?php } else { ?>
                <a href="manage_members.php<?php echo $qs?>&sort=referrer&type=asc" class="bluenave">Referrer</a>
                <?php } ?></td>
              <td align="center" nowrap="nowrap" class="gridHeader">Account Status</td>
              <td colspan="3" align="center" nowrap="nowrap" class="gridHeader">Actions</td>
            </tr>
            <?php
					// Add Sort to QueryString
					$qs .= sprintf("&sort=%s&type=%s", $_GET['sort'], $_GET['type']);
				?>
            <?php 
				if ($result) {
					//$result->data_seek(0);
					while ($row = $dbo->getobj($result)) : 
				?>
            
            <!-- MEMBER LISTING -->
            <tr>
              <td class="gridrow1"><a class="bluenave" href="view_member.php?id=<?php echo $row->nUser_ID; ?>" title="Edit member"> <strong><?php echo $row->sForename; ?> <?php echo $row->sSurname; ?></strong></a></td>
              <td class="gridrow1" align="left"><a class="bluenave" href="javascript:void(0)" title="Click To Send Email" onClick="openSendEmail('<?php echo $row->nUser_ID ?>')"><?php echo $row->sEmail ?></a></td>
              <td align="left" class="gridrow1"><?php echo ($row->nConfirmed == '1') ? '<span class="green">Confirmed</span>': '<span class="error">Un-Confirmed</span>'?></td>
              <td align="left" class="gridrow1"><?php echo getCurrentMemberships($row->nUser_ID);  ?></td>
              <td class="gridrow1" align="center"><?php echo fShowDate($chkSsettings->nDateFormat, $row->nJoinDate); ?>&nbsp;</td>
              <td class="gridrow1" align="center"><?php echo ($row->nAffiliate_ID !=0)?$row->sAffForename . '&nbsp;' . $row->sAffSurname:'None' ?></td>
              <td align="center" class="gridrow1"><form action="actions.php?type=member" method="post">
                  <?php if ($row->nUser_ID == 1) : ?>
                  <a href="#" onClick="javascript:alert('You cannot deactivate the admin user.');return false;"><img src="images/dropd.gif" alt="Not allowed to deactivate the admin user" width="16" height="16" border="0" /></a>
                  <?php else : ?>
                  <?php if ($row->nActive == 0) : ?>
                  <input type="hidden" value="1" name="active" />
                  <input type="image" src="images/adult_r.gif" title="Activate Member"/>
                  <?php else : ?>
                  <input type="hidden" value="0" name="active" title="Deactivate Member"/>
                  <input type="image" src="images/adult_off.gif"/>
                  <?php endif; // ($row->nActive == 0) ?>
                  <?php endif; // ($row->nUser_ID == 1) ?>
                  <input type="hidden" value="<?php echo $row->nUser_ID ?>" name="id" />
                  <input type="hidden" value="status" name="act" />
                </form></td>
              <td align="center" class="gridrow1"><form action="login_as_client.php" method="post" name="form1" target="_new">
                  <input type="submit" name="button" id="button" value="Login">
                  <input name="user" type="hidden" id="user" value="<?php echo $row->sEmail ?>">
                </form></td>
              <td colspan="2" align="center" class="gridrow1"><form action="actions.php?type=member" method="post">
                  <?php if ($row->nUser_ID == 1) : ?>
                  <a class="grid" href="#" title="Not allowed to delete member" OnClick="javascript:alert('You are not allowed to delete the admin user.');return false;"><img src="images/dropd.gif" alt="Not allowed to delete member" border="0" /></a><br>
                  <?php else : ?>
                  <input type="image" src="images/delete.gif" OnClick="return cdel('member');" alt="Delete member" title="Delete Member"/>
                  <?php endif; ?>
                  <input type="hidden" value="<?php echo $row->nUser_ID ?>" name="id" />
                  <input type="hidden" value="delete" name="act" />
                </form></td>
            </tr>
            <?php 
					endwhile; 
				}
				else{echo '<tr><td colspan="10" class="gridrow2">No Members Found'; if(isset($_SESSION['admin']['current_mqf_sql'])){echo ' Using Query Filter: '.$_SESSION['admin']['current_mqf_title'];}echo '</td></tr>';}
				?>
            <tr>
              <td colspan="10" class="gridFooter"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                  <td style='text-align:left'><?php echo $navigator; 	?></td>
                  <td style='text-align:right; padding-right:10px'> Page <?php echo $pageinfo ?></td>
                </tr>
                </table></td>
            </tr>
          </table>
          <br /></td>
      </tr>
    </table>
    <div id="sendEmail">
      <form action="actions.php?type=member" method="post" id="sendEmailModal">
        <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
          <tr>
            <td colspan="2" class="gridheader">Send Email To Member</td>
          </tr>
          <tr>
            <td class="gridrow2">From Name:</td>
            <td class="gridrow2"><label for="from_name"></label>
              <input type="text" name="from_name" id="from_name" value="<?php echo $objAdmin->sForename.' '.$objAdmin->sSurname ?>" style="width:90%"></td>
          </tr>
          <tr>
            <td class="gridrow2">From Email:</td>
            <td class="gridrow2"><label for="from_email"></label>
              <input type="text" name="from_email" id="from_email" value="<?php echo $objAdmin->sEmail ?>" style="width:90%"></td>
          </tr>
          <tr>
            <td class="gridrow2">Email Type</td>
            <td class="gridrow2"><p>
                <label>
                <input name="emailType" type="radio" id="EmailType_0" value="text" checked="CHECKED" onClick="setEmailType(this)">
                Plain Text</label>
                <br>
                <label>
                <input type="radio" name="emailType" value="html" id="EmailType_1" onClick="setEmailType(this)">
                Html</label>
                <br>
              </p></td>
          </tr>
        </table>
        <br>
        <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
          <tr>
            <td class="gridrow2">Subject:</td>
            <td class="gridrow2"><label for="subject"></label>
              <input name="subject" type="text" id="subject" size="50" style="width:90%"></td>
          </tr>
          <tr>
            <td class="gridrow2">Message</td>
            <td class="gridrow2"><label for="email_message"></label>
              <textarea name="email_message" id="email_message" cols="45" rows="15" style="width:90%"></textarea></td>
          </tr>
          <tr>
            <td colspan="2" class="gridrow2"><input type="submit" name="button2" id="button2" value="Send Mail">
              <input type="hidden" name="sendEmailToId" id="sendEmailToId">
              <input type="hidden" name="act" value="sendEmail"></td>
          </tr>
        </table>
      </form> 
    </div>
    <div id="manageFilters" title="Manage Member Query Filters">
    	<div id="manageFilters_addNew" style="display:none;">
        <hr>
		<form name="f1" method="post" action="actions.php?type=queryFilter" onSubmit="return checkthis()" id="addNewForm">
					<strong>New Filter Name</strong>
                    <input name="newFilterName" type="text" id="newFilterName" size="55">
                  <p><strong>Filter Fields</strong><br>
                    <input name="level" type="checkbox" id="level" value="1" onClick="showFilterFields(this)">
                    <label for="level"></label>
                    <label>Membership Level</label>
                    <input name="affiliate" type="checkbox" id="affiliate" value="1" onClick="showFilterFields(this)">
                    <label>Affiliate</label>
                    <input name="login" type="checkbox" id="login" value="1" onClick="showFilterFields(this)">
                    Last Login
                    <input name="emailStatus" type="checkbox" id="emailStatus" value="1" onClick="showFilterFields(this)">
                    Email Status
                    <input name="optin" type="checkbox" id="optin" value="1" onClick="showFilterFields(this)">
                    Opt-In Status 
                    <input name="join" type="checkbox" id="join" value="1" onClick="showFilterFields(this)">
                    Join Date</p>
                  <p>View Members Where
                  <div id="filterContainer" style="margin-left:15px;">
                    <div id="levelFilter" style="display:none;"> Membership Level
                      
                      <?php echo $levelsel ?>
                      <select name="levelFilterCompare" id="levelFilterCompare">
                        <option value="IN">Is Assigned</option>
                        <option value="NOT IN">Not Assigned</option>
                      </select>
                      <label for="levelFilterValue"></label>
                    </div>
                    <div id="affiliateFilter" style="display:none;">Is Affiliate
                      <label for="affiliateFilterValue"></label>
                      <select name="affiliateFilterValue" id="affiliateFilterValue">
                        <option value="1">True</option>
                        <option value="0">False</option>
                      </select>
                    </div>
                    <div id="loginFilter" style="display:none;">Last Login
                      <label for="loginFilterCompare"></label>
                      <select name="loginFilterCompare" id="loginFilterCompare" onChange="toggleFilterValue2(this);">
                        <option value=">">After</option>
                        <option value="<">Before</option>
                        <option value="=">On</option>
                        <option value="><">Between</option>
                        <option value="never">Never</option>
                      </select>
                      <input name="loginFilterValue" type="text" size="8" readonly class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, date("Ymd")) ?>">
                      <span id="loginFilterBetween" style="display:none;"> And <input name="loginFilterValue2" type="text" size="8" readonly class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, date("Ymd")) ?>"></span></div>
                    <div id="emailStatusFilter" style="display:none;"> Account Status
                      <label for="emailStatusFilterValue"></label>
                      <select name="emailStatusFilterValue" id="emailStatusFilterValue">
                        <option value="1">Confirmed</option>
                        <option value="0">Unconfirmed</option>
                      </select>
                    </div>
                    <div id="optinFilter" style="display:none;">Optin Status
                      <label for="optinFilterValue"></label>
                      <select name="optinFilterValue" id="optinFilterValue">
                        <option value="0">Receive All</option>
                        <option value="1">Receive None</option>
                      </select>
                    </div>
                    <div id="joinFilter" style="display:none;">Joined
                      <label for="joinFilterCompare"></label>
                      <select name="joinFilterCompare" id="joinFilterCompare" onChange="toggleFilterValue2(this)">
                        <option value=">">After</option>
                        <option value="<">Before</option>
                        <option value="=">On</option>
                        <option value="><">Between</option>
                      </select>
                      <input name="joinFilterValue" type="text" size="8" readonly class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, date("Ymd")) ?>">
                      <span id="joinFilterBetween" style="display:none;"> And <input name="joinFilterValue2" type="text" size="8" readonly class="datepicker" value="<?php echo fShowDate($chkSsettings->nDateFormat, date("Ymd")) ?>"></span>
                     </div>
                  </div>
                  </p>
                  <input name="act" type="hidden" id="act" value="saveFilter">
                  <p>&nbsp;</p>
                  <p>
                    <input class="inputSubmit" name="submit2" value="Apply Filter" type="button" onClick="submitAddNew()">
                &nbsp;
                    <input class="inputSubmit" name="cancel" value="Cancel" type="button" onClick="hideAddNew()">
                  </p>
                </form>    
    </div>
    	<div id="tableContainer" >
        	<div align="right" style="padding:5px;"><a href="#" onClick="showAddNew()">Add New Filter</a></div>  
			<div id="tableRows">Loading Filters ...</div>
    	</div>
	</div>
    <?php include_once('b.php'); ?>
</body>
</html>