<?php
	include_once ('../conn.php');
	include_once ('../functions.php');
	

	function notdeleted($path){$_SESSION['notdeleted'][] = $path;}
	function rrmdir($path) {
		// Open the source directory to read in files
		$i = new DirectoryIterator($path);
		foreach($i as $f) {
			if($f->isFile()) {
				unlink($f->getRealPath());
			}
			elseif(!$f->isDot() && $f->isDir()) {
				rrmdir($f->getRealPath());
			}
		}
		rmdir($path);
	}
	
	if($_GET['action'] == 'activate'){
		// Set The Plugin As Active
		$sql = "Update tblplugins SET nActive = 1 WHERE sName = '".$_GET['plugin']."';";
		$dbo->update($sql);
		// Register The Plugin
		pluginClass::load($_GET['plugin']);
		require_once( $chkSsettings->sRootPath . "/plugins/{$_GET['plugin']}/{$_GET['plugin']}.php" );   
		// Run The Plugin Activate Hook
		foreach(pluginClass::get_activate($_GET['plugin']) as $k=>$v){if(is_callable(array($k,$v))){call_user_func(array($k,$v));}}
		header("Location: manage_plugins.php?msg=Plugin ".$_GET['plugin']." Activated Successfully");exit;}
		
	if($_GET['action'] == 'deactivate'){
		$sql = "Update tblplugins SET nActive = 0 WHERE sName = '".$_GET['plugin']."';";
		$dbo->update($sql);
		// Run The Plugin De Activate Hook
		foreach(pluginClass::get_deactivate($_GET['plugin']) as $k=>$v){if(is_callable(array($k,$v))){call_user_func(array($k,$v));}}
		header("Location: manage_plugins.php?msg=Plugin ".$_GET['plugin']." Deactivated Successfully");exit;}
	
	if($_GET['action'] == 'delete'){
		
		if($_POST['delete_verify'] === '1'){
			$plugin = $_GET['plugin'];
			// Lets Run Plugin Delete Functions, Than Delete the plugin
			// Run The Plugin De Activate Hook
			foreach(pluginClass::get_deactivate($plugin) as $k=>$v){if(is_callable(array($k,$v))){call_user_func(array($k,$v));}}
			
			// Delete Plugin From Database
			removefromDB($dbo->format($_GET['plugin']));
			
			
			
			// Delete The Plugin Files ...
			// If Exists ...
			if(file_exists($chkSsettings->sRootPath.'/plugins/'.$plugin)){
				
				$mydir = $chkSsettings->sRootPath.'/plugins/'.$plugin; 
				rrmdir($mydir);
			}
			header("Location:manage_plugins.php?msg=Plugin $plugin Deleted Successfully!");
		}
		if($_POST['delete_verify'] === '0'){header("Location:manage_plugins.php");}
		else{
			// Display Confirm Delete Plugin Page
			$confirmDelete = 1;
			$meta = $PLUGINS->get_plugin_data($chkSsettings->sRootPath.'/plugins/'.$_GET['plugin'].'/'.$_GET['plugin'].'.php');
			//die($chkSsettings->sRootPath.'/plugins/'.$_GET['plugin'].'/'.$_GET['plugin'].'.php');
			}
		}

	// Lets Load Plugins Page ...
   // Populate the list of directories to check against
   if($confirmDelete!=1){
		 if ( ($directoryHandle = opendir( $chkSsettings->sRootPath . '/plugins/' )) == true ) {
			while (($file = readdir( $directoryHandle )) !== false) {
				// Make sure we're not dealing with a file or a link to the parent directory
				if( is_dir( $chkSsettings->sRootPath . '/plugins/' . $file ) && ($file == '.' || $file == '..') !== true ){
            		// Lets Check The Current Directory For Valid Plugin File.
					// Looking for /plugins/curdir/curdir.php
					if(is_file($chkSsettings->sRootPath . '/plugins/' . $file .'/'.$file.'.php')){
						// Got A Valid Plugin File. Lets Grab The Meta Data
						if($PLUGINS->has_plugin_data($chkSsettings->sRootPath . '/plugins/' . $file .'/'.$file.'.php')){
							$plugin[$file]['file']['meta'] = $PLUGINS->get_plugin_data($chkSsettings->sRootPath . '/plugins/' . $file .'/'.$file.'.php');
								if(!$PLUGINS->inDB($file)){$PLUGINS->addtoDB($file);}
						}	
					}
				}
			}
		 }
	}
  
   // Get the plugin list from MySQL.
   //die(var_dump($plugin));
   //$newResult = array();
   $res = $dbo->select( 'SELECT * FROM tblplugins');
   $count = $dbo->nr($res);
   
   // Lets go through the list and check for updates ...
   // Maintnanace on the DB and Check For Updates
   if($count){
	while($result = $dbo->getobj($res)){ 
	   if(is_file($chkSsettings->sRootPath . '/plugins/' . $result->sName .'/'.$result->sName.'.php')){
			// Got A Valid Plugin File. Lets check for Meta Data
			if(!$PLUGINS->has_plugin_data($chkSsettings->sRootPath . '/plugins/' . $result->sName .'/'.$result->sName.'.php')){
				// Now Invalid Plugin. Remove From DB
				$PLUGINS->removefromDB($result->sName);
				$modified = true;
				continue;	
			}
			else{
				// Do Version Update Checks ...
				$cur = $plugin[$result->sName]['file']['meta']["Version"];
				$checkUrl = $plugin[$result->sName]['file']['meta']["VersionURI"];
				$downloadUrl = $plugin[$result->sName]['file']['meta']["VersionDownloadURI"];
				$plugin[$result->sName]['newversion'] = $PLUGINS->updateAvailable($result->sName,$cur,$checkUrl);
			}
		
		}
		else{
			$PLUGINS->removefromDB($result->sName);
			$modified = true;
			continue;
		}
   }
   	// Maintnance may have removed some entries
	// Re-Run the Query
	if($modified){
		 $res = $dbo->select( 'SELECT * FROM tblplugins');
		 $count = $dbo->nr($res);
	}
	else{$dbo->seek($res,0);}

	   
	}
?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php include("inc-head.php");
		// ZipArchive is available since 5.2. Require this version to use this feature.
		if (version_compare(PHP_VERSION, '5.2', '>=')) {?>
        <script type="text/javascript" src="../includes/plupload/js/plupload.full.js"></script>
		<script type="text/javascript" src="../includes/plupload/js/jquery.plupload.queue/jquery.plupload.queue.js"></script>
		<script type="text/javascript">
		$(function() {
			
		$( "#uploadForm" ).dialog({
            autoOpen: false,
            show: "explode",
            hide: "explode",
			modal: true,
			width:'auto',
			closeOnEscape: true
        });
		
	 });
        function uploadPluginScreen(){
			var title = 'Upload New Plugin';
			var message = '';
			var messageType = 'success';
			
			$( "#uploadForm" ).dialog('option','title',title).dialog( "open" );
			$( "#uploadForm" ).dialog( "open" );
			$('#uploader').pluploadQueue({
			// General settings
			runtimes : 'flash,html5,gears,silverlight,browserplus',
			url : 'ajax/functions.php?act=upload_plugin',
			max_file_size : '10000mb',
			chunk_size : '1mb',
			multiple_queues : false,
      		multi_selection : false,
      		max_file_count : 1,
			dragdrop : false,
			// Resize images on clientside if we can
			//resize : {width : 320, height : 240, quality : 90},
	
			// Specify what files to browse for
			filters : [
				{title : "Zip File", extensions : "zip"}
			],
	
			// Flash settings
			flash_swf_url : '../includes/plupload/js/plupload.flash.swf',
	
			// Silverlight settings
			silverlight_xap_url : '../includes/plupload/js/plupload.silverlight.xap',
			
			// PreInit events, bound before any internal events
			preinit : {
			},
	
			// Post init events, bound after the internal events
			init : {
				FilesAdded: function(up, files) {
          			up.start();
        		},
				FileUploaded: function(up, file, response) {
					// Called when a file has finished uploading
					var obj = jQuery.parseJSON(response.response);
					if(obj.success){message = obj.success; messageType = 'success';}
					else{message = obj.error; messageType = 'error';}
					//console.log("my object: %o", obj)
					
					
					
				},
				UploadComplete: function(up, files,response) {
          			
					
					$.each(files, function(i, file) {
            		// Do stuff with the file. There will only be one file as it uploaded straight after adding!
          			});
					var url = 'manage_plugins.php';
					
					if(messageType == 'success'){url = url + '?msg='+message}
					if(messageType == 'error'){url = url + '?err='+message}
					
					window.location.href=url;
        },
				
	
				Error: function(up, args) {
					// Called when a error has occured
					//alert('[error] '+ args);
				}
			}
		});
		}
        </script>
        <!-- Load Queue widget CSS and jQuery -->
		<style type="text/css">
		@import url(../includes/plupload/js/jquery.plupload.queue/css/jquery.plupload.queue.css);
		</style>
        <?php } ?>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">

<!-- Include Navigation -->
<?php include_once ('top.php'); ?>
<!-- Start Content -->
<table cellpadding="0" cellspacing="0" width="100%">
	<tr> 
    <!-- START LEFT SIDE -->
    <td width="180" height="350" rowspan="2" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
		<?php include_once ('pageleft.php'); ?>
	</td>
    <!-- START RIGHT SIDE -->
    <td style="height:40px; width:100%; padding-left: 8px; padding-top: 8px; padding-right: 8px; vertical-align:top">
	<?php echo isset($message) ? $message: '' ?>
            <?php if($confirmDelete == 1){ ?>
            <h1>Delete Plugin</h1>
            <p>You are about to delete the following plugin:</p>
			
			<?php echo $_GET['plugin'] .' by '.$plugin[$_GET['plugin']]['file']['meta']['Author']?><br><br>
Deleting a plugin will remove all plugin settings, and attempt to delete the files from your system.
<p>Are you sure you wish to delete these files?</p>
<ul>
<?php
foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($chkSsettings->sRootPath.'/plugins/'.$_GET['plugin'].'/')) as $filename)
{
        echo "<li>".str_replace($chkSsettings->sRootPath,'',$filename)."</li>";
}
?>
</ul>
<form method="post" style="display:inline">
<input type="hidden" name="delete_verify" value="1">
<input name="" type="submit" value="Delete Files">
</form>
<form method="post" style="display:inline">
<input type="hidden" name="delete_verify" value="0">
<input name="" type="submit" value="Cancel">
</form>


            <?php }
			else{ ?>
            <h1>Plugin Management
			<?php 
			// ZipArchive is available since 5.2. Require this version to use this feature.
			if (version_compare(PHP_VERSION, '5.2', '>=')) {?>
			 - <a onClick="uploadPluginScreen()">Upload New</a><?php } ?></h1>
               
                  <table width="80%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
                  <tr class="gridtable">
                  <td class="gridheader">Plugin</td>
                  <td class="gridheader">Description</td>
                  </tr>
                  <?php while($result = $dbo->getobj($res)){ ?>
                  <tr>
                  <td class="gridrow1">
				  <?php echo $plugin[$result->sName]['file']['meta']['Name'] ?><br>
					<?php echo ($result->nActive)? ' <a href = "?action=deactivate&plugin='.$result->sName.'">Deactivate</a>': '<a href = "?action=activate&plugin='.$result->sName.'">Activate</a>  | <a href="?action=delete&plugin='.$result->sName.'">Delete</a>' ?>
                  </td>
                  <td class="gridrow1">
                  <?php 
				  if(!empty($plugin[$result->sName]['file']['meta'])){ ?>
				  	
					
					<?php echo $plugin[$result->sName]['file']['meta']["Description"]; ?>
                    <br /><br />
					By <a href="<?php echo $plugin[$result->sName]['file']['meta']["AuthorURI"] ?>">
						<?php echo $plugin[$result->sName]['file']['meta']["Author"] ?>
                      </a> | <a href="<?php echo $plugin[$result->sName]['file']['meta']["PluginURI"] ?>">Visit Plugin Site</a> | Version <?php echo $plugin[$result->sName]['file']['meta']["Version"] ?><br>
					<?php 
					$cur = $plugin[$result->sName]['file']['meta']["Version"];
					$checkUrl = $plugin[$result->sName]['file']['meta']["VersionURI"];
					$downloadUrl = $plugin[$result->sName]['file']['meta']["VersionDownloadURI"];
					$newVersion = $plugin[$result->sName]['newversion'];
					if ($newVersion != NULL && $newVersion !== false){ ?>
                    	<div class="notify-warning">New Version <?php echo $newVersion ?> Available<br>
<a href="<?php echo $downloadUrl ?>"> Download Now</a></div>
                    <?php	
					} 
					}
				   else{echo 'Unable To Read plugins/'.$result->sName.'/'.$result->sName.'.php';}
				   ?>
                  
                  </td>
                  </tr>
                <?php } 
                if (!$count){echo '<tr><td class="gridrow1" colspan="2">No Compatible Plugins Found! <a target="_blank" href="http://easymemberpro.com/plugin-directory/" >Get Some</a></td></tr>';} ?>
                <tr><td class="gridheader" colspan="2">&nbsp;</td></tr>
              </table> <?php } ?>
    </td>
    </tr>
    </table>
    <div id="uploadForm" style="width:50%; margin:auto"><div id="uploader" style="min-width:450px;"></div></div>
              <?php include_once ('b.php'); ?>
</body>
</html>