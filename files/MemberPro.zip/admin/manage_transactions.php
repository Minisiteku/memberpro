<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	// Load Refunded Transaction List ...
	$sql = "SELECT nTransaction_ID
	FROM `tbltransactions`
	WHERE sTransactionNumber
	IN (
		SELECT sTransactionNumber
		FROM tbltransactions
		WHERE nTransactionType_ID =2
	)
	AND nTransactionType_ID = '1'";
	
	$res = $dbo->select($sql);
	$refundedIds = array();
	if($dbo->nr($res)) while($row = $dbo->getobj($res)) $refundedIds[] = $row->nTransaction_ID;
	unset($res);
	
	// get tx types
	$result = $dbo->select("SELECT * FROM tbltransactiontypes;");
	while ($row = $dbo->getobj($result)) $txtypes[$row->nTransactionType_ID] = $row->sType;
			
	// Get Payment Processors
	$payres = $dbo->select("SELECT nPaymentProcessor_ID,sProcessorName FROM tblpaymentprocessors");
	if($payres) while($row = $dbo->getobj($payres)) $processors[$row->nPaymentProcessor_ID] = $row->sProcessorName;
	
	// Get total number of transactions AND get a currency amount.
	// This is the query for the total revenue text.
	$sql2 = "SELECT COUNT( * ) nCount FROM `tbltransactions` ";
	$sql3 = "SELECT COUNT( * ) nCount, SUM( `nSaleAmount` ) revenue FROM `tbltransactions` WHERE nTransactionType_ID = '1'";
	$sql3 = "SELECT COUNT( * ) nCount, SUM( `nSaleAmount` ) revenue FROM `tbltransactions` WHERE nTransactionType_ID = '2'";
	//$countquery = $dbo->getobject($sql2);
	$countquerySales = $dbo->getobject($sql3);
	$countqueryRefunds = $dbo->getobject($sql4);
	// Build Display Data
	$number = $countquerySales->nCount + $countqueryRefunds->nCount; // Number of records
	$revenue = $countquery->revenue;
	
	// Main query
	$sql = "
	SELECT tbltransactions.*,
	tblusers.sForename as firstname,
	tblusers.sSurname as lastname 
	FROM tbltransactions 
	LEFT JOIN tblusers ON tblusers.nUser_ID = tbltransactions.nUser_ID ";
	
	
	// Query Filters
	if(isset($_GET['id'])) $sql .="WHERE nTransaction_ID = ".$_GET['id']." ";
	elseif(isset($_GET['user'])) $sql .="WHERE tbltransactions.nUser_ID = ".$_GET['user']." ";	
	
	// Query Sorting		
	switch ($_GET['sort']) {
		case 'amount':
			$sortfield = 'tbltransactions.nSaleAmount';
			break;
		case 'txtype':
			$sortfield = 'tbltransactions.nTransactionType_ID';
			break;
		case 'processor':
			$sortfield = 'tbltransactions.sProcessor';
			break;
		case 'txnum':
			$sortfield = 'tbltransactions.sTransactionNumber';
			break;
		case 'email':
			$sortfield = 'tblusers.sEmail';
			break;
		case 'joindate':
			$sortfield = 'tblusers.nJoinDate';
			break;
		case 'referrer':
			$sortfield = 'sAffSurname';
			break;
		default:
			$sortfield = 'tbltransactions.dDateTime';
	}
	$sql .= "ORDER BY $sortfield {$_GET['type']}";
			
	$totalRecords = $dbo->num_rows($sql);	
	// Start Paging
	/*********************************************************/
	include_once('paging.php');
	$objPaging = new Paging();
	$aMPP = array('5', '10', '15', '20', '25', '50', '100');
	$mpp = (empty($_GET['mpp'])) ? 10 : $_GET['mpp'];
	$start = (empty($_GET['start'])) ? 0 : $_GET['start'];	
	unset($_GET['start']);
		 	
	$objPaging->Total_Records_Per_Page = $mpp; 
	$objPaging->Total_Records = $totalRecords;
	$index = $start ;
	$indexupto = $index + $objPaging->Total_Records_Per_Page;	 	
	$objPaging->prepare_ParameterString($_GET);
	$objPaging->set_Start_Item($indexupto); 	 		 	
	$objPaging->Has_First_Last = true;	
	$navigator = $objPaging->Create_Paging();
	$pageinfo = $objPaging->get_PageInfo();	 	
	$counter = 0;  
	$sql .= "LIMIT ".$objPaging->Total_Records_Per_Page." OFFSET ".$index;
	/*********************************************************/
//die($sql);
	$mainres = $dbo->select($sql);
	
	// Put together QueryString
	$qs = sprintf("?qry=%s&srchval=%s&start=%s&mpp=%s", $_GET['qry'], $_GET['srchval'], $start, $mpp);
			
	// Used For Sorting Links ...
	// Load Defaults
	$txtype = $txname = $processor = $dDateTime = 'desc';
			  
	if($_GET['sort']) {
		$type = ($_GET['type'] == 'asc')?'desc':'asc';
		$$_GET['sort'] = $type;
	}
?>
<html>
<head>
<title><?php echo $admintitle; ?></title>
<?php include("inc-head.php"); ?>
<link type="text/css" rel="stylesheet" href="../common/css/jqueryui/redmond/jquery-ui-1.8.24.custom.css">
<script language="javascript" src="../js/jquery-ui-1.8.24.custom.min.js"></script>
<script language="javascript" src="../js/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript"> 
		function cdel(w) {
			return confirm("Are you sure that you want to delete this transaction? \n This action cannot be reversed.");
		}
		function updateMPP(oList) {
			var mpp = oList.options[oList.selectedIndex].value;
			var qs = '?start=0';
			qs += '&sort=<?php echo $_GET['sort'] ?>';
			qs += '&type=<?php echo $_GET['type'] ?>';
			qs += '&mpp=' + mpp;
			document.location = '<?php echo $_SERVER['PHP_SELF']?>' + qs;
		}
      function toggle(id){
		var ele = document.getElementById(id);
		if(ele.style.display == 'none'){ele.style.display = 'block'}
		else{ele.style.display = 'none'}
		}
	function editTransaction(id){
		
		// This Function Grabs The Pre-defined html for the edit level dialog box.
		// It sets special functions, builds the dialog box, and wraps it all in a form
		// to send to actions.php
		// Grab The Populated Form
		//alert(id);
		var ddiv = $("#TransEdit_"+id).html();
		// Insert The data into the dialog element
		$("#model-form-container").html(ddiv);
		
		// Assign Ids for Auto Suggest
		$("#Model-Form input[name=mem]").attr('id','mem');
		$("#Model-Form input[name=suggestionsmHidden]").attr('id','suggestionsmHidden');
		
		// Assign The Picker Class
		//$("#Model-Form input[name=DateActive]").addClass('datepicker');
		$("#Model-Form input[name=trans_datetime]").attr('id','datetimepicker');
		
		// Register Picker
		//$( ".datepicker" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '2000:2037',changeYear: true});
		$( "#datetimepicker" ).datetimepicker({ 
			dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',
			timeFormat: "HH:mm:ss",
			yearRange: '1970:2037',
			changeYear: true });
		
		// Set the dialog title
		var title = $("#EditTrans h1.dialog-title").html()
		
		$( "#EditTrans" ).dialog('option','title',title);
		// Launch the Dialog Box
		$( "#EditTrans" ).dialog( "open" );
		
		//$( "#EditLevelId" ).val(id);
		return false;
	}
	function manualRefund(id){
		$("#refundTransactionNumber").val($("#sTransactionNumber_"+id).val());
		
		$( "#refundTrans" ).dialog( "open" );
		
	}
	$.fx.speeds._default = 1000;
	$(function() {
		$( "#EditTrans" ).dialog({
            autoOpen: false,
            show: "explode",
            hide: "explode",
			modal: true,
			width:'auto',
			height:'auto'
        });
		 $( "#refundTrans" ).dialog({
			resizable: false,
			autoOpen: false,
			width:'auto',
			height:'auto',
			modal: true,
			buttons: {
				"Process Refund": function() {
					$("#refundTransactionForm").submit();
					$( this ).dialog( "close" );
				},
				Cancel: function() {
					$( this ).dialog( "close" );
				}
			}
		});
	 });
	// Suggestion Scripting
	function lookup(inputString,file,suggestions,autosuggestionlist) {
		if(inputString.length == 0) {
			// Hide the suggestion box.
			$(suggestions).hide();
		}
		else {
			$.post('ajax/'+file, {queryString: ""+inputString+""}, function(data){
				if(data.length >0) {
					$(suggestions).show();
					$(autosuggestionlist).html(data);
				}
			});
		}
	} // lookup
	function fill(thisValue,id,suggestions,thisValueId) {
		$(id).val(thisValue);
		$(suggestions+'Hidden').val(thisValueId);
		$(suggestions).hide();
	}
    </script>
<style type="text/css">
.suggestionsBox {
	position: absolute;
	left: 200px;
	top: 40px;
	margin: 10px 0px 0px 0px;
	width: 250px;
	background-color: #212427;
	-moz-border-radius: 7px;
	-webkit-border-radius: 7px;
	border: 2px solid #000;
	color: #fff;
}
.suggestionList {
	margin: 0px;
	padding: 5px;
}
.suggestionList li {
	margin: 0px 0px 5px 0px;
	padding: 3px;
	cursor: pointer;
}
.suggestionList li:hover {
	background-color: #659CD8;
}
/* css for timepicker */
.ui-timepicker-div .ui-widget-header {
	margin-bottom: 8px;
}
.ui-timepicker-div dl {
	text-align: left;
}
.ui-timepicker-div dl dt {
	height: 25px;
	margin-bottom: -25px;
}
.ui-timepicker-div dl dd {
	margin: 0 10px 10px 65px;
}
.ui-timepicker-div td {
	font-size: 90%;
}
.ui-tpicker-grid-label {
	background: none;
	border: none;
	margin: 0;
	padding: 0;
}
.ui-timepicker-rtl {
	direction: rtl;
}
.ui-timepicker-rtl dl {
	text-align: right;
}
.ui-timepicker-rtl dl dd {
	margin: 0 65px 10px 10px;
}
</style>
</head>
<body>
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once('toolsleft.php'); ?></td>
    <td width="100%" align="left" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;"><table class="navTable" border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td width="125" class="navRow1" nowrap="nowrap">Transaction Log</td>
          <td class="navRow2" style="text-align:right; padding-right:20px"> Records per page&nbsp;
            <select id='mpp' style='height:1.5em' onChange="updateMPP(this)">
              <?php
				foreach ($aMPP as $val) {
					$selected = ($val == $mpp) ? 'selected' : '';
					echo "<option value='$val' $selected>$val</option>";
				}
			?>
            </select></td>
        </tr>
      </table>
      <div style="text-align:left;  margin-left:2px; margin-bottom:5px"> <span style="padding-right:20px"></span> <span class="navRow2">
        <?php if( isset($message)) echo $message ?>
        </span> </div>
      <table width="100%" cellpadding="0" cellspacing="1" class="gridTable">
        <tr>
          <td colspan="8" class="gridFooter"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td style='text-align:left'><?php echo $navigator;?></td>
                <td style='text-align:right; padding-right:10px'>Page <?php echo $pageinfo ?></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td class="gridHeader" align="right" style="white-space:nowrap; width:1px;">Amount</td>
          <td class="gridHeader"><a href="manage_transactions.php<?php echo $qs?>&sort=txtype&type=<?php echo $txtype ?>" class="bluenave">Type</a></td>
          <td class="gridHeader" align="center" nowrap="nowrap">Member</td>
          <td class="gridHeader"><a href="manage_transactions.php<?php echo $qs?>&sort=processor&type=<?php echo $processor; ?>" class="bluenave">Processor</a></td>
          <td align="left" nowrap="nowrap" class="gridHeader"><a href="manage_transactions.php<?php echo $qs?>&sort=txname&type=<?php echo $txname; ?>" class="bluenave">Processor Transaction Id</a></td>
          <td align="left" nowrap="nowrap" class="gridHeader"><a href="manage_transactions.php<?php echo $qs?>&sort=dDateTime&type=<?php echo $dDateTime ?>" class="bluenave">Date/Time</a></td>
          <td class="gridHeader" align="center" nowrap="nowrap">Affiliate</td>
          <td align="center" nowrap="nowrap" class="gridHeader">Actions</td>
        </tr>
        <?php
					// Add Sort to QueryString
					$qs .= sprintf("&sort=%s&type=%s", $_GET['sort'], $_GET['type']);
				if ($mainres){
					while ($row = $dbo->getobj($mainres)) { 
				?>
        <tr>
          <td class="gridrow1" align="right" style="white-space:nowrap; width:auto">
		  <?php 
			$style =($txtypes[$row->nTransactionType_ID] == 'Refund')?'color: #FF0000;':'color:#009900;';
			
			// Format The Number For Display
			$neg = '';
			$value = number_format((float)$row->nSaleAmount, 2, '.', '');
			
			if($txtypes[$row->nTransactionType_ID] == 'Refund'){
				$value = str_replace('-','',$value);
				$neg = '- ';
			}
			$prettynum = get_currency_symbol($chkSsettings->sCurrencyFormat).$neg.$value;
			
			echo '<span style="'.$style.'">'.$prettynum.'</span>'; ?>
            <?php
			if($row->nUser_ID){$name = $row->firstname.'&nbsp;'.$row->lastname;}
			else{
				// version 2.x member details
				$name = $row->sUserSurname.'&nbsp;'.$row->sUserForename;}
			?></td>
          <td class="gridrow1"><?php echo '<span style="'.$style.'">'.trim($txtypes[$row->nTransactionType_ID]); ?></span></a></td>
          <td class="gridrow1"><a href="view_member.php?id=<?php echo $row->nUser_ID ?>"> <?php echo $name ?> </a></td>
          <td class="gridrow1"><strong><?php echo trim($row->sProcessor); ?></strong></a></td>
          <td class="gridrow1" align="left"><?php echo $row->sTransactionNumber ?></td>
          <td class="gridrow1" align="left" ><?php echo $row->dDateTime; ?></td>
          <td class="gridrow1" align="center"><?php echo $row->sAffForename . '&nbsp;' . $row->sAffSurname ?></td>
          <td class="gridrow1" align="center" ><form name="form1" method="post" action="actions.php?type=transaction">
              <?php if($row->nTransactionType_ID == '1') {
              	if(!in_array($row->nTransaction_ID,$refundedIds)){?>
              <input name="refund" type="button" value="Refund" onClick="manualRefund('<?php echo $row->nTransaction_ID?>');">
              <input type="hidden" name="sTransactionNumber_<?php echo $row->nTransaction_ID?>" id="sTransactionNumber_<?php echo $row->nTransaction_ID?>" value="<?php echo $row->sTransactionNumber ?>" />
              <?php }else{ ?>
              <span class="error">Refunded</span>
              <?php }} ?>
              <input type="button" name="button3" id="button3" value="Edit" onClick=" editTransaction('<?php echo $row->nTransaction_ID?>');" style="display:inline">
              <input type="hidden" name="act" value="delete" />
              <input type="hidden" name="tx_id" value="<?php echo $row->nTransaction_ID?>" />
              <input type="submit" name="button2" id="button2" value="Delete" style="display:inline" onClick="return cdel();">
            </form></td>
        </tr>
        <?php }}
		else{?>
        <tr>
          <td colspan="8" class="gridrow1">No Transactions Recorded</td>
        </tr>
        <?php }
		?>
        <tr>
          <td colspan="8" class="gridFooter"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td style='text-align:left'><?php echo $navigator; ?></td>
                <td style='text-align:right; padding-right:10px'>Page <?php echo $pageinfo ?></td>
              </tr>
            </table></td>
        </tr>
      </table>
      <br /></td>
  </tr>
</table>
<?php
	// We need to go back through the loop and print divisions.
	$dbo->seek($mainres, 0);
	if($dbo->nr($mainres)){
		while($row = $dbo->getobj($mainres)){
			if($row->nUser_ID){$name = $row->firstname.'&nbsp;'.$row->lastname;}
			else{
				// version 2.x member details
				$name = $row->sUserSurname.'&nbsp;'.$row->sUserForename;
			}
			?>
<div id="TransEdit_<?php echo $row->nTransaction_ID ?>" style="display:none">
  <h1 class="dialog-title" style="display:none">Editing Transaction </h1>
  <table border="0" cellspacing="1" cellpadding="0" class="gridtable" width="449px;">
    <tr>
      <td class="gridheader">Member</td>
      <td class="gridrow1"><input  name="mem" value="<?php echo $name ?>"onKeyUp="lookup(this.value,'mem.php','#suggestionsm','#autoSuggestionsListm');" type="text"  class="required" autocomplete="off" />
        <input name="suggestionsmHidden" type="hidden" value="<?php echo $row->nUser_ID ?>" />
        </label></td>
    </tr>
    <tr>
      <td class="gridheader">Type</td>
      <td class="gridrow1"><select name="trans_type" id="trans_type">
          <option value="1" <?php echo ($row->nTransactionType_ID == '1')?'selected="selected"':''?>>Sale</option>
          <option value="2" <?php echo ($row->nTransactionType_ID == '2')?'selected="selected"':''?>>Refund</option>
          <option value="3" <?php echo ($row->nTransactionType_ID == '3')?'selected="selected"':''?>>Cancellation</option>
        </select></td>
    </tr>
    <tr>
      <td class="gridheader">Processor</td>
      <td class="gridrow1"><select name="processor" id="processor">
          <option value="" selected>None</option>
          <?php
				foreach ($processors as $k=>$v){?>
          <option value="<?php echo $v ?>" <?php echo ($row->sProcessor == $v) ?'selected="selected"':'' ?>><?php echo $v ?></option>
          <?php }
				
			if($txtypes[$row->nTransactionType_ID] == 'Refund'){
				
				$style = 'color: #FF0000;';}
			else{$style = 'color:#009900;';}
			// Format The Number For Display
			$neg = '';
			$value = number_format((float)$row->nSaleAmount, 2, '.', '');
			
			if($txtypes[$row->nTransactionType_ID] == 'Refund'){
				$value = str_replace('-','',$value);
				$neg = '- ';
			}
			$prettynum = $value;
			
			 ?>
        </select></td>
    </tr>
    <tr>
      <td class="gridheader">Amount</td>
      <td class="gridrow1"><?php echo get_currency_symbol($chkSsettings->sCurrencyFormat)?>
        <input type="text" name="trans_amount" id="trans_amount" value="<?php echo $prettynum ?>"></td>
    </tr>
    <tr>
      <td class="gridheader">Date</td>
      <td class="gridrow1"><input type="text" name="trans_datetime" id="datetime" 
		value="<?php echo date('m/d/Y h:i:s',strtotime($row->dDateTime)) ?> " readonly /></td>
    </tr>
    <tr>
      <td class="gridheader">Transaction #</td>
      <td class="gridrow1"><div id="txncontainer_<?php echo $row->nUserLevel_ID ?>">
          <input name="Txn" 
								type="text"  value="<?php echo ($row->sTransactionNumber)?$row->sTransactionNumber:'';?>" autocomplete="off"/>
        </div></td>
    </tr>
    <tr>
      <td colspan="2" class="gridheader"><input type="submit" name="button" id="button" value="Save Changes"></td>
    </tr>
  </table>
  <input type="hidden" name="trans_id" value="<?php  echo $row->nTransaction_ID  ?>" />
</div>
<?php } } ?>
<div id="EditTrans">
  <form action="actions.php?type=transaction" method="post" id="Model-Form">
    <div class="suggestionsBox" id="suggestionsm" style="display: none;"> <img src="images/upArrow.png" style="position: relative; top: -12px; left: 30px" alt="upArrow" />
      <div class="suggestionList" id="autoSuggestionsListm"></div>
    </div>
    <div id="model-form-container"></div>
    <input type="hidden" name="act" value="edit" />
  </form>
</div>
<div id="refundTrans" title="Refund Transaction"> <strong>Are You Sure you want to refund this transaction?</strong><br>
  <br>
  --------------------
  Processing Options --------------------<br>
  <form id="refundTransactionForm" action="actions.php?type=transaction" method="post">
    <input name="removeCommission" type="checkbox" value="1" checked>
    <strong>Remove Affiliate Commission </strong><br>
    <input name="cancelLevel" type="checkbox" value="1" checked>
    <strong>Cancel Membership Level Access</strong>
    <input type="hidden" name="sTransactionNumber" id="refundTransactionNumber" value="">
    <p>-------------------- Processing Options --------------------</p>
    <p><strong>This action cannot be undone!</strong></p>
    <input type="hidden" name="act" value="processRefundManually">
  </form>
</div>
<?php include_once('b.php'); ?>
</body>
</html>