<?php
include_once('../conn.php');
include_once('../functions.php');

$newMessage = "Use the link below for new member signup";
$newpath = "index.php?page=join&level=".$dbo->format($_GET['level']);

$upgradeMessage = "Use the link below for existing members so that they can purchase additional levels";
$upgradepath = "member/index.php?page=upgrade&level=".$dbo->format($_GET['level']);
?>
<html>
<head>
<title>Direct Member Level Sales Link</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="common/css/styles.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color:;
}
-->
</style>
<link href="../styles.css" rel="stylesheet" type="text/css">
</head>
<body leftmargin=0 topmargin=0 marginheight="0" marginwidth="0"  >
<br>

<table width="95%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#FFFFFF" style="border: 1px solid #CCC;">
  <tr>
	<td align="center" valign="middle" class="black">Sales Link</td>
    <td><input name="link2" type="text" readonly value="<?php echo $sSiteURL."/".$newpath;?>" size="80"></td>
	</tr>
    <tr>
	<td align="center" valign="middle" class="black">Member Upgrade Link</td>
    <td><!-- <input name="link2" type="text" readonly value="<?php echo $sSiteURL."/".$upgradepath;?>" size="80"> -->No Longer Needed. Improved Upgrade System Coming Soon ...</td>
	</tr>
</table>
</body>
</html>
