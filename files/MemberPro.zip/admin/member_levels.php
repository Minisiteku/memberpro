<?php
include_once '../conn.php';
include_once '../functions.php';


// Add Member Levels
if ( isset($_POST['add']) ) {
		//die(print_r($_POST));
		if(!get_magic_quotes_gpc()){$cleanHtml = addslashes($_POST['tosHtml']);}
		else{$cleanHtml = $_POST['tosHtml'];}
		$sql = "INSERT INTO tblmembershiplevels (
		nLevel_ID,
		nOrder,
		sLevel,
		nDisplayFront,
		nActive,
		nTosRequired,
		sTosHtml,
		sLevelDescription
		) VALUES (
		'',
		'0',
		'".$dbo->format($_POST['sLevel']) . "', 
		'1',
		'1',
		'".$_POST['requireTos']."',
		'".$cleanHtml."',
		'".$_POST['sLevelDescription']."'
		)";		
	//die($sql);
		$dbo->insert($sql);		
		
	
		$message="<p class='success'>The member level was added!</p>";}
		

// Update Member Levels
if ( isset($_POST['update']) ) {
	if (sizeof(($_POST['chkExistingMemberLevel']))) {	
			
		$values = implode(",", $_POST['chkExistingMemberLevel']);		
		
		$sql = "UPDATE tblmembershiplevels SET nActive=0 WHERE nLevel_ID NOT IN (" . $values . ")";
		$dbo->update($sql);		
		
		$sql = "UPDATE tblmembershiplevels SET nActive=1 WHERE nLevel_ID IN (" . $values . ")";
		$dbo->update($sql);
	} 
	else {
		$sql = "UPDATE tblmembershiplevels SET nActive=0";
		$dbo->update($sql);
	}
	
	if (sizeof(($_POST['chkDisplayFront']))) {	
			
		$values = implode(",", $_POST['chkDisplayFront']);		
		
		$sql = "UPDATE tblmembershiplevels SET nDisplayFront=0 WHERE nLevel_ID NOT IN (" . $values . ")";
		$dbo->update($sql);		
		
		$sql = "UPDATE tblmembershiplevels SET nDisplayFront=1 WHERE nLevel_ID IN (" . $values . ")";
		$dbo->update($sql);
	}
	else {
		$sql = "UPDATE tblmembershiplevels SET nDisplayFront=0";
		$dbo->update($sql);
	}
	

	
	foreach ($_POST as $key=>$value) {
		if (substr($key, 0, 7) == 'sLevel_') {
			$sql = "UPDATE tblmembershiplevels SET sLevel='" . $value . "' WHERE nLevel_ID=" . substr($key, 7);
			$dbo->update($sql);
		}
	}
	}

if(isset($_GET['id']) && isset($_GET['order'])){
	order_rows($_GET['id'],$_GET['order']);
	
	global $dbo;
	//test if there is any order set up	
	$result=$dbo->select("SELECT COUNT(nLevel_ID) as nr FROM tblmembershiplevels where nOrder!='0'");
	$check=$dbo->getobj($result);
	
	//the member level i wanna change
	$sql="SELECT nOrder,sLevel FROM  tblmembershiplevels WHERE nLevel_ID='".$dbo->format($_GET['id'])."'" ;
	$rs_=$dbo->select($sql);
	if(!empty($rs_))
		$row_= $dbo->getobj($rs_);	
		
	$my_id=$dbo->format($_GET['id']);
	$my_sLevel=$row_->sLevel;	
	$my_order=$row_->nOrder;
	
	
	if($check->nr!=0)
	{
		$sql="SELECT nLevel_ID,nOrder FROM  tblmembershiplevels WHERE nOrder<'".$my_order."' ORDER BY nOrder ASC , sLevel ASC";
		$sql2="SELECT nLevel_ID,nOrder FROM  tblmembershiplevels WHERE nOrder>'".$my_order."' ORDER BY nOrder ASC , sLevel ASC";	
	}
	else {
		$sql="SELECT nLevel_ID,nOrder FROM  tblmembershiplevels WHERE sLevel<'".$my_sLevel."' ORDER BY nOrder ASC , sLevel ASC";
		$sql2="SELECT nLevel_ID,nOrder FROM  tblmembershiplevels WHERE sLevel>'".$my_sLevel."' ORDER BY nOrder ASC , sLevel ASC";	
	}
	
	$rs_=$dbo->select($sql);
	$rs2_=$dbo->select($sql2);
	
	
	if(!empty($rs_))
		while($row_= $dbo->getobj($rs_))
			$id1[]=$row_->nLevel_ID;
			
		
	if(!empty($rs2_))
		while($row2_= $dbo->getobj($rs2_))
			$id2[]=$row2_->nLevel_ID;		
			
						
	if($_GET['order']=='up'){		
			if(sizeof($id1)!=0)
			foreach ($id1 as $key=>$value){
				//if it is not the last one
				if($key+1!=sizeof($id1))
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".$key."' WHERE nLevel_ID='".$value."'");
				else 
				{
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".$key."' WHERE nLevel_ID='".$my_id."'");
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".($key+1)."' WHERE nLevel_ID='".$value."'");
				}				
			}
			if(sizeof($id2)!=0)
			foreach ($id2 as $key2=>$value2){
			//if it is not the last one				
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".($key+2+$key2)."' WHERE nLevel_ID='".$value2."'");				
			}
			
	}
		
		if($_GET['order']=='down'){	
			if(sizeof($id1)!=0)	
			foreach ($id1 as $key=>$value){				
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".$key."' WHERE nLevel_ID='".$value."'");				
			}
			if(sizeof($id2)!=0)
			foreach ($id2 as $key2=>$value2){
				//if it is the first one
				if($key2==0)
				{
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".($key+1)."' WHERE nLevel_ID='".$value2."'");
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".($key+2)."' WHERE nLevel_ID='".$my_id."'");
				}
				else 
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".($key+2+$key2)."' WHERE nLevel_ID='".$value2."'");
				
			}
			
	}
	}

if($_GET['act'] == 'del' && isset($_GET['id'])){
	
	if($_GET['id'] !='1' or $_GET['id'] !='2'){
		// Delete The Membership Level.
		$sql = "DELETE FROM `tblmembershiplevels` WHERE `tblmembershiplevels`.`nLevel_ID` = ".$dbo->format($_GET['id']).";";
		$dbo->delete($sql);
		
		// Delete All Page Rights Based On This Level.
		
		$sql = "DELETE FROM `tblpagelevels` WHERE `nLevel_ID` = '{$dbo->format($_GET['id'])}'";
		$dbo->delete($sql);
			
	}
	
	

	
	// Check to see if any members are tied to this level
	// select from tbluserlevels where nLevel_ID = $_GET['id']
	
	}
?>
<html>
<head>
    <title>Member Levels</title>
	<?php include ('inc-head.php')?>
	<script type="text/javascript">
		function openPopup(page) {	
				window.open(page,'','height=150,width=700,scrollbars=no,location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=no');
		}
		function openPopup2(page) {	
				window.open(page,'','height=500,width=700,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=yes');
		}
		function toggle(ele1,ele2){
			if(ele1.checked){document.getElementById(ele2).style.display = 'block'}
			else{document.getElementById(ele2).style.display = 'none'}
			}
		function toggle1(ele){
			if(document.getElementById(ele).style.display == 'block'){document.getElementById(ele).style.display = 'none';}
			else{document.getElementById(ele).style.display = 'block';}
			}
		
        </script>
         <?php 
		 if(get_option('use_mce') == '1'){
		 	$doc_base = $chkSsettings->sSiteURL .'/';
			?>
			<script type="text/javascript" src="common/js/tiny_mce/tiny_mce.js"></script>
			<script type="text/javascript" src="common/js/tiny_mce/init.php?folder=<?php echo TEMPLATEFOLDER ?>&base=<?php echo $doc_base  ?>&linktype=r"></script>
   <?php  } ?>  
</head>
<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once 'top.php' ?>
    <table cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once 'settingsleft.php'; ?></td>

            <td width="100%" align="left" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">

                <!-- NAVIGATION -->

                <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td class="navRow1" nowrap="nowrap">Member Levels</td>
                    </tr>
                </table>
                
                <?php echo isset($message) ? $message : '' ?>

                <!-- ADD MEMBER LEVEL -->

                
                    <table class="gridTable" border="0" cellpadding="0" cellspacing="1" width="100%">
                    	<tr>
                            <td class="gridHeader" colspan="2">
                           <a href="#" onClick="toggle1('addMemberLevel');">
                            <img width="16" height="16" border="0" style="vertical-align: middle" alt="Add New Commission" src="images/icon_add.png"> Add New</a></td>
                    	</tr>
						</table>
                        <div id="addMemberLevel" style="display:none;">
                        <form name="form1"  id="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                        <table class="gridTable" border="0" cellpadding="0" cellspacing="1" width="100%">
                        <tr>
                    		<td width="200" class="gridRow1">Level <font color="Red"> * </font> </td>
                    		<td class="gridRow1">
                    				<input type="text" name="sLevel" id="sLevel" class="required"  style="width: 200px;"/>&nbsp;<small>e.g. Bronze</small>
                    		</td>
						</tr>
                    	<tr>
                    	  <td class="gridRow1">Description</td>
                    	  <td class="gridRow1"><label for="sLevelDescription"></label>
                   	      <textarea name="sLevelDescription" id="sLevelDescription" cols="60" rows="5"></textarea></td>
               	      </tr>
                    	<tr>
                    	  <td width="200" valign="top" class="gridRow1">Require Tos?</td>
                    	  <td class="gridRow1"><input name="requireTos" type="checkbox" id="requireTos" onChange="toggle(this,'tosHtmlEditor')" value="1">
                   	        <div id="tosHtmlEditor" style="display:none">Terms Of Service Html <br>
                   	          <label for="tosHtml"></label>
                   	          <textarea name="tosHtml" id="tosHtml" cols="45" rows="5"></textarea>
                   	        </div>
               	          <label for="requireTos"></label></td>
                  	  </tr>
							
					    <tr>
                     		<td colspan="2" class="gridFooter">
                         		<input type="submit" name="add" value="Add Member Level" class="inputSubmitb">
                     		</td>
                		</tr>
                        </table>
                </form>
                </div>
                <!-- Existing Member Level -->
                
                <form name="form2" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <table class="gridTable" border="0" cellpadding="0" cellspacing="1" width="100%">
                <tr>
                	<td class="gridHeader" align="center">Links</td>
                  <td class="gridHeader">Level</td>
                    <td class="gridHeader">Members (active/inactive)</td>
                    <td align="center" class="gridHeader">Order</td>
                    <td class="gridHeader" align="center">Active?</td>
					
               	  <td class="gridHeader" align="center">Display?</td>
                	<td class="gridHeader" align="center">Require Tos?</td>
                    <td class="gridHeader"align="center">View Tos</td>
                    <td align="center" class="gridHeader">Actions</td>
               	  </tr>
             
                <?php
                $sql = "SELECT * FROM tblmembershiplevels ORDER BY nOrder ASC , sLevel ASC";
                $result = $dbo->select($sql);
                $nr_reg=$dbo->num_rows($sql);
			//die(var_dump($result));
                $i=1;
                if ($result!==false) {
                	while($row = $dbo->getobj($result)) {
                	
					
						// Version 3.0
						// Lets get the count of the total members assigned to the member level
						$activecount = $dbo->num_rows('SELECT nUserLevel_ID FROM tbluserlevels WHERE nLevel_ID ='.$row->nLevel_ID.' AND nActive = 1' );
						$inactivecount = $dbo->num_rows('SELECT nUserLevel_ID FROM tbluserlevels WHERE nLevel_ID ='.$row->nLevel_ID.' AND nActive = 0' );
						
                		($row->nActive == '1')?$sActive = '<span class="green">YES</span>':$sActive = '<span class="error">NO</span>';
						($row->nTosRequired == '1')?$nRequireTos = '<span class="green">YES</span>':$nRequireTos = '<span class="error">NO</span>';	
                		($row->nDisplayFront == '1')?$nDisplayFront = '<span class="green">YES</span>':$nDisplayFront = '<span class="error">NO</span>';
							
						 if($row->nLevel_ID == '1'){
							$sDelete = "<a href='#' OnClick=\"alert('Sorry but you cannot delete " . $row->sLevel . " because it is a required level..'); \" >
							<img src='images/dropd.gif' alt='Delete Membership Level' border=''0'/></a>"; 
							 
						}
						 elseif ($activecount + $inactivecount > 0 || $row->nLevel_ID == '1' || $row->nLevel_ID == '2') {
                			$sDelete = "<a href='#' OnClick=\"alert('Sorry but you cannot delete " . $row->sLevel . " because it is already in use, instead, please hide it.'); \" >
							<img src='images/dropd.gif' alt='Delete Membership Level' border=''0'/></a>";
						} 
						else {
                			$sDelete = "<a href='member_levels.php?act=del&id=".$row->nLevel_ID."&delete=" . $row->nPaymentPlan_ID . "' onclick='
							return confirm(\'Are you sure you want to delete this level?"."\n"."This action can not be undone.\')><img src='images/delete.gif'></a>";
            			}?>
                        
                		<tr>
						<td class="gridRow1" align="center">
							<a href="javascript:openPopup('member_level_link.php?level=<?php echo  $row->nLevel_ID ?>)" > <img src="images/chain.jpg" alt="signup links" width="18" height="18" border="0" class="iconspacing"> </a>
							</td>
                		<td class="gridRow1"><a href="edit_member_level.php?id=<?php echo $row->nLevel_ID?>"><?php echo $row->sLevel ?></a></td>
						<td class="gridRow1" ><?php echo intval($activecount) . '/'.intval($inactivecount) ?></td>
						<td class="gridRow1" align="center" width="60px">
						<?php if($i!=1){?>
                			<div style=" float:right;width:30px;"><a href="member_levels.php?id=<?php echo $row->nLevel_ID?>&order=up"><img src="images/icon_arrow_up.png" alt="Up" width="" height="" border="0" /></a></div>
                		<?php }
                			
                		if($i<$nr_reg){ ?>
                			<div style=" float:left;width:30px;"><a href="member_levels.php?id=<?php echo $row->nLevel_ID?>&order=down"><img src="images/icon_arrow_down.png" alt="Down" width="" height="" border="0" /></a></div>
                		<?php }?>
						
						</td>
						<td class="gridRow1" align="center"><?php echo $sActive ?></td>
						
							
						<td class="gridRow1" align="center"><?php echo $nDisplayFront ?></td>
						<td class="gridRow1" align="center"><?php $nRequireTos ?></td>
						
						<?php if($row->sTosHtml != ""){?>
                        <td class="gridRow1" align="center">
                        	<a href="javascript:openPopup2('viewtos.php?id=<?php echo $row->nLevel_ID ?>')"  title="View Current Tos"> View Current Tos</a>
                       </td>
                            <?php }else{?>
                           <td class="gridRow1" align="center">No Tos Defined</td><?php }?>
                			
						<td class="gridRow1"><?php echo $sDelete ?></td>
						</tr>
                		<?php
						// For User Ease and Support, lets make sure the payplan and processor are activly assigned to the level.
						$sql = "SELECT tblpaymentplans.nPaymentProcessor_ID,tblpaymentprocessors.nActive as processorStatus 
						FROM tblpaymentplans 
						INNER JOIN tblpaymentprocessors ON tblpaymentprocessors.nPaymentProcessor_ID = tblpaymentplans.nPaymentProcessor_ID
						WHERE nMembershipLevel_ID = {$row->nLevel_ID} AND tblpaymentplans.nActive = '1'";
						
						$res = $dbo->select($sql);
						
						if(!$dbo->nr($rs)){?>
                        
                        <tr>
                        	<td colspan="9" style="background-color: #FFA8A8; border:thin solid #FF7D7D; color:#FFF;padding:5px;"><strong>Warning:</strong> There is no active payment plan attached to this level. <a href="payment_plans.php?level_id=<?php echo $row->nLevel_ID ?>">Fix This</a></td>
                        </tr>
                        
                        <?php }
						else{
							
							// We have payment plans ....
							// Lets make sure at least one is active.
							
							$count = 0;
							
							while($data = $dbo->getobj($res)){
								if($data->processorStatus == '1') $count ++;break;
								
							}
							
							if($count == 0){?>
                            
                             <tr>
                        	<td colspan="9" style="background-color: #FFA8A8; border:thin solid #FF7D7D; color:#FFF;padding:5px;"><strong>Warning:</strong> There are no active payment processors attached to this level. <a href="payment_processors.php">Fix This</a></td>
                        </tr>
                            
                            
                            <?php }
							
							
						}
						$i++;
                	}
                }
                ?>
                <tr><td class="gridfooter" colspan="11"></td></tr>
                </table>
                </form>

            </td>
        </tr>
    </table><?php include_once 'b.php'; ?>
    <script type="text/javascript">		
		$(document).ready(function()
		{
			$("#form1").validate();
		});
	</script>
</body>
</html>
