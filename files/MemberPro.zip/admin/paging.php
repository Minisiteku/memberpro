<?php
class Paging {
	
	var $Total_Records_Per_Page = 10;
	var $Total_Records;
	var $Total_Pages = 0;
	var $Page_String = "";
	var $CurrentItem;
	var $Script_Filename = '';
	var $Has_Prev_Next = true;
	var $Has_First_Last = false;
	var $Has_Block_Display = true;
	var $Start_Variable = "start";
	var $ParamString = '';
	var $inPageLink = '';
	var $displayPages = 5;

	
	function get_Block_StartPage($blockNumber) {
		return ($blockNumber)*$this->displayPages+1;
	}
	
	function get_CurrentBlock() {
		return ceil($this->CurrentItem/$this->displayPages)-1;
	}
	
	function get_CurrentBlock_StartPage() {
	 	return $this->get_CurrentBlock*$this->displayPages+1;
	}
	
	function get_Page_Navigation() {
		return $this->Page_String;
	}
	
	function get_PageInfo() {
		$totalpages = ($this->Total_Pages == 0) ? '1' : $this->Total_Pages;
		return $this->CurrentItem. ' of ' .$totalpages; 
	}
	
	function get_Page_Start_Item($page_Number) {		
		return $page_Number * $this->Total_Records_Per_Page;
	}
	
	function prepare_ParameterString($KeysandValues) {
		$this->ParamString="";
		if(!empty($KeysandValues))
		{
			if(is_array($KeysandValues))
			{
				foreach($KeysandValues as $ky=>$val)
				{
					$this->ParamString.="&".$ky."=".$val;
				}
			}
			else
			{
				echo "<font face=arial size=2 color=red><b>Please Send Parameters in Array</b></font>";
				die();
			}
		    return $this->ParamString;
		 }
		return;
	}
	
	function set_Start_Item($phpNewValue) {
		$phpNewValue = $phpNewValue/$this->Total_Records_Per_Page;
		$this->CurrentItem = ceil($phpNewValue);
	}
		
	function Create_Paging() {
		
		$this->Total_Pages = ceil($this->Total_Records/$this->Total_Records_Per_Page);
		
		if ($this->Total_Pages <= 1) 	return '';
		if (!empty($this->inPageLink)) $this->inPageLink = '#'.$this->inPageLink;
		
		
		/************************************************/
		/*								 ADD FIRST LAST   										  */
		/************************************************/		
		if ($this->Has_First_Last) {
			// Add First Page Link
			if ($this->CurrentItem > 1) {
				$this->Page_String .= sprintf("<a class='pglnk_unact' href='%s?%s=%d%s%s' title='First Page'>First Page</a>&nbsp;", $_SERVER['PHP_SELF'], $this->Start_Variable, $this->get_Page_Start_Item(0), $this->ParamString, $this->inPageLink);
			} else {
				$this->Page_String .= "First Page&nbsp;";	
			}
		}
			
		// Add Prev Block
		if($this->get_CurrentBlock() > 0) {
			$this->Page_String .= sprintf("<a class='pglnk_unact' href='%s?%s=%d%s%s' title='Previous 5 Pages'>&lt;&lt;</a>&nbsp;", $_SERVER['PHP_SELF'], $this->Start_Variable, $this->get_Page_Start_Item(($this->get_Block_StartPage($this->get_CurrentBlock() - 1))-1), $this->ParamString, $this->inPageLink);
		} else {
			$this->Page_String .= "&lt;&lt;&nbsp;";
		} // End Prev Block
		
		// Current Page > 1 and < Last Page
		if ($this->CurrentItem  > 1 && $this->CurrentItem <= $this->Total_Pages &&  ($this->displayPages <= ($this->Total_Pages - $this->CurrentItem))) {		  		
			$currentblock = (ceil($this->CurrentItem/$this->displayPages)-1)*$this->displayPages+1;
			for ($i=$currentblock; $i<$currentblock+$this->displayPages;$i++) {
				if ($i>0 && $i <= $this->Total_Pages) {		  							  
					if ($this->CurrentItem == $i)
						$this->Page_String.="<font class='pglnk_act'><b>".$i."</b></font> &nbsp;";
					else
						//$Page_String.="<a class='pglnk_unact' href='".$_SERVER['PHP_SELF']."?".$this->Start_Variable."=".$this->get_Page_Start_Item($i - 1).$this->ParamString."#".$this->inPageLink."'>".$i."</a> &nbsp;";
						$this->Page_String .= sprintf("<a class='pglnk_unact' href='%s?%s=%d%s%s' title='Previous 5 Pages'>%s</a>&nbsp;", $_SERVER['PHP_SELF'], $this->Start_Variable, $this->get_Page_Start_Item($i - 1), $this->ParamString, $this->inPageLink, $i);
				}								
			}	
		} 	elseif ($this->CurrentItem == 1) {
			if ($this->Total_Pages > $this->displayPages) 
				$tempCount = $this->displayPages;
			else
				$tempCount = $this->Total_Pages;
			for ($i=1;$i <= $tempCount;$i++) {
				if ($i>0) {
					if ($this->CurrentItem ==$i)
						$this->Page_String.="<font class='pglnk_act'><b>".$i."</b></font> &nbsp;";
					else
						//$Page_String.="<a class='pglnk_unact' href='".$_SERVER['PHP_SELF']."?".$this->Start_Variable."=".$this->get_Page_Start_Item($i - 1).$this->ParamString."#".$this->inPageLink."'>".$i."</a> &nbsp;";
						$this->Page_String .= sprintf("<a class='pglnk_unact' href='%s?%s=%d%s%s' title='Previous 5 Pages'>%s</a>&nbsp;", $_SERVER['PHP_SELF'], $this->Start_Variable, $this->get_Page_Start_Item($i - 1), $this->ParamString, $this->inPageLink, $i);
				}
			}	
		} else {
			$currentblock = (ceil($this->CurrentItem/$this->displayPages)-1)*$this->displayPages+1;
			for ($i=$currentblock; $i<$currentblock+$this->displayPages;$i++) {
				if($i>0 && $i <= $this->Total_Pages) {
					if($this->CurrentItem ==$i)
						$this->Page_String.="<font class='pglnk_act'><b>".$i."</b></font> &nbsp;";
					else
						//$Page_String.="<a class='pglnk_unact' href='".$_SERVER['PHP_SELF']."?".$this->Start_Variable."=".$this->get_Page_Start_Item($i - 1).$this->ParamString."#".$this->inPageLink."'>".$i."</a> &nbsp;";
						$this->Page_String .= sprintf("<a class='pglnk_unact' href='%s?%s=%d%s%s' title='Previous 5 Pages'>%s</a>&nbsp;", $_SERVER['PHP_SELF'], $this->Start_Variable, $this->get_Page_Start_Item($i - 1), $this->ParamString, $this->inPageLink, $i);
				}							
			}
		}
	  	
		if ($this->get_CurrentBlock() < floor($this->Total_Pages/$this->displayPages)) {
			// Add Next Block
			//$Page_String.="<a class='pglnk_unact' href='".$_SERVER['PHP_SELF']."?".$this->Start_Variable."=".$this->get_Page_Start_Item(($this->get_Block_StartPage($this->get_CurrentBlock() + 1))-1).$this->ParamString."#".$this->inPageLink."'>&gt;&gt;</a> &nbsp;";
			$this->Page_String .= sprintf("<a class='pglnk_unact' href='%s?%s=%d%s%s' title='Next 5 Pages'>&gt;&gt;</a>&nbsp;", $_SERVER['PHP_SELF'], $this->Start_Variable, $this->get_Page_Start_Item(($this->get_Block_StartPage($this->get_CurrentBlock() + 1))-1), $this->ParamString, $this->inPageLink);
		} else {
			$this->Page_String .= "&gt;&gt;&nbsp;";
		}
	
		if ($this->Has_First_Last) {
			// Add Last Page Link
			if ($this->CurrentItem < $this->Total_Pages) {
				$this->Page_String .= sprintf("<a class='pglnk_unact' href='%s?%s=%d%s%s' title='Last Page'>Last Page</a>&nbsp;", $_SERVER['PHP_SELF'], $this->Start_Variable, $this->get_Page_Start_Item($this->Total_Pages - 1), $this->ParamString, $this->inPageLink);
			} else {
				$this->Page_String .= "Last Page&nbsp;";	
			}
		}
			
	
		/************************************************/
		/*								 ADD PREVIOUS NEXT										  */
		/************************************************/
		if ($this->Has_Prev_Next) {
			// Add Prev
		  	if ($this->CurrentItem > 1) {
				$Prev_Next = sprintf("<a class='pglnk_unact' href='%s?%s=%d%s%s' title='Previous Page'>&lt;&nbsp;Prev</a>&nbsp;", $_SERVER['PHP_SELF'], $this->Start_Variable, $this->get_Page_Start_Item($this->CurrentItem - 2), $this->ParamString, $this->inPageLink);
			} else {
				$Prev_Next = "&lt;&nbsp;Prev&nbsp;";
			}
			
			// Add Separater
			$Prev_Next .= "|&nbsp;";
				
			// Add Next
		  	if($this->CurrentItem < $this->Total_Pages) {
				$Prev_Next .= sprintf("<a class='pglnk_unact' href='%s?%s=%d%s%s' title='Next Page'>&nbsp;Next&nbsp;&gt;&nbsp;</a>", $_SERVER['PHP_SELF'], $this->Start_Variable, $this->get_Page_Start_Item($this->CurrentItem), $this->ParamString, $this->inPageLink);
		  	} else {
		  		$Prev_Next .= "&nbsp;Next&nbsp;&gt;&nbsp;";
		  	}
		}
	   	   	
	   	// Return Complete Navigation String
	   	return "<span>".$this->Page_String."<span style='padding-left:20px'>".$Prev_Next."</span></span>";
   	
	}  // End Function


}

?>