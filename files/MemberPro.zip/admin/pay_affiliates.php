<?php
include_once('../conn.php');
include_once('../functions.php');

if ($chkSsettings->sCurrencyFormat == 'USD') { $cvalue = '$'; }
if ($chkSsettings->sCurrencyFormat == 'AUD') { $cvalue = 'AUD'; }
if ($chkSsettings->sCurrencyFormat == 'CAD') { $cvalue = 'CAD'; }
if ($chkSsettings->sCurrencyFormat == 'CZK') { $cvalue = 'CZK'; }
if ($chkSsettings->sCurrencyFormat == 'DKK') { $cvalue = 'DKK'; }
if ($chkSsettings->sCurrencyFormat == 'EUR') { $cvalue = '&euro;'; }
if ($chkSsettings->sCurrencyFormat == 'HKD') { $cvalue = 'HKD'; }
if ($chkSsettings->sCurrencyFormat == 'HUF') { $cvalue = 'HUF'; }
if ($chkSsettings->sCurrencyFormat == 'NZD') { $cvalue = 'NZD'; }
if ($chkSsettings->sCurrencyFormat == 'NOK') { $cvalue = 'NOK'; }
if ($chkSsettings->sCurrencyFormat == 'PLN') { $cvalue = 'PLN'; }
if ($chkSsettings->sCurrencyFormat == 'GBP') { $cvalue = 'GBP'; }
if ($chkSsettings->sCurrencyFormat == 'SGD') { $cvalue = 'SGD'; }
if ($chkSsettings->sCurrencyFormat == 'SEK') { $cvalue = 'SEK'; }
if ($chkSsettings->sCurrencyFormat == 'CHF') { $cvalue = 'CHF'; }
if ($chkSsettings->sCurrencyFormat == 'JPY') { $cvalue = '&yen;'; }

$sql = "SELECT * FROM tblaffiliatesettings";
$oAffiliateSettings = $dbo->getobject($sql);

$lastmonth = date('Ym01');
//echo $lastmonth;

// UPDATE ALL COMMISSIONS AS PAID
//=================================

?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php include("inc-head.php"); ?>
		<script language="javascript">
			function confirmAction(sAction) {
				var sName = (sAction == 'paypal') ? 'PayPal' : 'Check';
				if (confirm("Are you sure you want to mark all \""+sName+"\" commissions as paid?\n\nMake sure you have generated the pay file before continuing.\n ")) {
					document.location.replace('pay_affiliates.php?paid='+sAction);
				}
			}	
		</script>
		
<!-- =========Added calendar in order to choose a date range -->
	<link type="text/css" rel="stylesheet" href="calendar/popcalendar.css">
	<script language='javascript' src='calendar/popcalendar.js'></script>
	
			
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once('affiliateleft.php'); ?></td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">

			<table class="navTable" cellpadding="0" cellspacing="0" width="100%">

<?php
//================added for selections based on nDate field
$dtStart = $_GET['dtStart'];
$dtEnd = $_GET['dtEnd'];

if ($_GET['show_unpaid_commissions'] == "") {
	$yStart = date(Y)-1;
    $dtStart = date("m/d/").$yStart;
    $dtEnd = date("m/d/Y");
}
//========================================================
?>

				<tr>
					<td class="navRow1"> Pay Affiliates </td>
					<td class="navRow2" style="color:navy; text-align:right; padding-right:10px">
					Displaying unpaid commissions from <?php echo $dtStart ?> to <?php echo $dtEnd ?></td>
				</tr>
			</table>

<!-- added calendars to select date from to -->
<form action="pay_affiliates.php" method="get">
From: 
<input type="text" id="dtStart" name="dtStart" value="<?php echo $dtStart?>" size="10" />
	<img src="calendar/images/calendar2.gif" border="0" onClick="popUpCalendar(this, document.getElementById('dtStart'), 'mm/dd/yyyy')" style="cursor:pointer;" align="absmiddle" />
 &nbsp; 
To: 	
<input type="text" id="dtEnd" name="dtEnd" value="<?php echo $dtEnd?>" size="10" />
	<img src="calendar/images/calendar2.gif" border="0" onClick="popUpCalendar(this, document.getElementById('dtEnd'), 'mm/dd/yyyy')" style="cursor:pointer;" align="absmiddle" />	

 &nbsp; 
<input type="submit" value=" Show Unpaid Commissions " name="show_unpaid_commissions"/>
</form>
<!-- ========== ========= =========== ========== -->
			
			<span class="red">
				<?php if ($_GET['act'] == 'scheck') { echo "Check Pay File has been generated successfully<br><br>"; } ?>
				<?php if ($_GET['act'] == 'spaypal') { echo "Paypal Pay File has been generated successfully<br><br>"; } ?>
				<?php if ($_GET['act'] == 'snotyet') { echo "Not Known Pay File has been generated successfully<br><br>"; } ?>
				<?php if ($_GET['act'] == 'gsus') { echo "Payments marked as paid<br><br>"; } ?>
			</span>
			
<?php

//================added for selections based on nDate field
$dtStart = explode("/", $dtStart);
$date_start = $dtStart[2] . $dtStart[0] . $dtStart[1];
$date_start_timestamp = $dtStart[2] . "-" . $dtStart[0] . "-" . $dtStart[1] .
    " 00:00:00";

$dtEnd = explode("/", $dtEnd);
$date_end = $dtEnd[2] . $dtEnd[0] . $dtEnd[1];
$date_end_timestamp = $dtEnd[2] . "-" . $dtEnd[0] . "-" . $dtEnd[1] .
    " 23:59:59";
//============================================================    
    

    //Check if paypal is accepted//
    if ($oAffiliateSettings->nPaypal) {
		// Get Total Payments for PayPal
		$sql = "SELECT tblaffiliatepayments.nAffiliate_ID, SUM(tblaffiliatepayments.nCommission) AS amount FROM tblaffiliatepayments 
								INNER JOIN tblusers ON nUser_ID = tblaffiliatepayments.nAffiliate_ID
								WHERE (tblaffiliatepayments.sPaymentStatus = '' OR tblaffiliatepayments.sPaymentStatus IS NULL)
								AND (tblaffiliatepayments.sFilename = '' OR tblaffiliatepayments.sFilename IS NULL)
								AND NOT tblusers.sPaypalEmail = '' 
								AND nDate >= $date_start 
								AND nDate <= $date_end
								GROUP BY tblaffiliatepayments.nAffiliate_ID ";
		$rs = $dbo->select($sql);
		$commission = 0;
		$cnt = 0;
		if ($rs!==false) {
			while ($row = $dbo->getassoc($rs)) {
				$commission += $row['amount'];
				$cnt++;
			}	
		}

?>

	<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
	<tr><td colspan="4" class="gridHeader">Paypal</td></tr>
	<tr>
		<td class="gridHeader" width="25%">Total Payments </td>
		<td class="gridHeader" width="25%">Total Commission</td>
		<td class="gridHeader" width="25%">&nbsp;</td>
	</tr>
	<tr>
		<td class="gridrow2"><?php echo $cnt ?>&nbsp;</td>
		<td class="gridrow2"><?php echo  $cvalue.number_format($commission, 2); ?>&nbsp;</td>
		<?php if ($cnt > 0) { ?>
		<td class="gridrow2" align="center"><a href="pay_affiliates_csv_paypal.php?date_start=<?php echo $date_start?>&date_end=<?php echo $date_end?>"><strong>Generate Pay File</strong></a></td>
		<?php } else { ?>
		<td class="gridrow2" align="center" colspan="2">No unpaid affiliate commisions</td>
		<?php } ?>
	</tr>
    <tr><td colspan="4" class="gridfooter"></td></tr>
	</table>

<?php
    } //End of paypal check
    //Check if payment by checque is available
    if ($oAffiliateSettings->nCheck) {
		// Get Total Payments for Check
		$sql = "SELECT tblaffiliatepayments.nAffiliate_ID, SUM(tblaffiliatepayments.nCommission) AS amount FROM tblaffiliatepayments 
								INNER JOIN tblusers ON nUser_ID = tblaffiliatepayments.nAffiliate_ID
								WHERE (tblaffiliatepayments.sPaymentStatus = '' OR tblaffiliatepayments.sPaymentStatus IS NULL)
								AND (tblaffiliatepayments.sFilename = '' OR tblaffiliatepayments.sFilename IS NULL)
								AND (tblusers.sPaypalEmail IS NULL OR tblusers.sPaypalEmail = '')
								AND nDate >= $date_start 
								AND nDate <= $date_end								
								GROUP BY tblaffiliatepayments.nAffiliate_ID ";
		
		$rs = $dbo->select($sql);
		$commission = 0;
		$cnt = 0;
		if ($rs!==false) {
			while ($row = $dbo->getassoc($rs)) {
				$commission += $row['amount'];
				$cnt++;
			}	
		}
?>
		
	<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
	<tr><td colspan="4" class="gridHeader">Check</td></tr>
	<tr>
		<td class="gridHeader" width="25%">Total Payments </td>
		<td class="gridHeader" width="25%">Total Commission</td>
	
		<td class="gridHeader" width="25%">&nbsp;</td>
	</tr>
	<tr>
		<td class="gridrow2"><?php echo $cnt ?>&nbsp;</td>
		<td class="gridrow2"><?php echo  $cvalue.number_format($commission, 2); ?>&nbsp;</td>
		<?php if ($cnt > 0) { ?>
		<td class="gridrow2" align="center"><a href="pay_affiliates_csv_check.php?date_start=<?php echo $date_start?>&date_end=<?php echo $date_end?>"><b>Generate Pay File</b></a></td>
		<?php } else { ?>
		<td class="gridrow2" align="center" colspan="2">No unpaid affiliate commisions</td>
		<?php } ?>
	</tr>
    <tr><td colspan="4" class="gridfooter"></td></tr>
	</table>
<?php
    } //End of checque 
    if ((!$oAffiliateSettings->nCheck) || (!$oAffiliateSettings->nPaypal)) {
	// Get Total Payments for Unknown Payment Status
	$sql = "SELECT tblaffiliatepayments.nAffiliate_ID, SUM(tblaffiliatepayments.nCommission) AS amount FROM tblaffiliatepayments 
							INNER JOIN tblusers ON nUser_ID = tblaffiliatepayments.nAffiliate_ID
							WHERE (tblaffiliatepayments.sPaymentStatus = '' OR tblaffiliatepayments.sPaymentStatus IS NULL) 
								AND nDate >= $date_start 
								AND nDate <= $date_end							
							AND (tblaffiliatepayments.sFilename = '' OR tblaffiliatepayments.sFilename IS NULL) ";
	//check which payments are accepted not accepted payment methods should be included in Not Yet Known
	if (($oAffiliateSettings->nCheck) && (!$oAffiliateSettings->nPaypal)) {
		$sql .= " AND tblusers.sPaypalEmail IS NOT NULL AND NOT tblusers.sPaypalEmail = '' ";
	} elseif ((!$oAffiliateSettings->nCheck) && ($oAffiliateSettings->nPaypal)) {
		$sql .= " AND (tblusers.sPaypalEmail IS NULL OR tblusers.sPaypalEmail = '') ";
	}
	$sql .=	" GROUP BY tblaffiliatepayments.nAffiliate_ID ";					
	$rs = $dbo->select($sql);
	$commission = 0;
	$cnt = 0;
	if ($rs!==false) {
		while ($row = $dbo->getassoc($rs)) {
			$commission += $row['amount'];
			$cnt++;
		}	
	}
?>
	  
	<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
	<tr><td colspan="4" class="gridHeader">Not Yet Known</td></tr>
	<tr>
		<td class="gridHeader" width="25%">Total Payments </td>
		<td class="gridHeader" width="25%">Total Commission</td>
		<td class="gridHeader" width="25%">&nbsp;</td>
		<td class="gridHeader" width="25%">&nbsp;</td>
	</tr>
	<tr>
		<td class="gridrow2"><?php echo $cnt ?>&nbsp;</td>
		<td class="gridrow2"><?php echo  $cvalue.number_format($commission, 2); ?>&nbsp;</td>
		<td class="gridrow2" align="center">N/A</td>
		<td class="gridOptions1" align="center">N/A</td>
	</tr>
    <tr><td colspan="4" class="gridfooter"></td></tr>
	</table>
        
		</td>
    </tr>
    <?php } ?>
</table>
<?php include_once('b.php'); ?>
	</body>
</html>