<?php
	include_once ('../conn.php');
	include_once ('../functions.php');
	
	$now = time();
	$sFilename = "paypal-masspay-" . date("Ymd") . "-{$now}.txt"; // file name for CSV
	$lastmonth = date('Ym01');
	
	//=======added to get the select period =====================
	$date_start = $_GET['date_start'];
	$date_end = $_GET['date_end'];
	//===========================================================
	
	// Get Total Payments for PayPal
	$sql = sprintf("SELECT tblaffiliatepayments.nAffiliate_ID, 
	SUM(tblaffiliatepayments.nCommission) AS amount,
	tblusers.sForename, 
	tblusers.sSurname, 
	tblusers.sPaypalEmail
	FROM tblaffiliatepayments 
	INNER JOIN tblusers ON nUser_ID = tblaffiliatepayments.nAffiliate_ID
	WHERE (tblaffiliatepayments.sPaymentStatus = '' OR tblaffiliatepayments.sPaymentStatus IS NULL)
	AND tblusers.sPaypalEmail IS NOT NULL 
	AND NOT tblusers.sPaypalEmail = '' 
	AND (sFileName = '' OR sFileName IS NULL)
	AND UNIX_TIMESTAMP(nTimeStamp) <= %s
	AND nDate >= $date_start 
	AND nDate <= $date_end							
	GROUP BY tblaffiliatepayments.nAffiliate_ID, tblusers.sPaypalEmail, tblusers.sForename, tblusers.sSurname ",$now);
	$rs = $dbo->select($sql);
	
	$csv = '';
	if ($dbo->nr($rs) > 0) {
		while ($row = $dbo->getassoc($rs)) {
			$csv .= sprintf("%s\t%.2f\t%s\t%s\t%s\n", $row['sPaypalEmail'], $row['amount'],$chkSsettings->sCurrencyFormat, str_ireplace(' ', '_', $row['sForename'] . ' ' .$row['sSurname']), $note);
		}

		$sql = sprintf("UPDATE tblaffiliatepayments SET sFileName = '%s' 
		WHERE tblaffiliatepayments.nAffiliate_ID IN ( SELECT nUser_ID 
		FROM tblusers 
		WHERE tblusers.sPaypalEmail IS NOT NULL 
		AND NOT tblusers.sPaypalEmail = '')
		AND (tblaffiliatepayments.sPaymentStatus = '' OR tblaffiliatepayments.sPaymentStatus IS NULL)
		AND nDate >= $date_start 
		AND nDate <= $date_end								  
		AND (sFileName = '' OR sFileName IS NULL)
		AND UNIX_TIMESTAMP(nTimeStamp) <= %s", $sFilename, $now);
		$rs = $dbo->select($sql);
		header('Content-type:text/csv');
		header('Content-disposition:attachment;filename=' . $sFilename);
		echo $csv;
		exit();
	}
	else {header("Location: pay_affiliates.php");}
?>