<?php
include_once '../conn.php';
include_once '../functions.php';

// Update Payment Plans
if (isset($_POST['update'])) {
//die(var_dump($_POST));
    // Update coupon link
    foreach ($_POST as $key => $value) {
        if (substr($key, 0, 11) == 'nCoupon_ID_') {
            $sql = "UPDATE tblpaymentplans SET nCoupon_ID = $value WHERE nPaymentPlan_ID = " .substr($key, 11);
            $dbo->update($sql);
        }
    }

    
	#######################################################################################################
	// This will just update the status (active/deactive)
    if (is_array($_POST['chkExistingPlan'])) {
        $values = implode(",", $_POST['chkExistingPlan']);
    } 
	else {$values = 9999;}

    // Update unchecked boxes
    $sql = "UPDATE tblpaymentplans SET nActive=0 WHERE nPaymentPlan_ID NOT IN (" . $values .") ";
	if($_GET['level_id']){$sql .="AND nMembershipLevel_ID=" . $dbo->format($_GET['level_id']).";";}
	$dbo->update($sql);

    // Update checked boxes
    $sql = "UPDATE tblpaymentplans SET nActive=1 WHERE nPaymentPlan_ID IN (" . $values .") ";
	if($_GET['level_id']){$sql .="AND nMembershipLevel_ID=" . $dbo->format($_GET['level_id']).";";}
	
    $dbo->update($sql);
	###########################################################################################################3

    $message = '<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>The payment plans were updated successfully</div>';}

// Delete Payment Plans
if (isset($_GET['delete'])) {


    $sql = "DELETE FROM tblpaymentplans WHERE nPaymentPlan_ID=" . $_GET['delete'];
    $dbo->update($sql);

    $message = '<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>The payment plan was deleted successfully.</div>';}

$sql = "SELECT tblpaymentplans.*, tblpaymentprocessors.sProcessorName, tblpaymentprocessors.nActive as processorStatus FROM tblpaymentplans " .
        "INNER JOIN tblpaymentprocessors on tblpaymentprocessors.nPaymentProcessor_ID = tblpaymentplans.nPaymentProcessor_ID";
		
	if(isset($_GET['level_id'])){$sql .= ' WHERE tblpaymentplans.nMembershipLevel_ID='. $dbo->format($_GET['level_id']);}
		
        $sql .= ' ORDER BY sPlanName';
//die($sql);
    $plans = $dbo->select($sql);
?>

<html>
<head>
    <title><?php echo $admintitle; ?></title>
   	<?php include ('inc-head.php') ?>
   	<script language="javascript" type="text/javascript">
   	function changeLevel() {
   	   	var nLevel_ID = document.getElementById('nLevel_ID').value;
   	   	if (nLevel_ID != '') {
   	   	   	document.location.href = 'payment_plans.php?level_id=' + nLevel_ID;
   	   	}
		else{document.location.href = 'payment_plans.php';}
   	}
   		
	function cdel(w) {
		return confirm("Are you sure you want to DELETE the\n\""+w+"\" payment plan?");
}
function openPopup(page) {	
				window.open(page,'','height=150,width=700,scrollbars=no,location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=no');
		}

   	</script>
</head>

<body leftmargin="0" topmargin="0" rightmargin="0">
    <?php include_once 'top.php'; ?>

    <table cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
			<?php include_once'settingsleft.php'; ?></td>

            <td width="100%" align="left" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">

                <!-- NAVIGATION -->

                <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td class="navRow1" nowrap="nowrap">Payment Plans</td>
                    </tr>
                </table>

				<?php echo $message ?><!-- PAYMENT OPTIONS -->
                
                <!-- Existing Payment Plans -->
                
                <form name="form1" method="post" action="">
                
                <table class="gridTable" border="0" cellpadding="0" cellspacing="1" width="100%">
                <tr>
                  <td class="gridHeader"> <a href="payment_plans_add.php"><img src="images/icon_add.png" width="16" height="16" alt="Add New Commission" border="0" style="vertical-align: middle"> Add New</a> | Show Payment Plans For
                    <select name="nLevel_ID" id="nLevel_ID" onChange="changeLevel();">
                <option value="">Every</option>
                      <?php
$sql = "SELECT nLevel_ID, sLevel FROM tblmembershiplevels WHERE nActive=1 ORDER BY `nOrder` ASC";
$result = $dbo->select($sql);
while ($objLevel = $dbo->getobj($result)) {
    if (isset($_GET['level_id']) && $_GET['level_id'] == $objLevel->nLevel_ID) {
        echo '<option value="' . $objLevel->nLevel_ID . '" selected>' . $objLevel->
            sLevel . '</option>';
    } else {
        echo '<option value="' . $objLevel->nLevel_ID . '">' . $objLevel->sLevel .
            '</option>';
    }
}
?>
                    </select> 
                    Membership                  </td></tr>
                </table>
                </form>
                
                <br />
                <form name="form2" method="post" action="<?php echo $_SERVER['PHP_SELF'] .
'?' . $_SERVER['QUERY_STRING']; ?>">
                  <table class="gridTable" border="0" cellpadding="0" cellspacing="1" width="100%">
	                <tr>
	                	<td class="gridHeader">Links</td>
	                	<td class="gridHeader">Plan Name</td>
                        <td class="gridHeader">Member Count</td>
	                	<td class="gridHeader" width="300">Processor</td>
						<td class="gridHeader" width="300">Promotion Method</td>	
	                	<td class="gridHeader" width="100" align="center">Active?</td>
	                	<td class="gridHeader" width="100" align="center">Actions</td>
	                </tr>
	                <?php
    
    if ($plans !== false) {
		while ($row = $dbo->getobj($plans)) {
            //==============added for "delete plan option"
            $query_usedPlan = "SELECT COUNT(*) FROM tbluserlevels WHERE nPaymentPlan_ID=" .$row->nPaymentPlan_ID;
			$memcount = $dbo->getval($query_usedPlan);
			$query_usedPlan = "SELECT COUNT(*) FROM tbluserlevels WHERE nPaymentPlan_ID=" .$row->nPaymentPlan_ID." AND nActive = 0;";
			$memcountIA = $dbo->getval($query_usedPlan);
			//var_dump($usedPlan);
			
			if($row->nPaymentPlan_ID == '1'){
				$sDelete = "<a href='#' OnClick=\"alert('Sorry but you cannot delete " . $row->sPlanName . " because it is required by the system.'); \" >
				<img src='images/dropd.gif' alt='Delete Plan' border=''0'/></a>";
			}
			elseif ($memcount > 0) {
                $sDelete = "<a href='#' OnClick=\"alert('Sorry but you cannot delete " . $row->sPlanName . " because it is already in use, instead, please hide it.'); \" >
				<img src='images/dropd.gif' alt='Delete Plan' border=''0'/></a>";
            }
			else {
                $sDelete = "<a href='payment_plans.php?level_id=" . $_GET['level_id'] ."&delete=" . $row->nPaymentPlan_ID . "' OnClick=\"return cdel('" . $row->sPlanName . "');\" >
				<img src='images/drop.jpg' alt='Delete Plan' border=''0'/></a>";
            }

            //=============================================

            if ($row->nActive == '1')
                $sActive = '<input type="checkbox" name="chkExistingPlan[]" value="' . $row->nPaymentPlan_ID . '" checked>';
            else
                $sActive = '<input type="checkbox" name="chkExistingPlan[]" value="' . $row->nPaymentPlan_ID . '">';
			?>	

            <tr>
			<td class="gridRow1" align="center">
			<a href="javascript:openPopup('payment_plan_link.php?id=<?php echo $row->nPaymentPlan_ID ?>')" > <img src="images/chain.jpg" alt="signup links" width="18" height="18" border="0" class="iconspacing"> </a>
			</td>
            <td class="gridrow2"><a href="payment_plans_details.php?id=<?php echo $row->nPaymentPlan_ID ?>"><?php echo $row->sPlanName ?></a></td>
            <td class="gridrow2" align="center"><strong><span class="green"><?php echo ($memcount - $memcountIA) ?></span>/<span class="red" ><?php echo $memcountIA?><span></strong></td>
			<td class="gridrow2"><?php echo $row->sProcessorName ?></td>
            <td class="gridrow2">
			<select name="nCoupon_ID_<?php echo $row->nPaymentPlan_ID ?>">
            <option value="NULL">Public</option>
            <?php
            $sql = "SELECT * FROM tblcoupons WHERE bActive=1 ORDER BY sCouponCode";
            $result1 = $dbo->select($sql);
            if ($result1) {
                while ($row1 = $dbo->getobj($result1)) {
                    if ($row1->nCoupon_ID == $row->nCoupon_ID) {
                        echo '<option value="' . $row1->nCoupon_ID . '" selected="selected">Coupon -' . $row1->
                            sCouponCode . '</option>';
                    } else {
                        echo '<option value="' . $row1->nCoupon_ID . '">Coupon -' . $row1->sCouponCode .
                            '</option>';
                    }
                }
            }
            ?>
			</select>
			</td>
            <td class="gridrow2" align="center"><?php echo $sActive ?></td>
            <td class="gridrow2" align="center"><?php echo $sDelete ?></td>
        </tr>
        <?php 
		
		// Lets make sure that the payment processor is still active.
		if($row->processorStatus == '0'){?>
        <tr>
        	<td colspan="7" class="gridrow2"><div class="notify-warning"><strong>Warning:</strong> The payment processor for this plan is inactive. <a href="payment_processors.php">Fix This</a></div></td>
        </tr>
        <?php }
		
		
		
		} ?>
        <tr>
        	<td class="gridFooter" colspan="11">
			<input type="submit" name="update" value="Update Payment Plans" class="inputSubmitb">
            </td>
       </tr>
    <?php } ?>
</table>
</form>
	                
	              
	                
            </td>
        </tr>
    </table>
<?php include_once 'b.php'; ?>
</body>
</html>