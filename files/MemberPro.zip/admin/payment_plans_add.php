<?php
include_once '../conn.php';
include_once '../functions.php';

// Set sessions
if ( isset($_GET['id']) && is_numeric($_GET['id']) ) {
	
	$_SESSION['nPaymentProcessor_ID'] = $dbo->format($_GET['id']);
	
	$objProcessor = $dbo->getobject("SELECT * FROM tblpaymentprocessors WHERE nPaymentProcessor_ID=" . $_SESSION['nPaymentProcessor_ID']);
	
	if($objProcessor->sProcessorName == 'Free'){$_SESSION['sPaymentPlanType'] = 'free';}
	else{unset($_SESSION['sPaymentPlanType']);}
	}
if ( isset($_GET['sPaymentPlanType']) && strlen($_GET['sPaymentPlanType']) < 10 ) {$_SESSION['sPaymentPlanType'] = $dbo->format($_GET['sPaymentPlanType']);}

// Reset
if (isset($_GET['action']) && $_GET['action'] == 'reset') {
	unset($_SESSION['nPaymentProcessor_ID']);
	unset($_SESSION['sPaymentPlanType']);
	unset($_SESSION['form']);
	
	}
//die(var_dump($_POST));
// Add Payment Plan
if ( isset($_POST['add']) ) {
	$bError = false;
	$success = 0;
	//die(var_dump($_POST));
	// Lets Perform Some Validation. Shouldnt depend on javascript only.
	
	// Everything Needs A Plan Name ...
	$plan_type = $_POST['plan_type'];
	$nAmount = number_format($_POST['nAmount'],2);
	//$nAmount = (float)$nAmount;
	
	$minamount = (float)number_format('0.01');
	//die(var_dump($minamount));
	//die(var_dump($nAmount));
	if($plan_type != 'free'){
		// Start With Minimum Requirements
		// Amount Must Be Greater Than 0.00
		if($nAmount == number_format(0.00,2)){
			if($plan_type == 'onetime'){$errormsg['nAmount'] = 'Payment Cannot Be Free. Use the Free Payment Processor For Free Access.';}
			else{$errormsg['nAmount'] = 'Regular Payment Cannot Be Free.';}
			$bError = true;
			}
		
		
		//One Time Payments
		
		
		
		// Check Recurring.
		
		
		
		
		}
	
	if($bError === true){
		foreach($_POST as $k=>$v){$_SESSION['form']['data'][$k] = $v;}
		foreach($errormsg as $k=>$v){$_SESSION['form']['errormsg'][$k] = $v;}
		header("Location:?err=Please Correct The Following Errors Below");exit;
		}
	
	// No Errors Lets Continue 
	
	
	
	if ($plan_type == 'free') {
		
		$sql = "INSERT INTO tblpaymentplans (
		nPaymentProcessor_ID,
		sPlanName,
		sItemNumber,
		nRegularAmount,
		nTrialAmount1,
		nTrialAmount2,
		nRegularPeriod,
		sRegularPeriod,
		nTrial1Period,
		sTrial1Period,
		nTrial2Period,
		sTrial2Period,
		nOneTimePayment,
		nActive,
		nMembershipLevel_ID
		) VALUES (" . 
		$dbo->format($_POST['nPaymentProcessor_ID']) . ", '" .
		$dbo->format($_POST['sPlanName']) . "', '" .
		$dbo->format($_POST['sItemNumber']) . "' ,
		0,
		0,
		0,
		'".$dbo->format($_POST['nExpirePeriod'])."',
		'".$dbo->format($_POST['sExpirePeriod'])."',
		0,
		'',
		0,
		'', 
		1,
		1," .
		$dbo->format($_POST['nLevel_ID']) . " 
		)";
	
		$success = $dbo->insert($sql);
		
	} 
	elseif ($plan_type == 'recurring') {
	
		// Insert Row For Recurring Plan
		
		if (isset($_POST['nTrial1Amount']) && is_numeric($_POST['nTrial1Amount'])) {
			$trialamt1 = $dbo->format($_POST['nTrial1Amount']);
		} else {
			$trialamt1 = 0;
		}
			
		if (isset($_POST['nTrial2Amount']) && is_numeric($_POST['nTrial2Amount'])) {
			$trialamt2 = $dbo->format($_POST['nTrial2Amount']);
		} else {
			$trialamt2 = 0;
		}
		
		if (isset($_POST['nTrial1Period']) && is_numeric($_POST['nTrial1Period'])) {
			$trial1period = $dbo->format($_POST['nTrial1Period']);
		} else {
			$trial1period = 0;
		}
		
		if (isset($_POST['nTrial2Period']) && is_numeric($_POST['nTrial2Period'])) {
			$trial2period = $dbo->format($_POST['nTrial2Period']);
		} else {
			$trial2period = 0;
		}
		
		$sql = "INSERT INTO tblpaymentplans (
		nPaymentProcessor_ID,
		sPlanName,
		sItemNumber,
		nRegularAmount,
		nTrialAmount1,
		nTrialAmount2,
		nRegularPeriod,
		sRegularPeriod,
		nTrial1Period,
		sTrial1Period,
		nTrial2Period,
		sTrial2Period,
		nOneTimePayment,
		nActive,
		nMembershipLevel_ID,
		nRecurTimes,
		nZooFunnel
		) VALUES (" . 
		$dbo->format($_POST['nPaymentProcessor_ID']) . ", '" .
		$dbo->format($_POST['sPlanName']) . "', '" .
		$dbo->format($_POST['sItemNumber']) . "', '" .
		$dbo->format($_POST['nAmount']) . "', '" .
		$trialamt1 . "', '" .
		$trialamt2 . "', " .
		$dbo->format($_POST['nRegularPeriod']) . ", '" .
		$dbo->format($_POST['sRegularPeriod']) . "', " .
		$trial1period . ", '" .
		$dbo->format($_POST['sTrial1Period']) . "', " .
		$trial2period . ", '" .
		$dbo->format($_POST['sTrial2Period']) . "',
		0,
		1," .
		$dbo->format($_POST['nLevel_ID']) . ", " .
		$dbo->format($_POST['nRecurTimes']) . ",
		'".$dbo->format($_POST['nZooFunnel'])."'
		)";
		//die($sql);		
		$success = $dbo->insert($sql);
	}	
	
	// Insert Row for One Time Only plan
	else {
		
		
		$sql = "INSERT INTO tblpaymentplans (
		nPaymentProcessor_ID,
		sPlanName,
		sItemNumber,
		nRegularAmount,
		nTrialAmount1,
		nTrialAmount2,
		nRegularPeriod,
		sRegularPeriod,
		nTrial1Period,
		sTrial1Period,
		nTrial2Period,
		sTrial2Period,
		nOneTimePayment,
		nActive,
		nMembershipLevel_ID,
		nZooFunnel
		) VALUES (" . 
		$dbo->format($_POST['nPaymentProcessor_ID']) . ", '" .
		$dbo->format($_POST['sPlanName']) . "', '" .
		$dbo->format($_POST['sItemNumber']) . "' , '" .
		$dbo->format($_POST['nAmount']) . "',
		0,
		0,
		".$dbo->format($_POST['nExpirePeriod']).",
		'".$dbo->format($_POST['sExpirePeriod'])."',
		0,
		'',
		0,
		'', 
		1,
		1," .
		$dbo->format($_POST['nLevel_ID']) . ",
		'".$dbo->format($_POST['nZooFunnel'])."')";
		$success = $dbo->insert($sql);
	
	}
	
	if($success){
		unset($_SESSION['nPaymentProcessor_ID']);
		unset($_SESSION['sPaymentPlanType']);
		unset($_SESSION['form']);
		
		pluginClass::action("payment_plan_Added",$success);
		
		header("Location:payment_plans.php?level_id={$dbo->format($_POST['nLevel_ID'])}&msg=Payment plan added successfully");exit;
		}
	$message = '<p class="error">'.$dbo->error.'</p>';
}
?>

<html>
<head>
    <title><?php echo $admintitle; ?></title>
   	<?php include ('inc-head.php')?>
    <script language="javascript">
    
    	function getProcessorOptions(id) {
    		document.location.href='payment_plans_add.php?id=' + id;
    	}
    	
    	function updatePlanType(id) {
    		
    		var sPaymentPlanType='';
    		
    		if(id==1) {
    			sPaymentPlanType = "recurring";
    		}
    		else if(id==3) {
        		sPaymentPlanType = "free";
    		}
    		else {
    			sPaymentPlanType = "onetime";
    		}
    		
    		document.location.href='payment_plans_add.php?sPaymentPlanType=' + sPaymentPlanType;
    		
    	}
    </script>
</head>

<body leftmargin="0" topmargin="0" rightmargin="0">
    <?php include_once 'top.php'; ?>
<div style="clear:both"></div>
    <table cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
			<?php include_once 'settingsleft.php'; ?></td>

            <td width="100%" align="left" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">

                <!-- NAVIGATION -->

                <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td class="navRow1" nowrap="nowrap">Payment Plans</td>
                    </tr>
                </table>
                
                <?php echo isset($message) ? $message : '' ?>

                <!-- PAYMENT OPTIONS -->
				<?php 
				// We need to load the form to a variable so we can filter it with plugin class
				ob_start();
				?>
                <form name="form1" id="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                    <table class="gridtable" border="0" cellpadding="0" cellspacing="1" width="100%">
                    	<tr>
                            <td class="gridheader" colspan="2">Add New Payment Plan</td>
                    	</tr>
                    	<tr>
                    		<td class="gridrow2" width="200">Processor</td>
                    		<td class="gridrow2">
                    		<select name="nPaymentProcessor_ID" onChange="getProcessorOptions(this.options[this.selectedIndex].value)" style="width: 200px;"> 
                    		<option value="">Please choose a processor</option>
                    			<?php
                    				$sql = "SELECT nPaymentProcessor_ID, sProcessorName FROM tblpaymentprocessors WHERE nActive=1 ORDER BY sProcessorName";
                    				$result = $dbo->select($sql);
                    				while($row = $dbo->getobj($result))
                    				{
                    					if (isset($_SESSION['nPaymentProcessor_ID']) && $_SESSION['nPaymentProcessor_ID']==$row->nPaymentProcessor_ID) {
                    						echo '<option value="' . $row->nPaymentProcessor_ID . '" selected>' . $row->sProcessorName . '</option>';
                    					} else {
                    						echo '<option value="' . $row->nPaymentProcessor_ID . '">' . $row->sProcessorName . '</option>';
                    					}
                    					
                    				}
                    			?>
                    		</select> 
                    		&nbsp; <img src="images/reset.png" alt="Reset" align="absmiddle" /> <a href="payment_plans_add.php?action=reset">Reset Options</a>
                    		</td>
						</tr>
						<?php 
						if(isset($_SESSION['nPaymentProcessor_ID']) && !isset($_SESSION['sPaymentPlanType']))
						{
							// Is this a free payment processor?
							// Free Processor Plan Type Assigned In Head.
							$sql = "SELECT sProcessorName FROM tblpaymentprocessors WHERE nPaymentProcessor_ID = " . $_SESSION['nPaymentProcessor_ID'];
							$sProcessorName = $dbo->getval($sql);
							if ($sProcessorName != 'Free') {
						?>
							<tr>
	                    		<td class="gridrow2" width="200">Payment Plan Type</td>
	                    		<td class="gridrow2">
	                    		<input type="radio" name="sPaymentPlanType" value="recurring" onClick="updatePlanType(1)"> Recurring <input type="radio" name="sPaymentPlanType" value="onetime" onClick="updatePlanType(2)"> 
	                    		One Time Payment</td>
							</tr>
						<?php
							} 
						}
						
						if(isset($_SESSION['nPaymentProcessor_ID']) && isset($_SESSION['sPaymentPlanType'])){
							
							// Were All Set. Lets Start With The Options Page.
							$sql = "SELECT sProcessorName FROM tblpaymentprocessors WHERE nPaymentProcessor_ID = " . $_SESSION['nPaymentProcessor_ID'];
							$sProcessorName = $dbo->getval($sql);
							$sPaymentPlanType = $_SESSION['sPaymentPlanType'];
							
							$currency_symbol = get_currency_symbol($chkSsettings->sCurrencyFormat);
							
							if($sPaymentPlanType == 'free'){$nameexample = '(e.g. Free Account)';}
							elseif($sPaymentPlanType == 'onetime'){$nameexample = '(e.g. $97 One Time Only)';}
							else{$nameexample = '(e.g. Free 7 Day Trial then $47/Month)';}
							
							
							
							?>
                            <tr>
								<td class="gridrow2">Plan Name <font style="color:red"> * </font></td>
								<td class="gridrow2">
									<input name="sPlanName" class="required" style="width: 200px;" value="<?php echo $_SESSION['form']['data']['sPlanName'] ?> " />
							  <label for="sItemNumber" class="error" style="display: none"><br>You Must Enter A Plan Name</label></td>
					  </tr>
                      
                      <?php 
					  if($sPaymentPlanType !='free'){?>
					  <tr id="productNumber">
						  <td class="gridrow2"><?php echo $sProcessorName; ?> Product Number <font style="color:red"> * </font></td>
						  <td class="gridrow2"><input name="sItemNumber" class="required" id="sItemNumber" style="width: 200px;" value="<?php echo $objPaymentPlan->sItemNumber ?>" remote="ajax/functions.php?act=check_itemnumber&nPaymentPlan_ID=<?php echo $objPaymentPlan->nPaymentPlan_ID?>&sCurrentNum=<?php echo $objPaymentPlan->sItemNumber ?>" />
						    
						    <small>(This will uniquely identify your product in <?php echo $sProcessorName; ?>)</small><br>
<label for="sItemNumber" class="error" style="display: none">This item number is already in use for this processor</label></td>
					  </tr>
                      <?php if($sProcessorName == 'JvZoo'){?>
                      <?php } ?>
                      <tr id="paymentSchedule">
                          <td class="gridheader" colspan="2">Payment Schedule</td>
                          </tr> 
                          
                          <?php
						  // Display different options for recurring/one time
						if ($sPaymentPlanType == 'onetime') {
						?>
								<tr>
									<td colspan="2" class="gridrow2">
										One Time Payment Of <?php echo $currency_symbol ?>
									<input name="nAmount" value="<?php echo number_format($_SESSION['form']['data']['nAmount'],2) ?>" maxlength="10" style="width: 60px;" class="number required">  <?php echo $chkSsettings->sCurrencyFormat ?> <?php echo $_SESSION['form']['errormsg']['nAmount'] ?></td>
								</tr>
                            <?php }
						else{ ?>
                                <tr>
                                  <td  class="gridrow2"><p>
                                    <input name="bTrial1" type="checkbox" id="bTrial1" value="1" <?php echo ($_SESSION['form']['data']['nTrial1Period'] > 0)?'checked':'' ?>>
                                    <label for="bTrial1"></label>
Use Trial Period?</p></td>
                                  <td  class="gridrow2">
                                    <div>&nbsp;<?php echo $currency_symbol ?>
                                      <input name="nTrialAmount1" value="<?php echo number_format($_SESSION['form']['data']['nTrialAmount1'],2) ?>" maxlength="10" style="width: 60px;" class="number">
                                      <?php echo $chkSsettings->sCurrencyFormat ?> For The First
                                      <input name="nTrial1Period" value="<?php echo $_SESSION['form']['data']['nTrial1Period'] ?>" maxlength="10" style="width: 50px;" class="digits">
                                      <select name="sTrial1Period" style="width: 200px;">
                                        <option value="Days" <?php if($_SESSION['form']['data']['sTrial1Period']=='Days') echo ' selected' ?>>Days</option>
                                        <?php if($sProcessorName != 'JvZoo'){ ?>
                                        <option value="Weeks" <?php if($_SESSION['form']['data']['sTrial1Period']=='Weeks') echo ' selected' ?>>Weeks</option>
                                        <option value="Months" <?php if($_SESSION['form']['data']['sTrial1Period']=='Months') echo ' selected' ?>>Months</option>
                                        <option value="Year" <?php if($_SESSION['form']['data']['sTrial1Period']=='Year') echo ' selected' ?>>Years</option>
                                        <?php } ?>
                                      </select>
                                    </div>
                                    </td>
                                </tr>
                                 <?php if($sProcessorName == 'Paypal'){ ?>
                                <tr>
                                  <td class="gridrow2"><p>
                                    <input name="bTrial" type="checkbox" id="bTrial" value="1" <?php echo ($objPaymentPlan->nTrial2Period > 0)?'checked':'' ?>>
                                    <label for="bTrial"></label>
Second Trial Period?</p></td>
                                  <td class="gridrow2"><div>&nbsp;<?php echo $currency_symbol ?>
                                    <input name="nTrialAmount2" value="<?php echo number_format($_SESSION['form']['data']['nTrialAmount2'],2) ?>" maxlength="10" style="width: 60px;" class="number"/>
                                    <?php echo $chkSsettings->sCurrencyFormat ?> For The Next
                                    <input name="nTrial2Period2" value="<?php echo $_SESSION['form']['data']['nTrial2Period2'] ?>" maxlength="10" style="width: 50px;" class="digits">
  <select name="sTrial2Period2" style="width: 200px;">
    <option value="Days" <?php if($_SESSION['form']['data']['sTrial1Period']=='Days') echo ' selected' ?>>Days</option>
    <option value="Weeks" <?php if($_SESSION['form']['data']['sTrial1Period']=='Weeks') echo ' selected' ?>>Weeks</option>
    <option value="Months" <?php if($_SESSION['form']['data']['sTrial1Period']=='Months') echo ' selected' ?>>Months</option>
    <option value="Year" <?php if($_SESSION['form']['data']['sTrial1Period']=='Year') echo ' selected' ?>>Years</option>
  </select>
                                  </div></td>
                                </tr> 
									<?php } ?>
						<?php
						 ?>
						
								<tr>
									<td class="gridrow2"><input name="regular" type="checkbox" id="regular" checked disabled>
									  <label for="checkbox"></label>
								    Regular Schedule <font style="color:red"> * </font></td>
									<td class="gridrow2">
										<?php echo $currency_symbol ?> <input name="nAmount" value="<?php echo number_format($_SESSION['form']['data']['nAmount'],2) ?>" maxlength="10" style="width: 60px;" class="number required">
										<?php echo $chkSsettings->sCurrencyFormat ?> Every
                                        <input name="nRegularPeriod" value="<?php echo $_SESSION['form']['data']['nRegularPeriod'] ?>" maxlength="10" style="width: 50px;" class="digits required"> <select name="sRegularPeriod" style="width: 200px;" class="required">
                                        <option value="Months" <?php if($_SESSION['form']['data']['sRegularPeriod']=='Months') echo ' selected' ?>>Months</option>
										 <?php if($sProcessorName != 'JvZoo'){ ?> 
										 <option value="Days" <?php if($_SESSION['form']['data']['sRegularPeriod']=='Days') echo ' selected' ?>>Days</option>
										  <option value="Weeks" <?php if($_SESSION['form']['data']['sRegularPeriod']=='Weeks') echo ' selected' ?>>Weeks</option>
										  
										  <option value="Year" <?php if($_SESSION['form']['data']['sRegularPeriod']=='Year') echo ' selected' ?>>Years</option>
										 <?php } ?>
                                        
                                        
									    </select> 
										For 
										<input name="nRecurTimes" 
                                        value="<?php echo $_SESSION['form']['data']['nRecurTimes']; ?>" 
                                        maxlength="10" style="width: 50px;" class="digits required">
                                        	<span id="RecurPeriod"><?php echo ($sProcessorName == 'JvZoo')?'Months':'Periods' ?> </span>
											<?php 
											echo ($sProcessorName == 'JvZoo')?' (36 Max)':'Use 0 for Unlimited';
											echo ($_SESSION['form']['errormsg']['nAmount'])?'<span class="error">'.$_SESSION['form']['errormsg']['nAmount'].'</span>':'' ?></td>
								</tr>
								
						<?php } ?>
					  </table>
					  
					  <?php }
					  else{echo '</table>';}
					  ?>
                      
                      
                      
                      
                      
                      
						  
                            <div style="width:40%; float:left; margin-right:10px;">
                        <table class="gridtable" width="100%" cellpadding="0" cellspacing="1">
                        <tr>
                          <td colspan="2" class="gridheader"><?php echo ($sProcessorName=='Free')?'Confirmation':'Payment' ?> Success Options</td>
                        </tr>
                        <tr>
                          <td colspan="2" class="gridrow2">Activate Access To Membership Level:
                            <select name="nLevel_ID" style="width: 200px; color:black !important;font-weight:normal !important" class="required">
                              <option value="">Please choose a member level</option>
                              <?php
                    				$sql = "SELECT nLevel_ID, sLevel FROM tblmembershiplevels WHERE nActive=1 ORDER BY sLevel";
                    				$result = $dbo->select($sql);
                    				while($row = $dbo->getobj($result))
                    				{
                    					if ($_SESSION['form']['data']['nLevel_ID'] == $row->nLevel_ID)
                   							echo '<option value="' . $row->nLevel_ID . '" selected>' . $row->sLevel . '</option>';
                   						else
                   							echo '<option value="' . $row->nLevel_ID . '">' . $row->sLevel . '</option>';
                    				}
                    			?>
                            </select><label for="nLevel_ID" class="error" style="display: none"><br>You Must Assign A Membership Level</label>
                          </td>
                        </tr>
                        
						 <?php 
						if ($sPaymentPlanType == 'onetime' || $sPaymentPlanType == 'free'){ ?>
							<tr>
                        <td class="gridrow2" colspan="2">Will Expire In <input name="nExpirePeriod" id="nExpirePeriod" style="width: 50px;" value="<?php echo ($_SESSION['form']['data']['nRegularPeriod'])?$_SESSION['form']['data']['nRegularPeriod']:'0' ?>" maxlength="10"> 
                                <small><font style="color:red">*</font></small>
                              <?php
							  $expire = $_SESSION['form']['data']['sRegularPeriod'];
							  if($expire == '0'){$n = 'selected';}
							  if($expire == 'Days'){$d = 'selected';}
							  if($expire == 'Weeks'){$w = 'selected';}
							  if($expire == 'Months'){$m = 'selected';}
							  if($expire == 'Year'){$y = 'selected';}
							  ?>
                              <select name="sExpirePeriod" id="sExpirePeriod" style="width: 200px;">
                                <option value="Days" <?php echo $d ?>>Days</option>
                                <option value="Weeks" <?php echo $w ?>>Weeks</option>
                                <option value="Months" <?php echo $m ?>>Months</option>
                                <option value="Year" <?php echo $y ?>>Years</option>
                              </select> Use 0 For Life Time Access
                              </td>
                        </tr>
						<?php } ?>  
                         
                       
                        </table>
                  </div>
                   <?php if($sProcessorName !=='Free') { ?>
                  <div style="width:40%; float:left; padding:0 0px;">
                  <table class="gridtable" width="100%" cellpadding="0" cellspacing="1">
                       
                        <tr>
                          <td colspan="2" class="gridheader">Payment Refund Options</td>
                        </tr>
                        <tr>
                          <td colspan="2" class="gridrow2">Remove Access To Assigned Membership Level</td>
                        </tr>
                        <tr>
                          <td colspan="2" class="gridrow2">Set Account Status: Keep Account Active</td>
                        </tr>
                    </table></div>
                   <?php echo pluginClass::filter('payment_plan_add_form');
                        
                        } ?>
                         <div style="clear:both"></div>
                         <table class="gridtable" cellpadding="0" cellspacing="1" width="100%"><tr>
                           <td colspan="2" class="gridFooter">
                            	<input type="submit" value="Add Payment Plan" class="inputSubmitb">
                                <input type="hidden" value="1" name="add" />
                            <input name="plan_type" type="hidden" id="plan_type" value="<?php echo $sPaymentPlanType ?>" /></td>
                        </tr></table>
						  
						 <?php }
						 // End Page ...
						else{echo '</table>';}
						 
						?>
                    
              </form>
              
              <?php
			  $paymentplanform = ob_get_clean();
			  $paymentplanform = pluginClass::filter("admin_add_payment_plan_form",$paymentplanform);
			  echo $paymentplanform;
			  ?>
                
                

            </td>
        </tr>
    </table><?php unset($_SESSION['form']);include_once 'b.php'; ?>
 
	
	
</body>
</html>