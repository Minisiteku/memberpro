<?php
    include_once('../conn.php');
    include_once('../functions.php');
	ob_end_clean();
    // Member Payment Options
    if (isset($_POST['Update'])) {
        $bError = false;
        //die(var_dump($_POST));
        // Check for PayPal Info
        if (isset($_POST['bPaypal'])) {
            if (empty($_POST['sPaypalEmail'])) {
                $error_paypal = "Please enter your PayPal email address.";
                $bError = true;
            }
            if(isset($_POST['bPaypalSandbox'])) {
            	if(empty($_POST['sPaypalSandboxEmail'])) {
	            	$error_paypal2 = "Please enter your PayPal Sandbox email address.";
    	            $bError = true;	
            	}
            }
        }
        
        // Check for Authorize.Net Info
        if (isset($_POST['bAuthorize'])) {
            if (empty($_POST['sAuthorizeLoginID'])) {
                $error_authorize = "Please enter your Authorize.NET API Login ID.";
                $bError = true;
            } 
            if (empty($_POST['sAuthorizeTransactionID'])) {
                $error_authorize2 = "Please enter your Authorize Key.";
                $bError = true;
            }
        	if (empty($_POST['sMD5Hash'])) {
                $error_authorize3 = "Please enter your MD5 Hash.";
                $bError = true;
            }
        }

        // Check for 2Checkout Info
        if (isset($_POST['b2Checkout'])) {
            if (empty($_POST['s2CheckoutAccountNumber'])) {
                $error_checkout = "Please enter your 2Checkout account number.";
                $bError = true;
            }
        }

        // Check for ClickBank Info
        if (isset($_POST['bClickbank'])) {
            if (empty($_POST['sClickbankAccount'])) {
                $error_clickbank = "Please enter your ClickBank Account Nickname.";
                $bError = true;
            }
        }
		
		// Check for ClickBank Info
        if (isset($_POST['bClickbank'])) {
            if (empty($_POST['sClickbankAccount'])) {
                $error_clickbank = "Please enter your ClickBank Account Nickname.";
                $bError = true;
            }
        }
		
		// Check for Alert Pay - MDP - 4-7-12
        if (isset($_POST['bpayza'])) {
            if (empty($_POST['spayzaEmail'])) {
                $error_payza = "Please enter your payza merchant email address.";
                $bError = true;
            }
			if (empty($_POST['spayzaSecretWord'])) {
                $error_payza2 = "Please enter your Secret Word.";
                $bError = true;
            }
        }
		
		// Check for jvZoo Info
        if (isset($_POST['bJvZoo'])) {
            if (empty($_POST['sJvZooKey'])) {
                $error_jvzoo = "Please enter your JVZIPN Secret Key.";
                $bError = true;
            }
			if (empty($_POST['sJvZooId'])) {
                $error_jvzooid = "Please enter your JvZoo Affiliate Id.";
                $bError = true;
            }
        }

        if (!$bError) {
            
            // Lets flag any processor account id change for admin review emails.
			
			// Array - Stores an array of data about the changed account.
			$account_change = array();
			
			
			
			// Update Paypal
            if (isset($_POST['bPaypal']))
            {
            	$bSandbox = (!empty($_POST['bPaypalSandbox'])) ? '1' : '0';           	
            	
				// Lets check to see if the account has changed. if so Flag For Security ...
				
				$sql="SELECT sParam1 FROM tblpaymentprocessors WHERE sParam1 = '".$dbo->format($_POST['sPaypalEmail'])."' AND sProcessorName = 'Paypal';";
				
				if(!$dbo->num_rows($sql)){
					// Build The Array For Account Change Security
					$account_change['paypal']['newid'] = $dbo->format($_POST['sPaypalEmail']);
					$account_change['paypal']['displayname'] = 'Paypal';
				}
				
				$sql = "UPDATE tblpaymentprocessors SET " .
            	"nActive = 1, " .
            	"sParam1 = '" . $dbo->format($_POST['sPaypalEmail']) . "', " .
            	"sParam2 = '" . $dbo->format($_POST['sPaypalSandboxEmail']) . "', " .
            	"sParam3 = '" . $bSandbox . "', " .
				"nLog = '".$_POST['nPaypalLog']."'".
            	"WHERE sProcessorName = 'Paypal';";
            	$dbo->update($sql);
				
            } 
			else {
            	$sql = "UPDATE tblpaymentprocessors SET nActive=0 WHERE sProcessorName = 'Paypal';";
            	$dbo->update($sql);
            }
            
            // Update 2Checkout
            if (isset($_POST['b2Checkout']))
            {
            	
				$sql="SELECT sParam1 FROM tblpaymentprocessors WHERE sParam1 = '". $dbo->format( $_POST['s2CheckoutAccountNumber'] ). "' AND sProcessorName = '2Checkout';";
				if(!$dbo->num_rows($sql)){
					// Build The Array For Account Change Security
					$account_change['twoco']['newid'] = $dbo->format($_POST['s2CheckoutAccountNumber']);
					$account_change['twoco']['displayname'] = '2CheckOut';
					}
				
				
				$sql = "UPDATE tblpaymentprocessors SET " .
            			"nActive = 1, " .
            			"sParam1 = '" . $dbo->format($_POST['s2CheckoutAccountNumber']) . "', " .
            			"sParam2 = '" . $dbo->format($_POST['s2CheckoutSecretKey']) . "' ," .
						"nLog = '".$_POST['n2CheckoutLog']."' ".
            			"WHERE sProcessorName = '2Checkout';"
            			;
            	$dbo->update($sql);
            } 
			else {
            	$sql = "UPDATE tblpaymentprocessors SET nActive=0 WHERE sProcessorName = '2Checkout';";
            	$dbo->update($sql);
            }
            
            // Update Clickbank
            if (isset($_POST['bClickbank']))
            {
            	
				
				$sql="SELECT sParam1 FROM tblpaymentprocessors WHERE sParam1 = '". $dbo->format($_POST['sClickbankAccount']). "' AND sProcessorName = 'Clickbank';";
				if(!$dbo->num_rows($sql)){
					// Build The Array For Account Change Security
					$account_change['clickbank']['newid'] = $dbo->format($_POST['sClickbankAccount']);
					$account_change['clickbank']['displayname'] = 'Clickbank';
					}
				
				$sql = "UPDATE tblpaymentprocessors SET " .
            	"nActive = 1, " .
            	"sParam1 = '" . $dbo->format($_POST['sClickbankAccount']) . "', " .
            	"sParam2 = '" . $dbo->format($_POST['sClickbankKey']) . "' ," .
				"nLog = '".$_POST['nClickbankLog']."' ".
            	"WHERE sProcessorName = 'Clickbank';";
            	$dbo->update($sql);
				
				// Update CB footer
				(is_option('cbFooterOption')) ? update_option('cbFooterOption',$dbo->format($_POST['cbFooterOption'])):
				add_option('cbFooterOption',$dbo->format($_POST['cbFooterOption']));
				
				(is_option('cbFooterScript')) ? update_option('cbFooterScript',$dbo->format($_POST['cbFooter'])):
				add_option('cbFooterScript',$dbo->format($_POST['cbFooter']));
				
				
            }
			else {
            	$sql = "UPDATE tblpaymentprocessors SET nActive=0 WHERE sProcessorName = 'Clickbank';";
            	$dbo->update($sql);
            }
            
            // Update Authorize.Net
            if (isset($_POST['bAuthorize']))
            {
            	
				$sql="SELECT sParam1 FROM tblpaymentprocessors WHERE sParam1 = '". $dbo->format($_POST['sAuthorizeLoginID']). "' AND sProcessorName = 'Authorize.Net';";
				if(!$dbo->num_rows($sql)){
					// Build The Array For Account Change Security
					$account_change['authnet']['newid'] = $dbo->format($_POST['sAuthorizeLoginID']);
					$account_change['authnet']['displayname'] = 'Authorize.Net';
					}
				
				$sql = "UPDATE tblpaymentprocessors SET " .
            			"nActive = 1, " .
            			"sParam1 = '" . $dbo->format($_POST['sAuthorizeLoginID']) . "', " .
            			"sParam2 = '" . $dbo->format($_POST['sAuthorizeTransactionID']) . "', " .
            			"sParam3 = '" . $dbo->format($_POST['sMD5Hash']) . "' ," .
						"nLog = '".$_POST['nAuthorizeLog']."' ".
            			"WHERE sProcessorName = 'Authorize.Net';"
            			;
            	$dbo->update($sql);
            }
			else {
            	$sql = "UPDATE tblpaymentprocessors SET nActive=0 WHERE sProcessorName = 'Authorize.Net';";
            	$dbo->update($sql);
            }
			
			// Update payza
            if (isset($_POST['bpayza']))
            {
            	
				$sql="SELECT sParam1 FROM tblpaymentprocessors WHERE sParam1 = '". $dbo->format($_POST['spayzaEmail']). "' AND sProcessorName = 'payza';";
				if(!$dbo->num_rows($sql)){
					// Build The Array For Account Change Security
					$account_change['payza']['newid'] = $dbo->format($_POST['spayzaEmail']);
					$account_change['payza']['displayname'] = 'Payza';
					}
				
				
				$bSandbox = (!empty($_POST['bpayzaSandbox'])) ? '1' : '0';
				$sql = "UPDATE tblpaymentprocessors SET " .
            			"nActive = 1, " .
            			"sParam1 = '" . $dbo->format($_POST['spayzaEmail']) . "', " .
            			"sParam2 = '" . $dbo->format($_POST['spayzaSandboxEmail']) . "', " .
						"sParam3 = '" . $bSandbox . "', " .
						"sParam4 = '" . $dbo->format($_POST['spayzaSecretWord']) . "', " .
						"nLog = '".$_POST['npayzaLog']."'" .
            			"WHERE sProcessorName = 'payza';";
						
            	$dbo->update($sql);
            } 
			else {
            	$sql = "UPDATE tblpaymentprocessors SET nActive=0 WHERE sProcessorName = 'payza';";
            	$dbo->update($sql);
            }
			
			// Update JvZoo
			 if (isset($_POST['bJvZoo']))
            {
				
				
				$sql="SELECT sParam1 FROM tblpaymentprocessors WHERE sParam1 = '". $dbo->format($_POST['sJvZooId'])."' AND sProcessorName = 'JvZoo';";
				if(!$dbo->num_rows($sql)){
					// Build The Array For Account Change Security
					$account_change['jvzoo']['newid'] = $dbo->format($_POST['sJvZooId']);
					$account_change['jvzoo']['displayname'] = 'JvZoo';
					}
				//$sql="SELECT sParam2 FROM tblpaymentprocessors WHERE sParam2 = '". $dbo->format($_POST['sJvZooKey'])."' AND sProcessorName = 'JvZoo';";
				/*if(!$dbo->num_rows($sql)){
					// Build The Array For Account Change Security
					$account_change['jvzoo']['newid'] = $dbo->format($_POST['sJvZooKey']);
					$account_change['jvzoo']['displayname'] = 'JvZoo';
					}
				*/
				$sql = "UPDATE tblpaymentprocessors SET sParam1 = '".$dbo->format($_POST['sJvZooId'])."', sParam2 = '".$dbo->format($_POST['sJvZooKey'])."',sParam3 = '".$dbo->format($_POST['sJvZooTest'])."', nActive = '1', nLog = '".$dbo->format($_POST['nJvZooLog'])."' WHERE sProcessorName = 'JvZoo';";
				//die($sql);
            	$dbo->update($sql);
            } 
			else {
            	$sql = "UPDATE tblpaymentprocessors SET nActive=0 WHERE sProcessorName = 'JvZoo';";
            	$dbo->update($sql);
            }
			
			// Updates Finished ... Add A Hook Point For Plugins
			
			// Send Security Emails
			
			if(!empty($account_change)){
				// We have an account change! Lets Get The Current Admin User...
				$curAdmin = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID = ".$dbo->format($_SESSION['admin']['nUser_ID']).";");
				$curAdmin->ip = $_SERVER['REMOTE_ADDR'];
				
				
				foreach($account_change as $k => $v){
					// send the email to main admin.
					email_security_processorchange($v,$curAdmin);
					}
				}
            

            $message = '<p class="success">Member payment options have been updated successfully</p>';
        } 
		else {
            $message = '<p class="error">Please check your member payment options</p>';
        }
    }

	// Update Membership Periods
	if ( isset($_POST['pUpdate']) ) {
		for ($i = 1; $i < 6; $i++)
			$dbo->update(sprintf("UPDATE tblpaymentplans SET nActive = '%d', nPrice = %.2f, sPaypalItemName = '%s', s2CheckoutItemName = '%s', s1ShoppingCartPID = '%s', sClickBankItem = '%s' WHERE npaymentplan_id = '%s';", $dbo->format($_POST['pcheckr'.$i]), str_replace(array('$', ','), '', $dbo->format($_POST['npricer'.$i])), $dbo->format($_POST['sPaypalItemName'.$i]), $dbo->format($_POST['s2CheckoutItemName'.$i]), $dbo->format($_POST['s1ShoppingCartPID'.$i]), $dbo->format($_POST['sClickBankItem'.$i]), $i));
	
		$message = '<p class="success">Membership periods have been updated successfully</p>';}

// Get Payment Processors
$objPaypal = $dbo->getobject("SELECT * FROM tblpaymentprocessors WHERE sProcessorName='Paypal'");
$obj2Checkout = $dbo->getobject("SELECT * FROM tblpaymentprocessors WHERE sProcessorName='2Checkout'");
$objClickbank = $dbo->getobject("SELECT * FROM tblpaymentprocessors WHERE sProcessorName='Clickbank'");
$objAuthorize = $dbo->getobject("SELECT * FROM tblpaymentprocessors WHERE sProcessorName='Authorize.Net'");  
$objpayza = $dbo->getobject("SELECT * FROM tblpaymentprocessors WHERE sProcessorName='payza'");
$objJvzoo = $dbo->getobject("SELECT * FROM tblpaymentprocessors WHERE sProcessorName='JvZoo'");

$objClickbank->footer_option = get_option('cbFooterOption');
$objClickbank->footer_script = get_option('cbFooterScript');

pluginClass::action("admin_payment_processors_head"); ?>
<html>
    <head>
    <title><?php echo $admintitle; ?></title>
    <?php include("inc-head.php"); ?>
    <script language="javascript" src="../js/jquery-ui-1.8.24.custom.min.js"></script>
    <?php
        if($rw->nFreeMembership == 1){
    ?>
    <script type="text/javascript">
        window.onload = function(){
                document.getElementById('nFreeOnlyMembership').disabled = false;
            }
	
	
    </script>
    <?php   
        }   
    ?>
    <script type="text/javascript">
    function toggle(id){
		var ele = document.getElementById(id);
		if(ele.style.display == 'none'){ele.style.display = 'block'}
		else{ele.style.display = 'none'}
	}
	$( "#cbopts" ).dialog( "open" );
    </script>
    </head>

    <body leftmargin="0" topmargin="0" rightmargin="0">
    <?php include_once('top.php'); ?>
    <div style="clear:both"></div>
    <table cellpadding="0" cellspacing="0" width="100%">
      <tr>
        <td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once('settingsleft.php'); ?></td>
        <td width="100%" align="left" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;"><!-- NAVIGATION -->
          
          <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
            <tr>
              <td class="navRow1" nowrap="nowrap">Payment Processors</td>
            </tr>
          </table>
          <?php echo isset($message) ? $message : '' ?> 
          
          <!-- PAYMENT PROCESSOR OPTIONS -->
          
          <form action="payment_processors.php" name="form" method="post">
            <table class="gridTable" border="0" cellpadding="0" cellspacing="1" width="100%">
              <tr>
                <td class="gridHeader"><b>Payment Processor Options</b></td>
              </tr>
              
              <!-- PayPal -->
              
              <tr>
                <td class='gridRow1'><table>
                    <tr>
                    <td width="150" valign="top"><input type="checkbox" name="b2Checkout" <?php if($obj2Checkout->nActive =='1') {echo 'checked="checked"';}?> onChange="toggle('2coOpts')">
                        2Checkout </td>
                    <td><table cellpadding="0" cellspacing="0" border="0" id="2coOpts" style="display:<?php  if($obj2Checkout->nActive =='1') {echo 'block';}else{echo 'none';} ?>">
                        <tr>
                        <td width="150">Account Number<font color="Red"> *</font></td>
                        <td><input name="s2CheckoutAccountNumber" value="<?php echo $obj2Checkout->sParam1 ?>" style="width: 300px;"></td>
                        <td>&nbsp;&nbsp;<span style="color:#ff0000"><?php echo $error_checkout ?></span></td>
                      </tr>
                        <tr>
                        <td>Secret Word: (optional)</td>
                        <td colspan="2"><input name="s2CheckoutSecretKey" value="<?php echo $obj2Checkout->sParam2 ?>" style="width: 300px;"></td>
                      </tr>
                        <tr>
                        <td>Enable Logging?</td>
                        <td colspan="2"><input name="n2CheckoutLog" type="checkbox" value="1" <?php if($obj2Checkout->nLog =='1') {echo 'checked="checked"';}?>></td>
                      </tr>
                      </table></td>
                  </tr>
                  </table></td>
              </tr>
              
              <!-- 2Checkout -->
              
              <tr>
                <td class='gridRow1'><table>
                    <tr>
                    <td width="150" valign="top"><input name="bpayza" type="checkbox" id="bpayza" <?php if($objpayza->nActive =='1') {echo 'checked="checked"';}?> onChange="toggle('payzaOpts');">
                        <a href="https://secure.payza.com/?6rwyksi4xCJnqc6%2bzJq4Jw%3d%3d" target="_blank">Payza</a></td>
                    <td><table cellpadding="0" cellspacing="0" border="0" id="payzaOpts" style="display:<?php  if($objpayza->nActive =='1') {echo 'block';}else{echo 'none';} ?>">
                        <tr>
                        <td width="150">Merchant Email <font color="Red"> *</font></td>
                        <td><input name="spayzaEmail" value="<?php echo $objpayza->sParam1 ?>" style="width: 300px"></td>
                        <td>&nbsp;&nbsp;<span style="color:#ff0000"><?php echo $error_paypal ?></span></td>
                      </tr>
                        <tr>
                        <td>Use Sandbox?</td>
                        <td><input name="bpayzaSandbox" type="checkbox" id="bpayzaSandbox" value="1" <?php if($objpayza->sParam3 =='1') {echo 'checked="checked"';}?>></td>
                        <td></td>
                      </tr>
                        <tr>
                        <td>Sandbox Email<font color="Red"> *</font></td>
                        <td><input name="spayzaSandboxEmail" id="spayzaSandboxEmail" style="width: 300px;" value="<?php echo $objpayza->sParam2 ?>"></td>
                        <td>&nbsp;&nbsp;<span style="color:#ff0000"><?php echo $error_paypal2 ?></span></td>
                      </tr>
                        <tr>
                        <td>Security Code<font color="Red"> *</font></td>
                        <td><input name="spayzaSecretWord" id="spayzaSecretWord" style="width: 300px" value="<?php echo $objpayza->sParam4 ?>"></td>
                        <td><?php echo $error_payza2 ?></td>
                      </tr>
                        <tr>
                        <td>Enable Logging?</td>
                        <td colspan="2"><input name="npayzaLog" type="checkbox" value="1" <?php if($objpayza->nLog =='1') {echo 'checked="checked"';}?>></td>
                      </tr>
                      </table></td>
                  </tr>
                  </table></td>
              </tr>
              
              <!-- ClickBank -->
              
              <tr>
                <td class='gridRow1'><table>
                    <tr>
                    <td width="150" valign="top"><input type="checkbox" name="bAuthorize" <?php if($objAuthorize->nActive =='1') {echo 'checked="checked"';}?> onChange="toggle('AuthorizenetOpts')">
                        Authorize.Net </td>
                    <td><table cellpadding="0" cellspacing="0" border="0" id="AuthorizenetOpts" style="display:<?php  if($objAuthorize->nActive =='1') {echo 'block';}else{echo 'none';} ?>">
                        <tr>
                        <td width="150">API Login ID<font color="Red"> *</font></td>
                        <td><input name="sAuthorizeLoginID" value="<?php echo $objAuthorize->sParam1 ?>" style="width: 300px"></td>
                        <td>&nbsp;&nbsp;<span style="color:#ff0000"><?php echo $error_authorize ?></span></td>
                      </tr>
                        <tr>
                        <td>Transaction Key<font color="Red"> *</font></td>
                        <td><input name="sAuthorizeTransactionID" value="<?php echo $objAuthorize->sParam2 ?>" style="width: 300px"></td>
                        <td>&nbsp;&nbsp;<span style="color:#ff0000"><?php echo $error_authorize2 ?></span></td>
                      </tr>
                        <tr>
                        <td>MD5 Hash<font color="Red"> *</font></td>
                        <td><input name="sMD5Hash" value="<?php echo $objAuthorize->sParam3 ?>" style="width: 300px"></td>
                        <td>&nbsp;&nbsp;<span style="color:#ff0000"><?php echo $error_authorize3 ?></span></td>
                      </tr>
                        <tr>
                        <td>Enable Logging?</td>
                        <td colspan="2"><input name="nAuthorizeLog" type="checkbox" value="1" <?php if($objAuthorize->nLog =='1') {echo 'checked="checked"';}?>></td>
                      </tr>
                      </table></td>
                  </tr>
                  </table></td>
              </tr>
              <tr>
                <td class='gridRow1'>
                <table>
                    <tr>
                    <td valign="top">
                    	<input type="checkbox" name="bClickbank" <?php if($objClickbank->nActive =='1') {echo 'checked="checked"';}?> onChange="toggle('ClickbankOpts');"> ClickBank </td>
                    <td><br />
                    <table border="0" cellpadding="0" cellspacing="1" class="gridtable" id="ClickbankOpts" style="display:<?php  if($objClickbank->nActive =='1') {echo 'block';}else{echo 'none';} ?>">
                        <tr>
                        <td width="150" class="gridrow2">Account Nickname<font color="Red"> *</font></td>
                        <td width="317" class="gridrow2"><input name="sClickbankAccount" value="<?php echo $objClickbank->sParam1 ?>" style="width: 300px"></td>
                        <td width="50" class="gridrow2">&nbsp;&nbsp;<span style="color:#ff0000"><?php echo $error_clickbank ?></span></td>
                      </tr>
                        <tr>
                        <td class="gridrow2">Secret Key (optional)</td>
                        <td class="gridrow2"><input name="sClickbankKey" value="<?php echo $objClickbank->sParam2 ?>" style="width: 300px; "></td>
                        <td class="gridrow2"></td>
                      </tr>
                        <tr>
                          <td class="gridrow2">Enable Debugging?</td>
                          <td class="gridrow2"><input name="nClickbankLog" type="checkbox" value="1" <?php if($objClickbank->nLog =='1') {echo 'checked="checked"';}?>></td>
                          <td class="gridrow2"></td>
                        </tr>
                        <tr>
                          <td colspan="3" class="gridheader"><a href="https://support.clickbank.com/entries/22857278-Required-Disclaimers" target="_blank">ClickBank Required Disclaimer</a></td>
                        </tr>
                        <tr>
                          <td valign="top" class="gridrow2">Footer Script</td>
                          <td class="gridrow2"><label for="cbFooter"></label>
                            <?php
							?>
                              <label>
                                <input name="cbFooterOption" type="radio" id="cbFooterOption_0" onClick="$('#cbFooter').hide();" value="0"
                                <?php echo ($objClickbank->footer_option == '0')?'checked="CHECKED"':''?>>
                                Off</label>
                              
                              <label>
                                <input type="radio" name="cbFooterOption" value="1" id="cbFooterOption_1" onClick="$('#cbFooter').show();"
                                <?php echo ($objClickbank->footer_option == '1')?'checked="CHECKED"':''?>>
                                Global</label>
                              
                            <label>
                                <input type="radio" name="cbFooterOption" value="2" id="cbFooterOption_2" onClick="$('#cbFooter').show();"
                                <?php echo ($objClickbank->footer_option == '2')?'checked="CHECKED"':''?>>
                                Market Place Only</label>
                            
                            <textarea name="cbFooter" rows="10" id="cbFooter" style="font-size:9px; width:95%;
                            
                            <?php echo ($objClickbank->footer_option == '0')?'display:none;':''?>"><?php echo $objClickbank->footer_script ?></textarea>
                            <br>
                          <a href="https://support.clickbank.com/entries/22857278-Required-Disclaimers" target="_blank"></a></td>
                            <td class="gridrow2"></td>
                      </tr>
                      </table></td>
                  </tr>
                  </table></td>
              </tr>
              <tr>
                <td class='gridRow1'><table>
                    <tr>
                    <td width="150" valign="top"><input type="checkbox" name="bPaypal" <?php if($objPaypal->nActive =='1') {echo 'checked="checked"';}?> onChange="toggle('PayPalOpts');">
                        PayPal </td>
                    <td><table cellpadding="0" cellspacing="0" border="0" id="PayPalOpts" style="display:<?php  if($objPaypal->nActive =='1') {echo 'block';}else{echo 'none';} ?>">
                        <tr>
                        <td width="150">Primary Paypal Email <font color="Red"> *</font></td>
                        <td><input name="sPaypalEmail" value="<?php echo $objPaypal->sParam1?>" style="width:300px"></td>
                        <td>&nbsp;&nbsp;<span style="color:#ff0000"><?php echo $error_paypal ?></span></td>
                      </tr>
                        <tr>
                        <td>Use Sandbox?</td>
                        <td><input type="checkbox" name="bPaypalSandbox" <?php if($objPaypal->sParam3 =='1') {echo 'checked="checked"';}?>></td>
                        <td></td>
                      </tr>
                        <tr>
                        <td>Sandbox Email<font color="Red"> *</font></td>
                        <td><input name="sPaypalSandboxEmail" value="<?php echo $objPaypal->sParam2 ?>" style="width: 300px;"></td>
                        <td>&nbsp;&nbsp;<span style="color:#ff0000"><?php echo $error_paypal2 ?></span></td>
                      </tr>
                        <tr>
                        <td>Enable Logging?</td>
                        <td colspan="2"><input name="nPaypalLog" type="checkbox" value="1" <?php if($objPaypal->nLog =='1') {echo 'checked="checked"';}?>></td>
                      </tr>
                      </table></td>
                  </tr>
                  </table></td>
              </tr>
              <tr>
                <td class='gridRow1'><table>
                    <tr>
                    <td width="150" valign="top"><input name="bJvZoo" type="checkbox" id="bJvZoo" onChange="toggle('JvzooOpts');" <?php if($objJvzoo->nActive =='1') {echo 'checked="checked"';}?>>
                        JvZoo </td>
                    <td><table border="0" cellpadding="0" cellspacing="0" id="JvzooOpts" style="display:<?php  if($objJvzoo->nActive =='1') {echo 'block';}else{echo 'none';} ?>">
                        <tr>
                        <td width="150">Account Id<font color="Red"> *</font></td>
                        <td><input name="sJvZooId" id="sJvZooId" style="width: 300px" value="<?php echo $objJvzoo->sParam1 ?>"></td>
                        <td>&nbsp;&nbsp;<span style="color:#ff0000"><?php echo $error_clickbank ?></span></td>
                      </tr>
                        <tr>
                        <td>JVZIPN Secret Key:<font color="Red">*</font></td>
                        <td><input name="sJvZooKey" value="<?php echo $objJvzoo->sParam2 ?>" style="width: 300px; "></td>
                        <td><span style="color:#ff0000"><?php echo $error_jvzoo ?></span></td>
                      </tr>
                        <tr>
                        <td colspan="3"> Enable Logging?
                            <input name="nJvZooLog" type="checkbox" value="1" <?php if($objJvzoo->nLog =='1') {echo 'checked="checked"';}?>></td>
                      </tr>
                      </table></td>
                  </tr>
                  </table></td>
              </tr>
              <tr>
                <td class='gridRow1'><?php echo pluginClass::filter("admin_payment_processors_table"); ?></td>
              </tr>
              
              <tr>
                <td class="gridFooter"><input type="submit" name="Update" value="Save Changes" class="inputSubmitb"></td>
              </tr>
            </table>
          </form></td>
      </tr>
    </table>
    <?php include_once('b.php'); ?>
</body>
</html>
