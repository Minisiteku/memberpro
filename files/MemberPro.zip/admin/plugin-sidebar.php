<?php
// Sidebar For The Plugins Page (expanded.php)
echo pluginClass::filter('plugin_sidebar');
//if(is_callable(array($k,$v))){echo call_user_func(array($k,$v));}
//else{echo '<h1>Error: The Requested Page Could Not Be Loaded ...</h1>';}
?>