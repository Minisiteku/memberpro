<?php
include_once('../conn.php');
include_once('../functions.php');

if ($_GET['status'] != '')
{
	$sql="UPDATE tblpromoemails SET nactive='" . $dbo->format($_GET["status"]) . "' WHERE npromoemail_id='" . $dbo->format($_GET["projid"])."'";
	$dbo->update($sql);
}


if($_GET['act']=="d")
{
$dbo->delete("delete from tblpromoemails where npromoemail_id='" . $dbo->format($_GET["id"])."'");
header("location:promotional_emails.php?act=dsus");
}
?>
<html> 
<head>
<title><?php echo $admintitle; ?></title>
<?php include("inc-head.php"); ?>
<script type="text/javascript">
function cdel(w) {
if(confirm("Are you sure that you want to delete this promotional email?"))
{
	return true;
}
else
{
return false;
}
}
</script>
</head>
<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
    
    <tr>
      <td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">        <?php include_once('affiliateleft.php'); ?>      </td>
      <td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;"  valign="top" width="100%">
  	
  	    <table class="navTable" cellpadding="0" cellspacing="0" width="100%">        
            <tr>
              <td class="navRow1" nowrap="nowrap">Promotional Emails - <a href="add_promotional_emails.php"><strong>Add New</strong></a></td>
            </tr>
        </table>
  	    <p class="success">
        <?php if($_GET[act]=="adsus") { echo "Promotional email has been added successfully<br><br>"; }?>
        <?php if($_GET[act]=="upsus") { echo "Promotional email has been updated successfully<br><br>"; }?>
        <?php if($_GET[act]=="dsus") { echo "Promotional email has been deleted successfully <br><br>"; }?>
        </p>
  	    <table width="100%" cellpadding="0" cellspacing="1" class="gridTable">
          <tr>
            <td class="gridheader">Title</td>
            <td class="gridheader">Sort Order</td>
            <td colspan="3" align="center" nowrap="nowrap" class="gridheader">Actions</td>
            <?php
			$sqlcs="SELECT * FROM tblpromoemails order by npromoemail_id";
			$resultcs=$dbo->select($sqlcs);
			if(!empty($resultcs))
			$n=$dbo->nr($resultcs);
			$number = $n;                // record results selected from database 
			$displayperpage="10";                // record displayed per page 
			$pageperstage="10";                // page displayed per stage 
			$allpage=ceil($number/$displayperpage);        
			$allstage=ceil($allpage/$pageperstage);        // how many page will it be ? 
			if(trim($startpage)==""){$startpage=1;} 
			if(trim($_GET['nowstage'])==""){$_GET['nowstage']=1;} 
			if(trim($_GET['nowpage'])==""){$_GET['nowpage']=$startpage;} 
			$StartRow = 0;
			if (empty($_GET['nowpage']))
			{
				if($StartRow == 0){
					$_GET['nowpage'] = $StartRow + 1;
				}
			}else{
				$nowpage = $_GET['nowpage'];
				$StartRow = ($nowpage - 1) * $displayperpage;
			}
			$c=1;
			$sql="SELECT * FROM tblpromoemails ORDER BY nSortOrder LIMIT $StartRow,$displayperpage";
			$result=$dbo->select($sql);
			if(!empty($result))
			{
				$number=$dbo->nr($result);
				$num1=$dbo->nr($result);
			}
			if(!empty($result)){
			while($row=$dbo->getobj($result))
			{
			?>
					  <tr>
						<td class="gridrow2"> 
						<?php
						//$code = str_replace("\n", "<br>", $row->sEmailText);  
						//echo $code;
						echo $row->sTitle
						?></td>
						<td class="gridrow2" align="center"><?php echo $row->nSortOrder ?></td>
						<td class="gridActions1" align="center"><?php if ($row->nActive==0) { ?>
							<a href="<?php echo $_SERVER['PHP_SELF']; ?>?status=1&projid=<?php echo $row->nPromoEmail_ID?>" class="black"> <img src="images/adult_r.gif" alt="Not Active" width="16" height="16" border="0"></a>
							<?php } else { ?>
							<a href="<?php echo $_SERVER['PHP_SELF']; ?>?status=0&projid=<?php echo $row->nPromoEmail_ID?>" class=black> <img src="images/adult_off.gif" alt="Active" width="16" height="16" border="0"></a>
							<?php }?>
						</td>
						<td class="gridActions1" align="center"><a class="grid" href="edit_promotional_emails.php?act=e&amp;id=<?php echo $row->nPromoEmail_ID;?>" title="Edit Promotional email"> <img src="images/edit.gif" alt="Edit promotional email" border="0"></a> </td>
						<td class="gridActions1" align="center"><a class="grid" href="<?php echo $_SERVER['PHP_SELF']; ?>?act=d&amp;id=<?php echo $row->nPromoEmail_ID;?>" title="Delete Promotional email"  OnClick="return cdel('employer');"> <img src="images/delete.gif" alt="Delete Promotional email" border="0"></a> </td>
					  </tr>
					  <?php }
			}
			else{?>
			<tr>
						<td colspan="5" class="gridrow2"><strong>No Promotional Emails Exist! - <a href="add_promotional_emails.php"><strong>Add New</strong></a></strong></td>
					  </tr>
			
			<?php }
?>
          <tr>
            <td colspan="5" align="right" class="gridFooter">&nbsp;</td>
          </tr>
        
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td>Page
            <?php
			if($number==0)
			{
			echo "0 of 0";
			}
			else
			{
			echo $nowpage." of ".$allpage;
			}			
			?>
            <?php
			
if($_GET['nowstage']==1 and $_GET['nowpage']==1) 
{
$links="<span class='gridFaded'>&#171; Back &nbsp;|</span>";
}
else
{
$links="<a href='" . $_SERVER['PHP_SELF'] . "?nowstage=".($_GET['nowstage']-1)."&nowpage=".($_GET['nowstage']-1)."'>&#171; Back</a>&nbsp;|";
}
if($allpage==$_GET['nowstage'] and $allpage==$_GET['nowpage']) 
{
$links=$links."<span class=gridFaded> Next &#187;</span>";
}
elseif($number==0)
{
$links=$links."<span class=gridFaded> Next &#187;</span>";
}
else
{
$links=$links."<a href='" . $_SERVER['PHP_SELF'] . "?nowstage=".($_GET['nowstage']+1)."&nowpage=".($_GET['nowstage']+1)."'> Next &#187;</a>";
}

echo  $links; 

?></td>
          <td align="right">No of records found :
            <?php echo $n;?></td>
        </tr>
      </table>
      <br></td>
      </tr>
</table>
<?php include_once('b.php'); ?>
</body></html>