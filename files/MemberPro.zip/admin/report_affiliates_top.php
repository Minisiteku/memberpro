<?php

include_once( "../conn.php" );
include_once( "../functions.php" );
?>
<html>
  <head>
    <title><?php echo $admintitle; ?></title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<?php include ('inc-head.php')?>
<script type="text/javascript" src="../js/swfobject.js"></script>
<script type="text/javascript">
   swfobject.embedSWF("common/open-flash-chart.swf", "admin_chart_affiliates", "900", "200", "9.0.0", "expressInstall.swf", 
   {"data-file":"report_affiliates_top_data.php?y=<?php echo isset( $_GET['y'] ) ? $_GET['y'] : date( "Y" )?>"} );
  </script>
<script language="javascript">
  function changeYear() {
   var dropdown = document.getElementById('nYear');
   var index = dropdown.selectedIndex;
   var ddVal = dropdown.options[index].value;
   document.location.href = 'report_affiliates_top.php?y=' + ddVal;
  }
  </script>
<style>
   #note {
    margin-top: 5px;
    margin-bottom: 20px;
    font-size: 10px;
   }
   #note span {
    background-color: #FFC;
    padding: 5px;
   }
  </style>
  
  </head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>

<table cellpadding="0" cellspacing="0" width="100%">
   <tr>
    <td width="600%" colspan="6" class="menuRow3_members">&nbsp;</td>
   </tr>
  </table>
  <table cellpadding="0" cellspacing="0" width="100%">
   <tr>
    <td width="210" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
<?php include_once( "leftreports.php" ); ?>
</td>
    <td width="100%" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">
     <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
      <tr>
       <td nowrap="nowrap" class="navRow1"> Reports &raquo; Top 25 Affiliates </td>
       <td class="navRow2" width="100%">&nbsp;</td>
      </tr>
     </table>
     
     <div id="note">
<span>
<strong>Please note:</strong> This chart displays paid and unpaid affiliate commissions.</span></div>
<div id="chooseyear">
<strong>Choose Year</strong>: 
<select id="nYear" onChange="changeYear();">
    <?php
	$i = 0;
	// Why Only 5 Year Span Below? Should Start With Date Of First Record, and end at last... Duh? - $i < 5
	while ( $i < 5 ){
    $year = date( "Y" ) - $i;
    $selected = $year == $_GET['y'] ? "selected" : "";
    ?>
    <option value="<?php echo $year?>" <?php echo $selected ?>><?php echo $year ?></option>
    <?php 
	++$i;}
	?>
</select>      
     </div>
        
     <div align="center" id="admin_chart_affiliates" ></div>              

     <!-- Breakdown -->
     
     <h2>Top 25 Breakdown</h2>
     
     <table cellspacing="1" cellpadding="0" border="0" class="gridTable">
      <tr>
       <td class="gridHeader">Rank</td>
       <td class="gridHeader">Name</td>
       <td class="gridHeader">Email</td>
       <td class="gridHeader">No. of Sales</td>
       <td class="gridHeader">Commissions</td>
      </tr>
      <?php
	$year = isset( $_GET['y'] ) ? $_GET['y'] : date( "Y" );
	$curSymbol = get_currency_symbol( $chkSsettings->sCurrencyFormat );
	$sql = "SELECT 
         A.sForename AS sAffForename,
         A.sSurname AS sAffSurname,
         A.sEmail,
         COUNT(AP.nAffiliate_ID) AS nSales,
         SUM(AP.nCommission) AS nCommissionTotal
       FROM tblaffiliatepayments AP
       INNER JOIN tblusers A ON A.nUser_ID = AP.nAffiliate_ID
       WHERE NOT AP.sPaymentStatus = 'Refund' AND YEAR(nTimeStamp) = '{$year}'
       GROUP BY AP.nAffiliate_ID
       ORDER BY nCommissionTotal DESC
       LIMIT 25";
	  
$result = $dbo->select( $sql );
if ( $result )
{
    $i = 1;
	$totalSales = 0;
	
    while ( $row = $dbo->getarray( $result ) )
    {
        ?>
        <tr>
         <td class="gridOptions1">#<?php echo $i ?></td>
         <td class="gridOptions1"><?php echo $row['sAffForename']." ".$row['sAffSurname']?></td>
         <td class="gridOptions1"><?php echo $row['sEmail']?></td>
         <td class="gridOptions1"><?php echo $row['nSales']?></td>
         <td class="gridOptions1"><?php echo $curSymbol.number_format( $row['nCommissionTotal'], 2 )?></td>
        </tr>
        <?php
        $totalNoOfSales = $totalNoOfSales + $row['nSales'];
        $totalSales = $totalSales + (int)$row['nCommissionTotal'];
        ++$i;
    }
   
    ?>
    
    <tr>
        <td class="gridFooter"><strong>Totals</strong></td>
        <td class="gridFooter"><strong></strong></td>
        <td class="gridFooter"><strong></strong></td>
        <td class="gridFooter"><strong><?php echo $totalNoOfSales ?></strong></td>
        <td class="gridFooter"><strong><?php echo $curSymbol.number_format( $totalSales, 2 )?></strong></td>
       </tr>
	   <?php }else{ ?>
    <tr><td colspan="5" class="gridOptions1" align="center">No data to display</td></tr>
	<?php } ?>
</table>
<br />
</td>
</tr>
</table>
<?php include_once( "b.php" ); ?>
</body>
</html>
