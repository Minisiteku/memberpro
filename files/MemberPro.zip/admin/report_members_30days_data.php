<?php

include( "common/php/ofc/open-flash-chart.php" );
include_once( "../conn.php" );
include_once( "../functions.php" );
$title = new title( "Number of New Members Over The Past 30 Days" );
$now_date = date( "Ymd" );
$last_month_stamp = strtotime( "-30 days", time( ) );
$last_month_date = date( "Ymd", $last_month_stamp );
$date = $last_month_date;
$stamp = $last_month_stamp;
$list = array( );
$max = 0;
while ( $date <= $now_date )
{
    $list[$date] = array( "join" => 0, "canceled" => 0 );
    $stamp = $stamp + 86400;
    $date = date( "Ymd", $stamp );
}
$sql = "SELECT COUNT(*) as nCount,  nJoinDate FROM tblusers WHERE tblusers.nActive = 1 AND tblusers.nJoinDate >= {$last_month_date} AND tblusers.nAdmin = 0 GROUP BY nJoinDate";
$rs = $dbo->select( $sql );
while ( $row = @$dbo->getassoc( @$rs ) )
{
    $join_date = $row['nJoinDate'];
    $count = $row['nCount'];
    $list[$join_date]['join'] = $count;
    if ( $max < $count )
    {
        $max = ( integer )$count;
    }
}
$data_join = array( );
$x_labels = array( );
foreach ( $list as $date => $value )
{
    $data_join[] = ( integer )$value['join'];
    $x_labels[] = date( "D jS M", strtotime( $date ) );
}
$bar = new bar_glass( );
$bar->colour( "#009933" );
$bar->set_values( $data_join );
$x = new x_axis( );
$x->set_colours( "#666666", "#cccccc" );
$x->set_offset( 10 );
$x_labels1 = new x_axis_labels( );
$x_labels1->set_vertical( );
$x_labels1->set_labels( $x_labels );
$x->set_labels( $x_labels1 );
$y = new y_axis( );
$y->set_colours( "#666666", "#cccccc" );
$max = ( substr( $max, 0, 1 ) + 1 ) * pow( 10, strlen( $max ) - 1 );
$grade = pow( 10, strlen( $max ) - 1 );
$y->set_range( 0, $max, $grade );
$chart = new open_flash_chart( );
$chart->set_bg_colour( "ffffff" );
$chart->set_x_axis( $x );
$chart->set_y_axis( $y );
$title->set_style( "{font-size: 18px; font-family: Verdana; font-weight: bold; color: #000000; text-align: center; margin-bottom: 5px; }" );
$chart->set_title( $title );
$chart->add_element( $bar );
echo $chart->toString( );
?>
