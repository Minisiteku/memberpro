<?php

include_once( "../conn.php" );
include_once( "../functions.php" );
?>
<html>
  <head>
    <title><?php echo $admintitle; ?></title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<?php include ('inc-head.php')?>
<script type="text/javascript" >
  function changeDropdown() {
   var dropdown = document.getElementById('nDropdownID');
   var index = dropdown.selectedIndex;
   var ddVal = dropdown.options[index].value;
   document.location.href = 'report_members_level.php?cmd=' + ddVal;}
  </script>
<style>
   .small1 {
    font-size: 11px; 
    margin-left: 20px; 
    color: grey;
   }
  </style>
 </head>
 <body leftmargin="0" topmargin="0" rightmargin="0">
  <?php include_once( "top.php" ) ?>
  <table cellpadding="0" cellspacing="0" width="100%">
   <tr>
    <td width="600%" colspan="6" class="menuRow3_members">&nbsp;</td>
   </tr>
  </table>
  <table cellpadding="0" cellspacing="0" width="100%">
   <tr>
    <td width="210" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
<?php include_once( "leftreports.php" ); ?>
</td>
    <td width="100%" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">
     <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
      <tr>
       <td nowrap="nowrap" class="navRow1"> Reports &raquo; Members By Level </td>
       <td class="navRow2" width="100%">&nbsp;</td>
      </tr>
     </table>
     
     <h2>Members By Level</h2>
     
    <?php
if ( isset( $_GET['cmd'] ) && $_GET['cmd'] == "active" )
{
    $selectedActive = "selected";
    $selectedAll = "";
    $sqlWhere = " WHERE ML.nActive=1";
}
else if ( isset( $_GET['cmd'] ) && $_GET['cmd'] == "all" )
{
    $selectedActive = "";
    $selectedAll = "selected";
    $sqlWhere = "";
}
else
{
    $sqlWhere = " WHERE ML.nActive=1";
}
?>
     <div>
      <form>
<select id="nDropdownID" onChange="changeDropdown();">
        <option value="active" <?php echo $selectedActive; ?>>Show Active Levels Only </option>
        <option value="all" <?php echo $selectedAll;?>>Show All Levels</option>
       </select>
      </form>      
     </div>
     
     <table cellspacing="1" cellpadding="0" border="0" class="gridTable">
      <tr>
       <td class="gridHeader">Level</td>
       <td class="gridHeader">Active Members</td>
       <td class="gridHeader">Cancelled Members</td>
      </tr>
     <?php
	$sql = "SELECT ML.nLevel_ID,ML.sLevel,
	IFNULL(Active.nMembers,0) AS nActiveMembers,
         IFNULL(Cancelled.nMembers,0) AS nCancelledMembers
       FROM tblmembershiplevels ML
       LEFT JOIN
       (
       SELECT 
         L.nLevel_ID,
         sLevel,
         COUNT(UL.nLevel_ID) AS nMembers
       FROM tblmembershiplevels L
       LEFT JOIN tbluserlevels UL ON UL.nLevel_ID = L.nLevel_ID
       INNER JOIN tblusers U ON U.nUser_ID = UL.nUser_ID
       WHERE UL.nDateCancelled = 0
       GROUP BY UL.nLevel_ID
       ) AS Active ON Active.sLevel = ML.sLevel
       LEFT JOIN (

       SELECT 
         sLevel,
         COUNT(UL.nLevel_ID) AS nMembers
       FROM tblmembershiplevels L
       LEFT JOIN tbluserlevels UL ON UL.nLevel_ID = L.nLevel_ID
       INNER JOIN tblusers U ON U.nUser_ID = UL.nUser_ID
       WHERE UL.nDateCancelled > 0 
       GROUP BY UL.nLevel_ID

       ) AS Cancelled
       ON Cancelled.sLevel = Active.sLevel
       ".$sqlWhere."
       ORDER BY sLevel";
$result = $dbo->select( $sql );
if ( $result ){
    while($row = $dbo->getarray( $result )){
            ?>
        <tr>
         <td class="gridOptions1"><?php echo $row['sLevel']?></td>
         <td class="gridOptions1" align="right"><?php echo $row['nActiveMembers']?></td>
         <td class="gridOptions1" align="right"><?php echo $row['nCancelledMembers']?></td>
        </tr>
		<?php
            $totalActiveMembers = $totalActiveMembers + $row['nActiveMembers'];
            $totalCancelledMembers = $totalCancelledMembers + $row['nCancelledMembers'];
            $sql = "
         SELECT
           PP.sPlanName,
           PR.sProcessorName,
           IFNULL(Active.nCount,0) AS nActiveCount,
           IFNULL(Cancelled.nCount,0) AS nCancelledCount,
           IFNULL(nTotalCount,0) AS nTotalCount
         FROM tblpaymentplans PP
         LEFT JOIN
         (
         SELECT
           PP.nPaymentPlan_ID,
           sPlanName,
           COUNT(UL.nPaymentPlan_ID) AS nCount
         FROM tblpaymentplans PP
         INNER JOIN tbluserlevels UL ON UL.nPaymentPlan_ID = PP.nPaymentPlan_ID
         INNER JOIN tblusers U ON U.nUser_ID = UL.nUser_ID
         WHERE UL.nLevel_ID = ".$row['nLevel_ID']." AND UL.nDateCancelled = 0
         GROUP BY UL.nPaymentPlan_ID
         ) AS Active ON Active.nPaymentPlan_ID = PP.nPaymentPlan_ID
         LEFT JOIN (
         SELECT
           PP.nPaymentPlan_ID,
           sPlanName,
           COUNT(UL.nPaymentPlan_ID) AS nCount
         FROM tblpaymentplans PP
         INNER JOIN tbluserlevels UL ON UL.nPaymentPlan_ID = PP.nPaymentPlan_ID
         INNER JOIN tblusers U ON U.nUser_ID = UL.nUser_ID
         WHERE UL.nLevel_ID = ".$row['nLevel_ID']." AND UL.nDateCancelled > 0
         GROUP BY UL.nPaymentPlan_ID
         ) AS Cancelled ON Cancelled.nPaymentPlan_ID = PP.nPaymentPlan_ID
         LEFT JOIN (
         SELECT
           PP.nPaymentPlan_ID,
           sPlanName,
           COUNT(UL.nPaymentPlan_ID) AS nTotalCount
         FROM tblpaymentplans PP
         INNER JOIN tbluserlevels UL ON UL.nPaymentPlan_ID = PP.nPaymentPlan_ID
         INNER JOIN tblusers U ON U.nUser_ID = UL.nUser_ID
         WHERE UL.nLevel_ID = ".$row['nLevel_ID']."
         ) AS Total ON Total.nPaymentPlan_ID
         INNER JOIN tblpaymentprocessors PR
         ON PR.nPaymentProcessor_ID = PP.nPaymentProcessor_ID
         WHERE (NOT Active.nCount IS NULL OR NOT Cancelled.nCount IS NULL)
         ORDER BY nActiveCount DESC, sProcessorName
        ";
            $result1 = $dbo->select( $sql );
			if($result1){
				while($row1 = $dbo->getarray( $result1 )){
					?>
                     <tr>
            <td class="gridOptions1 small1">&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $row1['sPlanName']." (".$row1['sProcessorName'].")" ?></td>
            <td class="gridOptions1 small1" align="right"><?php echo $row1['nActiveCount']?></td>
            <td class="gridOptions1 small1" align="right"><?php echo $row1['nCancelledCount']?></td>
           </tr>
                    <?php
					}
				}
           ?>
          
          <?php }
	?>
    <tr>
        <td class="gridFooter"><strong>Totals</strong></td>
        <td class="gridFooter" align="right"><strong><?php echo $totalActiveMembers ?></strong></td>
        <td class="gridFooter" align="right"><strong><?php echo $totalCancelledMembers ?></strong></td>
       </tr>
    
	   <?php }
else{ ?>
    <tr><td colspan="5" class="gridOptions1" align="center">No data to display</td></tr>
	<?php } ?>
    </table>

     <br />
        
    </td>
   </tr>
  </table>
 <?php include_once( "b.php" ); ?>
</body>
</html>