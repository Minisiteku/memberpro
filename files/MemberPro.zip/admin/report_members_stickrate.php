<?php

include_once( "../conn.php" );
include_once( "../functions.php" );

?><html>
  <head>
    <title><?php echo $admintitle; ?></title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<?php include ('inc-head.php')?>
 <script language="javascript">
  function changeDropdown() {
   var dropdown = document.getElementById('nDropdownID');
   var index = dropdown.selectedIndex;
   var ddVal = dropdown.options[index].value;
   document.location.href = 'report_members_level.php?cmd=' + ddVal;
  }
  </script>
 <style>
   .small1 {
    font-size: 11px; 
    margin-left: 20px; 
    color: grey;
   }
   
   #note {
    margin-top: 5px;
    margin-bottom: 20px;
    font-size: 10px;
   }
   #note span {
    background-color: #FFC;
    padding: 5px;
   }
  </style>
 </head>
 <body leftmargin="0" topmargin="0" rightmargin="0">
  <?php include_once( "top.php" ) ?>
  <table cellpadding="0" cellspacing="0" width="100%">
   <tr>
    <td width="210" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
<?php include_once( "leftreports.php" ); ?>
</td>
    <td width="100%" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">
     <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
      <tr>
       <td nowrap="nowrap" class="navRow1"> Reports &raquo; Member Stick Rate By Level </td>
       <td class="navRow2" width="100%">&nbsp;</td>
      </tr>
     </table>
     
     <h2>Member Stick Rate By Level</h2>
     <div id="note">
<span>
<strong>Please note:</strong> The report below shows only levels that have <strong>recurring</strong> payment plans.</span></div>
     
     <table cellspacing="1" cellpadding="0" border="0" class="gridTable">
      <tr>
       <td class="gridHeader">Level</td>
       <td class="gridHeader">Average Months Members Remain Active</td>
      </tr>
     <?php
$sql = "
       SELECT 
         sLevel,
         sPlanName,
         sProcessorName,
         ROUND(AVG(nDaysJoined)/30,2) AS nAverageMonths,
         ROUND(MAX(nDaysJoined)/30,2) AS nMaxMonths,
         ROUND(MIN(nDaysJoined)/30,2) AS nMinMonths
       FROM (
       SELECT
         PP.nMembershipLevel_ID,
         PR.sProcessorName,
         PP.nPaymentPlan_ID,
         sPlanName,
         DATEDIFF(DATE(IF(UL.nDateCancelled>0, UL.nDateCancelled, CURDATE())), DATE(U.nJoinDate)) AS nDaysJoined
       FROM tblpaymentplans PP
       INNER JOIN tbluserlevels UL ON UL.nPaymentPlan_ID = PP.nPaymentPlan_ID
       INNER JOIN tblusers U ON U.nUser_ID = UL.nUser_ID
       INNER JOIN tblpaymentprocessors PR ON PR.nPaymentProcessor_ID = PP.nPaymentProcessor_ID
       WHERE (UL.nDateCancelled > 0 AND UL.nDateCancelled > 19000101) 
       OR (UL.nDateCancelled = 0)
       AND PP.nOneTimePayment = 0
       ) AS tbl1
       INNER JOIN tblmembershiplevels ML
       ON ML.nLevel_ID = tbl1.nMembershipLevel_ID
       GROUP BY nPaymentPlan_ID
       ORDER BY nMembershipLevel_ID";
	   
$result = $dbo->select( $sql );
if ( $result ){
    while ( $row = $dbo->getarray( $result ) )
    {
        if ( $level != $row['sLevel'] )
        {
            ?>
         <tr>
          <td class="gridOptions1"><?php echo $row['sLevel']?></td>
          <td class="gridOptions1" align="right">&nbsp;</td>
         </tr>
		 <?php 
            $level = $row['sLevel'];}
        ?>
        <tr>
         <td class="gridOptions1 small1"><?php echo $row['sPlanName'];?> ( <?php echo $row['sProcessorName'];?> )</td>
         <td class="gridOptions1 small1" align="right">
		 <?php echo $row['nAverageMonths']?> months <em>(max: <?php echo $row['nMaxMonths']?> months, min: <?php echo $row['nMinMonths']?> months)</em></td>
        </tr>
    <?php }
	
	}
else{?> 
<tr>
<td colspan="5" class="gridOptions1" align="center">No data to display</td></tr>
<?php } ?>

</table>
        </td>
   </tr>
  </table>

<?php include_once( "b.php" );?>
</body>
</html>