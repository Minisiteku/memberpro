<?php

include_once( "../conn.php" );
include_once( "../functions.php" );
?>
<html>
  <head>
    <title><?php echo $admintitle; ?></title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<?php include ('inc-head.php')?>

<script language="javascript">
  function changeDropdown() {
   var dropdown = document.getElementById('nDropdownID');
   var index = dropdown.selectedIndex;
   var ddVal = dropdown.options[index].value;
   document.location.href = 'report_refunds_level.php?cmd=' + ddVal;
  }
  </script>
<style>
   .small1 {
    font-size: 11px; 
    margin-left: 20px; 
    color: grey;
   }
  </style>
 </head>
 <body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once( "top.php" );?>
<table cellpadding="0" cellspacing="0" width="100%">
   <tr>
    <td width="600%" colspan="6" class="menuRow3_members">&nbsp;</td>
   </tr>
  </table>
  <table cellpadding="0" cellspacing="0" width="100%">
   <tr>
    <td width="210" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
	<?php include_once( "leftreports.php" ); ?></td>
    <td width="100%" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">
     <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
      <tr>
       <td nowrap="nowrap" class="navRow1"> Reports &raquo; Refunds By Level </td>
       <td class="navRow2" width="100%">&nbsp;</td>
      </tr>
     </table>
     
     <h2>Refunds By Level</h2>
     
<?php
if ( isset( $_GET['cmd'] ) && $_GET['cmd'] == "active" )
{
    $selectedActive = "selected";
    $selectedAll = "";
    $sqlWhere = " AND L.nActive=1";
}
else if ( isset( $_GET['cmd'] ) && $_GET['cmd'] == "all" )
{
    $selectedActive = "";
    $selectedAll = "selected";
    $sqlWhere = "";
}
else
{
    $sqlWhere = " AND L.nActive=1";
}
?>     
     <div>
      <form>
<select id="nDropdownID" onChange="changeDropdown();">
<option value="active" <?php $selectedActive; ?>>Show Active Levels Only</option>
        <option value="all" <?php echo $selectedAll ?>>Show All Levels</option>
       </select>
      </form>      
     </div>
     
     <table cellspacing="1" cellpadding="0" border="0" class="gridTable">
      <tr>
       <td class="gridHeader">Level</td>
       <td class="gridHeader">Refunds</td>
       <td class="gridHeader">Refund %</td>
      </tr>
      <?php
$sql = "
       SELECT 
         Sales.sLevel,
         Sales.sPlanName,
         Sales.sProcessor,
         nSales,
         IFNULL(nRefunds,0) AS nRefunds
       FROM
       (
       SELECT 
         PP.nPaymentPlan_ID,
         sLevel,
         COUNT(UL.nLevel_ID) AS nSales,
         sPlanName,
         sProcessor
       FROM tblmembershiplevels L
       INNER JOIN tbluserlevels UL ON UL.nLevel_ID = L.nLevel_ID
       INNER JOIN tbltransactions T ON T.sTransactionNumber = UL.sTransactionNumber
       INNER JOIN tblpaymentplans PP ON PP.nPaymentPlan_ID = UL.nPaymentPlan_ID
       INNER JOIN tblpaymentprocessors PR ON PR.nPaymentProcessor_ID = PP.nPaymentProcessor_ID
       WHERE T.nTransactionType_ID = 1 ".$sqlWhere."
       GROUP BY PP.nPaymentPlan_ID
       ) AS Sales 
       LEFT JOIN (
       SELECT 
         PP.nPaymentPlan_ID,
         sLevel,
         COUNT(UL.nLevel_ID) AS nRefunds,
         sPlanName,
         sProcessor
       FROM tblmembershiplevels L
       INNER JOIN tbluserlevels UL ON UL.nLevel_ID = L.nLevel_ID
       INNER JOIN tbltransactions T ON T.sTransactionNumber = UL.sTransactionNumber
       INNER JOIN tblpaymentplans PP ON PP.nPaymentPlan_ID = UL.nPaymentPlan_ID
       INNER JOIN tblpaymentprocessors PR ON PR.nPaymentProcessor_ID = PP.nPaymentProcessor_ID
       WHERE T.nTransactionType_ID = 2 ".$sqlWhere."
       GROUP BY PP.nPaymentPlan_ID
       ) AS Refunds ON Sales.nPaymentPlan_ID = Refunds.nPaymentPlan_ID
       ORDER BY Sales.sLevel, nRefunds DESC
      ";
$result = $dbo->select( $sql );
if ( $result )
{
    while ( $row = $dbo->getarray( $result ) )
    {
        if ( $row['sLevel'] != $level )
        {
            ?>
        <tr>
         <td class="gridOptions1"><?php echo $row['sLevel'] ?></td>
         <td class="gridOptions1" align="right">&nbsp;</td>
         <td class="gridOptions1" align="right">&nbsp;</td>
        </tr><?php
            $level = $row['sLevel'];
        }
        ?>
        <tr>
         <td class="gridOptions1 small1"><?php echo $row['sPlanName']?></td>
         <td class="gridOptions1 small1" align="right"><?php echo $row['nRefunds'] ?></td>
         <td class="gridOptions1 small1" align="right"><?php echo number_format( $row['nRefunds'] / $row['nSales'] * 100, 1 )?>%</td>
        </tr>
		<?php
    }
}
?><tr><td colspan="3" class="gridOptions1" align="center">No data to display</td></tr>
</table>

     <br />
        
    </td>
   </tr>
  </table>

<?php include_once( "b.php" );?>
</body>
</html>
