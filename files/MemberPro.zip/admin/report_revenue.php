<?php

include_once( "../conn.php" );
include_once( "../functions.php" );
?>
<html>
  <head>
    <title><?php echo $admintitle; ?></title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<?php include ('inc-head.php')?>
  <script type="text/javascript" src="../js/swfobject.js"></script>
  <script type="text/javascript">
   swfobject.embedSWF("common/open-flash-chart.swf", "admin_chart_revenue", "900", "200", "9.0.0", "expressInstall.swf", {"data-file":"report_revenue_data.php?y=<?php
echo isset( $_GET['y'] ) ? $_GET['y'] : date( "Y" );?>"} );
  </script>
  <script language="javascript">
  function changeYear() {
   var dropdown = document.getElementById('nYear');
   var index = dropdown.selectedIndex;
   var ddVal = dropdown.options[index].value;
   document.location.href = 'report_revenue.php?y=' + ddVal;
  }
  </script>
  <style>
   #note {
    margin-top: 5px;
    margin-bottom: 20px;
    font-size: 10px;
   }
   #note span {
    background-color: #FFC;
    padding: 5px;
   }
  </style>
  
 </head>
 <body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once( "top.php" );?>  
<table cellpadding="0" cellspacing="0" width="100%">
   <tr>
    <td width="600%" colspan="6" class="menuRow3_members">&nbsp;</td>
   </tr>
  </table>
  <table cellpadding="0" cellspacing="0" width="100%">
   <tr>
    <td width="210" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
<?php include_once( "leftreports.php" );?>
</td>
    <td width="100%" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">
     <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
      <tr>
       <td nowrap="nowrap" class="navRow1"> Reports &raquo; Revenue By Month </td>
       <td class="navRow2" width="100%">&nbsp;</td>
      </tr>
     </table>
     
     <div id="note"><span><strong>Please note:</strong> This chart displays <strong>NET</strong> revenue after refunds and affiliate payments have been deducted.</span></div>
     
     <div id="chooseyear">
      <strong>Choose Year</strong>: 
      <select id="nYear" onChange="changeYear();">
      <?php
$i = 0;
while ( $i < 5 )
{
    $year = date( "Y" ) - $i;
   $selected = $year == $_GET['y'] ? "selected" : "";
    echo "<option value=\"".$year."\" ".$selected.">".$year."</option>";
    ++$i;
	
}

?>
      </select>      
     </div>
        
     <div align="center" id="admin_chart_revenue" ></div>              

     <!-- Breakdown -->
     
     <h2>Monthly Breakdown</h2>
     
     <table cellspacing="1" cellpadding="0" border="0" class="gridTable">
      <tr>
       <td class="gridHeader">Month</td>
       <td class="gridHeader">No. of Sales</td>
       <td class="gridHeader">Amount of Sales</td>
       <td class="gridHeader">No. of Refunds</td>
       <td class="gridHeader">Amount of Refunds</td>
       <td class="gridHeader">Total Amount of Affiliate Payments</td>
       <td class="gridHeader">Total Net Amount</td>
      </tr>
   <?php
$year = isset( $_GET['y'] ) ? $_GET['y'] : date( "Y" );
$curSymbol = get_currency_symbol( $chkSsettings->sCurrencyFormat );
$chartArrayData = array( "Jan" => array( 0, 0, 0, 0, 0, 0 ), "Feb" => array( 0, 0, 0, 0, 0, 0 ), "Mar" => array( 0, 0, 0, 0, 0, 0 ), "Apr" => array( 0, 0, 0, 0, 0, 0 ), "May" => array( 0, 0, 0, 0, 0, 0 ),"Jun" => array( 0, 0, 0, 0, 0, 0 ), "Jul" => array( 0, 0, 0, 0, 0, 0 ), "Aug" => array( 0, 0, 0, 0, 0, 0 ), "Sep" => array( 0, 0, 0, 0, 0, 0 ), "Oct" => array( 0, 0, 0, 0, 0, 0 ), "Nov" => array( 0, 0, 0, 0, 0, 0 ), "Dec" => array( 0, 0, 0, 0, 0, 0 ) );
$sql = "
       SELECT 
         Sales.sMonth, 
         ROUND(IFNULL(Sales.nSales,0),2) AS nSales, 
         IFNULL(nNoOfSales,0) AS nNoOfSales,
         ROUND(IFNULL(Refunds.nRefunds,0),2) AS nRefunds,
         IFNULL(nNoOfRefunds,0) AS nNoOfRefunds,
         ROUND(IFNULL(AffiliatePayments.nAffiliateAmount,0),2) AS nAffiliateAmount,
         IFNULL(nNoOfAffPayments, 0) AS nNoOfAffPayments,
         ROUND((IFNULL(nSales,0) + IFNULL(nRefunds,0)) - IFNULL(nAffiliateAmount,0),2) As nNetIncome
       FROM
       (
       SELECT 
         MONTH(dDateTime) AS sMonth, 
         SUM(nSaleAmount) AS nSales,
         COUNT(nTransaction_ID) AS nNoOfSales
       FROM tbltransactions
       WHERE 
         YEAR(dDateTime) = '{$year}' 
         AND nTransactionType_ID = 1
       GROUP BY sMonth
       ) AS Sales 
       LEFT JOIN
       (
       SELECT 
         MONTH(dDateTime) AS sMonth, 
         SUM(nSaleAmount) AS nRefunds,
         COUNT(nTransaction_ID) AS nNoOfRefunds
       FROM tbltransactions
       WHERE 
         YEAR(dDateTime) = '{$year}' 
         AND nTransactionType_ID = 2
       GROUP BY sMonth
       ) AS Refunds ON Refunds.sMonth = Sales.sMonth
       LEFT JOIN (
       SELECT 
         MONTH(nTimeStamp) AS sMonth, 
         SUM(nCommission) AS nAffiliateAmount,
         COUNT(nAffiliatePayment_ID) AS nNoOfAffPayments
       FROM tblaffiliatepayments
       WHERE 
         YEAR(nTimeStamp) = '{$year}' 
       GROUP BY sMonth
       ) AS AffiliatePayments ON AffiliatePayments.sMonth = Refunds.sMonth
      ";
$result = $dbo->select( $sql );
if ( $result )
{
    while ( $row = $dbo->getarray( $result ) )
    {
        $month = date( "M", mktime( 0, 0, 0, $row['sMonth'], 1, $year ) );
        $chartArrayData[$month][0] = $row['nNoOfSales'];
        $chartArrayData[$month][1] = number_format( $row['nSales'], 2 );
        $chartArrayData[$month][2] = $row['nNoOfRefunds'];
        $chartArrayData[$month][3] = number_format( $row['nRefunds'], 2 );
        $chartArrayData[$month][4] = number_format( $row['nAffiliateAmount'], 2 );
        $chartArrayData[$month][5] = number_format( $row['nNetIncome'], 2 );
        $totalNoOfSales = $totalNoOfSales + $row['nNoOfSales'];
        $totalSales = $totalSales + $row['nSales'];
        $totalNoOfRefunds = $totalNoOfRefunds + $row['nNoOfRefunds'];
        $totalRefunds = $totalRefunds + $row['nRefunds'];
        $totalAffiliates = $totalAffiliates + $row['nAffiliateAmount'];
        $totalNet = $totalNet + $row['nNetIncome'];
    }
    foreach ( $chartArrayData as $key => $value )
    {
        ?>
        <tr>
         <td class="gridOptions1"><?php echo $key ?></td>
         <td class="gridOptions1"><?php echo $value[0] ?></td>
         <td class="gridOptions1"><?php echo $curSymbol.$value[1] ?></td>
         <td class="gridOptions1"><?php echo $value[2] ?></td>
         <td class="gridOptions1"><?php echo $curSymbol.$value[3] ?></td>
         <td class="gridOptions1">-<?php echo $curSymbol.$value[4] ?></td>
         <td class="gridOptions1"><?php echo $curSymbol.$value[5] ?></td>
        </tr><?php
    }
    ?><tr>
        <td class="gridFooter"><strong>Totals</strong></td>
        <td class="gridFooter"><strong><?php echo $totalNoOfSales ?></strong></td>
        <td class="gridFooter"><strong><?php echo $curSymbol.number_format( $totalSales, 2 ) ?></strong></td>
        <td class="gridFooter"><strong><?php echo $totalNoOfRefunds ?></strong></td>
        <td class="gridFooter"><strong><?php echo $curSymbol.number_format( $totalRefunds, 2 ) ?></strong></td>
        <td class="gridFooter"><strong><?php echo $curSymbol.number_format( 0 - $totalAffiliates, 2 ) ?></strong></td>
        <td class="gridFooter"><strong><?php echo $curSymbol.number_format( $totalNet, 2 ) ?></strong></td>
       </tr><?php
}
else
{
    ?><tr><td colspan="7" class="gridOptions1" align="center">No data to display</td></tr><?php
}
?>     </table>

     <br />
        
    </td>
   </tr>
  </table>
<?php include_once( "b.php" );?>
</body>
</html>
