<?php
include_once( "../conn.php" );
include_once( "../functions.php" );
?>
<html>
  <head>
    <title><?php echo $admintitle; ?></title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<?php include ('inc-head.php')?>
  <script type="text/javascript" src="../js/swfobject.js"></script>
  <script type="text/javascript">
   swfobject.embedSWF("common/open-flash-chart.swf", "chart", "900", "300", "9.0.0", "expressInstall.swf", {"data-file":"report_revenue_30days_data.php"} );
  </script>
  
 </head>
 <body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once( "top.php" );?>
<table cellpadding="0" cellspacing="0" width="100%">
   <tr>
    <td width="600%" colspan="6" class="menuRow3_members">&nbsp;</td>
   </tr>
  </table>
  <table cellpadding="0" cellspacing="0" width="100%">
   <tr>
    <td width="210" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
<?php include_once( "leftreports.php" ); ?></td>
    <td width="100%" valign="top" style="padding-left: 8px; padding-top: 8px; padding-right: 8px;">
     <table class="navTable" cellpadding="0" cellspacing="0" width="100%">
      <tr>
       <td nowrap="nowrap" class="navRow1"> Reports &raquo; Revenue In Last 30 Days </td>
       <td class="navRow2" width="100%">&nbsp;</td>
      </tr>
     </table>
       
     <div align="center" id="chart" ></div>             

     <br />
        
    </td>
   </tr>
  </table>
<?php include_once( "b.php" ); ?>
</body>
</html>