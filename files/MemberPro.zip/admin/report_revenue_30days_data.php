<?php

include( "common/php/ofc/open-flash-chart.php" );
include_once( "../conn.php" );
include_once( "../functions.php" );
$title = new title( "Revenue Earned Over The Past 30 Days" );
$now_date = date( "Y-m-d" );
$last_month_stamp = strtotime( "-30 days", time( ) );
$last_month_date = date( "Y-m-d", $last_month_stamp );
$date = $last_month_date;
$stamp = $last_month_stamp;
$list = array( );
$max = 0;
while ( $date <= $now_date )
{
    $list[$date] = array( "revenue" => 0 );
    $stamp = $stamp + 86400;
    $date = date( "Y-m-d", $stamp );
}
$sql = "SELECT SUM(nSaleAmount) as nCount,  dDateTime FROM tbltransactions WHERE ntransactiontype_id = 1 and dDateTime >= '{$last_month_date}' GROUP BY YEAR(dDateTime), MONTH(dDateTime) , DAY(dDateTime) ASC";
$rs = $dbo->select( $sql );
while ( $row = @$dbo->getassoc( @$rs ) )
{
    $dDateTime = substr( $row['dDateTime'], 0, 10 );
    $count = $row['nCount'];
    $list[$dDateTime]['revenue'] = $count;
    if ( $max < $count )
    {
        $max = ( integer )$count;
    }
}
$data_revenue = array( );
$x_labels = array( );
foreach ( $list as $date => $value )
{
    $data_revenue[] = ( integer )$value['revenue'];
    $x_labels[] = date( "D jS M", strtotime( $date ) );
}
$bar = new bar_glass( );
$bar->colour( "#009933" );
$bar->key( "Revenue", 12 );
$bar->set_values( $data_revenue );
$bar->set_tooltip( "\$".( "#val#" ) );
$x = new x_axis( );
$x->set_colours( "#666666", "#cccccc" );
$x->set_offset( 10 );
$x_labels1 = new x_axis_labels( );
$x_labels1->set_vertical( );
$x_labels1->set_labels( $x_labels );
$x->set_labels( $x_labels1 );
$y = new y_axis( );
$y->set_colours( "#666666", "#cccccc" );
$curSymbol = get_currency_symbol( $chkSsettings->sCurrencyFormat );
$y->set_label_text( $curSymbol."#val#" );
$max = ( substr( $max, 0, 1 ) + 1 ) * pow( 10, strlen( $max ) - 1 );
$grade = pow( 10, strlen( $max ) - 1 );
$y->set_range( 0, $max, $grade );
$chart = new open_flash_chart( );
$chart->set_bg_colour( "ffffff" );
$chart->set_x_axis( $x );
$chart->set_y_axis( $y );
$title->set_style( "{font-size: 18px; font-family: Verdana; font-weight: bold; color: #000000; text-align: center; margin-bottom: 5px; }" );
$chart->set_title( $title );
$chart->add_element( $bar );
$chart->set_number_format( 2, 1, 0, 0 );
echo $chart->toString( );
?>
