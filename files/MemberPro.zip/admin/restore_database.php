<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	if (isset($_POST['Restore'])) {
		if (isset($_POST['backupfile'])) {
			// Unzip file first
			$command = "gzip -d dump/".$_POST['backupfile'];
			$unzipped = basename($_POST['backupfile'], ".gz");			
			system($command, $result);
			if ($result == 0) {
				// Restore Backup
				$command = "mysql -u $db_username --password='$db_password' $db_name < dump/$unzipped";
				system($command, $return);
				if ($return == 1) $error = "restore";
				// Rezip File
				$command = "gzip dump/$unzipped";
				system($command, $return);
				if ($return == 1) $error = "zip";
				$message = "<p class='success'>Database restored successfully.</p>";
			}
		} else {
			$message = "<p class='error'>Please select a backup file to restore from</p>";			
		}			
	}
	
	function getBackupList() {
		$list = '';
		if ($handle = opendir('dump')) {
		    while (false !== ($file = readdir($handle))) {
		        if ($file != "." && $file != ".." && substr($file, strrpos($file,'.')+1) == 'gz') {
		            $list[] = $file;
		        }
		    }
		    closedir($handle);
		}
		@arsort($list);
		return $list;
	}

	
?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php include("inc-head.php"); ?>
		<style>
			LABEL {cursor:pointer}	
		</style>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0" onLoad="isReady=true">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
			<?php include_once('backupleft.php'); ?>
		</td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			<table class="navTable" width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td class="navRow1" width="100px"><span>Restore</span></td>
				</tr>
			</table>
			
			<?php echo isset($message) ? $message : '' ?>
			
			<!-- START TABLE LISTING -->
			<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
				<tr>
					<td class="gridHeader">Available Database Backups</td>
				</tr>
				<tr>
					<td class="gridRow1">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<form method="post" action="restore_database.php">
							<?php
								// Get the list of all tables from the database '$dbName'
								$back = getBackupList();	
								$cells = 4;							// Cells across (need to change cell width accordingly)
								if (!empty($back)) {	
									$i = 0;								
									foreach ($back as $item) {
										if ($i++ % $cells == 0) {
											if ($i == 1) 	echo "<tr>";
											else echo "</tr><tr>";
										}
										$display = explode('_',$item);
										$checked = ($item == $_POST['backupfile']) ? 'checked' : '';
										echo sprintf("<td class='gridRow1' style='width:25%%'><input type='radio' name='backupfile' value='%s' id='%s' %s style='margin-bottom:0px; margin-right:5px'><label for='%s'>%s</label></td>", $item, $item, $checked, $item, date('Y-m-d H:i(s) A',$display[3]));
									}	
									// Fill in missing table cells								 
									$start = ($i - intval($i / $cells) * $cells);
									if ($start > 0)
										for ($j = $start + 1; $j < $cells+1; $j++) echo "<td class='gridRow1'>&nbsp;</td>";
									echo "</tr>";									
								} else {
									echo "<div class='success' style='text-align:center; padding-top:5px; padding-bottom:8px'>No Backups Found.</div>";
								}
							?>
							<tr>
								<td colspan="4" class="gridHeader">
									<input type="submit" name="Restore" value="Restore">
								</td>
							</tr>
							</form>
						</table>
						<div style="margin-top:20px">
							Remember, you can have a daily database backup emailed to you automatically if required.
							Just <a href="script_settings.php">click here</a> and tick the "Daily Backup" checkbox.
						</div>
					</td>
				</tr>
				<tr>
					<td class="gridFooter">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td valign="top"></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>
	</body>
</html>