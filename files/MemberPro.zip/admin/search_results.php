<?php
include_once('../conn.php');
include_once('../functions.php');

// Activate / Deactivate Member
if (isset($_GET['active']) && is_numeric($_GET['active']))
{
	$sql = "UPDATE tblusers SET nActive = '" . $dbo->format($_GET['active']) . "' WHERE nUser_ID=" . $dbo->format($_GET['id']);
	$dbo->update($sql);
}

// Delete Member
if (isset($_GET['id']) && $_GET['act'] == 'd' && isset($_GET['id']) && is_numeric($_GET['id'])) {
	$dbo->delete("DELETE FROM tblusers WHERE nUser_ID = " . $dbo->format($_GET['id']) . " LIMIT 1");
}

// Set variable to hold search string
if (isset($_GET['st'])) {
	$st = $_GET['st'];
}
?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php include("inc-head.php"); ?>
		<script type="text/javascript">
			function cdel(w)
			{ 
				if (confirm("Are you sure you want to delete this member?")) return true;
				else return false;
			}
		</script>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once('memberleft.php'); ?></td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;"  valign="top" width="100%">
			<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td class="navRow1" nowrap="nowrap"> <a class="nav" href="#">Members</a></td>
					<td width="100%" align="left" class="navRow2"> &nbsp;- Search Results </td>
				</tr>
			</table>
			
			<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
				<tr>
					<td width="227" class="gridHeader">
<?php
	if ($_GET['sort'] == 'fname' && $_GET['type'] == 'asc')
	{
		echo "<a href=\"search_results.php?sort=fname&type=desc&st=$st\" class=\"bluenave\">First Name</a>";
	}
	elseif ($_GET['sort'] == 'fname' && $_GET['type'] == 'desc')
	{
		echo "<a href=\"search_results.php?sort=fname&type=asc&st=$st\" class=\"bluenave\">First Name</a>";
	}
	else
	{
		echo "<a href=\"search_results.php?sort=fname&type=asc&st=$st\" class=\"bluenave\">First Name</a>";
	}
?>
					</td>
					<td class="gridHeader" align="left" nowrap="nowrap" width="227">
<?php
	if ($_GET['sort'] == 'lname' && $_GET['type'] == 'asc')
	{
		echo "<a href=\"search_results.php?sort=lname&type=desc&st=$st\" class=\"bluenave\">Last Name</a>";
	}
	elseif ($_GET['sort'] == 'lname' && $_GET['type'] == 'desc')
	{
		echo "<a href=\"search_results.php?sort=lname&type=asc&st=$st\" class=\"bluenave\">Last Name</a>";
	} 
	else
	{
		echo "<a href=\"search_results.php?sort=lname&type=asc&st=$st\" class=\"bluenave\">Last Name</a>";
	}
?>
					</td>
					<td class="gridHeader" align="center" nowrap="nowrap" width="100">Join Date</td>
					<td class="gridHeader" align="center" nowrap="nowrap" width="79">Referrer</td>
					<td colspan="3" align="center" nowrap="nowrap" class="gridHeader">Actions</td>
					<td class="gridHeader" align="center" nowrap="nowrap">&nbsp;</td>
				</tr>
<?php
	if ($_POST['search1'] != '')
	{
		$sql = "SELECT * FROM tblusers WHERE sforename LIKE '" . $dbo->format($_POST['search1']) . "%'  OR ssurname LIKE '" . $dbo->format($_POST['search1']) . "%' OR semail LIKE '" . $dbo->format($_POST['search1']) . "%'";
	}
	
	if ($_GET['st'] != '')
	{
		$sql="SELECT * FROM tblusers WHERE sforename LIKE '" . $dbo->format($_GET['st']) . "%' OR ssurname LIKE '" . $dbo->format($_GET['st']) . "%'  OR semail LIKE  '" . $dbo->format($_GET['st']) . "%'";
	}
	
	$resultcs = $dbo->select($sql);
	$n = $dbo->nr($resultcs);
	$number = $n; // record results selected from database
	$displayperpage = "10"; // record displayed per page
	$pageperstage = "10"; // page displayed per stage
	$allpage = ceil($number / $displayperpage);
	$allstage = ceil($allpage / $pageperstage); // how many page will it be?
	
	if ( trim($startpage) == '') { $startpage = 1; }
	if ( trim($_GET['nowstage']) == '') { $_GET['nowstage'] = 1; }
	if ( trim($_GET['nowpage']) == '') { $_GET['nowpage'] = $startpage; }
	
	$StartRow = 0;
	
	if ( empty($_GET['nowpage']) )
	{
		if($StartRow == 0)
		{
			$_GET['nowpage'] = $StartRow + 1;
		}
	} 
	else
	{
		$nowpage = $_GET['nowpage'];
		$StartRow = ($nowpage - 1) * $displayperpage;
	}
	
	$c = 1;
	
	if ($_POST['search1'] != '')
	{
		$sql = "SELECT * FROM tblusers WHERE sforename LIKE '" . $dbo->format($_POST['search1']) . "%'  OR ssurname LIKE '" . $dbo->format($_POST['search1']) . "%' OR semail LIKE '" . $dbo->format($_POST['search1']) . "%'";
	}
	
	if ($_GET['st'] != '')
	{
		$sql="SELECT * FROM tblusers WHERE sforename LIKE '" . $dbo->format($_GET['st']) . "%' OR ssurname LIKE '" . $dbo->format($_GET['st']) . "%'  OR semail LIKE  '" . $dbo->format($_GET['st']) . "%'";
	}
	
	$result = $dbo->select($sql);
	$num1 = $dbo->nr($result);
	
	while ($row = $dbo->getobj($result)) :
?>
				<tr>
					<td class="gridRow1"><a class="bluenave" href="view_member.php?id=<?php echo $objPending->nUser_ID ?> " title="View Member Details"><strong><?php echo $row->sForename; ?></strong></a>&nbsp;</td>
					<td class="gridRow1" align="left"><?php echo $row->sSurname; ?>&nbsp;</td>
					<td class="gridOptions1" align="center"><?php echo fShowDate($chkSsettings->nDateFormat, $row->nJoinDate); ?>&nbsp;</td>
					<td class="gridOptions1" align="center">
					<?php
						$rwAffiliate = $dbo->getobject("SELECT * FROM tblusers WHERE nuser_id = $row->nAffiliate_ID");
						echo $rwAffiliate->sForename . "&nbsp;" . $rwAffiliate->sSurname;
					?>
					</td>
					<td class="gridActions1" align="center" width="44">
					<?php if ($_POST['search1'] != '') $st = $_POST['search1']; ?>
					<?php if ($row->nUser_ID == 1) : ?>
						<a href="#" onClick="javascript:alert('You cannot deactivate the admin user.');return false;"><img src="images/dropd.gif" alt="Not allowed to deactivate the admin user" width="16" height="16" border="0" /></a> 
					<?php else : ?>
						<?php if ($row->nActive == 0) : ?>
						<a href="<?php echo $_SERVER['PHP_SELF']; ?>?active=1&id=<?php echo $row->nUser_ID; ?>&id=<?php echo $row->nUser_ID; ?>&st=<?php echo $st; ?>" class="black"><img src="images/adult_r.gif" alt="Not Active" width="16" height="16" border="0" /></a>
						<?php else : ?>
						<a href="<?php echo $_SERVER['PHP_SELF']; ?>?active=0&id=<?php echo $row->nUser_ID; ?>&id=<?php echo $row->nUser_ID; ?>&st=<?php echo $st; ?>" class="black"><img src="images/adult_off.gif" alt="Active" width="16" height="16" border="0" /></a>
						<?php endif; // ($row->nActive == 0) ?>
					<?php endif; // ($row->nUser_ID == 1) ?>
					</td>
					<td class="gridActions1" align="center" width="43">
						<a class="grid" href="view_member.php?id=<?php echo $objPending->nUser_ID ?> " title="View Member Details"><img src="images/edit.gif" alt="Edit member" border="0" /></a>
					</td>
					<td class="gridActions1" align="center" width="43">
					<?php if ($row->nUser_ID == 1) : ?>
						<a class="grid" href="#" title="Delete member" OnClick="javascript:alert('You are not allowed to delete the admin user.');return false;"><img src="images/dropd.gif" alt="Not allowed to delete member" border="0" /></a>
					<?php else : ?>
						<a class="grid" href="<?php echo $_SERVER['PHP_SELF']; ?>?act=d&amp;id=<?php echo $row->nUser_ID; ?>&st=<?php echo $st?>" title="Delete member"  OnClick="return cdel('employer');"><img src="images/delete.gif" alt="Delete member" border="0" /></a>
					<?php endif; // ($row->nUser_ID == 1) ?>
					</td>
					<td class="gridActions1" align="center">&nbsp;</td>
				</tr>
<?php endwhile; ?>
				<tr>
					<td colspan="8" class="gridFooter">
					
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td>
									Page
									<?php if ($number == 0) { echo '0 of 0'; } else { echo "$nowpage of $allpage"; } ?>
<?php
	// Back Button
	if ($_GET['nowstage'] == 1 && $_GET['nowpage'] == 1)
	{
		$links = '<span class="gridFaded"> &laquo; Back&nbsp;|</span>';
	}
	else
	{
		$links = '<a href="' . $_SERVER['PHP_SELF'] . '?nowstage=' . ($_GET['nowstage'] - 1) . '&nowpage=' . ($_GET['nowstage'] - 1) . '"> &laquo; Back</a>&nbsp;|';
	}
	
	// Next Button
	if ($allpage == $_GET['nowstage'] && $allpage == $_GET['nowpage'])
	{
		$links .= '<span class="gridFaded"> Next &raquo;</span>';
	}
	elseif ($number == 0)
	{
		$links .= '<span class="gridFaded"> Next &raquo;</span>';
	}
	else
	{
		$links .= '<a href="' . $_SERVER['PHP_SELF'] . '?nowstage=' . ($_GET['nowstage'] + 1) . '&nowpage=' . ($_GET['nowstage'] + 1) . '"> Next &raquo;</a>';
	}
	
	echo $links;
?>
								</td>
								<td align="right">No of records found: <?php echo $n; ?></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>
	</body>
</html>