<?php
include_once('../conn.php');
include_once('../functions.php');

// Load The Default Template Object Based on Selected
$objTemplateOptions = $dbo->getobject("SELECT * FROM tbltemplatesettings WHERE sTemplateFolder = '".TEMPLATEFOLDER."'");
$active = TEMPLATEFOLDER;
$current = TEMPLATEFOLDER;

if(isset($_GET['name'])){
	//die('here');
	$fName = $dbo->format($_GET['name']);
	$namestr = '?name='.$_GET['name'];
	// Lets Look For Activation Call ...
	
	if($_GET['a'] == '1'){
		
		// Activation requested. Set As Active.
		update_option('activetemplate',$fName);
		
		header("Location: template_setup.php?msg=Template Activated Successfully!");
		exit;
		
		}
	
	$folder = $dbo->getobject("SELECT * FROM tbltemplatesettings WHERE sTemplateFolder = '".$fName."'");
	//die("SELECT * FROM tbltemplatesettings WHERE sTemplateFolder = '".$dbo->format($_GET['name'])."'");
	if($folder){
		
		$objTemplateOptions = $folder;
		$current = $fName;
		
		unset($folder);
		}
	else{
		//die(var_dump($folder));
		// Folder Not Found In database.
		// Lets Make Sure Its A Real Folder ...
		if(is_dir('../layout/'.$dbo->format($_GET['name']))){
			
			// It Exists but is not installed, lets install it!

			// Lets get the header widths.
			
			$headimgwidth = '';
			$mheadimgwidth = '';
			$headpath = 'layout/'.$dbo->format($_GET['name']).'/images/head1.jpg';
			$footerpath = 'layout/'.$dbo->format($_GET['name']).'/images/footer1.jpg';
			$mheadpath = 'layout/'.$dbo->format($_GET['name']).'/images/head2.jpg';
			$mfooterpath = 'layout/'.$dbo->format($_GET['name']).'/images/footer2.jpg';
			$bg = 'layout/'.$dbo->format($_GET['name']).'/images/bg.jpg';
			
			list($width) = getimagesize('../layout/'.$fName.'/images/head1.jpg');
			list($width1) = getimagesize('../layout/'.$fName.'/images/head2.jpg');
			
			$sql = "
			INSERT INTO `tbltemplatesettings` 
			(`nHeaderTextBold`, `nFooterTextBold`, `sHeaderNavAlign`, `sFooterNavAlign`, `nHideHeaderNav`, `nHideFooterNav`, `nHideFooterGraphic`, `nHidePoweredByLink`, `nHideBorder`, `btmcolor1`, `bodybackground`, `headerpath`, `footerpath`, `mheaderpath`, `mfooterpath`, `headimgwidth`, `mheadimgwidth`, `mbackcolor`, `mhovercolor`, `mtextcolor`, `sFrontEndTemplateFile`, `sMemberTemplateFile`, `sLanguageFile`, `sTemplateFolder`) VALUES
(0, 0, 'right', 'right', 0, 0, 0, 0, 0, '#333399', '#999999', '$headpath', '$footerpath', '$mheadpath', '$mfooterpath', '$width', '$width1', '#FFFFFF', '#99CCFF', '#000000', '', '', 'English', '".$fName."');
			";
			$insertid = $dbo->insert($sql);
			
			
			
			
			if(!$insertid){
				$msg = "<span class='error'>Failed In Install The Template.<br />Mysql Said: {$dbo->Error}</span>";
				}
			else{
				
				// Add The Option Field
				// This is a temporary solution for a new template option.
				// This option came about by removing the images from the default template, to prevent overwriting default templates that has images added later.
				if(!is_option($fName.'_template_head_bg')){
					add_option($fName.'_template_head_bg','#333399');
				}
				if(!is_option($fName.'_template_mhead_bg')){
					add_option($fName.'_template_mhead_bg','#333399');
				}
				// Load The New Template
				$objTemplateOptions = $dbo->getobject("SELECT * FROM tbltemplatesettings WHERE sTemplateFolder = '".$fName."'");
				//$objTemplateOptions = $folder;
				$current = $fName;
				unset($folder);
				}

			}
		}
		
	
	}

if ( isset($_POST['Submit']) ){
	$c = 0;
	
	// Main Settings Error Check
	if($_POST['sTemplateFolder'] && $_POST['sTemplateFolder'] !=''){
		if(!is_dir('../layout/'.$dbo->format($_POST['sTemplateFolder']))){
			$error[$c] = 'Template Folder is not a valid directory.';
			$c++;
			}
	}
	else{$error[$c] = 'You Must Enter a Template Folder <br />';$c++;}
	
	// Template Graphics Error Check
	if ($_FILES['imgfile1']['size'] > 204800){
		$c++;
		$shp = 1;
	}
	if ($_FILES['imgfile2']['type'] > 204800){
		$c++;
		$sfp = 1;
	}
	
	if ($_FILES['imgfile3']['type'] > 204800){
		$c++;
		$smhp = 1;
	}
	if ($_FILES['imgfile4']['type'] > 204800){
		$c++;
		$smfp = 1;
	}
	if ($_FILES['imgfile5']['type'] > 204800){
		$c++;
		$smbg = 1;
	}
	
	//
	
	
	
	if ($c == 0){
		
		//die(var_dump($_POST));
		$e = 0;
		$template_remove_border = ($_POST['tmpl-remove-border'] == 'on') ? 1 : 0;
		$template_disable_poweredby_link = ($_POST['disable-poweredby-link'] == 'on') ? 1 : 0;
		$template_header_nav_align = (isset($_POST['headerNavAlign'])) ? $dbo->format($_POST['headerNavAlign']) : 'right';
		$template_footer_nav_align = (isset($_POST['footerNavAlign'])) ? $dbo->format($_POST['footerNavAlign']) : 'right';
		$template_header_text_bold = (isset($_POST['headerTextBold'])) ? 1 : 0;
		$template_footer_text_bold = (isset($_POST['footerTextBold'])) ? 1 : 0;
		$template_hide_footer_nav = (isset($_POST['hideFooterNav'])) ? 1 : 0;
		$template_hide_header_nav = (isset($_POST['hideHeaderNav'])) ? 1 : 0;
		$template_hide_footer_graphic = (isset($_POST['hideFooterGraphic'])) ? 1 : 0;
		$custom_width_px = $dbo->format($_POST['customWidthPx']);
		
		$custom_width_px_members = $dbo->format($_POST['customWidthPxMembers']);
		$custom_width = $_POST['tblwidthoption'];
		//die(var_dump($_POST));
		
		
		//die(var_dump($custom_width_px_members));
		// Version 3.0 Template system stores settings for EACH template directory.
		// If new Files have been uploaded, lets store them ...
		
		
		
		if ($_FILES['imgfile1']['name'] != '')
		{
			move_uploaded_file($_FILES['imgfile1']['tmp_name'], ROOTPATH.'/layout/'.$dbo->format($_POST['sTemplateFolder']).'/images/head1.jpg');
		}
		if ($_FILES['imgfile2']['name'] != '')
		{
			move_uploaded_file($_FILES['imgfile2']['tmp_name'], ROOTPATH.'/layout/'.$dbo->format($_POST['sTemplateFolder']).'/images/footer1.jpg');
		}
		if ($_FILES['imgfile3']['name'] != '')
		{
			move_uploaded_file($_FILES['imgfile3']['tmp_name'], ROOTPATH.'/layout/'.$dbo->format($_POST['sTemplateFolder']).'/images/head2.jpg');
		}
		if ($_FILES['imgfile4']['name'] != '')
		{
			move_uploaded_file($_FILES['imgfile4']['tmp_name'], ROOTPATH.'/layout/'.$dbo->format($_POST['sTemplateFolder']).'/images/footer2.jpg');
		}
		if ($_FILES['imgfile5']['name'] != '')
		{
			move_uploaded_file($_FILES['imgfile5']['tmp_name'], ROOTPATH.'/layout/'.$dbo->format($_POST['sTemplateFolder']).'/images/bg.jpg');
		}
		
		// Either template already existed, or was created above.
		$sql = "UPDATE tbltemplatesettings SET ";
			
		// Basic Template Settings ....
		$sql .="
		nHideBorder = $template_remove_border,
		nHidePoweredByLink = $template_disable_poweredby_link, 
		sHeaderNavAlign = '$template_header_nav_align',
		sFooterNavAlign = '$template_footer_nav_align',
		nHeaderTextBold = $template_header_text_bold,
		nFooterTextBold = $template_footer_text_bold,
		nHideFooterNav = $template_hide_footer_nav,
		nHideHeaderNav = $template_hide_header_nav,
		nHideFooterGraphic = $template_hide_footer_graphic, ";
		
		// Template Graphics
		
		$headimgwidth = '';
		$mheadimgwidth = '';
		//die(var_dump($_POST));
		if($custom_width == '1'){
			
			$headimgwidth = $custom_width_px;
			$mheadimgwidth = $custom_width_px_members;
			//die(var_dump($_POST));
		}
		elseif($custom_width == '0'){
			
			
			list($headimgwidth) = getimagesize('../layout/'.$fName.'/images/head1.jpg');
			list($mheadimgwidth) = getimagesize('../layout/'.$fName.'/images/head2.jpg');
		
		
		}
		
		
		if($custom_width != '2'){$sql .= "headimgwidth = '$headimgwidth', mheadimgwidth = '$mheadimgwidth',";}
		
		
		// Template Colors ...	
		$sql .= "
		btmcolor1 = '" . $dbo->format($_POST['input2']) . "', 
		bodybackground = '" . $dbo->format($_POST['input3']) . "', 
		mbackcolor = '" . $dbo->format($_POST['inputm1']) . "', 
		mhovercolor = '" . $dbo->format( $_POST['inputm3']) . "', 
		mtextcolor = '" . $dbo->format($_POST['inputm4']) . "' ";
				
		$sql .=" 
		WHERE sTemplateFolder = '".$dbo->format($_POST['sTemplateFolder'])."'";
		//die($sql);
		if(!$dbo->update($sql)) $e++;$error2[$e] = $dbo->error;
		// Lets set this template to active
		//update_option('activetemplate',$dbo->format($_POST['sTemplateFolder']));
			
		// Update tblsitesettings
		$sql = "UPDATE tblsitesettings SET sJavascript = '" . addslashes($_POST['javascript']) . "'";
		$dbo->update($sql);
		if(isset($_GET['name'])){$backfolder = '&name='.$_GET['name'];}
		$message = "Template settings have been updated";
		header("Location: template_setup.php?msg=$message".$backfolder);
		exit;
	}
	else{
		$message = "Please Correct The Following Errors.";
		foreach($error as $v){
			$message .= "<div class='error'>".$v."</div>";
			}
		}
		
		}




//$objTemplateOptions = $dbo->getobject("SELECT * FROM tbltemplatesettings WHERE sTemplateFolder = '".TEMPLATEFOLDER."'");
//die(var_dump($objTemplateOptions));
$objSiteSettings = $dbo->getobject("SELECT * FROM tblsitesettings");
$current_language = $objTemplateOptions->sLanguageFile;

$current_header_width_array = list($headimgwidth) = getimagesize('../layout/'.$fName.'/images/head1.jpg');

$current_header_width = ($current_header_width_array[0])?$current_header_width_array[0]:'0';

$current_mheader_width_array = list($mheadimgwidth) = getimagesize('../layout/'.$fName.'/images/head2.jpg');
$current_mheader_width = ($current_mheader_width_array[0])?$current_mheader_width_array[0]:'0';
?>
<html>
	<head>
		<title><?php echo $sSitename ?> Admin Panel</title>
		<?php include("inc-head.php"); ?>
		<script language=JavaScript src="common/js/picker/picker.js"></script>
		<script type="text/javascript" language="JavaScript">
		<!--// Copyright 2006 Bontrager Connection, LLC
			var cX = 0; var cY = 0;
			function UpdateCursorPosition(e){ cX = e.pageX; cY = e.pageY;}
			function UpdateCursorPositionDocAll(e){ cX = event.clientX; cY = event.clientY;}
			if(document.all) { document.onmousemove = UpdateCursorPositionDocAll; }
			else { document.onmousemove = UpdateCursorPosition; }
			function AssignPosition(d) {
			d.style.left = (cX+10) + "px";
			d.style.top = (cY+10) + "px";
			}
			function HideContent(d) {
			if(d.length < 1) { return; }
			document.getElementById(d).style.display = "none";
			}
			function ShowContent(d) {
			if(d.length < 1) { return; }
			var dd = document.getElementById(d);
			AssignPosition(dd);
			dd.style.display = "block";
			}
			function ReverseContentDisplay(d) {
			if(d.length < 1) { return; }
			var dd = document.getElementById(d);
			AssignPosition(dd);
			if(dd.style.display == "none") { dd.style.display = "block"; }
			else { dd.style.display = "none"; }
			}
			
			function preloadImages() {
			  var d=document; if(d.images){ if(!d.p) d.p=new Array();
			    var i,j=d.p.length,a=preloadImages.arguments; for(i=0; i<a.length; i++)
			    if (a[i].indexOf("#")!=0){ d.p[j]=new Image; d.p[j++].src=a[i];}}
			}
			
			function showExample() {
				oDiv = document.getElementById('jexample');
				if (oDiv.style.visibility == 'visible') {
					oDiv.style.height = '1px';
					oDiv.style.visibility = 'hidden';
					oDiv.innerHTML = '';
					document.getElementById('example').value = 'Show';
				} else {
					oDiv.innerHTML = '&lt;script type="text/javascript"&gt;<br>window.onload = setTimeout("displayAlert()", 2000);<br><br>function displayAlert() {<br><span style="padding-left:10px">alert("Hello World!");</span><br>}<br>&lt;/script&gt;';
					oDiv.style.height = '110px';
					oDiv.style.visibility = 'visible';
					document.getElementById('example').value = 'Hide';
				}
			}
		function loadFolder(){
			var e = document.getElementById('sTemplateFolder');
			name = e.options[e.selectedIndex].value;
			window.location = 'template_setup.php?name='+name;
			}
		function activateFolder(folder){
			window.location = 'template_setup.php?name='+folder+'&a=1';
			}
		//-->
		function toggleCustomWidth(){
        	var custom = document.getElementById('tblwidthoption_1');
			var current = document.getElementById('tblwidthoption_2');
			
			var showcustom = document.getElementById('customWidth');
			var showcurrent = document.getElementById('currentWidth');
			var showimg = document.getElementById('imgWidth');
			
			showcustom.style.display = 'none';
			showcurrent.style.display = 'none';
			showimg.style.display = 'none';
		
        if(custom.checked){
			showcustom.style.display = 'block';
		}
		else if(current.checked){
			showcurrent.style.display = 'block';
		}
		else{showimg.style.display = 'block';}
		
      }
	  function updateColor(ele){
		  alert(ele.name+'_color');
		  display = document.getElementById(ele.name+'_color');
		  display.style.backgroundColor = ele.value;
		  
		  }
		</script>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once('settingsleft.php'); ?></td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			<h1>Template Setup</h1>
			
			<?php echo isset($message) ? $message : '' ?>
			
			<form name="tcp_test" method="post" action="<?php echo $_SERVER['PHP_SELF'].$namestr; ?>"  enctype="multipart/form-data">

				<!-- META TAGS JAVASCRIPT -->
				<table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridTable">
					<tr>
						<td colspan="2" class="gridHeader">Meta Tags, JavaScript</td>
					</tr>
					<tr>
						<td class="gridRow1">JavaScript:</label></td>
						<td class="gridRow1">
							<textarea name="javascript" cols="80" rows="4" style="margin-left:3px; margin-bottom:0px; word-wrap:normal" ><?php echo stripslashes($objSiteSettings->sJavascript)?></textarea>
							<div style="margin-left:5px; margin-top:3px; color:navy">NOTE: <font color="red">You MUST include script tags </font>&lt;script type="text/javascript"&gt;<font color="red"> between your code </font>&lt;/script&gt;<br /> 
							NOTE2: Until version 3.2, Javascript entered is SITEWIDE, NOT on a per template basis.</div>
						</td>
					</tr>
				</table>
				
				<!-- TEMPLATE FILES -->
				<table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridTable">
					<!--
                    Old Method Of Templating New is below commented out code
                    <tr>
						<td colspan="2" class="gridHeader">Template Layout Files</td>
					</tr>
					<tr>
						<td class="gridRow1" width="250">Front End Template File: <br /><small>(Stored in /layout folder</small>)</td>
						<td class="gridRow1">
							<input type="text" name="sFrontEndTemplateFile" id="sFrontEndTemplateFile" value="<?php /*echo $objTemplateOptions->sFrontEndTemplateFile*/ ?>" style="width: 350px;"/>
						</td>
					</tr>
					<tr>
						<td class="gridRow1" width="250">Member's Area Template File: <br /><small>(Stored in /layout folder</small>)</td>
						<td class="gridRow1">
							<input type="text" name="sMemberTemplateFile" id="sMemberTemplateFile" value="<?php /*echo $objTemplateOptions->sMemberTemplateFile*/ ?>" style="width: 350px;" />
						</td>
					</tr> !-->
                    <tr>
						<td class="gridRow1" width="250">Template Directory: <br /></td>
						<td class="gridRow1"><select name="sTemplateFolder" id="sTemplateFolder" onChange="loadFolder();">
						<?php
						$folders = array_diff(scandir('../layout/'), array('..', '.'));
						foreach($folders as $v){
							if(is_dir('../layout/'.$v)){ ?>
								<option value="<?php echo $v ?>" <?php if ($v == $objTemplateOptions->sTemplateFolder){echo 'selected';}?>><?php echo $v ?> </option>
                                <?php
								}
							}
						?>
						</select>	<?php echo ($active == $current)?'':' <strong>Template Inactive. - <a href = "javascript:activateFolder(\''.$current.'\')">Activate Template</a></strong>' ?>
					  </td>
					</tr>
				</table><br>
                <h2><?php echo 'Options For Template Folder '.$current ?></h2>
<br>

				
				<!-- MISCELLANEOUS TEMPLATE SETTINGS -->
				<table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridTable">
					<tr>
						<td colspan="2" class="gridHeader">Miscellaneous Template Settings</td>
					</tr>
					<!-- HEADER NAVIGATION SETTINGS -->
					<tr>
						<td class="gridRow1" width="250">Main Table Width</td>
						<td class="gridRow1"><p>
						  <label>
						    <input name="tblwidthoption" type="radio" id="tblwidthoption_2" onChange="toggleCustomWidth()" value="2" checked>
						    Use Current</label><span id="currentWidth" style="display:block; margin-left:25px;"> Main Width: <?php echo ($objTemplateOptions->headimgwidth)?$objTemplateOptions->headimgwidth:'0'?> Px<br />
                            Member Area Width: <?php echo ($objTemplateOptions->mheadimgwidth)?$objTemplateOptions->mheadimgwidth:'0'?> Px</span>
                          <label><br>

						    <input type="radio" name="tblwidthoption" value="0" id="tblwidthoption_0" onChange="toggleCustomWidth()">
						    Use Header Graphic Width</label>
                          <span id="imgWidth" style="display:none;  margin-left:25px;"> Main Width: <?php echo $current_header_width?> Px<br />
                            Member Area Width: <?php echo $current_mheader_width?> Px</span>
						  <label><br>

						    <input type="radio" name="tblwidthoption" value="1" id="tblwidthoption_1" onChange="toggleCustomWidth()">
						    Define Width</label>&nbsp;<span id="customWidth" style="display:none; margin-left:25px;"> Main Width <input name="customWidthPx" type="text" size="6" maxlength="4"> Px<br />
                            Member Area Width <input name="customWidthPxMembers" type="text" size="6" maxlength="4"> Px</span>
						
					    </p></td>
					</tr>
					<tr>
					  <td class="gridRow1">Header Navigation Text Bold:</td>
					  <td class="gridRow1"><input type="checkbox" name="headerTextBold" id="headerTextBold" <?php echo ( $objTemplateOptions->nHeaderTextBold ) ? 'checked="true"' : ''; ?> style="margin-left:3px;margin-bottom:0px" /></td>
			      </tr>
					<tr>
						<td class="gridRow1" >
							<span>Header Navigation Alignment:</span>
						</td>
						<td class="gridRow1">
							<?php $align = (empty($objTemplateOptions->sHeaderNavAlign)) ? 'right' : $objTemplateOptions->sHeaderNavAlign; ?>
							<table border="0" cellspacing="0" cellpadding="0" style="margin-top:2px; margin-bottom:2px">
								<tr>
									<td style="text-align:center">
										<label for="headerNavLeft" >Left</label><br>
										<input type="radio" name="headerNavAlign" id="headerNavLeft" value="left" <?php echo ( $align == 'left' ) ? 'checked="true"' : ''; ?> style="margin-left:3px;margin-top:3px" />
									</td>
									<td width="2">&nbsp;</td>
									<td style="text-align:center">
										<label for="headerNavRight" >Right</label><br>
										<input type="radio" name="headerNavAlign" id="headerNavRight" value="right" <?php echo ( $align == 'right' || $align == '' ) ? 'checked="true"' : ''; ?> style="margin-left:3px;margin-bottom:0px" />
									</td>
								</tr>
							</table>
						</td>
					</tr>
					<!-- FOOTER NAVIGATION SETTINGS -->
					<tr>
						<td class="gridRow1">Hide Footer Graphic:</td>
						<td class="gridRow1">
							<input type="checkbox" name="hideFooterGraphic" id="hideFooterGraphic" <?php echo ( $objTemplateOptions->nHideFooterGraphic ) ? 'checked="true"' : ''; ?> style="margin-left:3px;margin-bottom:0px" />
						</td>
					</tr>
					<tr>
						<td class="gridRow1">Hide Footer Navigation:</td>
						<td class="gridRow1">
							<input type="checkbox" name="hideFooterNav" id="hideFooterNav" <?php echo ( $objTemplateOptions->nHideFooterNav ) ? 'checked="true"' : ''; ?> style="margin-left:3px;margin-bottom:0px" />
						</td>
					</tr>
					<tr>
						<td class="gridRow1" >Footer Navigation Text Bold:</td>
						<td class="gridRow1">
							<input type="checkbox" name="footerTextBold" id="footerTextBold" <?php echo ( $objTemplateOptions->nFooterTextBold ) ? 'checked="true"' : ''; ?> style="margin-left:3px;margin-bottom:0px" />
						</td>
					</tr>
					<tr>
						<td class="gridRow1" >Footer Navigation Alignment:</td>
						<td class="gridRow1">
							<?php $align = (empty($objTemplateOptions->sFooterNavAlign)) ? 'right' : $objTemplateOptions->sFooterNavAlign; ?>
							<table border="0" cellspacing="0" cellpadding="0" style="margin-top:2px; margin-bottom:2px">
								<tr>
									<td style="text-align:center">
										<label for="footerNavLeft" >Left</label><br>
										<input type="radio" name="footerNavAlign" id="footerNavLeft" value="left" <?php echo ( $align == 'left' ) ? 'checked="true"' : ''; ?> style="margin-left:3px;margin-top:3px" />
									</td>
									<td width="2">&nbsp;</td>
									<td style="text-align:center">
										<label for="footerNavRight" >Right</label><br>
										<input type="radio" name="footerNavAlign" id="footerNavRight" value="right" <?php echo ( $align == 'right' || $align == '' ) ? 'checked="true"' : ''; ?> style="margin-left:3px;margin-bottom:0px" />
									</td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td class="gridRow1" >Remove Black Border From Template:</td>
						<td class="gridRow1">
							<input type="checkbox" name="tmpl-remove-border" id="tmpl-remove-border" <?php echo ( $objTemplateOptions->nHideBorder ) ? 'checked="true"' : ''; ?> />
						</td>
					</tr>
					<tr>
						<td class="gridRow1" >Hide "Powered by EasyMemberPro":</td>
						<td class="gridRow1">
							<input type="checkbox" name="disable-poweredby-link" id="disable-poweredby-link" <?php echo ( $objTemplateOptions->nHidePoweredByLink ) ? 'checked="true"' : ''; ?> style="margin-left:3px;margin-bottom:0px" />						
						</td>
					</tr>
				</table>
		      <h1>Template Graphics</h1>
				<table width="100%"  border="0" cellpadding="0" cellspacing="1" class="gridTable">
				  <tr>
				    <td class="gridHeader">Front End - Header Graphic</td>
			      </tr>
				  <tr>
				    <td class="gridRow1"><p><img src="<?php echo '../layout/'.$objTemplateOptions->sTemplateFolder.'/images/' ?>head1.jpg?<?php echo time() ?>" alt=""></p>
				      <p>Upload New Image
				        <input type="file" name="imgfile1" value="" />
			          </p>
				      <?php if ($shp == 1) { echo "<br />The image size should be below 200kb"; } ?></td>
			      </tr>
				  <tr>
				    <td class="gridHeader">Front End - Footer Graphic</td>
			      </tr>
				  <tr>
				    <td class="gridRow1"><p><img src="<?php echo '../layout/'.$objTemplateOptions->sTemplateFolder.'/images/' ?>footer1.jpg?<?php echo time() ?>" alt="" /></p>
				      <p>Upload New Image
				        <input type="file" name="imgfile2"  value="" />
			          </p>
				      <?php if ($sfp == 1) { echo "<br />The image size should be below 200kb"; } ?></td>
			      </tr>
				  <tr>
				    <td class="gridHeader">Membership Area - Header Graphic</td>
			      </tr>
				  <tr>
				    <td class="gridRow1"><p><img src="<?php echo '../layout/'.$objTemplateOptions->sTemplateFolder.'/images/' ?>head2.jpg?<?php echo time() ?>" alt="" /></p>
				      <p>Upload New Image
				        <input type="file" name="imgfile3"  value="" />
			          </p>
				      <?php if ($smhp == 1) { echo "<br />The image size should be below 200kb"; } ?></td>
			      </tr>
				  <tr>
				    <td class="gridHeader">Membership Area - Footer Graphic</td>
			      </tr>
				  <tr>
				    <td class="gridRow1"><p><img src="<?php echo '../layout/'.$objTemplateOptions->sTemplateFolder.'/images/' ?>footer2.jpg?<?php echo time() ?>" alt="" /></p>
				      <p>
				        <input type="file" name="imgfile4"  value="" />
			          </p>
				      <?php if ($smhp == 1) { echo "<br />The image size should be below 200kb"; } ?></td>
			      </tr>
				  <tr>
				    <td class="gridHeader">Membership Area - Background Image</td>
			      </tr>
				  <tr>
				    <td class="gridRow1"><p><img src="<?php echo '../layout/'.$objTemplateOptions->sTemplateFolder.'/images/' ?>bg.jpg?<?php echo time() ?>" alt="" /></p>
				      <p>
				        <input type="file" name="imgfile5"  value="" />
			          </p>
				      <?php if ($smbg == 1) { echo "<br />The image size should be below 200kb"; } ?></td>
			      </tr>
			  </table>
              <h1>Template Colors</h1>
              <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridTable">
					<tr><td colspan="2" class="gridheader">Website Colors</td></tr>
 
					<tr>
						<td class="gridrow1" width="350">Header Background Color</td>
						<td class="gridRow1"><table width="100%" border="0" cellspacing="0" cellpadding="0">
						  <tr>
						    <td width="7%"><div id="input100_color" style="background-color:<?php echo get_option($objTemplateOptions->sTemplateFolder.'_template_head_bg'); ?>; width:100%">&nbsp;</div></td>
						    <td style="padding-left:8px;"><input name="input100" type="Text" id="input100" value="<?php echo get_option($objTemplateOptions->sTemplateFolder.'_template_head_bg'); ?>" size="7" / onChange="updateColor(this)">
						      &nbsp;&nbsp;&nbsp;<a href="javascript:TCP.popup(document.forms['tcp_test'].elements['input100'])"><img width="15" height="13" border="0" alt="Click Here to Pick up the color" src="images/sel.gif" /></a></td>
					      </tr>
					    </table></td>
					</tr>
					<tr>
					  <td class="gridrow1">Member Header Background Color</td>
					  <td class="gridRow1"><table width="100%" border="0" cellspacing="0" cellpadding="0">
					    <tr>
					      <td width="7%"><div id="input101_color" style="background-color:<?php echo get_option($objTemplateOptions->sTemplateFolder.'_template_mhead_bg'); ?>; width:100%">&nbsp;</div></td>
					      <td style="padding-left:8px;"><input name="input101" type="Text" id="input101" value="<?php echo get_option($objTemplateOptions->sTemplateFolder.'_template_mhead_bg'); ?>" size="7" />
					        &nbsp;&nbsp;&nbsp;<a href="javascript:TCP.popup(document.forms['tcp_test'].elements['input101'])"><img width="15" height="13" border="0" alt="Click Here to Pick up the color" src="images/sel.gif" /></a></td>
				        </tr>
				      </table></td>
		        </tr>
					<tr>
					  <td class="gridrow1">Footer Navigation Background Color</td>
					  <td class="gridRow1"><table width="100%" border="0" cellspacing="0" cellpadding="0">
					    <tr>
					      <td width="7%" bgcolor="<?php echo $objTemplateOptions->btmcolor1; ?>">&nbsp;</td>
					      <td style="padding-left:8px;"><input name="input2" type="Text" value="<?php echo $objTemplateOptions->btmcolor1; ?>" size="7" />
					        &nbsp;&nbsp;&nbsp;<a href="javascript:TCP.popup(document.forms['tcp_test'].elements['input2'])"><img width="15" height="13" border="0" alt="Click Here to Pick up the color" src="images/sel.gif" /></a></td>
				        </tr>
				      </table></td>
		        </tr>
					<tr>
						<td class="gridRow1" width="350">Body Background Color</td>
						<td class="gridRow1">
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="7%" bgcolor="<?php echo $objTemplateOptions->bodybackground; ?>">&nbsp;</td>
									<td style="padding-left:8px;">
										<input name="input3" type="Text" value="<?php echo $objTemplateOptions->bodybackground; ?>" size="7" />
										&nbsp;&nbsp;&nbsp;<a href="javascript:TCP.popup(document.forms['tcp_test'].elements['input3'])"><img width="15" height="13" border="0" alt="Click Here to Pick up the color" src="images/sel.gif" /></a>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
							
				<table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridTable">
				  <tr><td colspan="2" class="gridheader">Menu Colors</td></tr>
					<tr>
						<td class="gridrow1" width="350">Menu Background Color</td>
						<td class="gridrow1">
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="7%" bgcolor="<?php echo $objTemplateOptions->mbackcolor; ?>">&nbsp;</td>
									<td style="padding-left:8px;">
										<input name="inputm1" type="Text" value="<?php echo $objTemplateOptions->mbackcolor; ?>" size="7" />
										&nbsp;&nbsp;&nbsp;<a href="javascript:TCP.popup(document.forms['tcp_test'].elements['inputm1'])"><img width="15" height="13" border="0" alt="Click Here to Pick up the color" src="images/sel.gif" /></a>
									</td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td class="gridrow1">Menu Hover Color</td>
						<td class="gridrow1">
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="7%" bgcolor="<?php echo $objTemplateOptions->mhovercolor; ?>">&nbsp;</td>
									<td style="padding-left:8px;">
										<input name="inputm3" type="Text" value="<?php echo $objTemplateOptions->mhovercolor; ?>" size="7" />
										&nbsp;&nbsp;&nbsp;<a href="javascript:TCP.popup(document.forms['tcp_test'].elements['inputm3'])"><img width="15" height="13" border="0" alt="Click Here to Pick up the color" src="images/sel.gif" /></a>
									</td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td class="gridrow1">Menu Text Color</td>
						<td class="gridrow1">
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="7%" bgcolor="<?php echo $objTemplateOptions->mtextcolor; ?>">&nbsp;</td>
									<td style="padding-left:8px;">
										<input name="inputm4" type="Text" value="<?php echo $objTemplateOptions->mtextcolor; ?>" size="7" />
										&nbsp;&nbsp;&nbsp;<a href="javascript:TCP.popup(document.forms['tcp_test'].elements['inputm4'])"><img width="15" height="13" border="0" alt="Click Here to Pick up the color" src="images/sel.gif" /></a>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
              <br />
				  <input type="submit" name="Submit" value="Save Changes"  class="inputSubmitb">
			  </p>
            </form>
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>
	</body>
</html>