<?php
include_once('../conn.php');
include_once('../functions.php');

if ( isset($_POST['Submit']) )
{
	// Update current SEO settings
	$dbo->update("UPDATE tblsitesettings SET 
		sMetaTags = '" . addslashes($_POST['metatags']) . "', 
		sGoogleAnalytics = '" . addslashes($_POST['googleanalytics']) . "', 
		sGoogleWebmaster = '" . addslashes($_POST['googlewebmaster']) . "'
		");
	$message = "SEO settings have been updated successfully";
}

$objSiteSettings = $dbo->getobject("SELECT * FROM tblsitesettings");
?>
<html>
	<head>
		<title><?php echo $sSitename ?> Admin Panel</title>
		<?php include("inc-head.php"); ?>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once('settingsleft.php'); ?></td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td nowrap="nowrap" class="navRow1">Testing &amp; Tracking (SEO) - Settings</td>
				</tr>
			</table>
			
			<span class="success"><?php echo isset($message) ? $message : '' ?></span>
			
			<form name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >

				<table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridTable">
					<tr>
						<td class="gridRow1" width="250">Meta Tags:</td>
						<td class="gridRow1">
							<textarea name="metatags" cols="80" rows="4" style="margin-left:3px; margin-bottom:0px; word-wrap:normal" ><?php echo stripslashes($objSiteSettings->sMetaTags)?></textarea>
							<br /><small>e.g: <?php echo htmlspecialchars('<meta name="description" content="your content here">');?></small>
						</td>
					</tr>
					<tr>
						<td class="gridRow1" width="250">Google Analytics:</td>
						<td class="gridRow1">
							<p>Sign up <a href="http://www.google.com/analytics/sign_up.html" target="_blank">HERE</a> &amp; paste the supplied code into the box below</p>
							<textarea name="googleanalytics" cols="80" rows="10" style="margin-left:3px; margin-bottom:0px; word-wrap:normal" ><?php echo stripslashes($objSiteSettings->sGoogleAnalytics)?></textarea>
						</td>
					</tr>
					<tr>
						<td class="gridRow1" width="250">Google Webmaster Tools:</td>
						<td class="gridRow1">
							<p>Sign up <a href="http://www.google.com/webmasters/tools/" target="_blank">HERE</a> &amp; paste the supplied code into the box below</p>
							<textarea name="googlewebmaster" cols="80" rows="4" style="margin-left:3px; margin-bottom:0px; word-wrap:normal" ><?php echo stripslashes($objSiteSettings->sGoogleWebmaster)?></textarea>
							<p><small>e.g. <?php echo htmlspecialchars('<meta name="google-site-verification" content="Czh1XM4Gq5dt6xEY9prSagznXfhy18tGnMJgAg11eRI" />'); ?></small></p>
						</td>
					</tr>
				</table>

				<br />
				<input type="submit" name="Submit" value="Save Changes"  class="inputSubmitb">
			</form>
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>
	</body>
</html>