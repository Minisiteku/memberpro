<?php
global $dbo;


// RETRIEVE ADMIN INFO
$objAdmin = $dbo->getobject("select * from tblusers where nUser_ID='". $_SESSION['admin']["nUser_ID"] . "'");

$sql = "SELECT count(nCancellation_ID) from tblcancellations where nStatus = 0;";
$result = $dbo->select($sql);
if($result){
	$data = $dbo->getarray($result);
	$cancel_requests = $data[0];}
	
// Support Link
$supportLink = ($licenseData->type == 'developer' && isset($DEVOPTS['SUPPORTURL']))?$DEVOPTS['SUPPORTURL']:'http://www.easymemberpro.com/support';

?>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <!--DWLayoutTable-->
  <tr>
    <td class="header-bg">
    <table border="0"  align="left" cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td width="20">&nbsp;</td>
          <td width="569" height="99"><img src="images/emp-cp-header-logo.jpg" width="546" height="106"></td>
          <td width="100%" align="right" nowrap="nowrap" valign="bottom" class="white" style="padding-bottom:9px;"> Current Date/Time: <span id="clock"><?php echo date("F j, Y, G:i"); ?></span><input type="hidden" value="<?php echo date("F j, Y, G:i:s"); ?>" id="serverTime">&nbsp;<br /><br />
Logged in: <?php echo $objAdmin->sForename; ?> | <a class="white" href="<?php echo ($sSiteURL != '') ? $sSiteURL : '../'; ?>" target="_blank">Website</a> | <a class="white" href="<?php echo $supportLink ?>" target="_blank">Support</a> | <a class="white" href="lout.php">Logout</a>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table class="gridtable margincancel" cellpadding="0" cellspacing="1" border="0" width="100%"><tr><td>
<ul class="sf-menu sf-js-enabled sf-shadow gridheader adminheader">
  <li><a class="sf-with-ul" href="home.php"><img src="../common/images/icons/house.png">&nbsp;Home</a></li>
  <li><a class="sf-with-ul" href="#"><img src="../common/images/icons/users.png">&nbsp;Members</a>
    <ul>
      <li><a href="add_members.php"><img src="../common/images/icons/user_add.png">&nbsp;Add Members</a></li>
      <li><a href="manage_members.php"><img src="../common/images/icons/group_gear.png">&nbsp;Manage Members</a></li>
      <li><a href="email_members.php"><img src="../common/images/icons/email_go.png" width="16" height="16">&nbsp;Email Members</a></li>
      <li><a href="expired_members.php"><img src="../common/images/icons/expired.png" width="16" height="16">&nbsp;Expired Members</a></li>
      <li><a href="cancel_requests.php"><img src="../common/images/icons/stop.png" width="16" height="16">&nbsp;Cancel Requests(<?php if($cancel_requests){echo $cancel_requests;}else echo "0"; ?>)</a></li>
      <li><a href="export_members.php"><img src="../common/images/icons/file_extension_xls.png">&nbsp;Export Members</a></li>
      <li><a href="import_members.php"><img src="../common/images/icons/file_extension_xls.png">&nbsp;Import Members</a></li>
    </ul>
    <?php echo pluginClass::filter("admin_menu_users"); ?>
  </li>
  <li><a class="sf-with-ul" href="#"><img src="../common/images/icons/affiliates.png">&nbsp;Affiliates</a>
    <ul>
      <li><a href="pay_affiliates.php"><img src="images/dollor.gif">&nbsp;Pay Affiliates</a></li>
      <li><a href="pay_affiliates_files.php"><img src="images/dollor.gif">&nbsp;Affiliates Files</a></li>
      <li><a href="email_members.php"><img src="images/emmail.gif">&nbsp;Email Affiliates</a></li>
      <li><a href="export_affiliates.php"><img src="images/export.jpg">&nbsp;Export Affiliates</a></li>
      <li><a href="#" class="sf-with-ul"><img src="images/th.jpg">&nbsp;Promotion Tools</a>
      <ul><li><a href="email_subject.php"><img src="images/th.jpg">&nbsp;Email Subject Lines </a></li>
      <li><a href="promotional_emails.php"><img src="images/th.jpg">&nbsp;Promotional Emails</a></li>
      <li><a href="promotional_graphics.php"><img src="images/th.jpg">&nbsp;Promotional Graphics</a></li></ul></li>
      <li><a href="unpaid_commissions.php"><img src="images/pay.jpg">&nbsp;Unpaid Commission</a></li>
      <?php echo pluginClass::filter("admin_menu_affiliates"); ?>
    </ul>
  </li>
  <li><a class="sf-with-ul" href="#"><img src="../common/images/icons/blackboard.png"  align="absmiddle" name="CCp" id="CCp2" width="16" height="16" />&nbsp;Content</a>
    <ul>
    <li><a href="page_management.php"><img src="images/mp.jpg">&nbsp;Pages</a></li>
    <li><a href="directory_management.php"><img src="images/directories.gif">&nbsp;Directories</a></li>
    <li><a href="member_levels.php"><img src="images/icon-levels.png">&nbsp;Member Levels</a></li>
      <li><a href="file_management.php"><img src="images/file_management.jpg">&nbsp;Files</a></li>
      <li><a href="video_management.php"><img src="images/icon_video.png">&nbsp;Videos</a></li>
     <?php echo pluginClass::filter("admin_menu_content"); ?>
    </ul>
  </li>
  <li><a class="sf-with-ul" href="manage_plugins.php"><img src="../common/images/icons/plugins.png">&nbsp;Plugins</a></li>
  <li><a class="sf-with-ul" href="#"><img src="../common/images/icons/reports.png">&nbsp;Tools / Reports</a>
    <ul>
    <li><a class="sf-with-ul" href="#">Admin Logs</a>
    <ul>
    <li><a href="admin_logins.php"><img src="images/th.jpg">&nbsp;Admin Logins</a></li>
    <li><a href="manage_transactions.php"><img src="images/pay.jpg">&nbsp;Transaction Log</a></li>
    <?php echo pluginClass::filter("admin_menu_tools_logs"); ?>
      </ul>
      </li>
      <li><a class="sf-with-ul" href="#">Admin Reports</a>
        <ul>
          <li><a class="sf-with-ul" href="#">Affiliate Reports</a>
            <ul>
              <li><a href="report_affiliates_top.php"><img src="images/pay.jpg">&nbsp;Top 25 Affiliates</a></li>
              <li><a href="unpaid_commissions.php"><img src="images/pay.jpg">&nbsp;Unpaid Commissions</a></li>
            </ul>
          </li>
          <li><a class="sf-with-ul" href="#">Member Reports</a>
            <ul>
              <li><a href="report_members_level.php"><img src="../common/images/icons/users.png">&nbsp;Members By Level</a></li>
              <li><a href="report_members_30days.php"><img src="../common/images/icons/users.png">&nbsp;Members In Last 30 Days</a></li>
               <li><a href="report_members_stickrate.php"><img src="../common/images/icons/users.png">&nbsp;Member Stick Rate By Level</a></li>
            </ul>
          </li>
          <li><a class="sf-with-ul" href="#">Revenue Reports</a>
            <ul>
              <li><a href="report_refunds_level.php"><img src="images/icon_report.png">&nbsp;Refunds By Level</a></li>
              <li><a href="report_revenue.php"><img src="images/icon_report.png">&nbsp;Revenue By Month</a></li>
               <li><a href="report_revenue_30days.php"><img src="images/icon_report.png">&nbsp;Revenue In Last 30 Days</a></li>
            </ul>
          </li>
      
      <?php echo pluginClass::filter("admin_menu_tools_reports"); ?>
      </ul>
      </li>
      <?php echo pluginClass::filter("admin_menu_tools"); ?>
    </ul>
  </li>
  <li><a class="sf-with-ul" href="#"><img src="../common/images/icons/settings.png"  align="absmiddle" name="DDp" id="DDp"/>&nbsp;Settings</a>
    <ul>
      <li><a class="sf-with-ul" href="#">General Settings</a>
        <ul>
         <li><a href="script_settings.php"><img src="images/icon_settings.png">&nbsp;Site Settings</a></li>
          <li><a href="user_fields.php"><img src="images/icon_member.png">&nbsp;User Fields</a></li>
          <li><a href="advanced_settings.php"><img src="images/icon_settings.png">&nbsp;Advanced Settings</a></li>
          <li><a href="manage_crons.php"><img src="images/icon_settings.png">&nbsp;Manage Cron Jobs</a></li>
          <?php echo pluginClass::filter("admin_menu_settings_general"); ?>
        </ul>
      </li>
      <li><a class="sf-with-ul" href="#">Emails</a>
        <ul>
          <li><a href="email_settings.php"><img src="images/icon_email.png">&nbsp;Email Settings</a></li>
          <li><a href="autoresponder_settings.php"><img src="images/icon_email.png">&nbsp;Autoresponders</a></li>
          <li><a href="email_templates.php"><img src="images/icon_email.png">&nbsp;Email Templates</a></li>
          <?php echo pluginClass::filter("admin_menu_settings_email"); ?>
          </ul>
          </li>
      <li><a class="sf-with-ul" href="#">Payments</a>
        <ul>
          <li><a href="coupons.php"><img src="images/icon-coupon.png">&nbsp;Coupons</a></li>
          <li><a href="payment_plans.php?action=reset"><img src="images/dollor.gif">&nbsp;Payment Plans</a></li>
          <li><a href="payment_processors.php"><img src="images/dollor.gif">&nbsp;Payment Processors</a></li>
          <?php echo pluginClass::filter("admin_menu_settings_payments"); ?>
          </ul>
          </li>
      <li><a class="sf-with-ul" href="#">Templates</a>
          <ul>
          <li><a href="template_setup.php"><img src="images/icon_settings.png">&nbsp;Template Setup</a></li>
          
          <?php echo pluginClass::filter("admin_menu_settings_templates"); ?>
          </ul>
          
      <li><a href="affiliate_management.php" class="sf-with-ul">Affiliate System</a>
      <ul>
      <li><a href="affiliate_management.php"><img src="images/icon_settings.png">&nbsp;Affiliate Settings</a></li>
      </ul>
      </li>
      <li><a class="sf-with-ul" href="#">Testing &amp; Tracking (SEO)</a>
          <ul>
          <li><a href="testing_tracking.php"><img src="images/icon_seo.png">&nbsp;SEO Settings</a></li>
          <?php echo pluginClass::filter("admin_menu_settings_testing"); ?>
          </ul>
          </li>
       <!-- <li><a class="sf-with-ul" href="#">Security</a>
          <ul>
          <li><img src="images/icon_seo.png"  width="16" height="16" style="float:left;" border="" align="absmiddle"><a href="testing_tracking.php">Ban Manager</a></li>
          </ul>
          </li>  -->
      <?php echo pluginClass::filter("admin_menu_settings"); ?>
    </ul>
  </li>
  <li><a class="sf-with-ul" href="manage_database.php"><img src="../common/images/icons/database.png">&nbsp;Database</a>
      <ul>
      <li><a href="manage_database.php"><img src="../common/images/icons/database_gear.png">&nbsp;Manage Database</a></li>
      <li><a href="restore_database.php"><img src="../common/images/icons/database_refresh.png">&nbsp;Restore Backups</a></li>
      <li><a href="delete_database.php"><img src="../common/images/icons/database_delete.png">&nbsp;Delete Backups</a></li>
      <?php echo pluginClass::filter("admin_menu_database"); ?>
      </ul>
      </li>
      <?php echo pluginClass::filter("admin_menu"); ?>
    </ul>
</td></tr></table>
    <div style="clear:both"></div>