<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	$currency_symbol = get_currency_symbol($chkSsettings->sCurrencyFormat);
	$startmonth = date('Ym01');
	$nextmonth = date('Ymd', strtotime('+1 month', strtotime($startmonth)));
	
	// Run The Commissions Query.
	$sql = "SELECT CONCAT(tblusers.sForename, ' ',tblusers.sSurname) AS name, 
	tblaffiliatepayments.nAffiliate_ID, 
	tblusers.sPaypalEmail AS sPaypalEmail,
	SUM(tblaffiliatepayments.nCommission) AS amount, 
	COUNT(nAffiliatePayment_ID) AS cnt 
	FROM tblaffiliatepayments 
	INNER JOIN tblusers ON nUser_ID = tblaffiliatepayments.nAffiliate_ID
	WHERE (tblaffiliatepayments.sPaymentStatus = '' OR tblaffiliatepayments.sPaymentStatus IS NULL)
	GROUP BY tblaffiliatepayments.nAffiliate_ID 
	ORDER BY amount, name";				
	
	$tot_cnt = 0;
	$tot_amt = 0;
			
	$rs = $dbo->select($sql); // Hold The Result For Processing Later

?>

<html><head><title><?php echo $admintitle; ?></title>
<?php include("inc-head.php"); ?>
</head>
<body leftmargin="0" topmargin="0" rightmargin="0">

<?php include_once('top.php'); ?>

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
	<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
	<?php include_once('affiliateleft.php'); ?>
	</td>
	<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">

	<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td class="navRow1" nowrap="nowrap"> Unpaid Commissions </td>
		<td width="100%" align="center" class="navRow2">&nbsp;</td>
	</tr>
	</table>
	
	<div style="line-height: 3em; vertical-align: middle;">
		<a href="unpaid_commissions_add.php"><img src="images/Add_24x24.png" width="24" height="24" alt="Add New Commission" border="0" style="vertical-align: middle"></a> 
		<a href="unpaid_commissions_add.php">Add New Commission</a>
	</div>

	<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
	<tr>
		<td class="gridheader">Affiliate Name </td>
		<td width="100" class="gridheader" align="center" nowrap="nowrap">Payable Subscriptions </td>
		<td width="350" class="gridheader" align="center" nowrap="nowrap">Paypal Email</td>
		<td width="100" class="gridheader" align="right" nowrap="nowrap">Owed</td>
		<td width="100" class="gridheader" align="center" nowrap="nowrap">View Details</td>
		<?php
		
			
			if ($rs!==false) {
				while ($row = $dbo->getobj($rs)) { ?>
		<tr><td class='gridrow2'><?php echo $row->name ?></td>
		  <!-- Subscription Count -->
		  <td width='100' class='gridrow2' align='center'><?php echo $row->cnt ?></td>
					<!-- Paypal Email -->
					<td width='350' class='gridrow2'><?php echo (empty($row->sPaypalEmail))? '<span style="color:red">Not Entered</span>' : $row->sPaypalEmail ?></td>
					<!-- Projected Payments -->
					<td width='100' class='gridrow2' align='right'><?php echo $currency_symbol.number_format($row->amount,2); ?></td>
					<!-- View Details -->
		<td width='100' class='gridrow2' align='center'><a href='unpaid_commissions_details.php?id=<?php echo $row->nAffiliate_ID ?>'>View</a></td></tr>
				<?php
                    $tot_cnt += $row->cnt;
					$tot_amt += $row->amount;			
				}			
				// Totals
				?>
                <tr><td class='gridrow2' style='text-align:right; font-weight:bold'>Total</td>
				<td class='gridrow2' style='text-align:center'><b><?php echo $tot_cnt ?></b></td><td class='gridrow2'></td>
				<td class='gridrow2' align='right'><b><?php echo $currency_symbol.number_format($tot_amt,2); ?></b></td>
		<td class='gridrow2'>&nbsp;</td></tr>
<?php
			}
			else { ?>
            <tr><td colspan='5' class='gridrow2' ><strong>No Unpaid Commissions</strong></td></tr>
<?php		}
		?>
        <tr><td class="gridfooter" colspan="5">&nbsp;</td></tr>
		</table>
	</td>
</tr>
</table>

<?php include_once('b.php'); ?>

</body>
</html>