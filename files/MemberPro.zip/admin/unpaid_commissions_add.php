<?php
	include_once('../conn.php');
	include_once('../functions.php');	
?>
<?php
if(isset($_POST['Add']))
{
	$sql="SELECT sEmail,sForename,sSurname from tblusers where nUser_ID='".$dbo->format($_POST['suggestionsmHidden'])."'";
	$rs=$dbo->select($sql);
	if(!empty($rs))
	{
		$row = $dbo->getobj($rs);
		$memberEmail = $row->sEmail;
		$sForename = $row->sForename;
		$sSurname = $row->sSurname;
	}
	
	$sItemName = $dbo->format($_POST['sItemName']);
	
	$sql="INSERT INTO tblaffiliatepayments (
		nCommission, 
		nDate, 
		nDatePaid, 
		sPaymentStatus, 
		nAffiliate_ID, 
		sUserForename, 
		sUserSurname, 
		sUserEmail, 
		nMemberJoinDate, 
		sItemName, 
		sTransactionNumber
	) VALUES (
		'".$dbo->format($_POST['nCommission'])."',
		'". date('Ymd') ."',
		'0',
		'',
		'".$dbo->format($_POST['suggestionsHidden'])."',
		'".$sForename."',
		'".$sSurname."',
		'".$memberEmail."',
		'".$_POST['nMemberJoinYear'].$_POST['nMemberJoinMonth'].$_POST['nMemberJoinDay']."',
		'".$sItemName."',
		'".$dbo->format($_POST['nTransactionNumber']) . "'
	)";

	if($dbo->insert($sql)){
		$message = 'The new commission was added.';
		$type = 'msg';
		
		}
	else{$message = 'There was an error adding the commission:<br />'.$dbo->error;
		$type = 'err';}
	
	header("Location: unpaid_commissions_add.php?".$type."=".$message);exit;
	}
?>
<html><head><title><?php echo $admintitle; ?></title>
<?php include ('inc-head.php')?>
<script type="text/javascript">

function lookup(inputString,file,suggestions,autosuggestionlist) {
    if(inputString.length == 0) {
        // Hide the suggestion box.
        $(suggestions).hide();
        
    } else {
        $.post('ajax/'+file, {queryString: ""+inputString+""}, function(data){
            if(data.length >0) {
                $(suggestions).show();
                $(autosuggestionlist).html(data);
            }
        });
    }
} // lookup

function fill(thisValue,id,suggestions,thisValueId) {
    $(id).val(thisValue);
    $(suggestions+'Hidden').val(thisValueId);
    $(suggestions).hide();
}


</script>

<style type="text/css">

.suggestionsBox {
    position: absolute;
    left: 400px;
    margin: 10px 0px 0px 0px;
    width: 250px;
    background-color: #212427;
    -moz-border-radius: 7px;
    -webkit-border-radius: 7px;
    border: 2px solid #000;
    color: #fff;
}

.suggestionList {
    margin: 0px;
    padding: 5px;
}

.suggestionList li {
    margin: 0px 0px 5px 0px;
    padding: 3px;
    cursor: pointer;
}

.suggestionList li:hover {
    background-color: #659CD8;
}
</style>


</head>


<body leftmargin="0" topmargin="0" rightmargin="0">

<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
<tr>
	<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
	<?php include_once('affiliateleft.php'); ?>
	</td>
	<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">

	<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td class="navRow1" nowrap="nowrap" width="30%"> Unpaid Commissions -  Add Commission</td>
	</tr>
	</table>
	
	<?php echo isset($message) ? $message : '' ?>

	<form name="fAddCommission" action="unpaid_commissions_add.php?action=add" method="post" id="form">
	<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
	<tr><td class="gridHeader" width="200">Affiliate  <font color="Red"> *</font></td><td class="gridRow1">	
		<div>
		      <div>		    	 
					<input id="aff" name="aff" onKeyUp="lookup(this.value,'aff.php','#suggestions','#autoSuggestionsList');" type="text"  class="required" />		
					<input type="hidden" id="suggestionsHidden" name="suggestionsHidden" />
		   	  </div>          
   			  <div class="suggestionsBox" id="suggestions" style="display: none;">
	      				<img src="images/upArrow.png" style="position: relative; top: -12px; left: 30px" alt="upArrow" />	
	     				 <div class="suggestionList" id="autoSuggestionsList"></div>
    		  </div>
		</div>	
	</td></tr>	
	<tr><td class="gridHeader" width="200">Member  <font color="Red"> *</font></td><td class="gridRow1">	
		<div>
			<div>	    	 
				<input id="mem" name="mem" onKeyUp="lookup(this.value,'mem.php','#suggestionsm','#autoSuggestionsListm');" type="text"  class="required" />		
				<input type="hidden" id="suggestionsmHidden" name="suggestionsmHidden" />
		   	</div>          
   			<div class="suggestionsBox" id="suggestionsm" style="display: none;">
	      		<img src="images/upArrow.png" style="position: relative; top: -12px; left: 30px" alt="upArrow" />	
	     		<div class="suggestionList" id="autoSuggestionsListm"></div>
    		</div>

	    </div>	
	</td></tr>
	<tr><td class="gridHeader">Join/Renewal Date  <font color="Red"> *</font></td><td class="gridRow1">
		<select name="nMemberJoinDay">
		<?php
			for ($i=1; $i<=31; $i++) {
				echo '<option value="' .sprintf("%02d", $i) . '">' .  sprintf("%02d", $i) . '</option>';
			}
		?>
		</select>
		
		<select name="nMemberJoinMonth">
		<?php
			for ($i=1; $i<=12; $i++) {
				echo '<option value="' .sprintf("%02d", $i) . '">' . date('M',mktime(0,0,0,$i,1,2000)) . '</option>';
			}
		?>
		</select>
		
		<select name="nMemberJoinYear">
		
		<?php
			for ($i=0; $i<5; $i++) {
				echo '<option value="' . date('Y',mktime(0,0,0,1,1,date('Y')-$i)) . '">' . date('Y',mktime(0,0,0,1,1,date('Y')-$i)) . '</option>';
			}
		?>
		</select>
	</td></tr>
	<tr><td class="gridHeader">Commission Amount  <font color="Red"> *</font></td><td class="gridRow1"><input type="text" name="nCommission"  class="number required"></td></tr>
	<tr><td class="gridHeader">Transaction Number  <font color="Red"> *</font></td><td class="gridRow1"><input type="text" name="nTransactionNumber"  class="required"></td></tr>
	<tr><td class="gridHeader">Level Name <font color="Red"> *</font></td><td class="gridRow1">
	
		<?php 
		$sql="SELECT sLevel FROM tblmembershiplevels ORDER BY sLevel ";
		
		$rs=$dbo->select($sql);
		?>
	<select name="sItemName">
	<?php if(!empty($rs))
		while($row=$dbo->getobj($rs))
			echo "<option value='".$row->sLevel."'>".$row->sLevel."</option>";
				
	?>
	</select>
	
	</td></tr>
	<tr><td class="gridFooter" colspan="2"><input type="submit" value="Add" name="Add"></td></tr>
	</table>
	</form>
	
	</td>
</tr>
</table>

<?php include_once('b.php'); ?>
<script type="text/javascript">		
		$(document).ready(function()
		{
			$("#form").validate(
			{

				onkeyup: false, 
 				rules: {
							
						nCommission: 
									{
									    max:100000
									}
 						}
 					
			
		});
		});
</script>
</body>
</html>