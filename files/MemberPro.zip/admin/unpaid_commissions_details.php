<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	switch ($chkSsettings->sCurrencyFormat) {
		case "USD":
			$cvalue = "$";
			break;
		case "EUR":
			$cvalue = "&euro;";
			break;
		case "JPY":
			$cvalue = "&yen;";
			break;
		default:
			$cvalue = $chkSsettings->sCurrencyFormat;
	}
	
	// Affiliate ID
	$affiliate_id = $dbo->format($_GET['id']);
	
	$objAffiliate = get_user_by_id($affiliate_id);
	
	// Delete commission
	if (isset($_GET['action']) && $_GET['action'] == 'delete') {
		$sql = "DELETE FROM tblaffiliatepayments WHERE nAffiliatePayment_ID=" . $dbo->format($_GET['del_id']);
		$dbo->delete($sql);
	}

?>

<html><head><title><?php echo $admintitle; ?></title>
<?php include("inc-head.php"); ?>
<script type="text/javascript">
function delete_commission(id) {
	
	if (confirm("Are you sure you want to delete this commission?")) {
		document.location.href='unpaid_commissions_details.php?id=<?php echo $affiliate_id?>&action=delete&del_id=' + id;
	}
}
</script>
</head>
<body leftmargin="0" topmargin="0" rightmargin="0">

<?php include_once('top.php'); ?>

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
	<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
	<?php include_once('affiliateleft.php'); ?>
	</td>
	<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">

	<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td class="navRow1" nowrap="nowrap"> Unpaid Commissions </td>
		<td width="100%" align="center" class="navRow2">&nbsp;</td>
	</tr>
	</table>
	
	<div style="line-height: 1em;">
		<a href="unpaid_commissions.php"><img src="images/Arrow_Left_24x24.png" width="24" height="24" alt="Go Back" border="0" style="vertical-align: middle"></a> <a href="unpaid_commissions.php">Go Back</a>
	</div>

	<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
	<tr>
		<td colspan="6" class="gridHeader">Unpaid Commissions For <?php echo $objAffiliate->sForename ?> <?php echo $objAffiliate->sSurname ?></td><tr>
		<td class="gridHeader">Member Name</td>
		<td class="gridHeader" width="250">Email Address</td>
		<td class="gridHeader" width="100">Join/Renewal Date</td>
		<td class="gridHeader" width="100">Membership</td>
		<td class="gridHeader" align="right" width="80">Commission</td>
		<td class="gridHeader" align="center" width="80">Actions</td>
	
		<?php
			// Old Query Below. Used The Sale Customer Email TO Check.
			// This is flawed as custom can change their email.
			// New method tracks by User Id, Not User Email.
				
			$sql = "
				SELECT tblaffiliatepayments . * , tblusers.nUser_ID
FROM tblaffiliatepayments
INNER JOIN tblusers ON sEmail = tblaffiliatepayments.sUserEmail
WHERE tblaffiliatepayments.sPaymentStatus = ''
AND tblaffiliatepayments.nAffiliate_ID ='$affiliate_id'
ORDER BY tblaffiliatepayments.nMemberJoinDate
			";
			//die($sql);
			
			// New Query Uses nUser_ID
			/*$sql = "
			SELECT tblaffiliatepayments . * , tblusers.nUser_ID
			FROM tblaffiliatepayments
			INNER JOIN tblusers ON nUser_ID = tblaffiliatepayments.sUserEmail
WHERE tblaffiliatepayments.sPaymentStatus = ''
AND tblaffiliatepayments.nAffiliate_ID ='$affiliate_id'
ORDER BY tblaffiliatepayments.nMemberJoinDate
			";*/
			
			$tot_amt = 0;
			
			$rs = $dbo->select($sql);
			if ($rs !== false) {
				while ($row = $dbo->getassoc($rs)) {
					echo '<tr>';
					echo '<td class="gridRow1"><a href="view_member.php?id='.$row['nUser_ID'].'"> ' . $row['sUserForename'] . ' ' . $row['sUserSurname'] . '</a></td>';
					echo '<td class="gridRow1"><a href="view_member.php?id='.$row['nUser_ID'].'">' . $row['sUserEmail'] . '</a></td>';
					echo '<td class="gridRow1">' . fShowDate($chkSsettings->nDateFormat, $row['nMemberJoinDate']) . '</td>';
					echo '<td class="gridRow1">' . $row['sItemName'] . '</td>';
					echo '<td class="gridRow1" align="right">' . $cvalue . ' ' . number_format($row['nCommission'], 2) . '</td>';
					echo '<td class="gridRow1" align="center"><a href="unpaid_commissions_edit.php?aid=' . $affiliate_id . '&pid='. $row['nAffiliatePayment_ID'] .'"><img src="images/Edit_24x24.png" width="24" height="24" alt="Edit Commission" border="0"></a> <a href="#" onclick="delete_commission(\''. $row['nAffiliatePayment_ID'] .'\')"><img src="images/Delete_24x24.png" width="24" height="24" alt="Delete Commission" border="0"></a></td>';
					echo '</tr>';
					$tot_amt += $row['nCommission'];				
				}			
				// Totals
				echo '<tr><td colspan="4" class="gridFooter" align="right"><b>Total</b></td>';
				echo '<td class="gridFooter" align="right"><b>' . $cvalue . ' ' . number_format($tot_amt, 2) . '</b></td>';
				echo '<td class="gridFooter">&nbsp;</td></tr>';
			} else {
				echo "<tr><td colspan='6' class='gridRow1' style='text-align:center; color:#ff0000; font-weight:bold'>No Records Found</td></tr>";
			}
		?>
		</table>
	</td>
</tr>
</table>

<?php include_once('b.php'); ?>

</body>
</html>