<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	// Affiliate Payment ID
	$affiliate_id = $dbo->format($_REQUEST['aid']);
	
	// Affiliate Payment ID
	$affiliatepayment_id = $dbo->format($_REQUEST['pid']);
	
	if(empty($affiliatepayment_id)) {
		die("Invalid ID");
	}
	
	// Update affiliate commission
	if( isset($_GET['action']) && $_GET['action'] == "update" )
	{
		$sql = "UPDATE tblaffiliatepayments SET nCommission=" . $dbo->format($_POST['nCommission']) . "	
		WHERE nAffiliatePayment_ID=" . $affiliatepayment_id;
		$dbo->update($sql);
		
		$updated = true;
	}
	
	$sql = "
		SELECT * FROM tblaffiliatepayments 
		WHERE nAffiliatePayment_ID = " . $affiliatepayment_id
		;
		
	$objAffiliatePayment = $dbo->getobject($sql);
	
?>

<html><head><title><?php echo $admintitle; ?></title>
<?php include("inc-head.php"); ?>
</head>
<body leftmargin="0" topmargin="0" rightmargin="0">

<?php include_once('top.php'); ?>

<table cellpadding="0" cellspacing="0" width="100%">
<tr>
	<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
	<?php include_once('affiliateleft.php'); ?>
	</td>
	<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">

	<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td class="navRow1" nowrap="nowrap"> Unpaid Commissions -  Edit Commission
		<?php
		if ($updated) {
			$message = '<p class="success">Commission has been updated!</p>';
		}
		?>		
		</td>
		<td width="100%" align="center" class="navRow2">&nbsp;</td>
	</tr>
	</table>
	
	<?php echo isset($message) ? $message : '' ?>
	
	<div style="line-height: 1em;">
		<a href="unpaid_commissions_details.php?id=<?php echo $affiliate_id?>"><img src="images/Arrow_Left_24x24.png" width="24" height="24" alt="Go Back" border="0" style="vertical-align: middle"></a> <a href="unpaid_commissions_details.php?id=<?php echo $affiliate_id?>">Go Back</a>
	</div>

	<form name="fUpdateCommission" action="unpaid_commissions_edit.php?action=update" method="post">
	<input type="hidden" name="pid" value="<?php echo $affiliatepayment_id?>">
	<input type="hidden" name="aid" value="<?php echo $affiliate_id?>">
	<table class="gridTable" cellpadding="0" cellspacing="1" width="100%">
	<tr><td class="gridHeader" width="200">Member Name</td><td class="gridRow1"><?php echo $objAffiliatePayment->sUserForename ?> <?php echo $objAffiliatePayment->sUserSurname ?></td></tr>
	<tr><td class="gridHeader">Join/Renewal Date</td><td class="gridRow1"><?php echo fShowDate($chkSsettings->nDateFormat, $objAffiliatePayment->nMemberJoinDate) ?></td></tr>
	<tr><td class="gridHeader">Commission Amount</td><td class="gridRow1"><input type="text" name="nCommission" value="<?php echo number_format($objAffiliatePayment->nCommission,2) ?>" style="width: 50px;"></td></tr>
	<tr><td class="gridFooter" colspan="2"><input type="submit" value="Update"></td></tr>
	</table>
	</form>
	
	</td>
</tr>
</table>

<?php include_once('b.php'); ?>

</body>
</html>