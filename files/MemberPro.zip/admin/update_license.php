<?php session_start();
define( "INEMP", true );

include("../conn_data.php");
error_reporting(0);

// Our Database Class
require_once '../includes/dbgate.php';
$dbo = new dbgate($db_host,$db_username,$db_password,$db_name);

function emp_checkActivationKey($sKey, &$sMsg){
		
		$KEY = $sKey;
		$HOST = $_SERVER['HTTP_HOST'];
		$PATH = str_replace('install/'.basename($_SERVER['PHP_SELF']),'',$_SERVER['PHP_SELF']);
		$IP = $_SERVER['SERVER_ADDR'];
	
		//die($server);
		$URL = 'http://licensing.easymemberpro.com/remote.php?cmd=INSTALL&key='.$KEY.'&serverhost='.$HOST.'&serverip='.$IP.'&serverpath='.$PATH.'&version='.VERSION;
		
		//$result = @file_get_contents($sUrl);
		$ch = curl_init($URL);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		// do your curl thing here
		$result = curl_exec($ch);
		$http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		
		// Command Sent To Licensing Server.
		// Let Check To Make Sure It Responded.
		if($http_status != '200'){
			// Licensing Server Is Offline!
			$sMsg = 'error=Licensing Server Offline. Please Try Later or Contact Support.';
			
		}
		else{
			// Server Response All Good.
			if (strpos($result, 'error') !== false) {
						
				$sMsg = substr($result, strpos($result, "=") + 1);
				return false;
			}
			else {
			return true;
		}
		}
	
		
		
	}

if($_POST){
	$sql = "SELECT * FROM tblusers WHERE sEmail = '{$dbo->format($_POST['sUsername'])}' AND sPassword = '{$dbo->format($_POST['sPassword'])}' AND nAdmin = '1'";
	if(!$dbo->num_rows($sql)) $message = '<div class="notify-error"><div class="notify-close, error-close" onClick="closeNotify(this)"></div>No Admin Found With The Username / Password Combo Specified.</div>';
	else{
		
		// Admin Details verified.
		
		// Validate Key
		if (!emp_checkActivationKey($dbo->format($_POST['sNewKey']), $err_msg)) {

       $err = true;

       $sKey_error = $err_msg;

                                }
								
								
		if(!$err){
			// Change Key
			$sql = "UPDATE tblsitesettings SET sKey = '{$dbo->format($_POST['sNewKey'])}' WHERE 1;";
			$dbo->update($sql);
			$sql = "DELETE FROM `tbloptions` WHERE `sName` = 'licenseData' LIMIT 1";
			$dbo->delete($sql);
			header("Location:index.php?msg=".urlencode('License Key Updated Successfully.'));
		}
		else{die($sKey_error);}
		
		}
	}

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Update License Key</title>
        		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
		<script type="text/javascript" src="../js/jquery.validate.js"></script>
        <script type="text/javascript" src="../js/superfish.js"></script>
		<script type="text/javascript" src="../js/supersubs.js"></script>
        <link rel="stylesheet" type="text/css" href="../common/css/superfish.css" media="screen">
        <link rel="stylesheet" type="text/css" href="common/css/styles.css">
        <style type="text/css">
.sf-menu li {
    border-collapse:collapse;

}
	.sf-menu li li {
        padding: 0px 0px 0px 2px;
        background: url("../../../common/images/row1.gif") repeat-x;
        background-color: #fafafa;
        border-color: #ffffff;
        border-style: solid;
        border-width: 1px 1px 0px 1px;
        border-collapse:collapse }
	.sf-menu li li li {
        padding: 0px 0px 0px 2px;
        background: url("../../../common/images/row1.gif") repeat-x;
        background-color: #fafafa;
        border-color: #ffffff;
        border-style: solid;
        border-width: 1px 1px 0px 1px;
        border-collapse:collapse }
	.sf-menu a:focus, .sf-menu a:hover, .sf-menu a:active { background: [[MENU_HOVER_COLOR]]; outline: 0; }
	.sf-menu a, .sf-menu a:visited { color: [[MENU_TEXT_COLOR]]; }
	.sf-menu { float: left;}
	.sf-menu img {
		border:none;
		width:16px;
		height:16px;
		float:left;
		}
</style>
<script type="text/javascript">
		// initialise plugins
		jQuery(function(){
			$("ul.sf-menu").supersubs({ 
				minWidth:    5,   	// minimum width of sub-menus in em units 
				maxWidth:    50,   	// maximum width of sub-menus in em units 
				extraWidth:  1     	// extra width can ensure lines don't sometimes turn over 
							// due to slight rounding differences and font-family 
		        }).superfish();
		});
	</script>
<meta charset="utf-8" />
</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" class="">
  <!--DWLayoutTable-->
  <tr>
    <td class="header-bg">
    <table border="0" align="left" cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td width="20">&nbsp;</td>
          <td width="569" height="99"><img src="images/emp-cp-header-logo.jpg" width="546" height="106"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table class="gridtable margincancel" cellpadding="0" cellspacing="1" border="0" width="100%"><tr><td>
<ul class="sf-menu sf-js-enabled sf-shadow gridheader adminheader">
  <li><a class="sf-with-ul" href="home.php"><img src="../common/images/icons/house.png">&nbsp;Home</a></li>
  
  		<li><a class="sf" href="license.php?action=update">&nbsp;Add New License</a></li>
        <li><a href="http://easymemberpro.com/member/index.php?page=licensekey" target="_new" class="sf">&nbsp;Manage License</a></li>
        <li><a href="http://easymemberpro.com/support" target="_new" class="sf">&nbsp;Contact Support</a></li>
  
  </ul>
  </td>
  </tr>
  </table>
  




<br />
<div style="font-family:verdana;">
<?php echo ($message)? $message : ''; ?>
<?php if($_GET['action'] == 'update'){?>
<h1>Update License Key</h1>
<form name="form1" method="post" action="">
<table width="500px;" align="center" cellspacing="1" class="gridtable">
<tr class="gridtable">
<td colspan="2" class="gridheader">Admin Details</td>
</tr>
<tr class="gridtable">
<td class="gridrow2">Admin Username:</td>
<td class="gridrow2"><input type="text" name="sUsername" id="sUsername" style="width:200px;"></td>
</tr>
<tr>
<td class="gridrow2">Admin Password:</td>
<td class="gridrow2"><input type="password" name="sPassword" id="sPassword" style="width:200px;"></td>
</tr>
<tr>
  <td colspan="2" class="gridheader">License Key</td>
  </tr>
<tr>
<td class="gridrow2">New Key:</td>
<td class="gridrow2"><input type="text" name="sNewKey" id="sNewKey" style="width:200px;"></td>
</tr>
<tr class="gridfooter">
<td colspan="2" class="gridfooter" style="text-align:right"><input type="submit" name="button" id="button" value="Submit"></td>
</tr>
</table> 
</form>
<?php }
else{ ?>
<div style="width:850px; color:#BF0B0B; font-family:verdana; line-height:190%; border-style:solid; border-width:2px; border-color: #EF6B00; padding:20px; margin:auto; margin-top:50px;margin-bottom:50px;">
<h3>The script has found an problem with your license key<br />
License Key:<?php echo (isset($_SESSION['key']))?$_SESSION['key']:'Unknown'; ?></b><br />
Error:<?php echo (isset($_GET['msg']))?stripslashes($_GET['msg']):'Unknown' ?></h3>
</div>


<?php } ?>
</div>

<?php include_once('b.php'); ?>
	</body>
</html>