<?php
include_once('../conn.php');
include_once('../functions.php');

// Update values
if (isset($_POST['Update'])) {
	
	// Update tblsitesettings
	$nDisplayAddress = isset($_POST['nDisplayAddress']) ? 1 : 0;
	$nDisplayPhone = isset($_POST['nDisplayPhone']) ? 1 : 0;
	$nDisplayMobile = isset($_POST['nDisplayMobile']) ? 1 : 0;
	$nDisplayCoupon = isset($_POST['nDisplayCoupon']) ? 1 : 0;
	
	$sql = "UPDATE tblsitesettings SET 
			nDisplayAddressField = $nDisplayAddress,
			nDisplayTelephoneField = $nDisplayPhone,
			nDisplayMobileField = $nDisplayMobile,
			nDisplayCouponField  = $nDisplayCoupon
			;";
	
	$dbo->update($sql);
	
	// Update tblcustomfieldsettings
	for ($i = 1; $i <= 10; $i++) {
		
		$nDisplay = isset($_POST["nDisplay_$i"]) ? 1 : 0;
		if($nDisplay == 1){$nRequired = isset($_POST["nRequired_$i"]) ? 1 : 0;}
		else{$nRequired = 0;}
		
		
		$sql = "UPDATE tblcustomfieldsettings SET
				sCustomFieldName = '" . $dbo->format($_POST["sCustomFieldName_$i"]) . "',
				nDisplay = $nDisplay,
				nSortOrder = " . $dbo->format($_POST["nSortOrder_$i"]) . ",
				nRequired = '$nRequired' 
				WHERE nCustomFieldSetting_ID = $i";
		
		$dbo->update($sql);
	}
	
	// Get updated site data
	$objSiteSettings = $dbo->getobject("SELECT * FROM tblsitesettings");
	
	// Update message
	$message = "<span class='success'>User fields have been updated.</span>";
	
} else {
	$objSiteSettings = $chkSsettings;
}
?>
<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php include ('inc-head.php')?>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">
<?php include_once('top.php'); ?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td width="180" height="350" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
			<?php include_once('settingsleft.php'); ?>
		</td>
		<td style="padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			<form action="<?php echo $_SERVER['PHP_SELF']; ?>" name="form" method="post" id="form">
				<table class="navTable" cellpadding="0" cellspacing="0" width="100%">
					<tr>
						<td width="10%" nowrap="nowrap" class="navRow1"> User Fields</td>
					</tr>
				</table>
				
				<?php echo isset($message) ? '<p>' . $message . '</p>' : ''; ?>
				
				<p>The settings on this page allow you to turn on/off certain fields from the member's join page. You can also add up to 10 custom fields incase you need to capture additional information when members sign up.</p>
				
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td align="center" valign="top">
							<table width="100%" cellpadding="0" cellspacing="1" class="gridtable">
								<tr>
									<td colspan="7"  class="gridheader">Common Fields</td>
								</tr>
								<tr>
									<td rowspan="2" class="gridheader">Field Name</td>
								  	<td colspan="2" align="center" class="gridheader">Join Form</td>
									<td colspan="2" align="center" class="gridheader">Affiliate Form</td>
									<td colspan="2" align="center" class="gridheader">Member Profile</td>
								</tr>
								<tr>
									<td class="gridheader">Display?</td>
									<td class="gridheader">Required?</td>
									<td class="gridheader">Display?</td>
									<td class="gridheader">Required?</td>
									<td class="gridheader">Display?</td>
									<td class="gridheader">Required?</td>
								</tr>
								<tr>
									<td class="gridrow1">First Name</td>
								  	<td align="center" class="gridrow1"><input name="checkbox" type="checkbox" id="checkbox" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox8" type="checkbox" id="checkbox8" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox" type="checkbox" id="checkbox" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox8" type="checkbox" id="checkbox8" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox" type="checkbox" id="checkbox" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox8" type="checkbox" id="checkbox8" checked="CHECKED" disabled></td>
								</tr>
								<tr>
									<td class="gridrow1">Last Name</td>
									<td align="center" class="gridrow1"><input name="checkbox5" type="checkbox" id="checkbox5" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox9" type="checkbox" id="checkbox9" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox5" type="checkbox" id="checkbox5" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox9" type="checkbox" id="checkbox9" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox5" type="checkbox" id="checkbox5" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox9" type="checkbox" id="checkbox9" checked="CHECKED" disabled></td>
								</tr>
								<tr>
									<td class="gridrow1">Email</td>
									<td align="center" class="gridrow1"><input name="checkbox6" type="checkbox" id="checkbox6" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox10" type="checkbox" id="checkbox10" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox6" type="checkbox" id="checkbox6" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox10" type="checkbox" id="checkbox10" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox6" type="checkbox" id="checkbox6" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox10" type="checkbox" id="checkbox10" checked="CHECKED" disabled></td>
								</tr>
								<tr>
									<td class="gridrow1">Password</td>
									<td align="center" class="gridrow1"><input name="checkbox7" type="checkbox" id="checkbox7" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox11" type="checkbox" id="checkbox11" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox7" type="checkbox" id="checkbox7" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox11" type="checkbox" id="checkbox11" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox7" type="checkbox" id="checkbox7" checked="CHECKED" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox11" type="checkbox" id="checkbox11" checked="CHECKED" disabled></td>
								</tr>
								<tr>
									<td class="gridrow1">Complete Address<br></td>
									<td align="center" class="gridrow1"><input type="checkbox" name="nDisplayAddress" value="1" <?php echo ($objSiteSettings->nDisplayAddressField) ? ' checked=checked' : ''; ?> /></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
								</tr>
								<tr>
									<td class="gridrow1">Phone</td>
								  	<td align="center" class="gridrow1"><input type="checkbox" name="nDisplayPhone" value="1" <?php echo ($objSiteSettings->nDisplayTelephoneField) ? ' checked=checked' : ''; ?> /></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
								</tr>
								<tr>
									<td class="gridrow1">Mobile</td>
								  	<td align="center" class="gridrow1"><input type="checkbox" name="nDisplayMobile" value="1" <?php echo ($objSiteSettings->nDisplayMobileField) ? ' checked=checked' : ''; ?> /></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
									<td align="center" class="gridrow1"></td>
								</tr>
								<tr>
									<td class="gridrow1">Coupon</td>
								  	<td align="center" class="gridrow1"><input type="checkbox" name="nDisplayCoupon" value="1" <?php echo ($objSiteSettings->nDisplayCouponField) ? ' checked=checked' : ''; ?> /></td>
									<td align="center" class="gridrow1">&nbsp;</td>
									<td align="center" class="gridrow1"><input name="checkbox2" type="checkbox" id="checkbox2" disabled></td>
									<td align="center" class="gridrow1"><input name="checkbox3" type="checkbox" id="checkbox3" disabled></td>
									<td align="center" class="gridrow1">&nbsp;</td>
									<td align="center" class="gridrow1">&nbsp;</td>
								</tr>
                                <tr>
                                <td class="gridfooter" colspan="9">&nbsp;</td>
                                </tr>
                                </table>
                                <table class="gridtable" cellpadding="0" cellspacing="1" width="100%">
								<tr>
									<td colspan="4" class="gridheader">Custom Fields</td>
								</tr>
								<tr>
									<td class="gridheader" width="350">Field Name</td>
								  	<td width="80" align="center" class="gridheader">Display?</td>
									<td width="96" class="gridheader">Sort Order</td>
									<td width="764" class="gridheader">Join Required?</td>
								</tr>
								<?php
								$objCustomFieldSettings = $dbo->select("SELECT * FROM tblcustomfieldsettings ORDER BY nSortOrder, sCustomFieldName");
								while($row = $dbo->getobj($objCustomFieldSettings)):
								?>
								<tr>
									<td class="gridrow1"><input type="text" name="sCustomFieldName_<?php echo $row->nCustomFieldSetting_ID ?>" value="<?php echo $row->sCustomFieldName ?>" style="width: 300px;" /></td>
									<td class="gridrow1" align="center"><input type="checkbox" name="nDisplay_<?php echo $row->nCustomFieldSetting_ID ?>" value="1" <?php echo ($row->nDisplay) ? ' checked=checked' : '' ?> /></td>
									<td class="gridrow1"><input type="text" name="nSortOrder_<?php echo $row->nCustomFieldSetting_ID ?>" value="<?php echo $row->nSortOrder ?>" style="width: 30px;" /></td>
									<td class="gridrow1"><input name="nRequired_<?php echo $row->nCustomFieldSetting_ID ?>" type="checkbox" id="nRequired_<?php echo $row->nCustomFieldSetting_ID ?>" value="1" <?php echo ($row->nRequired) ? ' checked=checked' : '' ?> /></td>
								</tr>
								<?php
								endwhile;
								?>
								<tr>
									<td colspan="4" class="gridFooter">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr>
												<td valign="top"><input type="submit" name="Update" value="Save Changes" class="inputSubmitb" /></td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</form>
		</td>
	</tr>
</table>
<?php include_once('b.php'); ?>
<script type="text/javascript">		
		$(document).ready(function()
		{
			$("#form").validate(
			{
				onkeyup: false 		 					
			
			});
		});
</script>
	</body>
</html>