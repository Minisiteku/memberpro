<?php
	include_once ('../conn.php');
	include_once ('../functions.php');
	include_once ('../includes/encrypt.php');
	
	function validateLicense($key){
		global $chkSsettings;
		// We Check The License Every 3 Days.
		// If Server Down Allow 3 Day Pass
		
		$check = 0;
		if(!is_option('license_lastChecked')) $check = 1;
		elseif(time() - (int)get_option('license_lastChecked') > 60*60*24*3 ) $check = 1;
		
		if($check == 0){return 1;}
		
		$KEY = $chkSsettings->sKey;
		$HOST = str_replace('www.','',$_SERVER['HTTP_HOST']);
		$IP = $_SERVER['SERVER_ADDR'];
		$PATH = str_replace('admin/'.basename($_SERVER['PHP_SELF']),'',$_SERVER['PHP_SELF']);
		$VERSION = $chkSsettings->nScriptVersion;
		
		$URL = "http://licensing.easymemberpro.com/remote.php?cmd=VERIFY&key=$KEY&serverhost=$HOST&serverip=$IP&serverpath=$PATH&version=$VERSION";
		
		// must set $url first. Duh...
		$ch = curl_init($URL);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		// do your curl thing here
		$result = curl_exec($ch);
		$http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		
		if($http_status != '200'){
			// Cannot Communicate With The Licensing Server.
			
			if(!get_option('license_serverDown')){
				// First Time Logged Down Server.
				// Log and Allow
				add_option('license_serverDown',time());
				// Noted The Down Server Time.
				// Allow Continue
				return 1;
				}
				
			if(time() - get_option('license_serverDown') > 60*60*24*3){
				// Server reported down for 3 days. Shouldnt Happen. Inactive
				$msg = 'The System Has Indicated That The License Server Has Been Down For More Than 3 Days. Contact Support.';
				header("Location:inactive.php?msg=$msg");exit;
				
			}
			else{
				// We Are Within The 3 day period. Allow the pass.
				return 1;
				}
				
		}
		else{
			// License Server Responded.
			if(get_option('license_serverDown') && get_option('license_serverDown')!=''){update_option('license_serverDown','');}
			
			// Redirect On Received Error ...
			if(strpos($result,'error=')!==false){
				$msg = str_replace('error=','',$result);
				$_SESSION['key']=$sKey;
				header("Location:inactive.php?msg=$msg");
				exit;
			}
			
			// License Verified.
			if(is_option('license_lastChecked')){update_option('license_lastChecked',time());}
			else{add_option('license_lastChecked',time());}
			
			return 1;
			
		}
		}

	if (isset($_POST['Submit'])) {
		
		validateLicense($chkSsettings->sKey);
		
		$sql = "SELECT * FROM tblusers WHERE sEmail = '" . $dbo->format($_POST['user']) ."' AND sPassword = '" . $dbo->format($_POST['password']) ."' AND nAdmin = 1 AND nActive = 1;";
		$result = $dbo->select($sql);
			
		if($dbo->nr($result)== 1){
			$objAdmin = $dbo->getobj($result);
		
			$secure->setAuth('admin',$objAdmin);
				
				
			// Set level access for admin
			set_user_level_privileges($objAdmin->nUser_ID);
		
			//TODO Check remember me functionality
			if ($_POST['rememberme'] == '1') {
				// Set Expiration = 1 year
				$encrypt = new Encrypt();
					$user = $encrypt->encode($_POST['user']);
					$pass = $encrypt->encode($_POST['password']);
					setcookie("adm_u", $user, time() + 31536000);
					setcookie("adm_p", $pass, time() + 31536000);
				} 
			else {
					// Expire Cookie
					setcookie("adm_u", "", time() - 3600);
					setcookie("adm_p", "", time() - 3600);
				}
			//header("Location: home.php");exit;
			if (isset($_GET['redirect'])) {
				$redirect_url = urldecode($_GET['redirect']);
			}
			else {$redirect_url = "home.php";}	
		}
		else {
			$redirect_url = "index.php?err=".urlencode('Invalid Username/Password Given! Please Try Again');
			if(isset($_GET['redirect'])) $redirect_url .= '&redirect='.$_GET['redirect'];
		}
		header("Location: $redirect_url");
		
	}
?>