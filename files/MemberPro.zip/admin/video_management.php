<?php

include_once ('../conn.php');
include_once ('../functions.php');

$ctid = (isset($_REQUEST['ctid'])) ? $_REQUEST['ctid'] : 0; // Category ID
$ft = (isset($_REQUEST['ft'])) ? $_REQUEST['ft'] : ''; // File Type
$ipp = (!empty($_GET['ipp'])) ? $_GET['ipp'] : 10; // Items per Page
$sort = (!empty($_GET['sort'])) ? $_GET['sort'] : 'sFileName';
$sortdir = (!empty($_GET['sortdir'])) ? $_GET['sortdir'] : 'ASC';
$start = (!empty($_GET['start'])) ? $_GET['start'] : 0;

// Set QueryString Values after post
if (isset($_POST['Update'])) {
    $ctid = $_POST['ctid'];
    $ipp = $_POST['ipp'];
    $sort = $_POST['sort'];
    $sortdir = $_POST['sortdir'];
    $start = $_POST['start'];
}

// Setup Options for Items per Page listing
$aIPP = array('5', '10', '15', '20', '25', '50', '100');

// DELETE FILE
if ($_GET['act'] == 'd') {
    $row = $dbo->getrow("SELECT sFilename FROM tblvideos WHERE nVideo_ID = '" . $dbo->format($_GET['flid']) . "'");
    $dbo->delete("DELETE FROM tblvideos WHERE nVideo_ID = " . $dbo->format($_GET['flid']));
    $message = "<p class='success'>Video has been deleted.</p>";
}

// LOCK/UNLOCK VIDEOS
if (isset($_GET['lock']) && is_numeric($_GET['lock'])) {
	if (isset($_GET['id']) && is_numeric($_GET['id'])) {
		$sql = "UPDATE tblvideos SET nMemberOnly=" . $dbo->format($_GET['lock']) . " WHERE nVideo_ID=" . $dbo->format($_GET['id']);
		$dbo->update($sql);
	}
}

// IMPORT FILES
if ($_GET['act'] == 'imp') {
	include_once('mime.php');
	$new = addVideosToDb('/');
    $removed = removeVideosFromDb();
    $msg = ($new > 0) ? $new . " videos(s) imported. " : "No videos to import. ";
    $msg .= ($removed > 0) ? $removed . " videos(s) removed. " : "No videos to remove. ";
    $message = "<p class='success'>$msg</p>";

}

// Get File Types List
$aFile = array('All Files', 'AUDIO', 'DOC', 'EXCEL', 'EXE', 'FLASH', 'IMAGES', 'PDF', 'VIDEO', 'ZIP');
ksort($aFile);
$filetype = '';
foreach ($aFile as $item) {
    $selected = ($item == $ft) ? 'selected' : '';
    $filetype .= sprintf("<option value='%s' %s>%s</option>", $item, $selected, $item);
}

?>
<html>
		<head>
		<title><?php echo $admintitle; ?></title>
		<?php include("inc-head.php"); ?>
		<style>
.iconspacing {
	margin-right:2px
}
</style>
		<script type="text/javascript">
			function cdel(w) {
				return confirm("Are you sure you want to DELETE the\n\""+w+"\" video?");
			}

			function openPopup(page) {	
				window.open(page,'','height=265,width=650,scrollbars=yes,location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=yes');
			}
			
			function MM_openBrWindow(theURL,winName,features) {
				window.open(theURL,winName,features);
			}
			
			function filterFiles(oList) {
				var ft = oList.options[oList.selectedIndex].value;
				var qs = '?start=0';
				qs += '&ft=' + ft;
				qs += '&sort=<?php echo $sort ?>';
				qs += '&sortdir=<?php echo $sortdir ?>';
				qs += '&ipp=<?php echo $ipp ?>';
				document.location = 'video_management.php' + qs;
			}

			function updateIPP(oList) {
				var ipp = oList.options[oList.selectedIndex].value;
				var qs = '?start=0';
				qs += '&ft=<?php echo $ft ?>';
				qs += '&sort=<?php echo $sort ?>';
				qs += '&sortdir=<?php echo $sortdir ?>';
				qs += '&ipp=' + ipp;
				document.location = 'video_management.php' + qs;
			}
		</script>
		</head>
		<body leftmargin="0" topmargin="0" rightmargin="0">

<!-- Include Navigation -->
<?php include_once ('top.php'); ?>

<!-- Start Content -->
<table  border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr> 
		<!-- START LEFT SIDE -->
		<td width="180" height="350" rowspan="2" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;"><?php include_once ('pageleft.php'); ?></td>
		<!-- START RIGHT SIDE -->
		<?php

$sql = sprintf("SELECT * FROM tblvideos ORDER BY %s %s ", $sort, $sortdir);

// Get Count to pass into paging object
$rs = $dbo->select("SELECT COUNT(*) FROM tblvideos " . $qry);
$row = $dbo->getarray($rs,'NUM');
$number = $row[0];

// Start Paging
/*********************************************************/
include_once ('paging.php');
$objPaging = new Paging();

unset($_GET['start']);

$objPaging->Total_Records_Per_Page = $ipp;
$objPaging->Total_Records = $number;
$index = $start;
$indexupto = $index + $objPaging->Total_Records_Per_Page;
$objPaging->prepare_ParameterString($_GET);
$objPaging->set_Start_Item($indexupto);
$objPaging->Has_First_Last = true;
$navigator = $objPaging->Create_Paging();
$pageinfo = $objPaging->get_PageInfo();
$counter = 0;
$sql .= "LIMIT " . $objPaging->Total_Records_Per_Page . " OFFSET " . $index;
/*********************************************************/
//echo $sql;

$result = $dbo->select($sql);

// Put together QueryString
$qs = sprintf("?ctid=%s&start=%s&ipp=%s&ft=%s", $ctid, $start, $ipp, $ft);
//echo $qs;

?>
		<td style="height:40px; padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%"><table class="navTable" border="0" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td colspan="2" class="navRow1" nowrap="nowrap">Video Management</td>
					<td class="navRow2" style="text-align:right; padding-right:20px"> Items per page&nbsp;
						<select id='ipp' style='height:1.5em' onChange="updateIPP(this)">
							<?php
foreach ($aIPP as $val) {
    $selected = ($val == $ipp) ? 'selected' : '';
    ;
    echo "<option value='$val' $selected>$val</option>";
}
?>
						</select></td>
				</tr>
			</table>
					<?php echo isset($message) ? $message : '' ?></td>
	</tr>
			<tr>
		<td style="width:100%; padding-left: 8px; padding-right: 8px; vertical-align:top; padding-top:0px"><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:0px">
				<tr>
					<td height="55" align="left" valign="top" bgcolor="#FFFFFF"><div align="justify">
							<table width="100%"  border="0" cellspacing="5" cellpadding="0">
								<tr>
									<td height="60" valign="top"><!-- HEADER -->
										
										<table width="100%"  border="0" cellspacing="0" cellpadding="0" style="margin-top:5px">
											<tr> 
												<!-- Add Videos Button -->
												<td style="padding-left:5px; vertical-align:bottom" colspan="4"><input class="inputSubmitb" type="button" onClick="document.location.href='video_management_add.php'" value="Add Remote Video" />
													&nbsp;&nbsp;&nbsp;&nbsp;
													<input class="inputSubmitb" type="button" onClick="document.location.href='video_management.php<?php echo $qs ?>&act=imp'" value="Import Local Videos" /></td>
											</tr>
											<tr>
												<td colspan="4" style="padding-top:5px"><span style="color:navy">&nbsp;</span></td>
											</tr>
											<form name="form1" method="post" action="video_management.php">
												<input type="hidden" id="act" name="act" value="">
												<tr align="right" valign="top">
													<td height="20" colspan="4"><!-- Hidden Fields for restoring variables after post -->
														
														<input type="hidden" name="ctid" value="<?php echo $ctid ?>">
														<input type="hidden" name="ipp" value="<?php echo $ipp ?>">
														<input type="hidden" name="sort" value="<?php echo $sort ?>">
														<input type="hidden" name="sortdir" value="<?php echo $sortdir ?>">
														<input type="hidden" name="start" value="<?php echo $start ?>">
														<table width="100%" border="0" cellpadding="0" cellspacing="0" class="gridTable">
															<tr>
																<td valign="top"><table width="100%"  border="0" cellpadding="0" cellspacing="1">
																		<!-- NAVIGATION -->
																		<tr>
																			<td colspan="6" class="gridFooter"><table width="100%" border="0" cellspacing="0" cellpadding="0">
																					<tr>
																						<td style='text-align:left'><?php echo $navigator; ?></td>
																						<td style='text-align:right; padding-right:10px'> Page <?php echo $pageinfo ?></td>
																					</tr>
																				</table></td>
																		</tr>
																		<!-- HEADINGS -->
																		<tr valign="top">
																			<td style="width:100px;" class="gridHeader"><?php $sd = ($sort == 'sFileName' && $sortdir == 'ASC') ? 'DESC' : 'ASC'; ?>
																				<a href="video_management.php<?php echo $qs ?>&sort=sFileName&sortdir=<?php echo $sd ?>" class="bluenave">Video Filename</a></td>
																			<td class="gridHeader"><?php $sd = ($sort == 'sURL' && $sortdir == 'ASC') ? 'DESC' : 'ASC'; ?>
																				<a href="video_management.php<?php echo $qs ?>&sort=sURL&sortdir=<?php echo $sd ?>" class="bluenave">Location</a></td>
																			<td class="gridHeader"> Embed Code </td>
																			<td class="gridHeader"><?php $sd = ($sort == 'nMemberOnly' && $sortdir == 'ASC') ? 'DESC' : 'ASC'; ?>
																				<a href="video_management.php<?php echo $qs ?>&sort=nMemberOnly&sortdir=<?php echo $sd ?>" class="bluenave">Member Only Video?</a></td>
																			<td style="text-align:left; padding-left:20px; vertical-align:middle" class="gridHeader">Action</td>
																		</tr>
																		<?php
                                                                            // Add Sort to QueryString
                                                                            $qs .= sprintf("&sort=%s&type=%s", $_GET['sort'], $_GET['sortdir']);
                                                                            if (!empty($result)){
                                                                                while ($row = $dbo->getobj($result)){
                                                                                    $localpath = 'assets'.$row->sPath;
                                                                        
                                                                                    // Subfolder detection
                                                                                    if($row->sPath !=='/'){$localpath .= '/';}
                                                                        ?>
																		<!-- VIDEO LISTING -->
																		<tr valign="top"> 
																			<!-- FILENAME -->
																			<td class="gridRow1"><?php echo $row->sFileName ?></td>
																			<!-- LOCATION -->
																			<td class="gridRow1">
																				<?php echo empty($row->sURL) ? '<a href="' . $localpath.$row->sFileName . '" target="_blank">Local File</a>' :
																				 '<a href="' . $row->sURL . '" target="_blank">Remote URL</a>'; ?>
																			</td>
																			<!-- EMBED CODE -->
																			<td class="gridRow1"> [[video <?php echo $row->nVideo_ID; ?>]] </td>
																			<!-- MEMBER ONLY -->
																			<td class="gridRow1"><?php if ($row->nMemberOnly == 0) : ?>
																				<a href="video_management.php<?php echo $qs?>&id=<?php echo $row->nVideo_ID; ?>&lock=1" class="black" 
																				title="This can currently be viewed on the front end and members area pages.
																				Click the padlock to only allow members to view this video.">
																				<img src="images/icon_lock_open.png" 
																				alt="This can currently be seen on the front end and members area. 
																				Click the padlock to only allow members to view this video." width="16" height="16" border="0" />
																				</a>
																				<?php else : ?>
																				<a href="video_management.php<?php echo $qs?>&id=<?php echo $row->nVideo_ID; ?>&lock=0" class=black 
																				title="This can currently be viewed on member's pages only. Click the padlock to unlock it so that 
																				you can use this video on both front-end AND members pages.">
																				<img src="images/icon_lock.png" alt="This can currently be viewed on member's pages only. 
																				Click the padlock to unlock it so that you can use this video on both front-end AND members pages." 
																				width="16" height="16" border="0" />
																				</a>
																				<?php endif; ?></td>
																			<!-- ACTIONS -->
																			<td class="gridRow1"><!-- Delete --> 
																				<a href="video_management.php<?php echo $qs ?>&flid=<?php echo $row->nVideo_ID; ?>&act=d" class="bluenew" OnClick="return cdel('<?php echo $row->sTitle ?>');"><img src="images/drop.jpg" width="16" height="16" border="0" class="iconspacing"></a></td>
																		</tr>
<?php 
		}
	}
	else{?>
																		<tr>
																			<td colspan="6" class="gridFooter">No Videos Added Yet</td>
																		</tr>
<?php 
	}
																	
?>
																		<tr>
																			<td colspan="6" class="gridFooter"><table width="100%" border="0" cellspacing="0" cellpadding="0">
																					<tr>
																						<td style='text-align:left'><?php echo $navigator; ?></td>
																						<td style='text-align:right; padding-right:10px'> Page <?php echo $pageinfo ?></td>
																					</tr>
																				</table>
																			</td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</form>
										</table>
									</td>
								</tr>
							</table>
						</div>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<?php include_once ('b.php'); ?>
</body>
</html>