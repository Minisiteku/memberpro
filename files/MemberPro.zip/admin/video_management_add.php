<?php
include_once ('../conn.php');
include_once ('../functions.php');

// Process form
if (isset($_POST['Submit'])) {
	// Trim
	$url = trim($_POST['sVideoURL']);
	// Add Video URL to database
	$message = addRemoteVideoToDb($url) ? "<span class='success'>Video added to database successfully</span>" : "<span class='error'>There was a problem adding this video, please check the URL and try again.</span>";
}
?>

<html>
	<head>
		<title><?php echo $admintitle; ?></title>
		<?php include ('inc-head.php')?>
	</head>
	<body leftmargin="0" topmargin="0" rightmargin="0">

<!-- Include Navigation -->
<?php include_once ('top.php'); ?>

<!-- Start Content -->
<table  border="0" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<!-- START LEFT SIDE -->
		<td width="180" height="350" rowspan="2" valign="top" nowrap="nowrap" class="contentSide_members" style="padding: 8px;">
			<?php include_once ('pageleft.php'); ?>
		</td>
		<!-- START RIGHT SIDE -->
		<td style="height:40px; padding-left: 8px; padding-top: 8px; padding-right: 8px;" valign="top" width="100%">
			<table class="navTable" border="0" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td colspan="2" class="navRow1" nowrap="nowrap">Video Management - Add Remote Video</td>
					<td class="navRow2" style="text-align:right; padding-right:20px"></td>
				</tr>
			</table>
			
			<?php echo isset($message) ? $message : '' ?>
			
			<div style="line-height: 1em; margin-bottom: 5px;">
				<a href="video_management.php"><img src="images/Arrow_Left_24x24.png" width="24" height="24" alt="Go Back" border="0" style="vertical-align: middle"></a> <a href="video_management.php">Go Back</a>
			</div>
			
		</td>
	</tr>

	<tr>
		<td style="width:100%; padding-left: 8px; padding-right: 8px; vertical-align:top; padding-top:0px">
			<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" style="margin-top:0px">
				<tr>
					<td height="55" align="left" valign="top" bgcolor="#FFFFFF">
						<div align="justify">
							<table width="100%"  border="0" cellspacing="5" cellpadding="0">
								<tr>
									<td valign="top">
									
									<form id="formVideo" method="post" action="video_management_add.php">
									
										<table width="100%" cellspacing="1" cellpadding="0" border="0" class="gridTable">
										<tr><td colspan="2" class="gridHeader">Add Remote Video</td></tr>
										<tr>
											<td class="gridRow1" width="150">URL <span style="color: red">*</span></td>
											<td class="gridRow1">
												<input type="text" name="sVideoURL" style="width: 500px;" class="url required" /> 
												<small>e.g. http://www.somewebsite.com/uploads/video123.flv</small>
											</td>
										</tr>
										<tr><td class="gridFooter" colspan="2"><input name="Submit" type="submit" value="Submit" class="inputSubmit"></td></tr>
										</table>
										
									</form>	
										
									</td>
								</tr>
							</table>
						</div>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<?php include_once ('b.php'); ?>
<script type="text/javascript">		
		$(document).ready(function()
		{
			$("#formVideo").validate();
		});
</script>
	</body>
</html>