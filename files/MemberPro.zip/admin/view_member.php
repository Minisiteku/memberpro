<?php
	include_once('../conn.php');
	include_once('../functions.php');
	
	if(!class_exists('empDateTime')){
		include_once('../includes/datetime.class.php');
		$empDateTime = new empDateTime($chkSsettings->nDateFormat);
	}
	
	// Set user id
	if (isset($_GET['id']) && is_numeric($_GET['id'])) {$_SESSION['user_id'] = $dbo->format($_GET['id']);}
	$user_id = $_SESSION['user_id'];
	
	// Get user's details
	$objUser = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID = " . $user_id);
	if($objUser->nActive){$status = 'Active';}
	else{$status = 'Inactive';}
	
	// Get Login Details
	$sql = "SELECT * from tbluserlogins WHERE nUser_ID = $user_id ORDER BY nTimestamp DESC limit 1";
	$result = $dbo->select($sql);
	if($dbo->nr($result)){$loginData = $dbo->getobj($result);}
	
	$currency_symbol = get_currency_symbol($chkSsettings->sCurrencyFormat);
	
	// Get Payment Processors
	$payres = $dbo->select("SELECT nPaymentProcessor_ID,sProcessorName FROM tblpaymentprocessors");
	if($payres){
		while($row = $dbo->getobj($payres)){
			$processors[$row->nPaymentProcessor_ID] = $row->sProcessorName;
		}
		
		
	}
	
	// GET Membership Levels
	$sql = "SELECT * FROM tblmembershiplevels";
	$levelRes = $dbo->select($sql);
	
	$levelsel = "<select id='membershiplevelselect' name='membershiplevel' onChange='getPaymentPlansByLevel(this)'>\n\t
	<option value = '0'>--- Choose Membership Level ---</option>\n\t";
	
	while($row = $dbo->getobj($levelRes)){
		$levelsel .= '<option value="'.$row->nLevel_ID.'">'.$row->sLevel.'</option>\n\t';
	}
	
	$levelsel .='</select>';
	
	
	
	
	
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8" />
    <title><?php echo $admintitle; ?></title>
    <?php include("inc-head.php"); ?>
    <link type="text/css" rel="stylesheet" href="../common/css/jqueryui/redmond/jquery-ui-1.8.24.custom.css">
   <script language="javascript" src="../js/jquery-ui-1.8.24.custom.min.js"></script>
   <!-- <script language="javascript" src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script> -->
	<script language="javascript" src="../js/jquery-ui-timepicker-addon.js"></script>
    <script language="javascript" type="text/javascript">
	
	// Resend Login Deatils Functions
	function resendLogin() {
			window.frames.runcode.location.replace('sendlogin.php?userid=<?php echo $user_id ?>');
		}
	function showResendMsg(type){
		if(type == 'msg'){$("#msgResend").addClass('green').html('Login Details Sent Successfully!');}
		else{$("#msgResend").addClass('error').html('Failed To Send Login Information!');}
		
		}
	// Used To Toggle Boxes For Editing
	function showEdit(box,act){
		if(box == 'profile'){
			if(act == 'edit'){
				$("#profileShow").hide();
				$("#profileEdit").show();
			}
			if(act == 'show'){
				$("#profileShow").show();
				$("#profileEdit").hide();
			}
		}
		if(box == 'account'){
			if(act == 'edit'){
				$("#accountShow").hide();
				$("#accountEdit").show();
			}
			if(act == 'show'){
				$("#accountShow").show();
				$("#accountEdit").hide();
			}
		}
		if(box == 'comments'){
			if(act == 'edit'){$("#commentsEdit").show();}
			if(act == 'show'){
				$("#comments").val('');
				$("#commentsEdit").hide();
			}
		}
		if(box == 'affiliate'){
			if(act == 'edit'){
				$("#affiliateShow").hide();
				$("#affiliateEdit").show();
			}
			if(act == 'show'){
				$("#affiliateShow").show();
				$("#affiliateEdit").hide();
			}
		}
		if(box == 'customfields'){
			if(act == 'edit'){
				$("#customfieldsShow").hide();
				$("#customfieldsEdit").show();
			}
			if(act == 'show'){
				$("#customfieldsShow").show();
				$("#customfieldsEdit").hide();
			}
		}
		return false;
	}
	
	function getPaymentPlansByLevel(level){
		levelId = $('#'+level.id).val();
		$.getJSON( "ajax/functions.php?act=getPaymentPlansByLevel&level="+levelId,function(data){
			//console.log(data);
			$('#paymentPlan').empty();
			$.each(data,function(index,value){
				$('#paymentPlan').append($("<option></option>").attr("value",value.nPaymentPlan_ID).text(value.sPlanName));
				
			});
			
			//
			
			});
		
	}
	
	function addPayment(row){
		// row is json row object
		$("#payment_LevelName").html(row.sLevel);
		$("#payment_PlanName").html(row.sPlanName);
		$("#payment_userLevelId").val(row.nUserLevel_ID);
		$("#paymentPlanId").val(row.nPaymentPlan_ID);
		
		if(row.nOneTimePayment == '0'){
			
			$("#payment_LevelIdentifier").html('Subscription');
			$("#payment_LevelIdentifier2").html('Subscription');
			$("#recurring-instructions").show();
			$("#onetime-instructions").hide();
			
		}
		
		$("#payment_LevelIdentifierValue").html(row.sTransactionNumber);
		
		$("#expirePeriod").html(row.nRegularPeriod+' '+row.sRegularPeriod);
		$("#currentExpireDate").html(row.formattedExpireDate);
		
		
		
		
		
		$( "#addPayment" ).dialog( "open" );
		
		
		
	}
	
	// Used to Load Modal Box For Member Level Reactivate
	function reactivateLevel(id){
		$( "#ReactivateLevel" ).dialog( "open" );
		$( "#ReactivateLevelId" ).val(id);
		return false;
		
	}
			
	function editLevel(id){
		
		// This Function Grabs The Pre-defined html for the edit level dialog box.
		// It sets special functions, builds the dialog box, and wraps it all in a form
		// to send to actions.php
		
		// Grab The Populated Form
		var ddiv = document.getElementById("LevelEdit_"+id).innerHTML
		
		// Insert The data into the dialog element
		$("#model-form-container").html(ddiv);
		
		// Assign Txn id for Auto Suggest
		$("#Model-Form input[name=Txn]").attr('id','Txn');
		
		// Assign The Picker Class
		$("#Model-Form input[name=DateActive]").addClass('datepicker');
		$("#Model-Form input[name=DateExpires]").addClass('datepicker');
		
		// Register Picker
		$( ".datepicker" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '2000:2037',changeYear: true});
		
		// Set the dialog title
		var title = $("#EditLevel h1.dialog-title").html()
		
		$( "#EditLevel" ).dialog('option','title',title).dialog( "open" );
		// Launch the Dialog Box
		$( "#EditLevel" ).dialog( "open" );
		
		$( "#EditLevelId" ).val(id);
		return false;
	}
	
	function loadRecentEmail(id){
		$.getJSON( "ajax/functions.php?act=loadRecentEmail&id="+id,function(data){
			$('#recentEmail_Subject').html(data.sSubject);
			$('#recentEmail_Message').html(data.sBodyHtml);
			$( "#recentEmail" ).dialog( "open" );
			//
			
			});
	}
		
	$.fx.speeds._default = 1000;
		
	$(function() {
		$( "#openAddNew" ).click(function() {
            $( "#AddNewLevel" ).dialog( "open" );
			$( "#nDateExpires" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '2000:2037',changeYear: true});
            return false;
        });
		$( "#openNewSale" ).click(function() {
            $( "#newSale" ).dialog( "open" );
			$( "#nDateExpires" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '2000:2037',changeYear: true});
            return false;
        });
		$( "#openAddTransaction" ).click(function() {
            $( "#AddTransaction" ).dialog( "open" );
			
            return false;
        });
		
		$( "#nExpires" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '2000:2037',changeYear: true});
		$( ".datepicker" ).datepicker({ dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',yearRange: '2000:2037',changeYear: true});
		$( ".datetimepicker" ).datetimepicker({ 
			dateFormat: '<?php echo fPickerDateFormat($chkSsettings->nDateFormat) ?>',
			timeFormat: "HH:mm:ss",
			yearRange: '1970:2037',
			changeYear: true });
		
		//
		$( "#AddNewLevel" ).dialog({
            autoOpen: false,
            show: "explode",
            hide: "explode",
			modal: true,
			width:'auto',
			height:'auto'
        });
		$( "#ReactivateLevel" ).dialog({
            autoOpen: false,
            show: "explode",
            hide: "explode",
			modal: true,
			width:'auto',
			height:'auto'
        });
		$( "#EditLevel" ).dialog({
            autoOpen: false,
            show: "explode",
            hide: "explode",
			modal: true,
			width:'auto',
			height:'auto'
        });
		$( ".mydialog" ).dialog({
            autoOpen: false,
            show: "explode",
            hide: "explode",
			modal: true,
			width:'auto',
			height:'auto'
        });
		$( "#recentEmail" ).dialog({
            autoOpen: false,
            show: "explode",
            hide: "explode",
			modal: true,
			width:( $(window).width() /1.75),
			height:( $(window).height() /1.75)
        });
		
		// Send Email Features
		$( "#sendEmail" ).dialog({
            autoOpen: false,
            show: "explode",
            hide: "explode",
			modal: true,
			width: '650px',
			height:'auto'
        });
		checked = $('input[name=emailType]:checked', '#sendEmailModal').val()
		
		if(checked == 'html'){$('#email_message').removeClass("mceNoEditor").addClass("mceEditor");}
		else{$('#email_message').removeClass("mceEditor").addClass("mceNoEditor");}
		
		$( "#RecentEmail" ).dialog({
            autoOpen: false,
            show: "explode",
            hide: "explode",
			modal: true,
			width:'auto',
			height:'auto'
        });
		
    });
	
	// Send Email Features
	function openSendEmail(id){
		$( "#sendEmailToId" ).val(id);
		$( "#sendEmail" ).dialog( "open" );
            return false;
			
	}
	function setEmailType(){
		checked = $('input[name=emailType]:checked', '#sendEmailModal').val()
		
		if(checked == 'html'){tinymce.execCommand('mceAddEditor',true,'email_message');}
		else{tinymce.execCommand('mceRemoveEditor',true,'email_message');}
	}
	
	// Auto Suggest Lookup
	function lookup(inputString,file,suggestions,autosuggestionlist) {
    if(inputString.length == 0) {
        // Hide the suggestion box.
        $(suggestions).hide();
        
    } else {
        $.post('ajax/'+file, {queryString: ""+inputString+""}, function(data){
            if(data.length >0) {
                $(suggestions).show();
                $(autosuggestionlist).html(data);
            }
        });
    }}
	// Auto Suggest chosen
	function fill(thisValue,id,suggestions,thisValueId) {
		$(id).val(thisValue);
		$(suggestions+'Hidden').val(thisValueId);
		$(suggestions).hide();
	}
	
	
	
	</script>
   <link type="text/css" rel="stylesheet" href="common/css/view_member.css">
</head>

    <body>
	<?php include_once('top.php'); ?>
	<?php
// Lets Load Some Lists
	// Get All Payment Plans into array. $planlist
	$sql = "SELECT nPaymentPlan_ID,sPlanName FROM tblpaymentplans;";
	$listres = $dbo->select($sql);
	while($row = $dbo->getobj($listres)){
		$planlist[$row->nPaymentPlan_ID] = $row->sPlanName;
	}
	
	// Get All Coupons
	$sql = "SELECT nCoupon_ID,sCouponCode FROM tblcoupons;";
	$couponres = $dbo->select($sql);
	if($couponres){
		while($row = $dbo->getobj($couponres)){
			$couponlist[$row->nCoupon_ID] = $row->sCouponCode;
		}
	}




?>
	<div style="padding:10px;">
		<h1>Member Details</h1>
		<?php echo isset($message) ? $message : '' ?>
		<div id="col1-3">
			<div class="memberInfoBox" id="profileShow" style="display:block">
				<div align="center"><strong>Member Profile</strong> <a href="#" onClick="return showEdit('profile','edit')"><img src="../common/images/icons/pencil.png" alt="Edit" width="16" height="16" border="0" style="float:right"></a></div>
				<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
					<tr class="memberDataRow">
						<td width="43%" class="">First name</td>
						<td width="57%" ><?php echo $objUser->sForename ?></td>
					</tr>
					<tr class="memberDataRow">
						<td>Last name</td>
						<td><?php echo $objUser->sSurname ?></td>
					</tr>
					<tr class="memberDataRow">
						<td>Email Address</td>
						<td><a style="text-decoration:underline" href="javascript:void(0)" onClick="openSendEmail('<?php echo $objUser->nUser_ID ?>')" title="Click To Send Email"><?php echo $objUser->sEmail ?></a></td>
					</tr>
					<tr class="memberDataRow">
						<td>Password</td>
						<td><?php echo $objUser->sPassword?></td>
					</tr>
					<tr class="memberDataRow">
						<td>Address</td>
						<td><?php echo $objUser->sAddr1 ?></td>
					</tr>
					<tr class="memberDataRow">
						<td>&nbsp;</td>
						<td><?php echo $objUser->sAddr2 ?></td>
					</tr>
					<tr class="memberDataRow">
						<td>City/Town</td>
						<td><?php echo $objUser->sTown ?></td>
					</tr>
					<tr class="memberDataRow">
						<td>State/County</td>
						<td><?php echo $objUser->sCounty ?></td>
					</tr>
					<tr class="memberDataRow">
						<td>Zip/Postcode</td>
						<td><?php echo $objUser->sPostcode ?></td>
					</tr>
					<tr class="memberDataRow">
						<td>Country</td>
						<td><?php echo get_country_name($objUser->sCountry) ?></td>
					</tr>
					<tr class="memberDataRow">
						<td>Telephone</td>
						<td><?php echo $objUser->sTelephone ?></td>
					</tr>
					<tr class="memberDataRow">
						<td>Mobile</td>
						<td><?php echo $objUser->sMobile ?></td>
					</tr>
				</table>
				<div align="center"></div>
				<br>
				<div align="center">
					<form action="login_as_client.php" method="post" name="form1" target="_new">
						<input name="user" type="hidden" id="user" value="<?php echo $objUser->sEmail ?>">
						<input type="submit" name="button" id="button" value="Login as Member">
						&nbsp;
						<input type="button" name="senddetails" id="senddetails" value="Send Login Details" onClick="resendLogin();">
					</form>
					<span id="msgResend"></span> </div>
			</div>
			<!-- Hidden Edit Details Box -->
			<div class="memberInfoBox" id="profileEdit" style="display:none">
				<form action="actions.php?type=member" method="post">
					<div align="center"><strong>Member Profile</strong></div>
					<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
						<tr class="memberDataRow">
							<td width="43%" class="">First name</td>
							<td width="57%" ><input class="required" name="sForename" id="sForename" style="width:90%;" type="text" value="<?php echo ($_SESSION['form']['sForename'])? $_SESSION['form']['sForename']: $objUser->sForename;?>" />
								<?php if($_SESSION['profile']['errors']['nm']==1)	echo '<br /><span class="error">[ REQUIRED ]</span>'; ?></td>
						</tr>
						<tr class="memberDataRow">
							<td>Last name</td>
							<td><input class="required" name="sSurname" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sSurname'])? $_SESSION['form']['sSurname']: $objUser->sSurname;?>" type="text" />
								<?php if($_SESSION['profile']['errors']['ln']==1) echo '<br /><span class="error">[ REQUIRED ]</span>';	?></td>
						</tr>
						<tr class="memberDataRow">
							<td>Email Address</td>
							<td><input class="required email" name="sEmail" style="width:90%;" size="40"  value="<?php echo ($_SESSION['form']['sEmail'])? $_SESSION['form']['sEmail']: $objUser->sEmail;?>" />
								<?php
		if($_SESSION['profile']['errors']['em']==1)	echo "<br /><span class=\"error\">[ REQUIRED ]</span>";
		if($_SESSION['profile']['errors']['em']==2) echo "<br /><span class=\"error\">[ INVALID ]</span>";
		?></td>
						</tr>
						<tr class="memberDataRow">
							<td>Password</td>
							<td><input class="" name="sPassword" style="width:90%;" size="40"  value="<?php echo ($_SESSION['form']['sPassword'])? $_SESSION['form']['sPassword']: $objUser->sPassword;?>" type="password"/>
								<?php if($_SESSION['profile']['errors']['pw']==1) echo '<br /><span class="error">Passwords Do Not Match</span>'; ?></td>
						</tr>
						<tr class="memberDataRow">
							<td>Confirm Password</td>
							<td><input class="" name="sConfirmPass" style="width:90%;" size="40"  value="" type="password"/></td>
						</tr>
						<tr class="memberDataRow">
							<td>Address</td>
							<td><input  name="sAddr1" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sAddr1'])? $_SESSION['form']['sAddr1']: $objUser->sAddr1;?>"type="text" /></td>
						</tr>
						<tr class="memberDataRow">
							<td>&nbsp;</td>
							<td><input  name="sAddr2" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sAddr2'])? $_SESSION['form']['sAddr2']: $objUser->sAddr2;?>"type="text" /></td>
						</tr>
						<tr class="memberDataRow">
							<td>City/Town</td>
							<td><input  name="sTown" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sTown'])? $_SESSION['form']['sTown']: $objUser->sTown;?>" /></td>
						</tr>
						<tr class="memberDataRow">
							<td>State/County</td>
							<td><input  name="sCounty" style="width:90%;" size="40"  value="<?php echo ($_SESSION['form']['sCounty'])? $_SESSION['form']['sCounty']: $objUser->sCounty;?>" type="text" /></td>
						</tr>
						<tr class="memberDataRow">
							<td>Zip/Postcode</td>
							<td><input  name="sPostcode" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sPostcode'])? $_SESSION['form']['sPostcode']: $objUser->sPostcode;?>" /></td>
						</tr>
						<tr class="memberDataRow">
							<td>Country</td>
							<td><?php
		if($_POST['country']=="")
		{
			$co7=$row->sCountry;
		}
		else
		{
			$co7=$_POST['country'];
		}
	
		$Selected = ($country) ? $country : (($_SESSION['form']['sCountry'])? $_SESSION['form']['sCountry']: $objUser->sCountry);
		//$CountryDropMenu = countrydm("sCountry",$Selected);
		//echo $CountryDropMenu;
		echo get_country_list('sCountry',$Selected,0);
		
		?></td>
						</tr>
						<tr class="memberDataRow">
							<td>Telephone</td>
							<td><input  name="sTelephone" style="width:90%;" value="<?php echo ($_SESSION['form']['Telephone'])? $_SESSION['form']['sTelephone']: $objUser->sTelephone;?>" /></td>
						</tr>
						<tr class="memberDataRow">
							<td>Mobile</td>
							<td><input  name="sMobile" style="width:90%;" value="<?php echo ($_SESSION['form']['Mobile'])? $_SESSION['form']['sMobile']: $objUser->sMobile;?>" /></td>
						</tr>
					</table>
					<input name="id" type="hidden" value="<?php echo $objUser->nUser_ID ?>">
					<input name="act" type="hidden" value="updateProfile">
					<br />
					<div align="center">
						<input type="submit" value="Update Profile" />
						&nbsp;
						<input type="button" value="Cancel" onClick="showEdit('profile','show')"/>
					</div>
				</form>
			</div>
			<!-- End Hidden End --> 
		</div>
		<div id="col2-3">
			<div class="memberInfoBox" id="accountShow">
				<div align="center"><strong>Account Information</strong> <a href="#" onClick="return showEdit('account','edit')"><img src="../common/images/icons/pencil.png" alt="Edit" width="16" height="16" border="0" style="float:right"></a></div>
				<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
					<tr class="memberDataRow">
						<td width="123">Account Type</td>
						<td width="255"><form action="actions.php?type=member" method="post">
								<?php
				
				// If Is Already Admin
				if($objUser->nAdmin){?>Administrator<?php }
				else{?>Customer<?php } ?>
						</form></td>
					</tr>
					<tr class="memberDataRow">
						<td width="123" class="">Status</td>
						<td width="255" ><form action="actions.php?type=member" method="post">
								<?php if ($objUser->nUser_ID == 1) : ?>
								<a href="#" onClick="javascript:alert('You cannot deactivate the admin user.');return false;"><img src="images/dropd.gif" alt="Not allowed to deactivate the admin user" width="16" height="16" border="0" /></a>
								<?php else : ?>
								<?php if ($objUser->nActive == 0) : ?>
								
								Inactive
								
								<?php else : ?>
								
								Active
								
								<?php endif; // ($row->nActive == 0) ?>
								<?php endif; // ($row->nUser_ID == 1) ?>
						</form></td>
					</tr>
					<tr class="memberDataRow">
						<td>Signup Date</td>
						<td><?php echo fShowDate($chkSsettings->nDateFormat, $objUser->nJoinDate) ?></td>
					</tr>
					<tr class="memberDataRow">
						<td>Customer For</td>
						<td><?php 
			  
				$diff = abs(time() - strtotime($objUser->nJoinDate));

				$years = floor($diff / (365*60*60*24));
				$months = floor($diff / (60*60*24*30));
				$days = floor($diff / (60*60*24));
				
				if($days < 30){$since = $days.' Days';}
				else{
					if($months < 12){$since = $months.' Months';}
					else{
						if($years > 1){$since = $years.' Years';}
						else{$since = $years.'Year';}
						}
					
					}
			  
			  echo $since ?></td>
					</tr>
					<tr class="memberDataRow">
						<td>Email Preference</td>
						<td><form action="actions.php?type=member" method="post">
								<?php if ($objUser->nUnsubscribe == '0'){  ?>
								Receive All
								
								<?php }else{?>
								Receive None
								
								<?php } ?>
							</form></td>
					</tr>
					<tr class="memberDataRow">
						<td>Email Status</td>
						<td><?php echo ($objUser->nConfirmed) ?'<span class="green">Confirmed</span>': '<span class="error">Un-Confirmed</span>' ?></td>
					</tr>
					<tr class="memberDataRow">
						<td>Last Login</td>
						<td><?php if($loginData){?>
							Date: <?php echo fShowDate($chkSsettings->nDateFormat,date('Ymd',$loginData->nTimestamp)) ?><br>
							Ip	Address: <?php echo $loginData->sIp ?><br>
							Browser: <?php echo $loginData->sBrowser ?>
							<?php }
              else{echo 'Never';} ?></td>
					</tr>
				</table>
			</div>
			<div class="memberInfoBox" id="accountEdit" style="display:none;">
				<div align="center"><strong>Account Information</strong></div>
				<form action="actions.php?type=member" method="post">
					<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
						<tr class="memberDataRow">
							<td width="123"><label for="nAdmin">Account Type</label></td>
							<td width="255">
								<select name="nAdmin" id="nAdmin">
									<option value="1" <?php echo ($objUser->nAdmin) ? 'selected' :''; ?>>Administrator</option>
									<option value="0" <?php echo (!$objUser->nAdmin) ? 'selected' :''; ?>>Customer</option>
							</select></td>
						</tr>
						<tr class="memberDataRow">
							<td width="123" class=""><label for="nActive">Status</label></td>
							<td width="255" >
								<select name="nActive" id="nActive">
									<option value="1" 
									<?php 
									if($objUser->nUser_ID == 1){echo 'disabled ';}
									if($objUser->nActive == '1'){echo 'selected';}
									
									?>>
									
									Active
									</option>
									<option value="0"
									
									<?php 
									if($objUser->nUser_ID == 1){echo 'disabled ';}
									if($objUser->nActive == '0'){echo 'selected';}
									
									?>
									
									
									>Inactive</option>
								</select>
							</td>
						</tr>
						<tr class="memberDataRow">
							<td><label for="nJoinDate">Signup Date</label></td>
							<td><input name="nJoinDate" type="text" id="nJoinDate" value="<?php echo fShowDate($chkSsettings->nDateFormat, $objUser->nJoinDate) ?>" class="datepicker"></td>
						</tr>
						<tr class="memberDataRow">
							<td><label for="nUnsubscribe">Email Preference</label></td>
							<td>
								<select name="nUnsubscribe" id="nUnsubscribe">
									<option value="0" <?php echo ($objUser->nUnsubscribe == '0') ? 'selected': '' ?>>Receive All</option>
									<option value="1" <?php echo ($objUser->nUnsubscribe == '1') ? 'selected': '' ?>>Receive None</option>
							</select></td>
						</tr>
						<tr class="memberDataRow">
							<td><label for="nConfirmed">Email Status</label></td>
							<td>
								<select name="nConfirmed" id="nConfirmed">
									<option value="1" <?php echo ($objUser->nConfirmed) ? 'selected' : '' ?> >Confirmed</option>
									<option value="0" <?php echo ($objUser->nConfirmed) ? '' : 'selected'?> >Unconfirmed</option>
								</select>							
							</td>
						</tr>
					</table>
				<div align="center">
					<input name="id" type="hidden" value="<?php echo $objUser->nUser_ID ?>">
					<input name="currentconfirm" type="hidden" value="<?php echo $objUser->nConfirmed ?>">
					<input name="act" type="hidden" value="updateAccount">
					<input name="" type="submit" value="Update Changes">&nbsp;&nbsp;
					<input type="button" name="button2" id="button2" value="Cancel" onClick="return showEdit('account','show')">
				</div>
				</form>
			</div>
<br />
<div class="memberInfoBox">
					<div align="center"><strong>Admin Functions</strong></div>
					<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
						<tr class="memberDataRow">
							<td colspan="2" class=""><a href = "#" id="openNewSale">Add New Sale</a> | <a href = "#" id="openAddNew">Assign Membership</a> | <a href = "#" id="openAddTransaction">Add New Transaction</a></td>
						</tr>
					</table>
		  </div><br>

		  <div class="memberInfoBox">
				<form action="actions.php?type=member" method="post">
					<div align="center"><strong>Admin Comments</strong></div>
					<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
						<tr class="memberDataRow">
							<td colspan="2" class=""><textarea name="sComments" id="comments" rows="5" style="width:99%" onKeyPress="showEdit('comments','edit')" ><?php echo $objUser->sComments ?></textarea>
								<input type="hidden" name="id" value="<?php echo $objUser->nUser_ID ?>" />
								<input type="hidden" name="act" value="updateComments" /></td>
						</tr>
					</table>
					<div id="commentsEdit" style="display:none" align="center">
						<input type="submit" value="Save Comments" />
						&nbsp;
						<input type="button" value="Cancel" onClick="showEdit('comments','show')" />
					</div>
				</form>
			</div>
		</div>
	  </table>
		<div id="col3-3">
			<div class="memberInfoBox" id="affiliateShow">
				<div align="center"><strong>Affiliate Information</strong> <a href="#" onClick="return showEdit('affiliate','edit')"><img src="../common/images/icons/pencil.png" alt="Edit" width="16" height="16" border="0" style="float:right"></a></div>
				<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
					<tr class="memberDataRow">
						<td width="123" class="">Referred By</td>
						<td width="255" ><?php $user = get_user_by_id($objUser->nAffiliate_ID);echo ($user)?'<a href="?id='.$objUser->nAffiliate_ID.'">'.$user->sForename.' '.$user->sSurname.'</a>':'None' ?></td>
					</tr>
					<tr class="memberDataRow">
						<td width="123" class="">Is Affiliate</td>
						<td width="255" ><?php echo ($objUser->nAffiliate)?'Yes':'No' ?></td>
					</tr>
					<?php if($objUser->nAffiliate){?>
					<tr class="memberDataRow">
						<td>Paypal Email</td>
						<td><?php echo ($objUser->sPaypalEmail)? $objUser->sPaypalEmail : 'None'?></td>
					</tr>
					<tr class="memberDataRow">
						<td>Custom Commission %</td>
						<td><?php echo ($objUser->nCustomCommission > 0)? $objUser->nCustomCommission.' %':'None' ?></td>
					</tr>
					<tr class="memberDataRow">
						<td>Affiliate Link</td>
						<td><?php echo $chkSsettings->sSiteURL?>/index.php?afid=<?php echo $objUser->nUser_ID ?></td>
					</tr>
					<?php } ?>
				</table>
			</div>
			<!-- Hidden Edit Field -->
			<div class="memberInfoBox" id="affiliateEdit" style="display:none">
				<form action="actions.php?type=member" method="post">
					<div align="center"><strong>Affiliate Information</strong></div>
					<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
						<tr class="memberDataRow">
							<td width="123" class="">Referred By</td>
							<td width="255" ><select name="nAffiliate_ID">
									<option value="">No Affiliate</option>
									<?php
		$sqlaf="select * from tblusers 
		where naffiliate=1 and nUser_ID != '" . $objUser->nUser_ID . "' 
		order by sforename";

		$resultaf = $dbo->select($sqlaf);
		if ($resultaf) {
			while($rowaf=$dbo->getobj($resultaf))
			{
				echo "<option value=\"" . $rowaf->nUser_ID . "\"";
			
				if($rowaf->nUser_ID==$objUser->nAffiliate_ID) echo "selected";
			
				echo ">" . $rowaf->sForename . " " . $rowaf->sSurname . "</option>";
			}
		}
		?>
								</select></td>
						</tr>
						<tr class="memberDataRow">
							<td width="123" class="">Is Affiliate</td>
							<td width="255" ><input type="checkbox" name="nAffiliate" value="1" 
			  <?php if($_SESSION['form']['nAffiliate']){if($_SESSION['form']['nAffiliate'] == 1){echo "checked";}}
			  else{if($objUser->nAffiliate==1) { echo "checked"; }} ?> /></td>
						</tr>
						<tr class="memberDataRow">
							<td>Paypal Email</td>
							<td><input class="inputText" name="sPaypalEmail" style="width:90%;" size="40" value="<?php echo ($_SESSION['form']['sPaypalEmail'])?$_SESSION['form']['sPaypalEmail']: $objUser->sPaypalEmail?>" />
								<?php if($_SESSION['affiliate']['errors']['pem']==2) echo "<br /><span class=\"error\">[ INVALID FORMAT ]</span>";?></td>
						</tr>
						<tr class="memberDataRow">
							<td>Custom Commission %</td>
							<td><input class="inputText" name="nCustomCommission" style="width: 50px;" size="40" value="<?php echo ($_SESSION['form']['nCustomCommission']) ?$_SESSION['form']['nCustomCommission']:$objUser->nCustomCommission?>" /></td>
						</tr>
					</table>
					<div align="center">
						<input type="submit" value="Save Affiliate" />
						&nbsp;
						<input type="button" value="Cancel" onClick="showEdit('affiliate','show')" />
					</div>
					<input type="hidden" name="id" value="<?php echo $objUser->nUser_ID ?>" />
					<input type="hidden" name="act" value="updateAffiliate" />
				</form>
			</div>
			<!-- END Hidden Edit Field --> 
			<br />
			<div class="memberInfoBox" id="customfieldsShow">
				<div align="center"><strong>Additional Profile Details</strong> <a href="#" onClick="return showEdit('customfields','edit')"><img src="../common/images/icons/pencil.png" alt="Edit" width="16" height="16" border="0" style="float:right"></a></div>
				<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
					<?php
			$c = 0;
			$objCustomFieldSettings = $dbo->select("SELECT * FROM tblcustomfieldsettings ORDER BY nSortOrder, sCustomFieldName");
			while($row2 = $dbo->getobj($objCustomFieldSettings)):
			if($row2->nCustomFieldSetting_ID ==1){$v = $objUser->sCustomField1;}
			elseif($row2->nCustomFieldSetting_ID ==2){$v = $objUser->sCustomField2;}
			elseif($row2->nCustomFieldSetting_ID ==3){$v = $objUser->sCustomField3;}
			elseif($row2->nCustomFieldSetting_ID ==4){$v = $objUser->sCustomField4;}
			elseif($row2->nCustomFieldSetting_ID ==5){$v = $objUser->sCustomField5;}
			elseif($row2->nCustomFieldSetting_ID ==6){$v = $objUser->sCustomField6;}
			elseif($row2->nCustomFieldSetting_ID ==7){$v = $objUser->sCustomField7;}
			elseif($row2->nCustomFieldSetting_ID ==8){$v = $objUser->sCustomField8;}
			elseif($row2->nCustomFieldSetting_ID ==9){$v = $objUser->sCustomField9;}
			else{$v = $objUser->sCustomField10;}
			if($v!='')$c++;
			if($c > 0 && $v !=''){
				
	?>
					<tr class="memberDataRow">
						<td width="136" nowrap="nowrap" ><?php echo $row2->sCustomFieldName ?></td>
						<td width="189"><?php echo $v; ?></td>
					</tr>
					<?php }endwhile;
	  if($c == 0){echo '<tr class="memberDataRow"><td>None</td></tr>';} ?>
				</table>
			</div>
			<!-- Hidden Edit Field -->
			<div class="memberInfoBox" id="customfieldsEdit" style="display:none;">
				<form action="actions.php?type=member" method="post">
					<div align="center"><strong>Additional Profile Details</strong></div>
					<table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" style="none">
						<?php
			$objCustomFieldSettings = $dbo->select("SELECT * FROM tblcustomfieldsettings ORDER BY nSortOrder, sCustomFieldName");
			while($row2 = $dbo->getobj($objCustomFieldSettings)):
			if($row2->nCustomFieldSetting_ID ==1){$v = $objUser->sCustomField1;}
			elseif($row2->nCustomFieldSetting_ID ==2){$v = $objUser->sCustomField2;}
			elseif($row2->nCustomFieldSetting_ID ==3){$v = $objUser->sCustomField3;}
			elseif($row2->nCustomFieldSetting_ID ==4){$v = $objUser->sCustomField4;}
			elseif($row2->nCustomFieldSetting_ID ==5){$v = $objUser->sCustomField5;}
			elseif($row2->nCustomFieldSetting_ID ==6){$v = $objUser->sCustomField6;}
			elseif($row2->nCustomFieldSetting_ID ==7){$v = $objUser->sCustomField7;}
			elseif($row2->nCustomFieldSetting_ID ==8){$v = $objUser->sCustomField8;}
			elseif($row2->nCustomFieldSetting_ID ==9){$v = $objUser->sCustomField9;}
			else{$v = $objUser->sCustomField10;}
	?>
						<tr class="memberDataRow">
							<td width="136" nowrap="nowrap" ><?php echo $row2->sCustomFieldName ?></td>
							<td width="189"><input  name="sCustomField<?php echo $row2->nCustomFieldSetting_ID ?>" id="sCustomField<?php echo $row2->nCustomFieldSetting_ID ?>"style="width:90%;" size="40" type="text" value="<?php echo $v; ?>" /></td>
						</tr>
						<?php endwhile; ?>
					</table>
					<input type="hidden" name="id" value="<?php echo $objUser->nUser_ID ?>" />
					<input type="hidden" name="act" value="updateCustom" />
					<div align="center">
						<input type="submit" value="Update Fields" />
						&nbsp;
						<input type="button" value="Cancel" onClick="showEdit('customfields','show')"/>
					</div>
				</form>
			<!-- END Hidden Edit Field -->
			</div>
            <br>
			<br>
			<div class="memberInfoBox" id="recentEmails">
			  <div align="center"><strong>Recent Emails</strong> </div>
  <table border="0" align="center" cellpadding="3" cellspacing="1" class="memberData" width="100%">
    <?php
			$c = 0;
			$objRecentEmails = $dbo->select("SELECT *,  UNIX_TIMESTAMP(dSentTime) as sentstamp FROM tblemails WHERE nUser_ID = ".$objUser->nUser_ID." AND nStatus = '1' ORDER BY dSentTime DESC LIMIT 5");
			if($objRecentEmails){
				while($row2 = $dbo->getobj($objRecentEmails)):?>
    <tr class="memberDataRow">
      <td width="136" nowrap="nowrap" ><?php echo $empDateTime->showDateFromStamp($row2->sentstamp); echo ' '.$empDateTime->showTimeFromStamp($row2->sentstamp);?></td>
      <td width="189"><a id="recentEmailLink" onClick="loadRecentEmail(<?php echo $row2->nEmail_ID; ?>);"><?php echo $row2->sSubject; ?></a></td>
    </tr>
    <?php endwhile;
			}
			
	  else{echo '<tr class="memberDataRow"><td>None</td></tr>';} ?>
  </table>
</div>

      </div>
        
	  <div style="clear:both"></div>
		<div align="center"><strong>Active Membership Levels</strong></div>
		<table width="100%" cellpadding="0" cellspacing="1" class="gridtable">
			<tr>
				<td class="gridheader"><strong>Membership Level</strong></td>
				<td class="gridheader">Started On </td>
				<td class="gridheader">Current Day</td>
				<td class="gridheader">Expires</td>
				<td class="gridheader">Coupon </td>
				<td class="gridheader">Pay Plan </td>
				<td class="gridheader">Payment Count</td>
				<td class="gridheader"><strong>Transaction #</strong></td>
				<td class="gridheader">Actions</td>
			</tr>
			<?php
				// Get only levels this user belongs to
				
				$sql = "SELECT tbluserlevels. *, 
				tblmembershiplevels.sLevel,
				tblpaymentplans.nRegularAmount,
				tblpaymentplans.nRegularPeriod,
				tblpaymentplans.sRegularPeriod,
				tblpaymentplans.nOneTimePayment,
				tblpaymentplans.sPlanName,
				tblpaymentprocessors.sProcessorName
				FROM tbluserlevels
				INNER JOIN tblmembershiplevels ON tblmembershiplevels.nLevel_ID = tbluserlevels.nLevel_ID
				LEFT JOIN tblpaymentplans ON tblpaymentplans.nPaymentPlan_ID = tbluserlevels.nPaymentPlan_ID
				LEFT JOIN tblpaymentprocessors ON tblpaymentprocessors.nPaymentProcessor_ID = tblpaymentplans.nPaymentProcessor_ID
				WHERE tbluserlevels.nUser_ID =".$dbo->format($_GET['id'])." AND tbluserlevels.nActive = 1;";

				//die($sql);
				$result = $dbo->select($sql);
				if($dbo->nr($result)){
					while($row = $dbo->getobj($result)){?>
			<tr>
				<td class="gridrow1"><?php echo $row->sLevel ?></td>
				<td class="gridrow1"><?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateActive);?></td>
				<td class="gridrow1"><?php  
				
				$start = strtotime($row->nDateActive);
				$end = time();
				$days_between = ceil(abs($end - $start) / 86400);
				echo $days_between
				
				  ?></td>
				<td class="gridrow1"><span 
				<?php if($row->nDateExpires < date('Ymd')){
					echo 'class="error">';
				}
				else{
					echo 'class="green">';
				}
				echo fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); ?></span></td>
				<td class="gridrow1"><?php echo  ($row->nCoupon_ID !=NULL && $row->nCoupon_ID !='0')?$row->nCoupon_ID:'None'; ?></td>
				<td class="gridrow1"><?php echo ($row->sPlanName)?$row->sPlanName: 'N/A' ?></td>
				<td class="gridrow1"><?php echo $row->nPaymentCounter;?></td>
				<td class="gridrow1"><?php echo ($row->sTransactionNumber)?$row->sTransactionNumber:'N/A';?></td>
				<td class="gridrow1"><form action="actions.php?type=member" method="post">
                    <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>" />
						<input type="hidden" name="nAssignedLevel_ID" value="<?php echo $row->nUserLevel_ID ?>" />
						<input type="hidden" name="act" value="modlevel" />
						<input type="hidden" name="Level" value="Deactivate" />
                        <?php 
						// No Payment Button Needed For One Time Payments, that never expire.
						
						if($row->nPaymentPlan_ID =! '0' || $row->nOneTimePayment != '1' && $row->nRegularPeriod != '0'){}
						
						if($row->nOneTimePayment == '1' && $row->nRegularPeriod == '0'){}else{
							 // No Payment Button Available For Admin Assigned Membership 
							 if($row->nPaymentPlan_ID != '0'){
							 $row->formattedExpireDate = fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); 
							?>
                  <script type="text/javascript">
                    rowObj_<?php echo $row->nUserLevel_ID ?> = <?php echo json_encode($row)?>
                    
                    </script>
						<input type="button" name="button3" id="button3" value="Add Payment" onClick="addPayment(rowObj_<?php echo $row->nUserLevel_ID ?>)">
						<?php }
						} ?>
                  <input name="" type="button" value="Edit" onClick="editLevel('<?php echo $row->nUserLevel_ID ?>')"/>
<input name="" type="submit" value="Deactivate" />
					</form></td>
			</tr>
			<?php }
				}
				else{
					echo '<tr><td class="gridrow1" colspan="9"> No Active Memberships</td></tr>';
					} ?>
			<tr>
				<td class="gridfooter" colspan="9">&nbsp;</td>
			</tr>
		</table>
		<br>
		
		<!-- Edit Levels Begin Model boxes -->
		<?php
// We need to go back through the loop and print divisions.
	
	if($dbo->nr($result)){
		$dbo->seek($result, 0);
		while($row = $dbo->getobj($result)){?>
		<div id="LevelEdit_<?php echo $row->nUserLevel_ID ?>" style="display:none">
			<h1 class="dialog-title" style="display:none">Editing "<?php echo $row->sLevel ?>" Active Membership Level </h1>
			
				<table border="0" cellspacing="1" cellpadding="0" class="gridtable" width="449px;">
					<tr>
						<td class="gridheader"><label for="Plan">Payment Plan</label></td>
						<td class="gridrow1">
							<select name="Plan" id="Plan">
								<option value="0" <?php if($row->nPaymentPlan_ID == 0){ echo 'selected'; }?>>None</option>
								<?php
							// build the select from the predefined array of details.
							// Current Payment Plan Id $row->nPaymentPlan_ID
							foreach($planlist as $k=>$v){ ?>
								<option value="<?php echo $k ?>" <?php  if($k == $row->nPaymentPlan_ID) { echo 'selected';} ?> ><?php echo $v; ?></option>
								<?php } ?>
							</select></td>
					</tr>
					<tr>
						<td class="gridheader"><label for="Count">Payment Count</label></td>
						<td class="gridrow1">
							<input type="text" name="Count" id="Count" value="<?php echo $row->nPaymentCounter ?>"/></td>
					</tr>
					<tr>
						<td class="gridheader">Transaction #</td>
						<td class="gridrow1">
							<div id="txncontainer_<?php echo $row->nUserLevel_ID ?>">	    	 
								<input name="Txn" onKeyUp="lookup(this.value,'txn.php','.suggestionsm','.autoSuggestionsListm');" 
								type="text"  value="<?php echo ($row->sTransactionNumber)?$row->sTransactionNumber:'';?>" autocomplete="off"/>		
								<input type="hidden" id="suggestionsmHidden" name="suggestionsmHidden" />
		   					</div>          
   							<div class="suggestionsBox suggestionsm"  style="display: none;">
	      					<img src="images/upArrow.png" style="position: relative; top: -12px; left: 30px" alt="upArrow" />	
	     					<div class="suggestionList autoSuggestionsListm" ></div>
    						</div>

							
							
						</td>
					</tr>
					<tr>
						<td class="gridheader">Coupon Used</td>
						<td class="gridrow1"><select name="Coupon" id="Coupon">
								<option value="0" <?php if($row->nCoupon_ID == NULL){ echo 'selected'; }?>>None</option>
								<?php foreach($couponlist as $k=>$v){ ?>
								<option value="<?php echo $k ?>" <?php  if($k == $row->nCoupon_ID) { echo 'selected';} ?> ><?php echo $v; ?></option>
								<?php } ?>
							</select></td>
					</tr>
					<tr>
						<td class="gridheader">Start Date</td>
						<td class="gridrow1"><input type="text" name="DateActive" value="<?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateActive); ?>" /></td>
					</tr>
					<tr>
						<td class="gridheader">Expire Date</td>
						<td class="gridrow1"><input type="text" name="DateExpires" value="<?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); ?>"/></td>
					</tr>
				</table>
			<input type="hidden" name="level_id" value="<?php  echo $row->nUserLevel_ID  ?>" />
		</div>
		<?php }
	}
?>
		
		<!-- Edit Levels Begin Model boxes --> 
		
		<br>
		<div align="center">
		  <strong>Inactive Membership Levels</strong>
		  <table width="100%" cellpadding="0" cellspacing="1" class="gridtable">
		    <tr>
		      <td class="gridheader"><strong>Membership Level</strong></td>
		      <td class="gridheader">Started On </td>
		      <td class="gridheader">Current Day</td>
		      <td class="gridheader">Expires</td>
		      <td class="gridheader">Coupon </td>
		      <td class="gridheader">Pay Plan </td>
		      <td class="gridheader">Payment Count</td>
		      <td class="gridheader"><strong>Transaction #</strong></td>
		      <td class="gridheader">Actions</td>
	        </tr>
		    <?php
				// Get only levels this user belongs to
				
				$sql = "SELECT tbluserlevels. *, 
				tblmembershiplevels.sLevel,
				tblpaymentplans.nRegularAmount,
				tblpaymentplans.nRegularPeriod,
				tblpaymentplans.sRegularPeriod,
				tblpaymentplans.nOneTimePayment,
				tblpaymentplans.sPlanName,
				tblpaymentprocessors.sProcessorName
				FROM tbluserlevels
				INNER JOIN tblmembershiplevels ON tblmembershiplevels.nLevel_ID = tbluserlevels.nLevel_ID
				LEFT JOIN tblpaymentplans ON tblpaymentplans.nPaymentPlan_ID = tbluserlevels.nPaymentPlan_ID
				LEFT JOIN tblpaymentprocessors ON tblpaymentprocessors.nPaymentProcessor_ID = tblpaymentplans.nPaymentProcessor_ID
				WHERE tbluserlevels.nUser_ID =".$_GET['id']." AND tbluserlevels.nActive = 0;";

				//die($sql);
				$result = $dbo->select($sql);
				if($dbo->nr($result)){
					while($row = $dbo->getobj($result)){?>
		    <tr>
		      <td class="gridrow1"><?php echo $row->sLevel ?></td>
		      <td class="gridrow1"><?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateActive);?></td>
		      <td class="gridrow1"><?php  
				
				$start = strtotime($row->nDateActive);
				$end = time();
				$days_between = ceil(abs($end - $start) / 86400);
				echo $days_between;
				
				  ?></td>
		      <td class="gridrow1"><?php echo fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); ?></td>
		      <td class="gridrow1"><?php echo  ($row->nCoupon_ID !=NULL)?$row->nCoupon_ID:'None'; ?></td>
		      <td class="gridrow1"><?php echo ($row->sPlanName)?$row->sPlanName: 'N/A' ?></td>
		      <td class="gridrow1"><?php echo $row->nPaymentCounter;?></td>
		      <td class="gridrow1"><?php echo ($row->sTransactionNumber)?$row->sTransactionNumber:'N/A';?></td>
		      <td class="gridrow1"><form name="form2" method="post" action="actions.php?type=member">
                  <?php if($row->nOneTimePayment == '1' && $row->nRegularPeriod == '0'){}else{
					  $row->formattedExpireDate = fShowDate($chkSsettings->nDateFormat, $row->nDateExpires); 
					  ?>
                <script type="text/javascript">
                    rowObj_<?php echo $row->nUserLevel_ID ?> = <?php echo json_encode($row)?>
                    
                    </script>
                  <input type="button" name="button4" id="button4" value="Add Payment" onClick="addPayment(rowObj_<?php echo $row->nUserLevel_ID ?>)">
                  <?php } ?>
                  <input  type="button" value="Reactivate" onClick="reactivateLevel('<?php echo $row->nUserLevel_ID ?>')"/>
                  <input  type="submit" value="Delete" />
		          <input name="act" type="hidden" id="act" value="modlevel" />
				  <input name="Level" type="hidden" id="Level" value="Delete" />&nbsp;
	            <input name="nAssignedLevel_ID" type="hidden" id="nAssignedLevel_ID" value="<?php echo $row->nUserLevel_ID ?>" />
		      </form></td>
	        </tr>
		    <?php }
				}
				else{
					echo '<tr><td class="gridrow1" colspan="9"> No Active Memberships</td></tr>';
					} ?>
		    <tr>
		      <td class="gridfooter" colspan="9">&nbsp;</td>
	        </tr>
	      </table>
		  <p>&nbsp;</p>
		</div>
		<br>
		<?php
			/// Code For Transactions
			?>
		<div align="center"><strong>Recent Transactions</strong> -<a href="manage_transactions.php?user=<?php echo $objUser->nUser_ID ?>"> View All</a></div>
		<table width="100%" cellpadding="0" cellspacing="1" class="gridtable">
			<tr>
				<td class="gridheader"><strong>Transaction Type</strong></td>
				<td class="gridheader"><strong>Payment Processor</strong></td>
				<td class="gridheader">Amount</td>
				<td class="gridheader">Date</td>
				<td class="gridheader"><strong>Transaction #</strong></td>
			</tr>
			<?php
			$sql = "
			SELECT tbltransactions . * ,tbltransactiontypes.sType
FROM tbltransactions
JOIN tbltransactiontypes ON tbltransactiontypes.nTransactionType_ID = tbltransactions.nTransactionType_ID
WHERE nUser_ID = '{$objUser->nUser_ID}' ORDER BY `tbltransactions`.`nTransaction_ID` DESC LIMIT 5";
			
$res = $dbo->select($sql);
// Used for V2 Compatibility
$sql2 = "
			SELECT tbltransactions . * ,tbltransactiontypes.sType
FROM tbltransactions
JOIN tbltransactiontypes ON tbltransactiontypes.nTransactionType_ID = tbltransactions.nTransactionType_ID
WHERE sUserEmail = '{$objUser->sEmail}' ORDER BY `tbltransactions`.`nTransaction_ID` DESC LIMIT 5";
$res2 = $dbo->select($sql2);
			if($dbo->nr($res)){
				while($row3 = $dbo->getobj($res)){ ?>
			<tr>
				<td class="gridrow1"><a href="manage_transactions.php?id=<?php echo $row3->nTransaction_ID ?>"><?php echo $row3->sType ?></a></td>
				<td class="gridrow1"><?php echo $row3->sProcessor ?></td>
				<td class="gridrow1"><?php echo $currency_symbol; echo number_format($row3->nSaleAmount,2); ?></td>
				<td class="gridrow1"><?php echo fShowDate($chkSsettings->nDateFormat,date('Ymd',strtotime($row3->dDateTime))) ?></td>
				<td class="gridrow1"><?php echo $row3->sTransactionNumber ?></td>
			</tr>
			<?php }
				}
			elseif($dbo->nr($res2)){
				while($row3 = $dbo->getobj($res2)){ ?>
			<tr>
				<td class="gridrow1"><?php echo $row3->sType ?></td>
				<td class="gridrow1"><?php echo $row3->sProcessor ?></td>
				<td class="gridrow1"><?php echo $currency_symbol;echo number_format($row3->nSaleAmount,2); ?></td>
				<td class="gridrow1"><?php echo fShowDate($chkSsettings->nDateFormat,strtotime($row3->dDateTime)) ?></td>
				<td class="gridrow1"><?php echo $row3->sTransactionNumber ?></td>
			</tr>
			<?php }
				}
			else{echo '<tr><td colspan = "5" class="gridrow1">No Transactions For User</td></tr>';}
			?>
			<tr>
				<td class="gridfooter" colspan="8">&nbsp;</td>
			</tr>
		</table>
		<?php echo pluginClass::filter('admin_view_member_bottom');?>
		<p class="navRow2">&nbsp;</p>
		<p class="navRow2"><!-- addded form validation --> 
			<script type="text/javascript">
$(document).ready(function()
{
	
	
	$("#f").validate({
		rules: {
			sPassword: {
				minlength:6
			},
			sPassword2: {
				equalTo: "#sPassword",
				 minlength:6
			
			},			
			sEmail: { 
			//	remote: '../ajax/check_username.php'
        	} 
		},
		messages: {
			sPassword: {
				minlength : errMinLength
			},
			sPassword2: {
				equalTo: errEqualTo,
				minlength : errMinLength	
			},
			sEmail: { 
      			 remote: jQuery.format(" User already exists!")
 			}
		}
	});
});
          </script> 
		</p>
	</div>
	<?php include_once('b.php'); ?>
	<iframe name="runcode" scrolling="auto" frameborder="1" style="width:0; height:0; visibility:hidden" src="about:blank" tabindex="-1"></iframe>
	<div id="ReactivateLevel" style="display:none">
		<h2>Reactivate Membership For <?php echo $objUser->sForename ?> <?php echo $objUser->sSurname ?></h2>
		<form action="actions.php?type=member" method="post">
			Select New Expiration Date
			<input  id="nExpires" name="nExpires" style="width: 80px;" value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd',strtotime('+1 month')));?>" readonly />
			<input type="hidden" name="nAssignedLevel_ID" id="ReactivateLevelId" value="" />
			<input type="hidden" name="id" value="<?php echo $_GET['id']  ?>" />
			<input type="hidden" name="act" value="modlevel" />
			<input type="hidden" name="Level" value="Reactivate" />
			<input name="" type="submit" value="Reactivate" />
		</form>
	</div>
	<div id="EditLevel" style="display:none">
		<form id="Model-Form" action="actions.php?type=member" method="post">
			<div id="model-form-container">
			
			</div>
			<input type="hidden" name="act" value="modlevel" />
			<input type="hidden" name="Level" value="Edit" />
			<input type="submit" value="Save Changes" />
		</form>
	</div>
     <?php include('includes/add-payment.php'); ?>
    <div id="newSale" class="mydialog" title="Add New Sale For <?php echo $objUser->sForename ?> <?php echo $objUser->sSurname ?>">
    <p><strong>Adding A New Sale Will Perform The Following Actions:</strong><br>
    Add A New Sale Transaction To The database<br>
    Assign Affiliate Commission On The Sale<br>
    Assign New Membership Level To Member    </p>
    <form action="actions.php?type=member" method="post">
  <table width="449" border="0" cellpadding="0" cellspacing="1" class="gridtable">
  <tr>
   <td class="gridrow2">Membership Level</td>
   <td class="gridrow2"><?php echo $levelsel ?></td>
 </tr>
 <tr>
   <td class="gridrow2">Payment Plan</td>
   <td class="gridrow2"><select name="paymentPlan" id="paymentPlan">
     <option>--- Select Payment Plan ---</option>
   </select>   </td>
 </tr>
 <tr>
   <td class="gridrow2">Transaction #</td>
   <td class="gridrow2"><input type="text" name="transactionnumber" id="transactionnumber" />     </td>
 </tr>
 <tr>
   <td class="gridrow2">Date / Time</td>
   <td class="gridrow1"><input type="text" name="datetime" id="datetime" class="datetimepicker" 
		value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd')); echo ' '.date('H:i:s');?> " readonly />     </td>
 </tr>
</table>
<input name="act" type="hidden" value="processManualSale" />
<input type="hidden" name="id" value="<?php echo $_GET['id']  ?>" />
<input type="submit" value="Process Sale" />
	</form>
	
	
	
    
    </div>
	<div id="AddTransaction" class="mydialog" style="display:none;" title="Add New Transaction For <?php echo $objUser->sForename ?> <?php echo $objUser->sSurname ?>">
	
	<form action="actions.php?type=member" method="post">
	
	<table width="449" border="0" cellpadding="0" cellspacing="1" class="gridtable">
	<tr>
		<td class="gridheader"><label for="type">Transaction Type</label></td>
		<td class="gridrow1">
			<select name="type" id="type">
				<option value="1" selected>Sale</option>
				<option value="2">Refund</option>
				<option value="3">Cancellation</option>
			</select></td>
	</tr>
	<tr>
		<td class="gridheader">Processor</td>
		<td class="gridrow1">
			<select name="processor" id="processor">
				<option value="" selected>None</option>
				<?php
				foreach ($processors as $k=>$v){?>
					<option value="<?php echo $v ?>"><?php echo $v ?></option>
				
				
				
				<?php }
				
				
				?>
		</select></td>
	</tr>
	<tr>
		<td class="gridheader">Transaction #</td>
		<td class="gridrow1"><input type="text" name="transactionnumber" id="transactionnumber"></td>
	</tr>
	<tr>
		<td class="gridheader"><label for="amount">Amount</label></td>
		<td class="gridrow1">
			<?php echo $currency_symbol ?><input type="text" name="amount" id="amount"></td>
	</tr>
	<tr>
		<td class="gridheader">Date / Time</td>
		<td class="gridrow1"><input type="text" name="datetime" id="datetime" class="datetimepicker" 
		value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd')); echo ' '.date('H:i s');?> " readonly /></td>
	</tr>
</table>

<input type="hidden" name="act" value="addTransaction" />
<input type="hidden" name="id" value="<?php echo $_GET['id']  ?>" />
<input type="submit" value="Save Transaction" />
	</form>
	</div>
	<div id="AddNewLevel" style="display:none;">
		<h2>Add New Membership For <?php echo $objUser->sForename ?> <?php echo $objUser->sSurname ?></h2>
		<form action="actions.php?type=member" method="post">
			<select name="nLevel_ID" id="nLevel_ID" style="width:50%;">
				<option value="">Assign a level to this member</option>
				<?php 
				// Get all levels which user is not already assigned to
				$sql = "SELECT nLevel_ID, sLevel FROM tblmembershiplevels 
				WHERE nActive=1 AND nLevel_ID NOT IN (SELECT nLevel_ID FROM tbluserlevels WHERE nUser_ID = " . $objUser->nUser_ID . ")ORDER BY sLevel";
				$result = $dbo->select($sql);
				if ($result) {
					while ($objLevel = $dbo->getobj($result)) {
						echo '<option value="' . $objLevel->nLevel_ID . '">' . $objLevel->sLevel . '</option>';
					}
				}
				?>
			</select>
			&nbsp;
			
			Expires:
			<input  name="nDateExpires" id="nDateExpires" style="width: 80px;" value="<?php echo fShowDate($chkSsettings->nDateFormat, date('Ymd',strtotime('+1 month')));?>" readonly />
			<?php if($df==1)	echo "<span class=\"required\">Invalid date format (mm/dd/yyyy)</span>"; ?>
			<input type="hidden" name="act" value="modlevel" />
			<input type="hidden" name="Level" value="Add" />
			<input type="hidden" name="id" value="<?php echo $_GET['id']  ?>" />
			<input name="Level" type="submit" class="inputsubmit" id="Level"  value="Add">
		</form>
	</div>
	<script type="text/javascript">
    <?php if($_SESSION['profile']['errors']){
		//die(var_dump($_SESSION['profile']['errors'])); ?>
		
		$(document).ready(showEdit('profile','edit'));
		<?php } ?>
		<?php if($_SESSION['affiliate']['errors']){
		//die(var_dump($_SESSION['profile']['errors'])); ?>
		
		$(document).ready(showEdit('affiliate','edit'));
		<?php } ?>
		</script>
        <div id="sendEmail">
  <form action="actions.php?type=member" method="post" id="sendEmailModal">
  <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
    <tr>
      <td colspan="2" class="gridheader">Send Email To Member</td>
    </tr>
    <tr>
      <td class="gridrow2">From Name:</td>
      <td class="gridrow2"><label for="from_name"></label>
        <input type="text" name="from_name" id="from_name" value="<?php echo $chkSsettings->sSiteName ?>" style="width:90%"></td>
    </tr>
   <tr>
      <td class="gridrow2">From Email:</td>
      <td class="gridrow2"><label for="from_email"></label>
        <input type="text" name="from_email" id="from_email" value="<?php echo $chkSsettings->sSupportEmail ?>" style="width:90%"></td>
    </tr>
    <tr>
      <td class="gridrow2">Email Type</td>
      <td class="gridrow2"><p>
       <label>
          <input name="emailType" type="radio" id="EmailType_0" value="text" checked="CHECKED" onClick="setEmailType(this)">
          Plain Text</label>
        <br>
        <label>
          <input type="radio" name="emailType" value="html" id="EmailType_1" onClick="setEmailType(this)">
          Html</label>
        <br>
      </p></td>
    </tr>
    </table><br>
    <table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
    <tr>
      <td class="gridrow2">Subject:</td>
      <td class="gridrow2"><label for="subject"></label>
        <input name="subject" type="text" id="subject" size="50" style="width:90%"></td>
    </tr>
    <tr>
      <td class="gridrow2">Message</td>
      <td class="gridrow2"><label for="email_message"></label>
        <textarea name="email_message" id="email_message" cols="45" rows="15" style="width:90%"></textarea></td>
    </tr>
    <tr>
      <td colspan="2" class="gridrow2"><input type="submit" name="button2" id="button2" value="Send Mail">
        <input type="hidden" name="sendEmailToId" id="sendEmailToId">
        <input type="hidden" name="act" value="sendEmail"></td>
    </tr>
  </table></form>
</div>
<div id="recentEmail" >
<table width="50%" border="0" class="gridtable" style="min-width:650px;">
  <tr>
    <td colspan="2" class="gridheader">&nbsp;</td>
    </tr>
  <tr>
    <td class="gridheader">Subject</td>
    <td class="gridrow2"><span id="recentEmail_Subject">Loading ...</span></td>
  </tr>
  <tr>
    <td valign="top" class="gridheader">Message</td>
    <td class="gridrow2"><span id="recentEmail_Message" style="max-width:400px;">Loading ...</span></td>
  </tr>
  </table>

</div>
</body>
</html>