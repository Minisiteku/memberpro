<?php
// File Used To Display Tos For Members
include_once('../conn.php');

$tos = $dbo->getobject("SELECT `sTosHtml`
FROM `tblmembershiplevels`
WHERE `nLevel_ID` =".$_GET['id']."");

echo $tos->sTosHtml;
?>