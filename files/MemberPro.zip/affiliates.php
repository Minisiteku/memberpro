<?php
	// Test
	if(!defined("INEMP")){header("HTTP/1.0 403 Forbidden");die('Caught Security Exception! Forbidden');}
	global $dbo, $sSitename, $sSiteURL, $adminemail, $adminname, $admintitle, $chkSsettings, $language;
	//error_reporting('E_ALL ~ E_WARNING');
	$sql = "SELECT * FROM tblaffiliatesettings";	        		     
	$objAffiliateSettings = $dbo->getobject($sql);
	
	if($objAffiliateSettings->nHideAffiliateProgram) {echo $language['affjoin_err0'];}
	else {
		if(isset($_POST['Submit']))	{
			$today = date("Ymd");
			$time = date("g:i a");
			//die('here');
			// PHP Form Validation - Added by MDP 1-1-12 ////////////////////////////////////////////////////////////////////////
			//die(var_dump($_POST));
			$required = array('sForename','sSurname', 'sEmail','sAddr1', 'sTown','sCounty','sPostcode','sCounty','pass1');
			
			// Check No Spam //
			
			$nospam = get_option('nospam');
			if( $nospam == 'recaptcha'){
				require_once('common/recaptchalib.php');
				# the response from reCAPTCHA
				$resp = recaptcha_check_answer (get_option('recaptcha_private'),$_SERVER["REMOTE_ADDR"],$_POST["recaptcha_challenge_field"],$_POST["recaptcha_response_field"]);
				//unset($_SESSION['reCaptcha']);
							
				if (!$resp->is_valid) {header("Location: index.php?page=affiliates&err=5");exit;}
			}
			elseif($nospam == 'ayah'){
				define( 'AYAH_PUBLISHER_KEY', get_option('ayah_pubkey'));
				define( 'AYAH_SCORING_KEY', get_option('ayah_scorekey'));
				require_once("common/ayah/ayah.php");
				$ayah = new AYAH();
				// Use the AYAH object to get the score.
				$score = $ayah->scoreResult();
				//die($score);
				// Check the score to determine what to do.
				if (!$score){header("Location: index.php?page=affiliates&err=5");exit;}
			
			}
			
			// End No Spam //
			
			foreach ($_POST as $k=>$v){
				
				// While looking post, lets add to a session for form population on error
				$_SESSION['form'][$k] = $v;
				// Ok let's validate
				
				// Blank Field Validation
				if(in_array($k,$required )){
					if ($v == ""){header("Location:index.php?page=affiliates&err=1");exit;}
					//else{}
				}
				//email validation
					if($k=='sEmail'){
						if (!isValidEmail($v)){
							header("Location: index.php?page=affiliates&err=4");exit;
							}
						}
				
				// Password Validation
				if($k=='pass1' && strlen($v) <=5){header("Location: index.php?page=affiliates&err=3");exit;}
				
				// Paypal Email Validation (if applicable)
				if($k == 'sPaypalEmail'){
					if($objAffiliateSettings->nPaypal){
						if($v == ""){header("Location:index.php?page=affiliates&err=1");exit;}
						elseif(!isValidEmail($v)){
							header("Location: index.php?page=affiliates&err=4");exit;
							}
						}
					}		
				
			}
			
			if (strcmp($_POST['pass1'],$_POST['pass2']) < 0) {header("Location: index.php?page=affiliates&err=2");exit;}
			
			//
			
			/// END Validation //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			 
			$objUser = new stdClass();
			foreach($_POST as $k => $v){$objUser->$k = $v;}
			
			$objUser->sPassword = $_POST['pass1'];
			
			// Force The User as an Affiliate. Auto-enroll for customers only.
			$objUser->nAffiliate = 1;
			
			$nUser_ID = add_user($objUser);
			//die(var_dump($nUser_ID));
			// TODO: This Should Be An Email Template.
			/*$message="<h1>Please Confirm Your Email</h1><br />Thank you for joining us as an affiliate. Before we can activate your account, you must verify your email address so we know you're a real person.
			<br />
			We've sent a special link to your email address and you'll need to click on that to activate your account.";
			*/
			//$confURL = "$sSiteURL/verify_account.php?aff=1&security=".md5($nUser_ID);
			
			// New Confirm System
			// Create The Confirm Entry and get The Conf Code.
			
			$sql = "INSERT INTO `tbluserconfirm` (`nConfirm_ID`, `nUser_ID`, `nAffiliate`, `nPaymentPlan_ID`, `nSignupTime`, `sSignupIp`) 
			VALUES (NULL, '".$nUser_ID."', '1', '$nPaymentPlan_ID', '".time()."', '".$_SERVER['REMOTE_ADDR']."');";
			
			$confCode = md5($dbo->insert($sql));
			
			$confURL = "$sSiteURL/verify_account.php?conf=$confCode";
			
			// Send login details to the new member!
			// Moved Code to New Function - MDP - 3-18-12      		          		     
			email_affiliate_signup($nUser_ID,$confURL,$objAffiliateSettings);
			
			$sRedirect = 'index.php?page=affiliate_verify';
			header("Location: " . $sRedirect);exit;
						
			echo '<div style="width:100%"><span class="success">' . $message. '</span></div>';
			
		}
		else {
			// PHP Validation Err Msg- MDP - 1-1-12
			$msg = "";
			$errcode = $_GET['err'];
			//die($language['affjoin_err1']);
			if($errcode == 1){$msg = $language['affjoin_err1'];}
			elseif($errcode == 2){$msg = $language['affjoin_err2'];}
			elseif($errcode == 3){$msg = $language['affjoin_err3'];}
			elseif($errcode == 4){$msg = $language['affjoin_err4'];}
			elseif($errcode == 5){$msg = $language['join_captcha_err'];}
			
			// Anti Spam //
			$nospam = get_option('nospam');
			
			if($msg !=""){?><div align="center"><span class="red"><?php echo $msg; ?></span></div><?php } ?>
			<form action="" method="post"  id="form">
			<?php if($nospam == 'recaptcha'){ ?>
			 <script type="text/javascript">
			 var RecaptchaOptions = {
				theme : 'clean'
			 };
			 </script>
				 <?php } ?>
					<table width="650" align="center" cellpadding="0" cellspacing="1" class="gridtable">
						<tr><td class="gridheader" colspan="2"><span style="color:red"><?php echo $language['contact_required_fields'];  ?></span></td></tr>
						<tr>
							<td class="gridrow1" ><?php echo $language['affiliateedit_firstname'] ?> <span style='color:red'>*</span></td>
							<td class="gridrow2"><input name='sForename' type='text' class='required' id='sForename' style="width:300px;" value="<?php echo $_SESSION["form"]["sForename"] ?>"/></td>
						</tr>
						<tr>
							<td  class="gridrow1" ><?php echo $language['affiliateedit_lastname'] ?> <span style='color:red'>*</span></td>
							<td class="gridrow2"><input name='sSurname' type='text' class='required' id="sSurname"  style="width:300px;" value="<?php echo $_SESSION['form']['sSurname'] ?>"/></td>
						</tr>
						<tr>
							<td  class="gridrow1" ><?php echo $language['affiliateedit_address'] ?> <span style='color:red'>*</span></td>
							<td class="gridrow2"><input name='sAddr1' type='text' class='required' id='sAddr1'  style="width:300px;" value="<?php echo $_SESSION['form']['sAddr1'] ?>"/></td>
						</tr>
						<tr>
							<td  class="gridrow1" > </td>
							<td class="gridrow2"><input name='sAddr2' type='text' class='' id='sAddr2'  style="width:300px;" value="<?php echo $_SESSION['form']['sAddr2'] ?>"/></td>
						</tr>
						<tr>
							<td  class="gridrow1" ><?php echo $language['affiliateedit_city'] ?> <span style='color:red'>*</span></td>
							<td class="gridrow2"><input name='sTown' type='text' class='required' id='sTown'  style="width:300px;" value="<?php echo $_SESSION['form']['sTown'] ?>"/></td>
						</tr>
						<tr>
							<td class="gridrow1" ><?php echo $language['affiliateedit_county'] ?> <span style='color:red'>*</span></td>
							<td class="gridrow2"><input name='sCounty' type='text' class='required' id='sCounty'  style="width:300px;" value="<?php echo $_SESSION['form']['sCounty'] ?>"/></td>
						</tr>
						<tr>
							<td class="gridrow1" ><?php echo $language['affiliateedit_postcode'] ?> <span style='color:red'>*</span></td>
							<td class="gridrow2"><input name='sPostcode' type='text' class='required' id='sPostcode'  style="width:300px;" value="<?php echo $_SESSION['form']['sPostcode'] ?>"/></td>
						</tr>
						<tr>
							<td class="gridrow1" ><?php echo $language['affiliateedit_country'] ?> <span style='color:red'>*</span></td>
							<td class="gridrow2"><?php echo get_country_list('sCountry',$_SESSION['form']['sCountry'],1) ?></td>
						</tr>
						<tr>
							<td class="gridrow1" ><?php echo $language['affiliateedit_email'] ?> <span style='color:red'>*</span></td>
							<td class="gridrow2">
								<input name='sEmail' type='text' class='required email' id='sEmail'  style="width:300px;" value="<?php echo $_SESSION['form']['sEmail'] ?>"/>
								<input type='hidden' id='user_exist' name='user_exist' value='' />
								<input type="hidden" name="must" id="must" value="0" />
								<span id='user_e' style='color:red'></span>
							</td>
						</tr>
						<?php if($objAffiliateSettings->nPaypal) { ?>
						<tr>
							<td class="gridrow1" ><?php echo $language['affiliateedit_paypal_email'] ?><span style='color:red'>*</span></td>
							<td class="gridrow2"><input name='sPaypalEmail' type='text' class='required email' id='sPaypalEmail'  style="width:300px;" value="<?php echo $_SESSION['form']['sPaypalEmail'] ?>"/></td>
						</tr>
						<?php 
						}
						?>
						<tr>
							<td class="gridrow1" ><?php echo $language['affiliateedit_password']?> <span style="color: red">*</span></td>
						  <td class="gridrow2"><input type="password" name="pass1" id="pass1" class="required"	style="width: 300px;" /></td>
						</tr>
						<tr>
							<td class="gridrow1" ><?php echo $language['affiliateedit_confirm_password']?><span style="color: red">*</span></td>
							<td class="gridrow2"><input type="password" name="pass2" id="pass2" class="required"	style="width: 300px;" /></td>
						</tr>
						 <!-- Start Recaptcha -->
				 <?php
				if($nospam == 'recaptcha'){require_once('common/recaptchalib.php'); ?>
	   <tr>
		<td class="gridrow1"><?php echo $language['join_nospam'] ?></td>
        <td class="gridrow2"><?php echo recaptcha_get_html(get_option('recaptcha_public'), $error);?></td>
       </tr>
   
   <?php }
   				elseif($nospam == 'ayah'){
					define( 'AYAH_PUBLISHER_KEY', get_option('ayah_pubkey'));
					define( 'AYAH_SCORING_KEY', get_option('ayah_pubkey'));
					require_once("common/ayah/ayah.php");
					$ayah = new AYAH();?>
	  				<tr>
					<td class="gridrow1" align=""><?php echo $language['join_nospam'] ?></td>
        			<td class="gridrow2"><?php echo $ayah->getPublisherHTML(); ?></td>
      				</tr>
        <?php } ?>
					<!-- End recaptcha -->
						<tr>
						  <td colspan="2" class="gridfooter"><input class="inputsubmit" type='submit' name='Submit' value='<?php echo $language['misc_continue'] ?>' /></td>
					  </tr>
					</table>
					</form>
			
					<script type="text/javascript">				
					$(document).ready(function(){
			
						$("#form").validate(
							{
								rules: {
										pass1: {
											minlength:6
										},
										pass2: {
											equalTo: "#pass1",
											minlength:6															
										},
										sEmail: { 
											//remote: 'ajax/check_username.php'
										} 
								}, 
								messages: { 
											pass1: {
												minlength : errMinLength
											},
											pass2: {
												equalTo: errEqualTo,
												minlength : errMinLength	
											},
											sEmail: { 
												// remote: jQuery.format(" User already exists!")
											}
								}									
							}							
						);
					});
					</script>
			<?php
			// Destroy Form Population Session - Added by MDP - 1-1-12
			$_SESSION['form'] = "";
			////////////
				}
	}
?>