<?php
	include_once('../conn.php');
	include_once('../functions.php');
	error_reporting(0);
	$act = $_GET['act'];
	
	if($act == 'check_coupon'){
		
		$today = date("Ymd");
		$coupon = $dbo->format($_GET['sCouponCode']);
		
		// Get count of coupons used
		$sql = "SELECT COUNT( nCoupon_ID ) 
		FROM tbluserlevels
		WHERE nCoupon_ID
		IN (
		
		SELECT nCoupon_ID
		FROM tblcoupons
		WHERE sCouponCode =  '$coupon'
		)";
		
		$count = $dbo->getval($sql);
		
		// Check if coupon quantity is unlimited or not
		$sql = "SELECT nQtyAvailable FROM tblcoupons WHERE sCouponCode='$coupon'";
		$nQtyAvailable = $dbo->getval($sql);
		
		$qparam = '';
		
		if ($nQtyAvailable > 0) $qparam .= "AND $count < nQtyAvailable";
		
		// Get matches
		$q = "SELECT * FROM tblcoupons WHERE sCouponCode='$coupon' AND nExpiryDate > $today AND bActive=1 " . $qparam;
		
		$res = $dbo->select($q);
		$nr = $dbo->nr($res);
		
		if($nr==0) $valid = false; // Invalid coupon
		else $valid = true; // Valid coupon
		
		header('Content-type: application/json');
		echo json_encode($valid);				
	}
	
	if($act == 'check_username'){
		header('Content-type: application/json');
		echo json_encode(($dbo->num_rows("SELECT nUser_ID FROM tblusers WHERE sEmail='".$dbo->format($_GET['sEmail'])."'")?false:true));
	}

?>