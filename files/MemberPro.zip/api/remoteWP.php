<?php
	define( "INEMP", true );
	include "../conn_data.php";
	error_reporting(0);
	
	// Our Database Class
	// mysql is depreciated as of PHP 5.5.0
	// Moving to mysqli
	if (function_exists('mysqli_connect')) {
  		//mysqli is installed
		define('MYSQL_EXTENSION','mysqli');
		require_once '../includes/dbmysqli.php';
	}
	else {
		define('MYSQL_EXTENSION','mysql');
		require_once '../includes/dbgate.php';
	}
	
	$dbo = new dbgate($db_host,$db_username,$db_password,$db_name);
	
	// GET REQUEST
	$username = isset($_GET['username']) ? trim(strip_tags($_GET['username'])) : '';
	$password = isset($_GET['password']) ? trim(strip_tags($_GET['password'])) : '';
	$get_levels = isset($_GET['get_levels']) ? trim(strip_tags($_GET['get_levels'])) : '';
	
	$ret = '0';
	if(($username != '' || $password != '')){
	
		$result = $dbo->select("SELECT nUser_ID FROM tblusers WHERE sEmail = '".$dbo->format($username)."' AND MD5(sPassword) = '".$dbo->format($password)."' AND nActive=1 LIMIT 1");
	
		if($dbo->nr($result) > 0 ) {
	
			// Get User ID
			$row = $dbo->getassoc($result);
			$user_id = $row['nUser_ID'];
			
			// Get levels for user
			$query = "SELECT nLevel_ID FROM tbluserlevels WHERE nUser_ID=$user_id AND nActive = '1'";
			//die($query);
			$result2 = $dbo->select($query) or die($dbo->error);
			$user_levels = '';
			if($result2){
				//die(var_dump($result2));
				while ($row = $dbo->getarray($result2)) {$user_levels .= $row['nLevel_ID'] . ',';}
			}
			else $user_levels = '0,';
			if(!$user_levels || $user_levels == '') $user_levels = '0,';
			// remove extra,
			$user_levels = substr($user_levels, 0, -1);
	
			$ret = $user_levels;
		}
		else $ret = '0';
	}
	else $ret = '0';
	if(!headers_sent()){
		header("Pragma: no-cache");
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
		header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
		header("Cache-Control: must-revalidate");
	}
	echo $ret;
	exit;
?>