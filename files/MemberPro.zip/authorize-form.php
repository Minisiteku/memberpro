<?php
	if(!defined("INEMP")){header("HTTP/1.0 403 Forbidden");die('Caught Security Exception! Forbidden');}
	global $dbo;
	
	if (!is_numeric($_GET['id'])) die('Invalid payment plan ID');
	
	$nPaymentPlan_ID=$dbo->format($_GET['id']);
	
	// Find the plan details from tblPayment Plans
	$sql = "SELECT * FROM tblpaymentplans WHERE nPaymentPlan_ID='$nPaymentPlan_ID'"; 
	$objPaymentPlan = $dbo->getobject($sql);
	
	$sItemNumber = $objPaymentPlan->sItemNumber;
	$sItemName = $objPaymentPlan->sItemName;
	
	if(isset($_POST['submit'])){
		//Process the Authorize.Net payment
		if($objPaymentPlan->nOneTimePayment == '1') include('process-authorize.php');
		else include('process-authorizeARB.php');
	}
	else {
		if (!is_numeric($_GET['user_id'])) die('Invalid User ID');
	
		// One Time Payment
		if ($objPaymentPlan->nOneTimePayment == '1') {
		
			$form = '<form action="index.php?page=authorize-form&id=' . $nPaymentPlan_ID . '&method=single" onsubmit="return validateFormOnSubmit(this)" method="post">
			<input type="hidden" name="item_number" value="' . $sItemNumber . '">
			<input type="hidden" name="item_name" value="' . $sItemName . '">
			<input type="hidden" name="user_id" value="' . $_GET['user_id'] . '">
			<input type="hidden" name="CUSTID" value="' . $_GET['user_id'] . '">';
		// Recurring payment
		}
		else {
			$form = '<form action="index.php?page=authorize-form&id=' . $nPaymentPlan_ID . '&method=rec" method="post" onsubmit="return validateFormOnSubmit(this)">
			<input type="hidden" name="item_number" value="' . $sItemNumber . '">
			<input type="hidden" name="item_name" value="' . $sItemName . '">
			<input type="hidden" name="user_id" value="' . $_GET['user_id'] . '">
			<input type="hidden" name="CUSTID" value="' . $_GET['user_id'] . '">';		
		}
		
		// Get User Info
		$objUser = get_user_by_id($dbo->format($_GET['user_id']));
		
		?>
	<?php echo $form ?>
	<table border="0" align="center" cellpadding="0" cellspacing="0">
	  <tr>
		<td><table width="50%">
			<tr>
			  <td colspan="2"><strong>Card Holder Details</strong></td>
			</tr>
			<tr>
			  <td width="84">First Name</td>
			  <td width="344"><input name="x_first_name" maxlength="35" value="<?php echo $objUser->sForename ?>" style="width: 200px" /></td>
			</tr>
			<tr>
			  <td>Last Name</td>
			  <td><input name="x_last_name" maxlength="35" value="<?php echo $objUser->sSurname ?>" style="width: 200px" /></td>
			</tr>
			<tr>
			  <td>Address:</td>
			  <td><input name="x_address" maxlength="35" value="<?php echo $objUser->sAddr1 ?>" style="width: 200px" /></td>
			</tr>
			<tr>
			  <td>City/Town:</td>
			  <td><input name="x_city" maxlength="35" value="<?php echo $objUser->sTown ?>" style="width: 200px" /></td>
			</tr>
			<tr>
			  <td>State/County:</td>
			  <td><input name="x_state" maxlength="35" value="<?php echo $objUser->sCounty ?>" style="width: 200px" /></td>
			</tr>
			<tr>
			  <td>Zip/Postcode:</td>
			  <td><input name="x_zip" maxlength="35" value="<?php echo $objUser->sPostcode ?>" style="width: 200px" /></td>
			</tr>
			<tr>
			  <td>Country:</td>
			  <td><select name="x_country" id="x_country" style="width: 200px">
				  <option value='af'>Afghanistan</option>
				  <option value='al'>Albania</option>
				  <option value='dz'>Algeria</option>
				  <option value='as'>American Samoa</option>
				  <option value='ad'>Andorra</option>
				  <option value='ao'>Angola</option>
				  <option value='ai'>Anguilla</option>
				  <option value='aq'>Antarctica</option>
				  <option value='ag'>Antigua and Barbuda</option>
				  <option value='ar'>Argentina</option>
				  <option value='am'>Armenia</option>
				  <option value='aw'>Aruba</option>
				  <option value='au'>Australia</option>
				  <option value='at'>Austria</option>
				  <option value='az'>Azerbaijan</option>
				  <option value='bs'>Bahamas</option>
				  <option value='bh'>Bahrain</option>
				  <option value='bd'>Bangladesh</option>
				  <option value='bb'>Barbados</option>
				  <option value='by'>Belarus</option>
				  <option value='be'>Belgium</option>
				  <option value='bz'>Belize</option>
				  <option value='bj'>Benin</option>
				  <option value='bm'>Bermuda</option>
				  <option value='bt'>Bhutan</option>
				  <option value='bo'>Bolivia</option>
				  <option value='ba'>Bosnia-Herzegovina</option>
				  <option value='bw'>Botswana</option>
				  <option value='bv'>Bouvet Island</option>
				  <option value='br'>Brazil</option>
				  <option value='io'>British Indian Ocean Territory</option>
				  <option value='bn'>Brunei Darussalam</option>
				  <option value='bn'>Brunei Darussalam</option>
				  <option value='bg'>Bulgaria</option>
				  <option value='bf'>Burkina Faso</option>
				  <option value='bi'>Burundi</option>
				  <option value='kh'>Cambodia</option>
				  <option value='cm'>Cameroon</option>
				  <option value='ca'>Canada</option>
				  <option value='cv'>Cape Verde</option>
				  <option value='ky'>Cayman Islands</option>
				  <option value='cf'>Central African Republic</option>
				  <option value='td'>Chad</option>
				  <option value='cl'>Chile</option>
				  <option value='cn'>China</option>
				  <option value='cx'>Christmas Island</option>
				  <option value='cc'>Cocos (Keeling) Islands</option>
				  <option value='co'>Colombia</option>
				  <option value='km'>Comoros</option>
				  <option value='cg'>Congo</option>
				  <option value='cd'>Congo (Brazzaville)</option>
				  <option value='ck'>Cook Islands</option>
				  <option value='cr'>Costa Rica</option>
				  <option value='hr'>Croatia</option>
				  <option value='cy'>Cyprus</option>
				  <option value='cz'>Czech Republic</option>
				  <option value='dk'>Denmark</option>
				  <option value='dj'>Djibouti</option>
				  <option value='dm'>Dominica</option>
				  <option value='do'>Dominican Republic</option>
				  <option value='tp'>East Timor</option>
				  <option value='ec'>Ecuador</option>
				  <option value='eg'>Egypt</option>
				  <option value='sv'>El Salvador</option>
				  <option value='gq'>Equatorial Guinea</option>
				  <option value='er'>Eritrea</option>
				  <option value='ee'>Estonia</option>
				  <option value='et'>Ethiopia</option>
				  <option value='fk'>Falkland Islands</option>
				  <option value='fo'>Faroe Islands</option>
				  <option value='fj'>Fiji</option>
				  <option value='fi'>Finland</option>
				  <option value='su'>Former USSR</option>
				  <option value='fr'>France</option>
				  <option value='fx'>France (European Territory)</option>
				  <option value='gf'>French Guiana</option>
				  <option value='tf'>French Southern Territories</option>
				  <option value='ga'>Gabon</option>
				  <option value='gm'>Gambia</option>
				  <option value='ge'>Georgia</option>
				  <option value='de'>Germany</option>
				  <option value='gh'>Ghana</option>
				  <option value='gi'>Gibraltar</option>
				  <option value='gr'>Greece</option>
				  <option value='gl'>Greenland</option>
				  <option value='gd'>Grenada</option>
				  <option value='gp'>Guadeloupe (French)</option>
				  <option value='gu'>Guam (USA)</option>
				  <option value='gt'>Guatemala</option>
				  <option value='gg'>Guernsey</option>
				  <option value='gn'>Guinea</option>
				  <option value='gw'>Guinea Bissau</option>
				  <option value='gy'>Guyana</option>
				  <option value='ht'>Haiti</option>
				  <option value='hm'>Heard and McDonald Islands</option>
				  <option value='va'>Holy See (Vatican City State)</option>
				  <option value='hn'>Honduras</option>
				  <option value='hk'>Hong Kong</option>
				  <option value='hu'>Hungary</option>
				  <option value='is'>Iceland</option>
				  <option value='in'>India</option>
				  <option value='id'>Indonesia</option>
				  <option value='iq'>Iraq</option>
				  <option value='ie'>Ireland</option>
				  <option value='im'>Isle of Man</option>
				  <option value='il'>Israel</option>
				  <option value='it'>Italy</option>
				  <option value='ci'>Ivory Coast (Cote D Ivoire)</option>
				  <option value='jm'>Jamaica</option>
				  <option value='jp'>Japan</option>
				  <option value='je'>Jersey</option>
				  <option value='jo'>Jordan</option>
				  <option value='kz'>Kazakhstan</option>
				  <option value='ke'>Kenya</option>
				  <option value='ki'>Kiribati</option>
				  <option value='kw'>Kuwait</option>
				  <option value='kg'>Kyrgyz Republic (Kyrgyzstan)</option>
				  <option value='la'>Laos</option>
				  <option value='lv'>Latvia</option>
				  <option value='lb'>Lebanon</option>
				  <option value='ls'>Lesotho</option>
				  <option value='lr'>Liberia</option>
				  <option value='ly'>Libya</option>
				  <option value='li'>Liechtenstein</option>
				  <option value='lt'>Lithuania</option>
				  <option value='lu'>Luxembourg</option>
				  <option value='mo'>Macao</option>
				  <option value='mk'>Macedonia</option>
				  <option value='mg'>Madagascar</option>
				  <option value='mw'>Malawi</option>
				  <option value='my'>Malaysia</option>
				  <option value='mv'>Maldives</option>
				  <option value='ml'>Mali</option>
				  <option value='mt'>Malta</option>
				  <option value='mh'>Marshall Islands</option>
				  <option value='mq'>Martinique (French)</option>
				  <option value='mr'>Mauritania</option>
				  <option value='mu'>Mauritius</option>
				  <option value='yt'>Mayotte</option>
				  <option value='mx'>Mexico</option>
				  <option value='fm'>Micronesia</option>
				  <option value='md'>Moldova</option>
				  <option value='mc'>Monaco</option>
				  <option value='mn'>Mongolia</option>
				  <option value='me'>Montenegro</option>
				  <option value='ms'>Montserrat</option>
				  <option value='ma'>Morocco</option>
				  <option value='mz'>Mozambique</option>
				  <option value='mm'>Myanmar</option>
				  <option value='na'>Namibia</option>
				  <option value='nr'>Nauru</option>
				  <option value='np'>Nepal</option>
				  <option value='nl'>Netherlands</option>
				  <option value='an'>Netherlands Antilles</option>
				  <option value='nt'>Neutral Zone</option>
				  <option value='nc'>New Caledonia (French)</option>
				  <option value='nz'>New Zealand</option>
				  <option value='ni'>Nicaragua</option>
				  <option value='ne'>Niger</option>
				  <option value='ng'>Nigeria</option>
				  <option value='nu'>Niue</option>
				  <option value='nf'>Norfolk Island</option>
				  <option value='kp'>North Korea</option>
				  <option value='mp'>Northern Mariana Islands</option>
				  <option value='no'>Norway</option>
				  <option value='om'>Oman</option>
				  <option value='pk'>Pakistan</option>
				  <option value='pw'>Palau</option>
				  <option value='pa'>Panama</option>
				  <option value='pg'>Papua New Guinea</option>
				  <option value='py'>Paraguay</option>
				  <option value='pe'>Peru</option>
				  <option value='ph'>Philippines</option>
				  <option value='pn'>Pitcairn Island</option>
				  <option value='pl'>Poland</option>
				  <option value='pf'>Polynesia (French)</option>
				  <option value='pt'>Portugal</option>
				  <option value='pr'>Puerto Rico</option>
				  <option value='qa'>Qatar</option>
				  <option value='re'>Reunion (French)</option>
				  <option value='ro'>Romania</option>
				  <option value='ru'>Russian Federation</option>
				  <option value='rw'>Rwanda</option>
				  <option value='gs'>S. Georgia &amp; S. Sandwich Isls.</option>
				  <option value='sh'>Saint Helena</option>
				  <option value='kn'>Saint Kitts &amp; Nevis Anguilla</option>
				  <option value='lc'>Saint Lucia</option>
				  <option value='pm'>Saint Pierre and Miquelon</option>
				  <option value='st'>Saint Tome (Sao Tome) and Principe</option>
				  <option value='vc'>Saint Vincent &amp; Grenadines</option>
				  <option value='ws'>Samoa</option>
				  <option value='sm'>San Marino</option>
				  <option value='sa'>Saudi Arabia</option>
				  <option value='sn'>Senegal</option>
				  <option value='rs'>Serbia</option>
				  <option value='sc'>Seychelles</option>
				  <option value='sl'>Sierra Leone</option>
				  <option value='sg'>Singapore</option>
				  <option value='sk'>Slovak Republic</option>
				  <option value='si'>Slovenia</option>
				  <option value='sb'>Solomon Islands</option>
				  <option value='so'>Somalia</option>
				  <option value='za'>South Africa</option>
				  <option value='kr'>South Korea</option>
				  <option value='es'>Spain</option>
				  <option value='lk'>Sri Lanka</option>
				  <option value='sr'>Suriname</option>
				  <option value='sj'>Svalbard and Jan Mayen Islands</option>
				  <option value='sz'>Swaziland</option>
				  <option value='se'>Sweden</option>
				  <option value='ch'>Switzerland</option>
				  <option value='sy'>Syria</option>
				  <option value='tj'>Tadjikistan</option>
				  <option value='tw'>Taiwan</option>
				  <option value='tz'>Tanzania</option>
				  <option value='th'>Thailand</option>
				  <option value='tg'>Togo</option>
				  <option value='tk'>Tokelau</option>
				  <option value='to'>Tonga</option>
				  <option value='tt'>Trinidad and Tobago</option>
				  <option value='tn'>Tunisia</option>
				  <option value='tr'>Turkey</option>
				  <option value='tm'>Turkmenistan</option>
				  <option value='tc'>Turks and Caicos Islands</option>
				  <option value='tv'>Tuvalu</option>
				  <option value='um'>USA Minor Outlying Islands</option>
				  <option value='ug'>Uganda</option>
				  <option value='ua'>Ukraine</option>
				  <option value='ae'>United Arab Emirates</option>
				  <option value='uk'>United Kingdom</option>
				  <option value='us'>United States</option>
				  <option value='uy'>Uruguay</option>
				  <option value='uz'>Uzbekistan</option>
				  <option value='vu'>Vanuatu</option>
				  <option value='ve'>Venezuela</option>
				  <option value='vn'>Vietnam</option>
				  <option value='vg'>Virgin Islands (British)</option>
				  <option value='vi'>Virgin Islands (USA)</option>
				  <option value='wf'>Wallis and Futuna Islands</option>
				  <option value='eh'>Western Sahara</option>
				  <option value='ye'>Yemen</option>
				  <option value='zr'>Zaire</option>
				  <option value='zm'>Zambia</option>
				  <option value='zw'>Zimbabwe</option>
				</select></td>
			</tr>
			<tr>
			  <td>Email:</td>
			  <td><input name="x_email" maxlength="35" value="<?php echo $objUser->sEmail ?>" style="width: 200px" /></td>
			</tr>
			<tr>
			  <td>Phone:</td>
			  <td><input name="x_phone" maxlength="35" style="width: 200px" /></td>
			</tr>
		  </table></td>
		<td valign="top"><table width="98%">
			<tr>
			  <td colspan="2"><strong>Credit Card Information</strong></td>
			</tr>
			<tr>
			  <td>CC Number:</td>
			  <td><input name="x_card_num" maxlength="35" style="width: 200px" /></td>
			</tr>
			<tr>
			  <td>CC Type:</td>
			  <td><select name='x_method' onchange='handleRefreshOnCardTypeChange(&quot;VISA&quot;, false ,false);'>
				  <option value='VISA' selected="selected">Visa</option>
				  <option value='MASTERCARD'>Master Card</option>
				  <option value='AMEX'>American Express</option>
				  <option value='DISCOVER'>Discover</option>
				  <option value='MAESTR_UK'>Maestro UK</option>
				  <option value='SOLO'>Solo</option>
				  <option value='DINERS'>Diners Club</option>
				  <option value='JCB'>JCB</option>
				</select></td>
			</tr>
			<tr>
			  <td>Expiration </td>
			  <td> Month:
				<select name="ccmonth">
				  <option value='' selected="selected">--</option>
				  <option value="01">01</option>
				  <option value="02">02</option>
				  <option value="03">03</option>
				  <option value="04">04</option>
				  <option value="05">05</option>
				  <option value="06">06</option>
				  <option value="07">07</option>
				  <option value="08">08</option>
				  <option value="09">09</option>
				  <option value="10">10</option>
				  <option value="11">11</option>
				  <option value="12">12</option>
				</select>
				Year
				<select name="ccyear">
				  <option value='' selected="selected">----</option>
				  <option value='2012'>2012</option>
				  <option value='2013'>2013</option>
				  <option value='2014'>2014</option>
				  <option value='2015'>2015</option>
				  <option value='2016'>2016</option>
				  <option value='2017'>2017</option>
				  <option value='2018'>2018</option>
				  <option value='2019'>2019</option>
				  <option value='2020'>2020</option>
				  <option value='2021'>2021</option>
				  <option value='2022'>2022</option>
				  <option value='2023'>2023</option>
				  <option value='2024'>2024</option>
				</select></td>
			</tr>
			<tr>
			  <td>3 Digit Security Code:</td>
			  <td><input name="x_card_code" maxlength="3" style="width: 30px;" /></td>
			</tr>
		  </table>
		  <div align="right">
			<input type="submit" name="submit" id="submit" value="Complete Payment" />
		  </div></td>
	  </tr>
	</table>
	</form>
	<script type="text/javascript">
		var cardsSupportingLocalCurrency = [];
		var cardCodes = ['VISA','MASTERCARD','AMEX','DISCOVER','MAESTR_UK','SOLO','DINERS','JCB' ];
		var cardRegExps = ['^4.+','^5[1-5].+','^3[47].+','^6(011|5).+','^6759.+','^(6334|6767).*','^(3(0[0-5]|[68])|55).*','^(2131|1800|35).*' ];
		function setCardCompany() {
			try {
				var cardNumberDigits = "";
				var origCardNumber = arguments[0].value;
				for (i = 0; i < origCardNumber.length; i++) {
					var currNumberChar = origCardNumber.charAt(i);
					if (currNumberChar >= "0" && currNumberChar <= "9") {
						cardNumberDigits += currNumberChar;
					}
				}
			
				for (idxCard = 0; idxCard < cardRegExps.length; ++idxCard) {
					var re = new RegExp(cardRegExps[idxCard]);
					if (cardNumberDigits.match(re) ) {
						document.tdForm.cardCompany.value = cardCodes[idxCard];
						handleRefreshOnCardTypeChange("VISA", false , false);
						return;
					}
				}
			}
			catch(e) {}
		}
		</script>
	<?php } ?>