<?php
// Edit the two lines below to use the keys for your site.
// (Note: you can find your keys at http://portal.areyouahuman.com/dashboard)
//define( 'AYAH_PUBLISHER_KEY', 'your_publisher_key_goes_here');
//define( 'AYAH_SCORING_KEY', 'your_scoring_key_goes_here');


// Set defaults for values needed by the ayah.php file.
// (Note: you do not need to change these.)
define( 'AYAH_WEB_SERVICE_HOST', 'ws.areyouahuman.com');
define( 'AYAH_TIMEOUT', 0);
define( 'AYAH_DEBUG_MODE', FALSE);
define( 'AYAH_USE_CURL', TRUE);
