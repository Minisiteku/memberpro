<?php
	// This file loads all the required javascript for any given page.
	// Accepts CSV GET string script. ?script=jquery,superfish,validator,
	error_reporting(0);
	if(!ob_start("ob_gzhandler")) ob_start();
	//ob_start();
	if(isset($_GET['script'])){
		// Set The Header For Javascript Output
		//include("../includes/openlib/code-compress.php");

		//$c = new PhpClosure();
		//header("content-type: application/x-javascript");
		$scripts = explode(',',$_GET['script']);
		foreach($scripts as $v){
			switch($v){
				case 'jq': echo file_get_contents("../js/jquery-1.8.3.min.js");break;
				case 'validate': echo file_get_contents('../js/jquery.validate.js');break;
				case 'hover': echo file_get_contents('../js/hoverIntent.js');break;
				case 'menus': echo file_get_contents('../js/superfish.js');echo file_get_contents('../js/supersubs.js');break;
				case 'fplayer': echo file_get_contents('../js/flowplayer/flowplayer-3.2.8.min.js');break;
				case 'emp': echo file_get_contents('../js/system/emp.js');break;
			
			}
				}
		
	}

$buffer = ob_flush();

/* insert code here then flush the buffer to $buffer */

    $cacheTime = time(); // or the file date of your static file

    $gmt_mtime = gmdate('D, d M Y H:i:s', $cacheTime ) . ' GMT';
    header("Content-type: application/x-javascript;");
    header("Last-Modified: " . $gmt_mtime ,true);
    header('Content-Length: ' . strlen($buffer),true);
    header("Cache-Control: private, max-age=6000, pre-check=6000");
	header("Pragma: private");
	header("Expires: " . gmdate("D, d M Y H:i:s", $cacheTime + $seconds) . " GMT",true);

echo $buffer;
?>