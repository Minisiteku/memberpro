<?php
	error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING ^ E_STRICT);
	//error_reporting(E_ALL );
	@session_start();
	// Version 3.0 Security For Pages.
	// Constant INEMP makes sure outside php pages meant to be loaded through index.php,php include, and plugins are not accessed directly.
	define( "INEMP", true );
	
	// Require Deletion Of Install Directory
	if (strpos($_SERVER['REQUEST_URI'], '/admin/') !== FALSE && file_exists('../install')) {
		require_once('insecure.php');
		die();
	}
	include("conn_data.php");
	
	// Our Database Class
	// mysql is depreciated as of PHP 5.5.0
	// Moving to mysqli
	if (function_exists('mysqli_connect')) {
  		//mysqli is installed
		define('MYSQL_EXTENSION','mysqli');
		require_once 'includes/dbmysqli.php';
	}
	else {
		define('MYSQL_EXTENSION','mysql');
		require_once 'includes/dbgate.php';
	}
	
	$dbo = new dbgate($db_host,$db_username,$db_password,$db_name);
	
	// Load Options Into Session For Db Reduection.
	$sql = "SELECT * FROM tbloptions;";
	$res = $dbo->select($sql);
	while($row = $dbo->getobj($res)){$_SESSION['options'][$row->sName] = $row->sValue;}
	
	// Set Timezone
	$tz = ($_SESSION['options']['timezone'])? $_SESSION['options']['timezone']: date_default_timezone_get();
	date_default_timezone_set($tz);
	
	// Get The Current Active Template
	$folder = $_SESSION['options']['activetemplate'];
	
	define('TEMPLATEFOLDER',$folder);
	
	
	$chkSsettings = $dbo->getobject("SELECT * FROM tblsitesettings WHERE nSiteSetting_ID = 1");
	$objTemplateSettings = $dbo->getobject("SELECT * FROM tbltemplatesettings WHERE sTemplateFolder = '".TEMPLATEFOLDER."'");
	
	define('ROOTPATH',$chkSsettings->sRootPath);
	define('TEMPLATEURL',$chkSsettings->sSiteURL.'/layout/' .TEMPLATEFOLDER.'/');
	define('TEMPLATEIMGURL',$chkSsettings->sSiteURL.'/layout/' .TEMPLATEFOLDER.'/images/');
	
	define('TEMPLATEPATH',ROOTPATH.'/layout/' .TEMPLATEFOLDER.'/');
	define('TEMPLATEIMGPATH',ROOTPATH.'/layout/' .TEMPLATEFOLDER.'/images/');
	
	define('PLUGINPATH',ROOTPATH.'/plugins/');
	define('UPLOADPATH',ROOTPATH.'/admin/assets/');
	
	// Our Security Class
	require_once(ROOTPATH.'/includes/security.class.php');
	$secure = new Secure(SALT); // Salt Defined In Conn_Data
	
	////////////////////////////////////////////////////
	// Global Varialbles
	////////////////////////////////////////////////////
	
	$today = date("Ymd");
	$time = date("g:i a");
	
	$admintitle = $chkSsettings->sSiteName;
	$sSitename = $chkSsettings->sSiteName;
	$sSiteURL = $chkSsettings->sSiteURL;
	$adminemail = $chkSsettings->sAdminEmail;
	$supportemail = $chkSsettings->sSupportEmail;
	$sPaypalEmail = $chkSsettings->sPaypalEmail;
	$adminname = $chkSsettings->sSiteOwner;
	$sKey = $chkSsettings->sKey;
	
	
	// Check that malicious users can't open folders by using the index.php?page=xxx feature
	// Or has crazy characters / sql injection attempt
	$badchars = array('/','\\',';','&',',');
	foreach($badchars as $v){if(strpos($_GET['page'], $v)!==false) {header("Location: $chkSsettings->sSiteURL/index.php");}}
	
	// Admin login check
	if ((strpos($_SERVER['REQUEST_URI'], '/admin/') !== FALSE) 
	&& (strpos($_SERVER['REQUEST_URI'], '/admin/index.php') === FALSE) 
	&& (strpos($_SERVER['REQUEST_URI'], '/admin/verify.php') === FALSE)) { 
		// this request is an admin request.
		// New method
		$secure->checkAuth('admin'); // redirects to Admin Login On Fail.
		
		$licenseData = $secure->getLicenseDetails($chkSsettings->sKey);
		$licenseData->key = $chkSsettings->sKey;

		if($licenseData->type == 'developer' && file_exists('includes/devopts.php')){
		// Loads DEVOPTS[] 
		include('includes/devopts.php');
	}
	}
	
	if($_GET['msg']) $message = '<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>'.$_GET['msg'].'</div>';
	if($_GET['err']) $message = '<div class="notify-error"><div class="notify-close, error-close" onClick="closeNotify(this)"></div>'.$_GET['err'].'</div>';
	
	if($_GET['warn']) $message = '<div class="notify-warning"><div class="notify-close, warning-close" onClick="closeNotify(this)"></div>'.$_GET['warn'].'</div>';
	// Our plugin class
	require_once( ROOTPATH.'/includes/plugins.php');
?>