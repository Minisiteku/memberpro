<?php
	if(!defined("INEMP")){header("HTTP/1.0 403 Forbidden");die('Caught Security Exception! Forbidden');}
	// COMPOSE CONTACT MESSAGE
	global $dbo, $sSitename, $sSiteURL, $adminemail, $adminname, $admintitle, $language,$chkSsettings;
	
	$msg = "";
	$errcode = $_GET['err'];
	$nospam = get_option('nospam');

	if($errcode == 6){$msg = $language['join_captcha_err'];}

	if (isset($_POST['submit'])) {
    	$c = 0;
		if ($_POST['name'] == '') {
			$c++;
			$nm = 1;
		}
	
		if ($_POST['email'] == '') {
			$c++;
			$em = 1;
		}
	
		if ($_POST['email'] != '' && !isValidEmail($_POST['email'])) {
			$c++;
			$em = 2;
		}
	
		if ($_POST['message'] == '') {
			$c++;
			$mess = 1;
		}
		
		// Check No Spam //
		if( $nospam == 'recaptcha'){
			require_once('common/recaptchalib.php');
			# the response from reCAPTCHA
			$resp = recaptcha_check_answer (get_option('recaptcha_private'),$_SERVER["REMOTE_ADDR"],$_POST["recaptcha_challenge_field"],$_POST["recaptcha_response_field"]);
			//unset($_SESSION['reCaptcha']);
								
			if (!$resp->is_valid) {$c++;$rc = 1;}
		}
		elseif($nospam == 'ayah'){
			define( 'AYAH_PUBLISHER_KEY', get_option('ayah_pubkey'));
			define( 'AYAH_SCORING_KEY', get_option('ayah_scorekey'));
			require_once("common/ayah/ayah.php");
			$ayah = new AYAH();	
					
			// Use the AYAH object to get the score.
			$score = $ayah->scoreResult();
			//die(var_dump($score));
			// Check the score to determine what to do.
			if (!$score){$c++;$rc = 1;}
		}
		
		// End No Spam //

    	$bSent = 0;
    
    	if ($c == 0) {
			$bSent = email_admin_contact($_POST['name'],$_POST['email'],$_POST['message']);
        } 
    }
	
	if($nospam == 'recaptcha'){ ?>
	 <script type="text/javascript">
	 var RecaptchaOptions = {
		theme : 'clean'
	 };
	 </script>
	<?php }

	if ($bSent == 1) {echo '<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>' . $language['contact_message_sent_successfully'] . '</div>'; }
	else{
	?>
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>?page=contact" method="post" name="form1" id="form1">
	  <table cellspacing="1" cellpadding="2" border="0" class="gridtable" width="650" align="center">
		<tr>
			<td class="gridheader" colspan="2"><?php echo $language['contact_contact_us'] ?><div style="float:right; width:150px;" align="right"><?php echo $language['contact_required_fields']; ?></div></td>
		  </tr>
		  <tr>
			<td width="150" class="gridrow1"><?php echo $language['contact_name'] ?>:</td>
			<td class="gridrow2"><input name="name" type="text" style="width: 400px;" value="<?php echo $_POST['name']; ?>" size="90" /><?php echo ($nm == 1) ? ' <span class="error">* [' . $language['errors_required'] . ']</span>' :
		' <span class="red">*</span>'; ?></td>
		  </tr>
		  <tr>
			<td class="gridrow1"><?php echo $language['contact_email'] ?>:</td>
			<td class="gridrow2"><input name="email" type="text" style="width: 400px;" value="<?php echo $_POST['email']; ?>" size="90" /> <?php
		if ($em == 1) {
			echo ' <span class="error">* [' . $language['errors_required'] . ']</span>';
		}
		elseif ($em == 2) {
			echo ' <span class="error">* [' . $language['errors_invalid'] . ']</span>';
		} 
		else {echo ' <span class="red">*</span>';} ?></td>
		  </tr>
		  <tr>
			<td class="gridrow1"><?php echo $language['contact_message'] ?>:</td>
			<td class="gridrow2"><textarea name="message" cols="90" class="txtarea" style="width: 400px; height: 200px;"><?php echo
		$_POST['message']; ?></textarea><?php echo ($mess == 1) ?
		' <span class="error">* [' . $language['errors_required'] . ']</span>' : ' <span class="red">*</span>'; ?></td>
		  </tr>
		  
		  <!-- No Spam Validation -->
			<?php
			
			if($nospam == 'recaptcha'){require_once('common/recaptchalib.php'); ?>
		   <tr>
			<td class="gridrow1"><?php echo $language['contact_anti_spam'] ?></td>
			<td class="gridrow2"><?php echo recaptcha_get_html(get_option('recaptcha_public'), $error);?><?php echo ($rc == 1) ?
		' <span class="error"> [' . $language['contact_wrong_antispam'] . ']</span>' : ' <span class="red">*</span>'; ?></td>
		   </tr>
	   
	   <?php }
			elseif($nospam == 'ayah'){
						define( 'AYAH_PUBLISHER_KEY', get_option('ayah_pubkey'));
						define( 'AYAH_SCORING_KEY', get_option('ayah_pubkey'));
						require_once("common/ayah/ayah.php");
						$ayah = new AYAH();?>
						<tr>
						<td class="gridrow1" align=""><?php echo $language['contact_anti_spam'] ?></td>
						<td class="gridrow2"><?php echo $ayah->getPublisherHTML(); ?><?php echo ($rc == 1) ?
		' <span class="error"> [' . $language['contact_wrong_antispam'] . ']</span>' : ' <span class="red">*</span>'; ?></td>
						</tr>
			<?php } ?>
		<!-- End No Spam -->
		  <tr>
			<td colspan="2" class="gridrow1" align="center"><input name="submit" type="submit" value="<?php echo $language['misc_submit'] ?>" /></td>
		  </tr>
	  </table>
		<p>&nbsp;</p>
	</form>
	<?php } 
?>