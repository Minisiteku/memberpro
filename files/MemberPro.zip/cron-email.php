<?php
	//error_reporting(E_ALL);
	//if(defined('STDIN') ) echo("Running from CLI");
	//else echo("Not Running from CLI"); 
	include_once ('conn.php');
	include_once ('functions.php');
	
	if(is_option('emailCron_LastRun')) update_option('emailCron_LastRun',time());
	else add_option('emailCron_LastRun',time());

	// 
	pluginClass::action('cron_email_preBroadcast');
	
	
	// Check if there is already a broadcast running via cron
	// This is used to prevent another cron from running if previous cron is still processing.
	
	if(!is_option('email_broadcasting')){
		add_option('email_broadcasting','1');
	
		// Lets find all broadcasts that are scheduled to be delivered and grab the ids
		$sql = "SELECT nBroadcast_ID FROM tblbroadcasts WHERE dScheduleTime < '".date('Y-m-d H:i:s')."' AND (nStatus = '0' OR nStatus = '-1')ORDER BY dScheduleTime ASC;";
		$res = $dbo->select($sql);
		
		if($dbo->nr($res)){
			$broadcastIds = array();
			while($row = $dbo->getobj($res)) $broadcastIds[] = $row->nBroadcast_ID;
		}
		// Start Processing The Broadcasts
		foreach ($broadcastIds as $v){
			// Set The Broadcast to In Progress ...
			$dbo->update("UPDATE tblbroadcasts SET nStatus = '1' WHERE nBroadcast_ID = $v");
			$bcres = $dbo->select("SELECT * FROM tblbroadcasts WHERE nBroadcast_ID = $v");
			
			while($broadcast = $dbo->getobj($bcres)){
				
				$query = $broadcast->sMemberQuery;
				
				$memberListRes = $dbo->select($query);
				
				// Check if Emails moved to database yet
				// Status 0 in Pending
				// status -1 is Resend
				if($broadcast->nStatus == '1'){
					// Emails Not In Database Yet ...
					while ($member = $dbo->getobj($memberListRes)) {
					
					$to = $member->sEmail;
					$subject = $broadcast->sSubject;
					$body = $broadcast->sBody;
					$bodyHtml = $broadcast->sBodyHtml;
					
					// Subject
					$subject = str_replace("[[FIRSTNAME]]", $member->sForename, $subject);
					
					// Message
			
					// Find - Replace [MERGE CODES]
					$find = array('[[FIRSTNAME]]', '[[LAST NAME]]', '[[PASSWORD]]', '[[EMAIL]]','[[JOINDATE]]', '[[EXPIREDATE]]', '[[USERNAME]]');
					$repl = array($member->sForename, $member->sSurname, $member->sPassword, $member->sEmail,date('m/d/Y', strtotime($member->nJoinDate)), date('m/d/Y', strtotime($member->nDateExpires)), $member->sEmail);
					
					$body = str_replace($find, $repl, $body);
					$bodyHtml = str_replace($find, $repl, $bodyHtml);
			
					// Wrap lines longer than 70 characters
					$body = wordwrap($body, 70);
					
					// Plain Email Messages Formatted ....
					// Lets append footers, afflinks and canSpam
					
					// Footer -> CanSpam -> Powered By
					
					$body .= $chkSsettings->sEmailFooter;
					$bodyHtml .= $chkSsettings->sEmailFooter;
					
					$body .= getCanSpam($member->nUser_ID);
					$bodyHtml .= getCanSpam($member->nUser_ID,'html');
					
					$body .= getPoweredByEmail();
					$bodyHtml .= getPoweredByEmail('html');
					// Instead of sending out the mail now, we store it in the database.
					// Check Mail Method
					
					$sql = "INSERT INTO `tblemails` (
					`nEmail_ID` ,
					`nBroadcast_ID` ,
					`nUser_ID` ,
					`sUserEmail` ,
					`nAdmin_ID` ,
					`sSubject` ,
					`sBody` ,
					`sBodyHtml` ,
					`dTimeCreated` ,
					`dSendTime` ,
					`dSentTime` ,
					`nStatus`
					)
					VALUES (
					NULL , 
					'".$broadcast->nBroadcast_ID."', 
					'".$member->nUser_ID."', 
					'".$member->sEmail."', 
					'".$broadcast->nAdmin_ID."', 
					'".$subject."', 
					'".$dbo->format($body)."', 
					'".storeHtmlToDb($bodyHtml)."', 
					'".date('Y-m-d H:i:s')."', 
					'".$broadcast->dScheduleTime."', 
					'0000-00-00 00:00:00', 
					'0')";
					$dbo->insert($sql);	
				}
					
				}
			}
		}
		// Broadcast Emails stored in email database
		
		// Lets Send The Broadcast Emails
		
		foreach ($broadcastIds as $v){
			
			$emailres = $dbo->update("SELECT * FROM tblemails WHERE nBroadcast_ID = $v AND nStatus = '0';");
			
			if($dbo->nr($emailres) == 0){
				// All Emails Sent For This Broadcast.
				// Set To Complete.
				$dbo->update("UPDATE tblbroadcasts SET nStatus = '2', dSentTime = '".date('Y-m-d H:i:s')."' WHERE nBroadcast_ID = $v AND nStatus = '1';");
			}
			else{
				
				// Lets start sending emails!
				// Calculate Throttle Speed
				$limit = get_option('mail_seconds');
			
				while($row = $dbo->getobj($emailres)){
					
					$to = $row->sUserEmail;
					$from = $supportemail;
					$subject = $row->sSubject;
					$text_content = $row->sBody;
					$html_content = readHtmlFromDb($row->sBodyHtml);
					
					// Check Mail Method
					if(get_option('mail_method') == 'php'){
						$result = multipart_email($to, $from, $subject, $html_content, $text_content);
						if($result){
							$sql = "UPDATE tblemails SET nStatus = '1', dSentTime = '".date('Y-m-d H:i:s')."' WHERE nEmail_ID = '".$row->nEmail_ID."';";
							$dbo->update($sql);
						}
						else{
							$sql = "UPDATE tblemails SET nStatus = '-1' WHERE nEmail_ID = '".$row->nEmail_ID."';";
							$dbo->update($sql);
						}
						if($limit != 0) sleep($limit);
					}
					else{
						
						// New SMTP
						// Call PEARMAIL
						require_once "Mail.php";
						require_once('Mail/mime.php');
						
						$host = get_option('smtp_host');
						$port = get_option('smtp_port');
						$username = get_option('smtp_user');
						$password = get_option('smtp_password');
						
						$from = '"'.$sSitename.'" <'.$supportemail.'>';
						$headers = array (
						'From' => $from, 
						'To' => $to,'Subject' => $subject);
						
						// Creating the Mime message
						$mime = new Mail_mime();
						
						// Setting the body of the email
						$mime->setTXTBody($text_content);
						$mime->setHTMLBody($html_content);
			
						$body = $mime->get();
						$headers = $mime->headers($headers);
						
						$smtp = @Mail::factory('smtp',array ('host' => $host,'port' => $port,'auth' => true,'username' => $username,'password' => $password));
						$mail = @$smtp->send($to, $headers, $body);
						
						if (@PEAR::isError($mail)) {
							
							$sql = "UPDATE tblemails SET nStatus = '-1' WHERE nEmail_ID = '".$row->nEmail_ID."';";
							$dbo->update($sql);
							//$code = $mail->getCode();
				   
							//if($code == '10001') {$servererr = 1;$message = 'Connection Error: Check your SMTP host/port details and try again.';break;}
							//elseif($code == '10002') {$servererr = 1;$message = 'Authentication Error: Check your SMTP settings and try again.';break;}
						}
						else{
							$sql = "UPDATE tblemails SET nStatus = '1', dSentTime = '".date('Y-m-d H:i:s')."' WHERE nEmail_ID = '".$row->nEmail_ID."';";
							$dbo->update($sql);
						}
						
						
						if($limit != 0){sleep($limit);}
			 
					/**/
							
					}
				}
			}
			
			// Unless script failed, all mails should be sent, and broadcast should be completed.
			
			$sql = "SELECT COUNT(*) as count from tblemails WHERE nBroadcast_ID = $v AND nStatus = '0';";
			$count = $dbo->getval($sql);
			
			if(!$count || $count == 0){
				$dbo->update("UPDATE tblbroadcasts SET nStatus = '2', dSentTime = '".date('Y-m-d H:i:s')."' WHERE nBroadcast_ID = $v AND nStatus = '1';");
			}
		}
		
		remove_option('email_broadcasting');
		
	}
	
?>