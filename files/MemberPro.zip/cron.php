<?php
	#!/usr/bin/php
	error_reporting(0);
	
	// Version 3.0
	// Cron is now required for multiple tasks including member expiration.
	// Also Summary Report Sent To Admin Email, including the backup if applicable.
	
	include_once ('conn.php');
	include_once ('functions.php');
	
	// Lets Start The Email String
	$cronmessage = 'Cron Job Summary for '.date('m-d-Y h:i:s A')."\n \r";
	$cronsubject = 'EMP Cron Job Summary For '.$sSitename;
	
	

	##########################################################
	### Member Expiration System #############################
	##########################################################

	if(get_option('auto_process_cancelled') == '1'){
		// Lets Deactivate The Cancelled Members
		$exp = 0;
		$nNow = date("Ymd");
		$sql = "SELECT * FROM tbluserlevels WHERE nDateCancelled != 0 AND nDateCancelled < $nNow AND nActive = '1'";
		//die($sql);
		$result = $dbo->select($sql);
		if($result){
			while($row = $dbo->getobj($result)){
				// Send The Email Informing them their membership access has expired.
				//email_member_expiry($row->nUser_ID, $row->nLevel_ID);
				// Update the membership access to inactive.
				$sql = "UPDATE `tbluserlevels` SET `nActive` = '0' WHERE `nUserLevel_ID` = '".$row->nUserLevel_ID."' LIMIT 1 ;";
				$res = $dbo->update($sql);
				// Add to the Count
				$exp++;
			}
		}
	$cronmessage .="($exp) Cancelled Memberships processed. \n \r";
	
	}
	
	// Expired memberships
	$exp = 0;
	$nNow = date("Ymd");
	
	// Get Count Of All Expired memberships
	$nr = $dbo->num_rows("SELECT * FROM tbluserlevels WHERE nDateExpires < $nNow AND nActive = '1'");

	if(get_option('auto_process_expired') == '1'){
		
		// Lets Deactivate The Expired Members
		
		
		// Check to see if recurring payments are excluded.
		if(!is_option('exclude_recurring_auto_process_expired') || get_option('exclude_recurring_auto_process_expired') == '0'){
			$result = $dbo->select("SELECT * FROM tbluserlevels WHERE nDateExpires < $nNow AND nActive = '1'");
		}
		else{
			// Could use a join, but this is just as easy ...
			// Get paymnt plan numbers to exclude.
			$sql = "SELECT nPaymentPlan_ID FROM tblpaymentplans WHERE nOneTimePayment = '0' AND nPaymentProcessor_ID != '6' ;";
			$res = $dbo->select($sql);
			$ids = array();
			
			while($row = $dbo->getobj($res)) $ids[] = $row->nPaymentPlan_ID;
			
			$NOTIN = implode(',',$ids);
			$sql = "SELECT * FROM tbluserlevels WHERE nDateExpires < $nNow AND nActive = '1' AND nPaymentPlan_ID NOT IN ($NOTIN);";
			$result = $dbo->select($sql);
			
		}
		
		if($result){
			while($row = $dbo->getobj($result)){
				
				// Update the membership access to inactive.
				
				// V-3.0.11 
				// Issues come into play when a member is subscribed to the same level more than once.
				// The code below allows the possibility of 2 membership levels being active. 1 with an expired date, and one with a good date.
				// The specific expired level is not in the query, and is possibly expiring the very first one, and deactivating the wrong one.
				
				//$result = $dbo->update("UPDATE `tbluserlevels` SET `nActive` = '0' WHERE `nUser_ID` =".$row->nUser_ID." AND `nLevel_ID` = '".$row->nLevel_ID."' LIMIT 1 ;");
				
				// Rebuild Query To Call The Specific Record.
				$sql = "UPDATE `tbluserlevels` SET `nActive` = '0' WHERE nUserLevel_ID = {$row->nUserLevel_ID} LIMIT 1 ;";
				$res2 = $dbo->update($sql);
				
				// Send The Email Informing them their membership access has expired.
				email_member_expiry($row->nUser_ID, $row->nLevel_ID);
				
				// Add to the Count
				$exp++;
			}
		}
		$cronmessage .="($exp) Expired Memberships processed. \n \r";
		$exp = 0;
		
	}
	else{
		// Inform Admin If There Are Expired Memberships That Need To Be Processed.
		if($nr > 0){
			$cronmessage .= 'Automatic Processing Of Expired Memberships Is Off!\n\r You Have '.$nr.' Expired Memberships That Need To Be Processed.\n\r';
		}
	}


	// Lets Warn The Soon To Expire members
	// This should only occur based on a setting, or Free/OneTime Payment Plans.
	$today = date("Y-m-d");
	//$today = '2012-08-29';
	$todaytime = strtotime($today);
		
		
	// 7 day expiration notice
	$noticetime = strtotime("+7 days",$todaytime);
	$noticedate = date('Ymd',$noticetime);

	$sql = "SELECT tbluserlevels.*, tblpaymentplans.nOneTimePayment FROM tbluserlevels 
	INNER JOIN tblpaymentplans ON tblpaymentplans.nPaymentPlan_ID = tbluserlevels.nPaymentPlan_ID 
	WHERE tbluserlevels.nDateExpires = ".$noticedate." AND tbluserlevels.nActive = 1 
	AND tblpaymentplans.nOneTimePayment = '1';";
	//die($sql);
	$result = $dbo->select($sql);
	$c = 0;
	if($result){
		
		while($row = $dbo->getobj($result)){
			// Send The Email to the Member
			email_member_expiry_notice($row->nUser_ID, $row->nLevel_ID);
			$c++;
		}
		if($c) $cronmessage .="($c) Expiration Notifications Sent. \n \r";
	
	}
	
	#########################################################################
	### Content Systems #####################################################
	#########################################################################
	
	// Lets Contact Members about Todays Drip Feeded Content!
	$result_pages = $dbo->select("SELECT * FROM tblpages WHERE nConfEmail='1'");
	$pagecount = 0;
	while ($row_pages = $dbo->getobj($result_pages)) {
		
		$nAccessDays = $row_pages->nAccessDays;
		$nAccessDaysInSecons = $nAccessDays * 3600 * 24;
		$sConfEmailContent = $row_pages->sConfEmailContent;
	
		$today = date('Ymd');
		
		$query_users = "SELECT * FROM tbluserlevels, tblusers WHERE UNIX_TIMESTAMP($today) - UNIX_TIMESTAMP(tbluserlevels.nDateActive) = $nAccessDaysInSecons
		AND tbluserlevels.nUser_ID = tblusers.nUser_ID AND tblusers.nUnsubscribe=0";
		
		$result_users = $dbo->select($query_users);
		$c = 0;
		while ($row_users = $dbo->getobj($result_users)) {
	
			$nUser_ID = $row_users->nUser_ID;
			$sForename = $row_users->sForename;
			$sEmail = $row_users->sEmail;
			$to = $sEmail;
			
			
	
			$message = "$sConfEmailContent \n";
			
			$find = array('[[FIRSTNAME]]', '[[LASTNAME]]', '[[PASSWORD]]', '[[EMAIL]]','[[JOINDATE]]', '[[EXPIREDATE]]', '[[USERNAME]]');
			
			$repl = array($row_users->sForename, $row_users->sSurname, $row_users->sPassword, $row_users->sEmail,
				date('m/d/Y', strtotime($row_users->nJoinDate)), date('m/d/Y', strtotime($row_users->nDateExpires)), $row_users->sEmail);
				
			$message = str_replace($find, $repl, $message);
	
			//$user_id = encrypt($nUser_ID, SALT);
			
			//$defaultOptOut = "\n\n---------------------\n" . " Please click " . $sSiteURL .
			//	"/index.php?page=unsubscribe&id=" . $user_id . " to unsubscribe ";
				
			$OptOut = get_option('email_CanSpam');
			
			$objFooter = $dbo->getobject("SELECT sEmailFooter FROM tblsitesettings WHERE nSiteSetting_ID  = '1'");
			
			$message = $message . "\n\n" . $objFooter->sEmailFooter;
			// Add canspam / opt out info
			$message .= $OptOut;
	
			$subject = "New Content Is Available For You";
			
			// We have an html editor in place, lets try sending it in html only mode for now.
			//$headers = "MIME-Version: 1.0\r\n";
			//$headers .= "Content-type: text/plain; charset=iso-8859-1\r\n";
			$headers .= "From: $sSitename <$supportemail>\r\n";
			mail($to, $subject, $message, $headers);
			$c++;
		}
		$pagecount ++;
		
	}
	
	////
	
	// Lets Activate Scheduled Pages - Coming Soon
	
	
	// Log The Cron Run.
	// To Do. Log Cron Type. 'daily'. May run multiple cron types in future.
	$sql = "INSERT INTO `tblcronlog` (`id` ,`timestamp` ,`log`)VALUES (NULL , '".time()."', '');";
	$dbo->insert($sql);
	#################################################################################################################
	### Database Operations #########################################################################################
	#################################################################################################################
	
	//===========backs up the database - backups will be available for restore in /admin/restore_database.php
	
	// lets check to see if backups are enabled 3.0.
	if(get_option('auto_backup') == '1'){
		
		function getTableList(){
			global $dbo;
			$rs = $dbo->exec("SHOW TABLES");
			while ($row = $dbo->getassoc($rs)) {$aList[] = $row[0];}
			return $aList;
		}
		
		$cronmessage .="Automatic Daily Database Backups Are Enabled. \n \r";
		// Check if folder is writeable
		if (is_writable('admin/dump')) {
		
			// Folder Is Writable. Lets Make Sure We Can Run Exec
			
			$EXEC = (exec('echo EXEC') == 'EXEC')?true:false;
			
			$aTables = getTableList();
			$my_file = date('Y_m_d').'_'.time()."_db.gz";// Time Added To File Name To Protect From Unauthorized Downloads by guessing file name.
			$my_path = "admin/dump/";
			$backupFile = $my_path . $my_file;
			$command = "/usr/bin/mysqldump --opt -u $db_username --password='$db_password' $db_name  | gzip > $backupFile";
			
			echo  exec($command, $result);
			
			if (is_file(dirname(__file__) . '/' . $backupFile)) {
				
				if(get_option('auto_backup_attach') =='1'){$cronmessage .="Your Daily Backup has been attached to this email. \n \n";}
				else{$cronmessage .= "Your Daily Backup has been created and archived successfully. \n\r";}
			}
			else {$cronmessage .= "Error: Unable to create backup file. \n\r";}
		} 
		else {$cronmessage .= "Folder admin/dump is not writeable. Please change the folder's attributes to writable permissions.  \n \r";}
		
	 }
	else{$cronmessage .="Automatic Daily Backups are not enabled. \n\r";}
	
	//==========================================================================
	
	function mail_attachment($filename, $path, $mailto, $from_mail, $from_name, $subject, $message) {
		$file = $path . $filename;
		$file_size = @filesize($file);
		if($file_size > 0){
			$handle = fopen($file, "r");
			$content = fread($handle, $file_size);
			fclose($handle);
			$content = chunk_split(base64_encode($content));
			}
		
		$uid = md5(uniqid(time()));
		$name = basename($file);
		$header = "From: " . $from_name . " <" . $from_mail . ">\r\n";
		// $header .= "Reply-To: ".$replyto."\r\n";
		$header .= "MIME-Version: 1.0\r\n";
		$header .= "Content-Type: multipart/mixed; boundary=\"" . $uid . "\"\r\n\r\n";
		$header .= "This is a multi-part message in MIME format.\r\n";
		$header .= "--" . $uid . "\r\n";
		$header .= "Content-type:text/plain; charset=iso-8859-1\r\n";
		$header .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
		$header .= $message . "\r\n\r\n";
		$header .= "--" . $uid . "\r\n";
		$header .= "Content-Type: application/octet-stream; name=\"" . $filename . "\"\r\n"; // use diff. tyoes here
		$header .= "Content-Transfer-Encoding: base64\r\n";
		$header .= "Content-Disposition: attachment; filename=\"" . $filename . "\"\r\n\r\n";
		$header .= $content . "\r\n\r\n";
		$header .= "--" . $uid . "--";
	
		if (mail($mailto, $subject, $message, $header)) {
			 //echo "mail send ... OK"; // or use booleans here
		} else {
			//echo "mail send ... ERROR!";
		}
	 } // End mail_attachment function
	$mailto = $chkSsettings->sAdminEmail;
	$my_mail = $chkSsettings->sSupportEmail;
	$my_name = 'EMP Cron';
	
	// Send Cron Summary Email
	if(get_option('auto_backup_attach')== '1'){$sendfile = $myfile;}
	else{$sendfile = '';}
	
	mail_attachment($my_file, $my_path, $mailto, $my_mail, $my_name, $cronsubject, $cronmessage);
	
	die($cronmessage);
?>