<?php

	//- turn off compression on the server
	if(function_exists('apache_setenv')){apache_setenv('no-gzip', 1);}
	@ini_set('zlib.output_compression', 'Off');
	
	// Make Sure We received A File Id.
	if ( (!isset($_GET['id'])) || (!is_numeric($_GET['id'])) ) {
		header("HTTP/1.0 400 Bad Request");
		echo "<h1>400 Bad Request</h1>";
		exit;
	}
	//
	include_once('conn.php');
	include_once('functions.php');
	
	function checkPHPAUTH(){
		global $dbo, $chkSsettings, $secure;
		// This Function Performs HTTP AUTH
		// If We Have A Successful Login With HTTP AUTH Set Session Var
		if(!$_SESSION['user']['HTTP_AUTH']){
			// Above Is Set On Successful Login So We DO NOT Have A Successful Login
			if ( !isset($_SERVER['PHP_AUTH_USER']) ) {
				// No Login Attempt, Lets Send Login Box
				header('WWW-Authenticate: Basic realm="'.$chkSsettings->sSiteName.': Member Only Downloads - Please Enter Your Login Details"');
				header('HTTP/1.0 401 Unauthorized');
				exit;
			}
			else{
				// PHP AUTH is SET
				// Lets Validate.
				$user = $dbo->format($_SERVER['PHP_AUTH_USER']);
				$pass = $dbo->format($_SERVER['PHP_AUTH_PW']);
				
				$sql = "SELECT nUser_ID from tblusers WHERE sEmail = '$user' AND sPassword = '$pass' AND nActive = 1 LIMIT 1";
				$objUser = $dbo->getobject($sql);
				
				// HTTP AUTH User Found
				if($objUser){
					// Http Auth Passed
					// Set EMp Auth
					$secure->setAuth('user',$objUser);
					$_SESSION['user']['HTTP_AUTH'] = true;
				}
				else {
					header('WWW-Authenticate: Basic realm="'.$chkSsettings->sSiteName.': Member Only Downloads - Please Enter Your Login Details"');
					header('HTTP/1.0 401 Unauthorized');
					die('Login Details failed.');
				}
			}
		}
	}
	
	$fileid = $dbo->format($_GET['id']);
	
	// Look for file in database
	$objFile = $dbo->getobject("SELECT * FROM tblfiles WHERE nFile_ID=" . $fileid);
	
	if(!$objFile){header("HTTP/1.1 404 Not Found");exit;}
	$getstr = '';
	$poststr = '';
	
	if ($objFile->nMemberOnly) {
		//error_log("Is member Only. Check Emp Login Status");
		// SESSION CHECK
		//$vars = get_defined_vars();
		
		if(!$secure->checkAuth('user',false)){
			// User Is Not Logged In Through This Interface.
			error_log("Not Emp Logged In, Lets Do HTTP AUTH");
			// Lets add HTTP login support.
			checkPHPAUTH();
		}
	}
	
	$remote = ($objFile->sURL == "") ? 0 : 1;
	
	// Build the File Path.
	//$path  = ($remote) ? $objFile->sURL : ROOTPATH . "/admin/assets".$objFile->sPath;
	// V3.1.6
	// Optionally use the root path, or the site url for local files ...
	
	if($remote){$path = $objFile->sURL;}
	else{
		
		$path = (is_option('protected_usepath') || get_option('protected_usepath') == '1')
		? ROOTPATH.'/admin/assets'.$objFile->sPath: $sSiteURL . "/admin/assets".$objFile->sPath;
		
	}

	
	
	
	// Sub Detection ONLY for local files ... This was a bug until 3.0.7
	// Paths In Subdir Are not trailed with  a /. Add One.
	if($remote == 0 ) $path = ($objFile->sPath !=='/')? $path.'/' : $path;
	// Subfolder detection //////////////////////////////////////////
	////////////////////////////////////////////////////////////////
	
	$fileName   = ($remote) ? basename($objFile->sURL) : $objFile->sFilename;
	$dirFile    = ($remote) ? $path : $path . $fileName;
	
	// Cross Type Fix For File->type - Can Be Mime, Or Extension.
	
	if(strpos($objFile->sType,'/') === false){

		// Set as File Ext.
		if(!function_exists(get_type)) require 'admin/mime.php';	
		$ctype = get_type($objFile->sType);


// Determine Content Type
    /*switch ($objFile->sType) {
      case "pdf": $ctype="application/pdf"; break;
      case "exe": $ctype="application/octet-stream"; break;
      case "zip": $ctype="application/zip"; break;
      case "doc": $ctype="application/msword"; break;
      case "xls": $ctype="application/vnd.ms-excel"; break;
      case "ppt": $ctype="application/vnd.ms-powerpoint"; break;
      case "gif": $ctype="image/gif"; break;
      case "png": $ctype="image/png"; break;
      case "jpeg":$ctype="image/jpeg"; break;
      case "jpg": $ctype="image/jpeg"; break;
      default: $ctype="application/force-download";}*/
	}
	else $ctype = $objFile->sType;
	
	// Everything Set - Lets Check Options
	$stream = 0;
	
	// Check If Stream
	//if($ctype == 'application/pdf'){$stream == 1;}
	// Deliver The Protected File
	deliver_file($objFile,$dirFile,$ctype,$stream);
	
?>