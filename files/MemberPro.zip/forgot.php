<?php
	if(!defined("INEMP")){header("HTTP/1.0 403 Forbidden");die('Caught Security Exception! Forbidden');}
	global $dbo, $sSitename, $supportemail, $sSiteURL, $language;

	// If button submitted
	if (isset($_POST["fSubmit"])) {
		$err = 0;
		$errmsg = '';
		if (trim($_POST["user"]) == ""){ 
			$err++;
			$errmsg = $language['forgotpassword_please_enter_email'];
		}
		else{
			
			if (!isValidEmail($_POST["user"])) {
				$err++;
				$errmsg = $language['forgotpassword_email_invalid'];
			}
		}

		if($err == 0){
			$res = $dbo->select("SELECT * FROM tblusers WHERE sEmail='" . $dbo->format($_POST["user"]) . "' LIMIT 1");
			if ($dbo->nr($res) == 0) {
				$err++;
				$errmsg = $language['forgotpassword_not_found'];
			}
			
		}
		
		
		if($err == 0){
			$row = $dbo->getobj($res);
			email_forgot_password($row);
			header("Location:index.php?page=login&msg={$language['forgotpassword_email_sent']}");exit;
		}
		else{
			header("Location:index.php?page=forgot&err=$errmsg");exit;
		}
	
	}
?>

<form name="form1" method="post" action="index.php?page=forgot">

<?php if (isset($message)) echo $message ?>

<table cellpadding="4" cellspacing="0" align="center" border="0">
<tr><td><?php echo $language['forgotpassword_email'] ?></td><td><input name="user" class="box" style="width: 200px;"></td></tr>
<tr><td align="right" colspan="2"><input name="fSubmit" value="<?php echo $language['misc_submit'] ?>" class="button" type="submit" /></td></tr>
</table>
			
</form>