<?php
	if(!defined("INEMP")){header("HTTP/1.0 403 Forbidden");die('Caught Security Exception! Forbidden');}
	require_once ('includes/functions-emails.php');
	require_once ('includes/functions-membershiplevels.php');
	require_once ('includes/functions-formatting.php');
	require_once ('includes/functions-transactions.php');
	require_once ('includes/functions-affiliates.php');
	require_once ('includes/functions-users.php');
	require_once ('includes/functions-menu.php');
	require_once ('includes/functions-pages.php');
	require_once ('includes/functions-files.php');
	require_once ('includes/functions-videos.php');
	require_once ('includes/process-functions.php');
	include_once ('includes/functions-folders.php');
	include_once ('includes/functions-payment.php');
	include_once ('includes/functions.3.0.php');
	include_once ('includes/functions-order.php');
	include_once ('includes/functions-notify.php'); // Action Notification System
	
	
	function genpassword($length){
		srand((double)microtime() * 1000000);
		$vowels = array("a", "e", "i", "o", "u");
		$cons = array("b", "c", "d", "g", "h", "j", "k", "l", "m", "n", "p", "r", "s",
			"t", "u", "v", "w", "tr", "cr", "br", "fr", "th", "dr", "ch", "ph", "wr", "st",
			"sp", "sw", "pr", "sl", "cl");
		$num_vowels = count($vowels);
		$num_cons = count($cons);
		for ($i = 0; $i < $length; $i++) {
			$password .= $cons[rand(0, $num_cons - 1)] . $vowels[rand(0, $num_vowels - 1)];
		}
		return substr($password, 0, $length);}
	// Function for password generation
	function get_random_string($valid_chars, $length)
	{
		// start with an empty random string
		$random_string = "";
	
		// count the number of chars in the valid chars string so we know how many choices we have
		$num_valid_chars = strlen($valid_chars);
	
		// repeat the steps until we've created a string of the right length
		for ($i = 0; $i < $length; $i++)
		{
			// pick a random number from 1 up to the number of valid chars
			$random_pick = mt_rand(1, $num_valid_chars);
	
			// take the random character out of the string of valid chars
			// subtract 1 from $random_pick because strings are indexed starting at 0, and we started picking at 1
			$random_char = $valid_chars[$random_pick-1];
	
			// add the randomly-chosen char onto the end of our string so far
			$random_string .= $random_char;
		}
	
		// return our finished random string
		return $random_string;}


/*function dateDiff($nDateFormat, $endDate, $beginDate)
{
$date_parts1=explode($nDateFormat, $beginDate);
$date_parts2=explode($nDateFormat, $endDate);
$start_date=gregoriantojd($date_parts1[0], $date_parts1[1], $date_parts1[2]);
$end_date=gregoriantojd($date_parts2[0], $date_parts2[1], $date_parts2[2]);
return $end_date - $start_date;
}
*/

function encodeHTML($sHTML)
{
    $sHTML = str_replace('&', '&amp;', $sHTML);
    $sHTML = str_replace('<', '&lt;', $sHTML);
    $sHTML = str_replace('>', '&gt;', $sHTML);
    return $sHTML;}

function get_string_between($string, $start, $end){
    $string = " " . $string;
    // changed this from original strpos
    $ini = strpos($string, $start);
    if ($ini == 0)
        return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);}

// return the date in format specified in settings section of admin tool
function fShowDate($dateformat, $formatdate){
    if ($dateformat == 1) {
        $ldate = substr($formatdate, 4, 2) . '/' . substr($formatdate, 6, 2) . '/' .
            substr($formatdate, 0, 4);
    }
    if ($dateformat == 2) {
        $ldate = substr($formatdate, 6, 2) . '/' . substr($formatdate, 4, 2) . '/' .
            substr($formatdate, 0, 4);
    }
    if ($dateformat == 3) {
        $ldate = substr($formatdate, 4, 2) . '-' . substr($formatdate, 6, 2) . '-' .
            substr($formatdate, 0, 4);
    }
    if ($dateformat == 4) {
        $ldate = substr($formatdate, 6, 2) . '-' . substr($formatdate, 4, 2) . '-' .
            substr($formatdate, 0, 4);
    }

    return $ldate;}
	
function fStoreDate($dateformat, $formatdate){
	// Date Stored In DB As YYYYMMDD
	
    if ($dateformat == 1) {
        //mm/dd/yyyy
		$pieces = explode('/',$formatdate);
		$ldate = $pieces[2].$pieces[0].$pieces[1];
		
    }
    if ($dateformat == 2) {
        //dd/mm/yyyy
		$pieces = explode('/',$formatdate);
		$ldate = $pieces[2].$pieces[1].$pieces[0];
    }
    if ($dateformat == 3) {
       //mm-dd-yyyy
	   $pieces = explode('-',$formatdate);
		$ldate = $pieces[2].$pieces[0].$pieces[1];
    }
    if ($dateformat == 4) {
        //dd-mm-yyyy
		 $pieces = explode('-',$formatdate);
		$ldate = $pieces[2].$pieces[1].$pieces[0];
    }

    return $ldate;
	}
function fMysqlTimestamp($dateformat, $formatdate){
	// Date Returned As YYYY-MM-DD
	
    if ($dateformat == '1') {
        //mm/dd/yyyy
		
		$pieces = explode('/',$formatdate);
		$ldate = $pieces[2].'-'.$pieces[0].'-'.$pieces[1];
		
    }
    if ($dateformat == 2) {
        //dd/mm/yyyy
		$pieces = explode('/',$formatdate);
		$ldate = $pieces[2].'-'.$pieces[1].'-'.$pieces[0];
    }
    if ($dateformat == 3) {
       //mm-dd-yyyy
	   $pieces = explode('-',$formatdate);
		$ldate = $pieces[2].'-'.$pieces[0].'-'.$pieces[1];
    }
    if ($dateformat == 4) {
        //dd-mm-yyyy
		 $pieces = explode('-',$formatdate);
		$ldate = $pieces[2].'-'.$pieces[1].'-'.$pieces[0];
    }

    return $ldate;
	}
// This is used to Format The jQuery Ui Date Picker Accoring to the Admin set Date Format. (picker does not use standard dating formats.)	
function fPickerDateFormat($dateformat){
	if ( $dateformat == '1') {$picdateformat = 'mm/dd/yy';}
elseif ($dateformat == '2') { $picdateformat = 'dd/mm/yy';}
elseif ($dateformat == '3') { $picdateformat = 'mm-dd-yy';}
elseif ($dateformat == '4') { $picdateformat = 'dd-mm-yy';}
return $picdateformat;
	}
	// Converts YYYYMMDD into TimeStamp
	function getTimeStampFromYYYY($datetime){
		$YYYY = substr($datetime, 0, 4);
		$MM = substr($datetime, 4, 2);
		$DD = substr($datetime, 6, 2);
		//die("$YYYY-$MM-$DD");
		return strtotime("$YYYY-$MM-$DD");
	}
// return the last day of the next month
// accepts date in YYYYMMDD format
function fLastDayNextMonth($nDBDate){
    $day = '01';
    $month = substr($nDBDate, 4, 2);
    $year = substr($nDBDate, 0, 4);
    $lastdate = date('Ymd', mktime(0, 0, 0, $month + 2, $day - 1, $year));
    return $lastdate;}

// return the last day of the this month
// accepts date in YYYYMMDD format
function fLastDayThisMonth($nDBDate){
    $day = '01';
    $month = substr($nDBDate, 4, 2);
    $year = substr($nDBDate, 0, 4);
    $lastdate = date('Ymd', mktime(0, 0, 0, $month + 1, $day - 1, $year));
    return $lastdate;}


// generic function to set a cookie. defines the cookie path/domain if it is not present.
function emp_setcookie($cookie_key, $cookie_value, $expire = 0, $cookie_path =
    '', $cookie_domain = '')
{
    //lk - i need to define the default cookie path/domain
    $cookie_path = ($cookie_path == '') ? '' : preg_replace('|https?://[^/]+|i', '',
        $cookie_path . '/');
    $cookie_domain = ($cookie_domain == '') ? '' : preg_replace('|https?://[^/]+|i',
        '', $cookie_domain . '/');
    $expire = time() + $expire;
    return setcookie($cookie_key, $cookie_value, $expire, $cookie_path, $cookie_domain);
}

// clears out all the cookies (if the key starts with 'emp-')
function emp_clearcookies($key_check = 'emp-')
{
    $success = false;
    if (!empty($_COOKIE)) {
        foreach ($_COOKIE as $key => $value) {
            if (substr($key, 0, strlen($key_check)) == $key_check) {
                $success = emp_setcookie($key, ' ', -31536000);
                if (isset($_SESSION[$key])) {
                    $_SESSION[$key] = '';
                }
                if (!$success)
                    break;
            }
        }
    }
    return $success;
}

// attempts to retrieve the affiliate id
function get_referer_affiliate_id()
{
    // set the affiliate id to 0
    $affiliate_id = 0;
    // check if it is stored in a cookie
    if (isset($_COOKIE['emp-afid'])) {
        $affiliate_id = $_COOKIE['emp-afid'];
    }
    // check if it is stored in the session object
    elseif (isset($_SESSION['emp-afid'])) {
        $affiliate_id = $_SESSION['emp-afid'];
    }
    // return the affiliate id
    return $affiliate_id;
}


function mysql_fetch_scalar_query($sql)
{
	global $dbo;
    $result = '0';
    if (!empty($sql)) {
        $query_handle = $dbo->select($sql);
        if (!empty($query_handle)) {
            $query = $dbo->getassoc($query_handle);
            if (is_array($query)) {
                if (count($query) > 0) {
                    $result = ($query[0] == 0) ? '0' : $query[0];
                }
            }
            unset($query);
        }
        unset($query_handle);
    }
    return $result;
}

function get_emp_version(){
	global $dbo;
	$version_number = $dbo->getval("SELECT nScriptVersion FROM tblsitesettings");
	if($version_number===false) {
		$version_number = '2.0';
	}
    return $version_number;}

function isValidEmail($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function check($field, $value)
{
	global $dbo;
	$value = $dbo->format($value);
    $sql = "SELECT COUNT($field) AS expr FROM tblusers WHERE $field = '$value'";
    $res = $dbo->select($sql);
    $rs = $dbo->getassoc($res);
    $dbo->free($res);
    return ($rs["expr"] ? true : false);
}
function isValidPassword($password)
{
   $regex = array("options"=>array("regexp"=>"^[[:alnum:]]{6,}$"));
   
   return filter_var($password,FILTER_VALIDATE_REGEXP,$regex);
	
}

// Phasing out this function as it is not very stable.
function email($to, $from_name, $from_email, $subject, $message, $contentType = "html", $to_cc = null, $to_bcc = null)
{
	global $dbo, $chkSsettings;
    
	$emailMessage = $message.$chkSsettings->sEmailFooter.getPoweredByEmail($contentType);
		
	
	
	if(get_option('mail_method') == 'php'){
		$headers = "From: \"$from_name\" <" . $from_email . ">\r\n";
    	$headers .= "Reply-To: \"$from_name\" <$from_email>\r\n";
	
    	if ($to_cc != null) $headers .= "CC: $to_cc\r\n";
    	if ($to_bcc != null) $headers .= "BCC: $to_bcc\r\n";
	
    	$headers .= "X-Sender: \"$from_name\" <$from_email>\r\n";
    	$headers .= 'MIME-Version: 1.0' . "\r\n";
    	$headers .= ($contentType == "plain")? 'Content-type: text/plain;' . "\r\n":'Content-type: text/html;' . "\r\n";
    	$headers .= "X-Priority: 3\n";
		$success = mail($to, $subject, $emailMessage, $headers);
	}
	else{
		@include_once('Mail.php');
		@require_once('Mail/mime.php');
		$host = get_option('smtp_host');
		$port = get_option('smtp_port');
		$username = get_option('smtp_user');
		$password = get_option('smtp_password');
		
		$from = "$from_name <$from_email>";
		$headers = array (
		'From' => $from,
		'To' => $to,
		'Subject' => $subject);
		
		if($contentType == "html"){
			$mime = @new Mail_mime();
        	$mime->setHTMLBody($emailMessage);
        	$emailMessage = $mime->get();
			$headers = $mime->headers($headers);
			
		}
		$smtp = @Mail::factory('smtp',array ('host' => $host,'auth' => true,'username' => $username,'password' => $password));

		$success = @$smtp->send($to, $headers, $emailMessage);
		
		// Log It In Databse
		$objUser = new stdClass();
		$objUser->email = $to;
		$objUser->id = get_userid_by_email($to);
		
		$objEmail = new stdClass();
		$objEmail->subject = $subject;
		$objEmail->body = $text_content;
		$objEmail->bodyHtml = $html_content;
		logSystemEmail($objUser,$objEmail);
		
		return $success;
	}
}

	// New Emai Format - replacing the old email function prior to 2.3 - MDP - 3-18-12
	function multipart_email($to, $from, $subject, $html_content, $text_content, $headers='') { 
		global $chkSsettings, $sSitename, $dbo;
		
		$textMessage = $text_content.$chkSsettings->sEmailFooter.getPoweredByEmail();
		$htmlMessage = $html_content.$chkSsettings->sHtmlEmailFooter.getPoweredByEmail('html');
		
		# Setup mime boundary
		$mime_boundary = 'Multipart_Boundary_x'.md5(time()).'x';
		$headers = 'From: "'.$sSitename.'"'." <$from>\n";
		$headers .= "X-Sender-IP: $_SERVER[SERVER_ADDR]\n";
		$headers .= 'Date:'.date('n/d/Y g:i A')."\n";
		$headers  .= "MIME-Version: 1.0\n";
		$headers .= "Content-Type: multipart/alternative;";
		$headers .= " boundary=\"$mime_boundary\"\n\n";
		
		$body = "This is a multi-part message in MIME format.";
		
		# Add in plain text version
		$body.= "\n--$mime_boundary\n";
		$body.= "Content-Type: text/plain; charset=\"charset=us-ascii\"\n";
		$body.= "Content-Transfer-Encoding: 8bit\n\n";
		
		$body.= $textMessage;
		
		# Add in HTML version
		$body.= "\n--$mime_boundary\n";
		$body.= "Content-Type: text/html; charset=\"UTF-8\"\n";
		$body.= "Content-Transfer-Encoding: 8bit\n\n";
		
		$body.= $htmlMessage;
		
		# End email
		$body.= "\n--$mime_boundary--"; # <-- Notice trailing --, required to close email body for mime's
		//die($body);
		# Finish off headers
		
		# Mail it out
		return mail($to, $subject, $body, $headers);
		// Log It In Databse
		$objUser = new stdClass();
		$objUser->email = $to;
		$objUser->id = get_userid_by_email($to);
		
		$objEmail = new stdClass();
		$objEmail->subject = $subject;
		$objEmail->body = $textMessage;
		$objEmail->bodyHtml = $htmlMessage;
		logSystemEmail($objUser,$objEmail);
	}

	function smtpEmail($to, $from, $subject, $html_content, $text_content, $headers=''){
		global $chkSsettings, $sSitename, $supportemail;
		include_once('Mail.php');
		include_once('Mail/mime.php');
		
		$host = get_option('smtp_host');
		$port = get_option('smtp_port');
		$username = get_option('smtp_user');
		$password = get_option('smtp_password');
		
		$from = "$sSitename <$supportemail>";
		
		$headers = array ('From' => $from,'To' => $to,'Subject' => $subject,'Content-Type'=> 'text/html; charset=UTF-8');
		
		
	
		// Creating the Mime message
		$mime = @new Mail_mime();
		
		$body = $text_content;
		$bodyHtml = $html_content;
		
		// Footer -> Powered By
				
		$text_content .= $chkSsettings->sEmailFooter.getPoweredByEmail();
		$html_content .= $chkSsettings->sEmailFooter.getPoweredByEmail('html');
	
		// Setting the body of the email
		$mime->setTXTBody($text_content);
		$mime->setHTMLBody($html_content);
		
		$body = $mime->get();
		$headers = $mime->headers($headers);
		// Sending the email
		$smtp = @Mail::factory('smtp',array ('host' => $host,'port' => $port,'auth' => true,'username' => $username,'password' => $password));
		@$smtp->send($to, $headers, $body);
		
		// Log It In Databse
		$objUser = new stdClass();
		$objUser->email = $to;
		$objUser->id = get_userid_by_email($to);
		
		$objEmail = new stdClass();
		$objEmail->subject = $subject;
		$objEmail->body = $text_content;
		$objEmail->bodyHtml = $html_content;
		logSystemEmail($objUser,$objEmail);
	}

// Function to return short currency symbol 
// Accepts currency in 3 letter format (e.g. GBP)
function get_currency_symbol($cur) {
	if ($cur == "USD") {
        $currency_symbol = "$";
    }
    if ($cur == "AUD") {
        $currency_symbol = "$";
    }
    if ($cur == "CAD") {
        $currency_symbol = "CAD";
    }
    if ($cur == "CZK") {
        $currency_symbol = "CZK";
    }
    if ($cur == "DKK") {
        $currency_symbol = "DKK";
    }
    if ($cur == "EUR") {
        $currency_symbol = "&euro;";
    }
    if ($cur == "HKD") {
        $currency_symbol = "HKD";
    }
    if ($cur == "HUF") {
        $currency_symbol = "HUF";
    }
    if ($cur == "NZD") {
        $currency_symbol = "NZD";
    }
    if ($cur == "NOK") {
        $currency_symbol = "NOK";
    }
    if ($cur == "PLN") {
        $currency_symbol = "PLN";
    }
    if ($cur == "GBP") {
        $currency_symbol = "�";
    }
    if ($cur == "SGD") {
        $currency_symbol = "SGD";
    }
    if ($cur == "SEK") {
        $currency_symbol = "SEK";
    }
    if ($cur == "CHF") {
        $currency_symbol = "CHF";
    }
    if ($cur == "JPY") {
        $currency_symbol = "";
    }
	if($cur == 'PHP'){$currency_symbol = '&#8369;';}
    
    return $currency_symbol;}

// Function to encode string/id
function emp_encode ($sValue) {
	
	$sSalt = strtolower(substr($_SERVER['DOCUMENT_ROOT'], 0, 6));
	return md5($sValue . $sSalt);}

// Function to decode encrypted string/id
function emp_decode ($sValue) {
	
	$sSalt = strtolower(substr($_SERVER['DOCUMENT_ROOT'], 0, 6));
	if (md5($sValue . $sSalt) == $sValue) {
		return true;
	} else {
		return false;
	}}

// Country list
function get_country_list($country, $Selected = '', $is_required = 0){
	global $language,$dbo;
	
	if ($is_required) {
		$required = 'class="required"';
	} else {
		$required = '';
	}
	
	$sql = 'SELECT * FROM tblcountries ORDER BY `sort` ASC;';
	$res = $dbo->select($sql);
	
	while($row = $dbo->getobj($res)){
		if($row->country_code == $Selected){$sel = 'selected';}
		else{$sel = '';}
		/*if($row->country_code == 'US' || $row->country_code == 'GB'){
			$toplist .= '<option value="'.$row->country_code.'" '.$sel.'>'.$row->country_name.'</option>';
			}
			else{$countrylist .='<option value="'.$row->country_code.'" '.$sel.'>'.$row->country_name.'</option>';}
		*/
		$countrylist .='<option value="'.$row->country_code.'" '.$sel.'>'.$row->country_name.'</option>';
		}
		$toplist .='<option value="" disabled="disabled">----------------------------------</option>';
		$ccdrop = '<select name="'.$country.'" style="width:250px;" '.$required.'>';
		$ccdrop .= $countrylist;
		$ccdrop .= '</select>';
		
    // Also pulled UK and US to top of menu.
	
	return $ccdrop;
	
	}
	
function get_country_name($cc){
	global $dbo;
	//die("SELECT country_name FROM tblcountries WHERE country_code = '".$dbo->format($cc)."';");
	return $dbo->getval("SELECT country_name FROM tblcountries WHERE country_code = '".$dbo->format($cc)."';");
	}

// Will send HTTP Post to remote script
// Modified to allow passing of a post url - MDP - 5-8-12
function send_post($objUser, $objPaymentPlan, $type = 'new', $url = "NONE") {
	global $chkSsettings;
	if($url == 'NONE'){$url = $chkSsettings->HTTPPostURL;}
	$post_url = $url;
	$user_id = $objUser->nUser_ID;
	$username = urlencode($objUser->sEmail);
	$password = urlencode($objUser->sPassword);
	$forename = urlencode($objUser->sForename);
	$surname = urlencode($objUser->sSurname);
	$itemnumber = urlencode($objPaymentPlan->sItemNumber);
	$itemname = urlencode(get_level_name_by_payment_plan($objPaymentPlan->nPaymentPlan_ID));

	$fields = "user_id=$user_id&username=$username&password=$password&forename=$forename&surname=$surname&itemname=$itemname&itemnumber=$itemnumber&type=$type&action=$action"; 

	//open connection
	$ch = curl_init();
	
	//set the url, number of POST vars, POST data
	curl_setopt($ch,CURLOPT_URL,$post_url);
	curl_setopt($ch,CURLOPT_POST,1);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$fields);
	
	//execute post
	$result = curl_exec($ch);
	//die($result);
	//close connection
	curl_close($ch);
	}

//=====================added functions to encrypt and decrypt stuff
function encrypt($string, $key){
    $result = '';
    for ($i = 0; $i < strlen($string); $i++)
    {
        $char = substr($string, $i, 1);
        $keychar = substr($key, ($i % strlen($key)) - 1, 1);
        $char = chr(ord($char) + ord($keychar));
        $result .= $char;
    }
    return base64_encode($result);}

function decrypt($string, $key)
{
    $result = '';
    $string = base64_decode($string);

    for ($i = 0; $i < strlen($string); $i++)
    {
        $char = substr($string, $i, 1);
        $keychar = substr($key, ($i % strlen($key)) - 1, 1);
        $char = chr(ord($char) - ord($keychar));
        $result .= $char;
    }
    return $result;}
//============================================================

// Error Logging System
function elog($msg){
	global $elogfile,$elogging;
	if($elogging){
		// format the message.
		$s = '['.date("j-M-Y g:i a").'] '; // [10-12-2012 10:36 AM] 
		$e = PHP_EOL;
		$data = $s.$msg.$e;
		
		if($elogfile){error_log($data,3,$elogfile);}
		else{error_log($msg);}
		
		}
	
	
	}
function regex_filter($str,$pattern){
	$opts = array("options"=>array("regexp"=>$pattern));
	return filter_var($str, FILTER_VALIDATE_REGEXP,$opts);
	}
?>