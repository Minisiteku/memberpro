<?php if(!defined("INEMP")){header("HTTP/1.0 403 Forbidden");die('Caught Security Exception! Forbidden');} ?>
<script type="text/javascript" src="scripts.js"></script>	
<link rel="stylesheet" type="text/css" href="common/css/styles.css" />
<link rel="stylesheet" type="text/css" href="common/css/superfish.css" media="screen">
<script type="text/javascript">			
	errEqualTo='&nbsp;Please enter the same value again!';
	errRequired='&nbsp;The field is mandatory!';
	errRemote='';
	errEmail='&nbsp;Please enter a valid email address!';
	errUrl='';
	errDate='';
	errDateISO='';
	errNumber='';
	errDigits='';
	errLinkv='';
	errCreditCard='';				
	errAccept='';
	errMaxLength='';
	errMinLength='&nbsp;Please enter at least 6 characters!';
	errRangeLength='';
	errRangeValue='';
	errMaxValue='';
	errMinValue='';
</script>	      
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.validate.js"></script>
<script type="text/javascript" src="js/hoverIntent.js"></script>
<script type="text/javascript" src="js/superfish.js"></script>
<script type="text/javascript">
	// initialise plugins
	jQuery(function(){
		jQuery('ul.sf-menu').superfish();
	});
</script>
<?php echo pluginClass::filter("main_head"); ?>