<?php

/**
* dbgate is a database handler class.
*
* dbgate is a class that contains our database connection.
* All mysql queries should be performed through this class.
*
* Example usage:
* $dbo->connect($dbhost,$dbuser,$dbpass);
*
* @package  Example
* @version  $Revision: 1.3 $
* @access   public
* @see      http://www.easymemberpro.com/docs
*/
	if(!defined("INEMP")){header("HTTP/1.0 403 Forbidden");die('Caught Security Exception! Forbidden');}

/*
    Database gateway class  (constructor connects automatically)
    
	Methods:
	
    format('myvalue') - trims and escapes a value, strips tags 

    select('select ...') - returns one or more rows, or false 

    getrow('select ...') - returns one row, or false 
 
	getobject('select ...') - returns one object, or false 

	getval('select ...') - returns one value, or false 

	insert() - inserts one row, return mysql_error()

	update() - updates database, return mysql_error()

    exec('delete from ...') -  any query

	connect() - connect to database
	
	delete() -  deletes row(s), return mysql_error()
	
*/
	class dbgate{
		
		var $connection;
		var $error;
		var $errorNo;
		var $insertId;
		var $result;
		
		function dbgate($db_host,$db_username,$db_password,$db_name) { $this->connect($db_host,$db_username,$db_password,$db_name); }
		
		/**
    	* Connect to a database
    	*
    	* @param  string  $db_host the database host name
    	* @return array   all of the exciting sample options
    	* @access private
		*/
		function connect($db_host,$db_username,$db_password,$db_name){   	
			
			$this->connection = mysql_connect($db_host,$db_username,$db_password);
			if(!$this->connection) exit('<hr>No sql connection<hr>');
			
			if(!mysql_select_db($db_name, $this->connection)) exit('<hr>No database connection<hr>');
		}
		function format($value, $notagstrip=false){
			// escapes value for query
			if(get_magic_quotes_gpc()) $value = stripslashes($value);
			
			if($notagstrip==false) $value = strip_tags($value); 
			
			$value = mysql_real_escape_string(trim($value));
			
			return $value;
		}
		function selectDb($dbname){
			if(!mysql_select_db($dbname,$this->connection)) exit('<hr>No database connection<hr>');
		}
		function create($sql){
			$this->sql = $sql;
			$result = mysql_query($this->sql,$this->connection);
			$this->error = mysql_error();
			$this->errorNo = mysql_errno();
			if(!$result) return false;
			return true;
		}
		function drop($sql){
			$this->sql = $sql;
			$result = mysql_query($this->sql,$this->connection);
			$this->error = mysql_error();
			$this->errorNo = mysql_errno();
			if(!$result) return false;
			return true;
		}
		function close($link = ''){
			if($link == '') $link = $this->connection;
			return mysql_close($link);
		}
		//
		function exec($sql){
			// executes a query
			$this->sql = $sql;
			$result = mysql_query($this->sql,$this->connection);
			return $result;
		}
		function select($sql){ 
			// returns result set
			$this->sql = $sql;
			$this->result = mysql_query($this->sql,$this->connection);
			$this->error = mysql_error();
			$this->errorNo = mysql_errno();
			if(!$this->result) {return false;}
			elseif(@mysql_num_rows($this->result)<1) return false;
			return $this->result;
		} 
		function insert($sql){
			$this->sql = $sql;
			$this->result = mysql_query($this->sql,$this->connection);
			$this->error = mysql_error();
			$this->errorNo = mysql_errno();
			$this->insertId = mysql_insert_id();
			if($this->result) return $this->insertId;
			return 0;
		}	
		function update($sql){
			$this->sql = $sql;
			$this->result = mysql_query($this->sql,$this->connection);
			$this->error = mysql_error();
			$this->errorNo = mysql_errno();
			return $this->result;
		}
		function delete($sql){
			$this->sql = $sql;
			$this->result = mysql_query($this->sql,$this->connection);
			$this->error = mysql_error();
			$this->errorNo = mysql_errno();
			return $this->result;
		}
		//
		
		function getarray($res,$type = 'BOTH'){
			return mysql_fetch_array($res,constant('MYSQL_'.$type));
		}
		function getassoc($res = ''){
			if($res == '') $res = $this->result;
			return mysql_fetch_assoc($res);
		}
		function getobj($res = ''){
			if($res == '') $res = $this->result;
			return mysql_fetch_object($res);
		}
		function nr($res = ''){
			if($res == '') $res = $this->result;
			return ($res)? mysql_num_rows($res):0;
		}
		function seek($res,$offset){
			return mysql_data_seek($res,$offset);
		}
		function numfields($res = ''){
			if($res == '') $res = $this->result;
			return mysql_num_fields($res);
		}
		function fieldtype($res,$i){
			return mysql_field_type($res,$i);
		}
		function fieldname($res,$i){
			return mysql_field_name($res,$i);
		}
		function free($res = ''){
			if($res == '') $res = $this->result;
			return mysql_free_result($res);
		}
		
		// ShortCuts
		function getval($sql){
			// return one value
			$result = $this->select($sql);
			if(!$result) return false;
			else {	
				$row = mysql_fetch_array($result);
				return  $row[0];
			}
		}
		function num_rows($sql){ 
			// returns result set
			$this->sql = $sql;
			$result = mysql_query($this->sql,$this->connection);
			if(!$result) return false;	
			return @mysql_num_rows($result);
		} 
		function getrow($sql){
			// return one row
			$result = $this->select($sql);
			if(!$result) return false;
			return  mysql_fetch_assoc($result);
		}
		function getobject($sql){
			// return one object
			$this->result = $this->select($sql,$this->connection);
			if(!$this->result) return false;
			return  mysql_fetch_object($this->result);
		}
	}
?>