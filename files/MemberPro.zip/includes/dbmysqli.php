<?php

/**
* dbgate is a database handler class.
*
* dbgate is a class that contains our database connection.
* All mysql queries should be performed through this class.
*
* Example usage:
* $dbo->connect($dbhost,$dbuser,$dbpass);
*
* @package  Example
* @version  $Revision: 1.3 $
* @access   public
* @see      http://www.easymemberpro.com/docs
*/
if(!defined("INEMP")){header("HTTP/1.0 403 Forbidden");die('Caught Security Exception! Forbidden');}
/*
    Database gateway class  (constructor connects automatically)
    
	Methods:
	
    format('myvalue') - trims and escapes a value, strips tags 

    select('select ...') - returns one or more rows, or false 

    getrow('select ...') - returns one row, or false 
 
	getobject('select ...') - returns one object, or false 

	getval('select ...') - returns one value, or false 

	insert() - inserts one row, return mysql_error()

	update() - updates database, return mysql_error()

    exec('delete from ...') -  any query

	connect() - connect to database
	
	delete() -  deletes row(s), return mysql_error()
	
*/
	class dbgate{
		
		var $connection;
		var $logConn;
		var $error;
		var $errorNo;
		var $insertId;
		var $result;
		var $stmt;
		
		function dbgate($db_host,$db_username,$db_password,$db_name)
		{
			$this->connect($db_host,$db_username,$db_password,$db_name);
		}
		
		/**
    	* Connect to a database
    	*
    	* @param  string  $db_host the database host name
    	* @return array   all of the exciting sample options
    	* @access private
		*/
		function connect($db_host,$db_username,$db_password,$db_name){   	
			
			$this->connection = new mysqli($db_host, $db_username, $db_password, $db_name);
			
			if ($this->connection->connect_error) trigger_error('Database connection failed: '  . $this->connection->connect_error, E_USER_ERROR);
		}
		function format($value, $notagstrip=false){
			// escapes value for query
			if(get_magic_quotes_gpc()) $value = stripslashes($value);
			
			if($notagstrip==false) $value = strip_tags($value); 
			//die(var_dump($value));
			$value = $this->connection->escape_string(trim($value));
			
			return $value;
		}
		function selectDb($dbname){
			if(!$this->connection->select_db($dbname)) trigger_error('Database selection failed: Cannot Connect to '.$dbname);
		}
		function create($sql){
			$this->sql = $sql;
			$this->result = $this->connection->query($this->sql);
			$this->error = $this->connection->error;
			$this->errorNo = $this->connection->errno;
			//$this->logQuery();
			if(!$this->result) return false;
			return true;
		}
		function drop($sql){
			$this->sql = $sql;
			$this->result = $this->connection->query($this->sql);
			$this->error = $this->connection->error;
			$this->errorNo = $this->connection->errno;
			//$this->logQuery();
			if(!$this->result) return false;
			return true;
		}
		function close(){ return $this->connection->close();}
		
		function exec($sql){
			// executes a query
			$this->sql = $sql;
			//$result = mysql_query($this->sql,$this->connection);
			$this->result = $this->connection->query($this->sql);
			//$this->logQuery();
			return $this->result;
		}
		function select($sql){ 
			// returns result set
			$this->sql = $sql;
			$this->result = $this->connection->query($this->sql);
			$this->error = $this->connection->error;
			$this->errorNo = $this->connection->errno;
			//$this->logQuery();
			if(!$this->result) {return false;}
			elseif($this->result->num_rows < 1) return false;
			return $this->result;
		} 
		function insert($sql){
			$this->sql = $sql;
			$this->result = $this->connection->query($this->sql);
			$this->error = $this->connection->error;
			$this->errorNo = $this->connection->errno;
			$this->insertId = $this->connection->insert_id;
			//$this->logQuery();
			if($this->result) return $this->insertId;
			return 0;
		}	
		function update($sql){
			$this->sql = $sql;
			$this->result = $this->connection->query($this->sql);
			$this->error = $this->connection->error;
			$this->errorNo = $this->connection->errno;
			//$this->logQuery();
			return $this->result;
		}
		function delete($sql){
			$this->sql = $sql;
			$this->result = $this->connection->query($this->sql);
			$this->error = $this->connection->error;
			$this->errorNo = $this->connection->errno;
			//$this->logQuery();
			return $this->result;
		}
		 
		function getarray($res,$type = 'BOTH'){
			if($res == '') $res = $this->result;
			return $res->fetch_array(constant('MYSQLI_'.$type));
			
		}
		function getassoc($res = ''){
			if($res == '') $res = $this->result;
			return $res->fetch_assoc();
		}
		function getobj($res = ''){
			if($res == '') $res = $this->result;
			return $res->fetch_object();
		}
		function nr($res = ''){
			if($res == '') $res = $this->result;
			return ($res)? $res->num_rows:0;
		}
		function seek($res,$offset){
			$res->data_seek($offset);
		}
		function numfields($res = ''){
			if($res == '') $res = $this->result;
			return $res->field_count;
		}
		function fieldtype($res,$i){
			return $res->fetch_field_direct($i);
		}
		function fieldname($res,$i){
			$field = $res->fetch_field_direct($i);
			return $field->name;
		}
		function free($res = ''){
			
			if($res == '') $res = $this->result;
			return $res->free_result();
		}
		
		// ShortCuts
		function getval($sql){
			// return one value
			$this->result = $this->select($sql);
			if(!$this->result) return false;
			else {	
				$row = $this->result->fetch_array();
				return  $row[0];
			}
		}
		function num_rows($sql){ 
			// returns result set
			$this->sql = $sql;
			$this->result = $this->connection->query($this->sql);
			//$this->logQuery();
			if(!$this->result) return false;	
			return $this->result->num_rows;
		} 
		function getrow($sql){
			// return one row
			$this->result = $this->select($sql);
			if(!$this->result) return false;
			
			return  $this->result->fetch_assoc();
		}
		function getobject($sql){
			// return one object
			$this->result = $this->select($sql,$this->connection);
			
			if(!$this->result) return false;
			return  $this->result->fetch_object();
		}
	}
?>