<?php
    // ***************************************
    // Function to return affiliate commission
    // ***************************************
    function getAffiliateCommission($amount, $affiliateid) {
        global $dbo;
        $comm = 0;
        
        if ($amount > 0) {
        
	        $objCommissionType = $dbo->getobject("SELECT * FROM tblaffiliatesettings");
	        // Get affiliate record
	        $objAffiliate = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID=$affiliateid");
	        if ($objAffiliate !== false) {
	            if ($objAffiliate->nCustomCommission != 0) {
	                $comm = ($objAffiliate->nCustomCommission * $amount)/100;
	            } else {
	                $comm = ($objCommissionType->nPercentage * $amount)/100;
	            }
			}
		
		}
		
        return $comm;
    }
    
    // *****************************************************************************
    // Add affiliate commission to database and email affiliate with New Sale email
    // *****************************************************************************
    
    function addAffiliatesPayments($affiliate_id,$objUser,$commission = 0,$description,$currency_symbol,$transaction_number) {
        global $dbo, $chkSsettings, $sSitename, $sSiteURL, $adminname, $adminemail;
	
		if ($commission > 0) {

	        $today = date("Ymd");
        
	        $sql = "
	            INSERT INTO tblaffiliatepayments (
	            nAffiliate_ID,
	            sUserForename, 
	            sUserSurname, 
	            sUserEmail, 
	            nMemberJoinDate, 
	            nCommission,
	            nDate, 
	            sItemName,
				sTransactionNumber
				) VALUES ( 
	            '$affiliate_id',
	            '$objUser->sForename',
	            '$objUser->sSurname',
	            '$objUser->sEmail',
	            '$objUser->nJoinDate',
	            '$commission',
	            '$today', 
	            '$description',
				'$transaction_number')
	        ";
			//	echo $sql;
	        $commissionId = $dbo->insert($sql);
        
	        // Get affiliate record
	        $objAffiliate = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID=$affiliate_id");
        
	        // Send email to affiliate
			//
	        if ($objAffiliate !== false) {
				if ($commission != 0) email_affiliate_sale($objUser,$objAffiliate,$commission,$description);
			}
			return $commissionId;
		}
    }

	// Mark affiliate payment as paid/cancelled
	function set_affiliate_payment_by_transaction ($transaction, $status) {
		global $dbo;
		
		$sql = "
			UPDATE tblaffiliatepayments SET
			sPaymentStatus = '" . $dbo->format($status) . "' 
			WHERE sTransactionNumber = '" . $dbo->format($transaction) . "'";
		$dbo->update($sql);
		if($dbo->error){$message = "<p class='error'>".$dbo->error."</p>";}
		
		if($status == 'refund'){
			// remove The Affiliate Commission Amount
			$dbo->update("Update tbltransactions SET nCommissionAmount = '0.00' WHERE sTransactionNumber = '" . $dbo->format($transaction) . "' AND nTransaction_Type = '1' LIMIT 1;");
			}
		else{$message = "<p class='success'>Payments updated successfully</p>";}
	}
	
	
	// External Affiliate Market Place Functions ...
	
	function set_marketplace($marketplace){

	// Current Market Places Accepted.
	// JZ - JvZoo
	// CB - Clickbank

	// If this is a link from a market place, all other payment processors must be disabled.
	// Also, Inhouse Affiliate System Must Be Disabled as well.
	
	if($marketplace == 'CB'){$marketprocessor = 'Clickbank';}
		elseif($marketplace == 'JZ'){
			$marketprocessor = 'JvZoo';
			}
		else{$skip = 1;}
	
		if(!$skip){
		$sql = "SELECT * FROM tblpaymentprocessors WHERE sProcessorName = '$marketprocessor' AND nActive = '1' ";
		$active = $dbo->num_rows($sql);
		}
		
		//
	
		if($active){
			// Ok they came from the marketplace, and that processor is active.
		
			// Check The Cookie, and set if not exists.
			if(!isset($_COOKIE['marketplace'])){
				if($marketplace == 'CB'){
			// Clickbank sets Affiliate Cookies For 60 days. We will do the same.
			setcookie('marketplace','CB',60*60*24*60);
			}
				elseif($marketplace == 'JZ'){
					// JvZoo sets Lifetime Affiliate Cookies. We will do the same, well 100 years.
					setcookie('marketplace','CB',60*60*24*365*100);
			}
		}
		
			// Cookie Set.
			// Set A Session Var
			$_SESSION['marketplace'] == '$marketplace';
		}}
		
	function get_marketplace_processor($mp){
		
		if($mp == 'CB'){return 'Clickbank';}
		elseif($mp == 'JZ'){return 'JvZoo';}
		else{return false;}
		
		}
	function get_marketplace(){
		return $_COOKIE['marketplace'];
		}

	
?>
