<?php

// Builder Functions
	function getCanSpam($id,$type = 'text'){
		global $chkSsettings,$language,$objTemplateSettings;
		if(!$language){
			require_once($chkSsettings->sRootPath."/languages/".strtolower($objTemplateSettings->sLanguageFile).".php");
		}
		$user_id = encrypt($id, SALT);
		
		$textLink = $chkSsettings->sSiteURL.'/index.php?page=unsubscribe&id='.$user_id;
		$htmlLink = "<a href='".$chkSsettings->sSiteURL."/index.php?page=unsubscribe&id=$user_id'>".$language['unsubscribe_link']."</a>";
		$textMessage = str_replace('[[UNSUB_LINK]]',$textLink,get_option('sEmailCanSpam'));
		$htmlMessage = str_replace('[[UNSUB_LINK]]',$htmlLink,get_option('sHtmlEmailCanSpam'));
		
		return ($type == 'text')?$textMessage:$htmlMessage;
	}
	function getPoweredByEmail($type = 'text'){
		global $chkSsettings,$language,$objTemplateSettings;
		//die($chkSsettings->sRootPath);
		if(!$language){
			require_once($chkSsettings->sRootPath."/languages/".strtolower($objTemplateSettings->sLanguageFile).".php");
		}
		$affurl = (!empty($chkSsettings->sEMPAffiliateLink)) ? $chkSsettings->sEMPAffiliateLink : 'http://www.easymemberpro.com ';
		$tlink = '';$hlink = '';
		if(get_option('email_powered_by') == '1'){
			$tlink = "\n".$language['powered_by']."\n".$affurl;
			$hlink = "<br /><br />".$language['powered_by']." <strong><a href='".$affurl."'>Easy Member Pro ".$language['membership_software']."</a>"; 
		}
		
		return $link = ($type == 'text')?$tlink:$hlink;}
		
	function logSystemEmail($objUser,$objEmail){
		global $dbo;
		$sql = "
		INSERT INTO `tblemails` (
		`nEmail_ID` ,
		`nUser_ID` ,
		`sUserEmail` ,
		`sSubject` ,
		`sBody` ,
		`sBodyHtml` ,
		`dTimeCreated` ,
		`dSentTime` ,
		`nStatus`
		)
		VALUES (
		NULL ,
		'".$objUser->id."', 
		'".$objUser->email."', 
		'".$objEmail->subject."', 
		'".$objEmail->body."', 
		'".$objEmail->bodyHtml."', 
		'".date('Y-m-d H:i:s')."', 
		'".date('Y-m-d H:i:s')."', 
		'1')";
		$dbo->insert($sql);	
		
	}

	// Member emails
	// This email is used to send confirmation codes for free signups.
	function email_member_confirm($objUser,$confCode){
		global $chkSsettings,$dbo,$nPaymentPlan_ID;
		
		$sSitename = $chkSsettings->sSiteName;
		$sSiteURL = $chkSsettings->sSiteURL;
		$adminname = $chkSsettings->sSiteOwner;
		$adminemail = $chkSsettings->sAdminEmail;
		
		
		$confLink = $chkSsettings->sSiteURL  . '/verify_account.php?conf=' . $confCode ;
		
		
		$sql = "SELECT * FROM tblemailtemplates	WHERE sType = 'FREE_SIGNUP_VERIFY'";
		$objEmail = $dbo->getobject($sql);
	
		$objEmail->sSubject= str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sSubject);
		
		$objEmail->sBody = str_replace("[[FIRSTNAME]]", $objUser->sForename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[LASTNAME]]", $objUser->sSurname, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[EMAIL]]", $objUser->sEmail, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[LINK]]", $confLink, $objEmail->sBody);
		
		
		// NEW HTML FIELD FOR MULTI_PART EMAILS - MDP - 3-17-12
		$objEmail->sBodyHtml = str_replace("[[FIRSTNAME]]", $objUser->sForename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[LASTNAME]]", $objUser->sSurname, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[EMAIL]]", $objUser->sEmail, $objEmail->sBodyHtml);
		//$objEmail->sBodyHtml = str_replace("[[PASSWORD]]", $objUser->sPassword, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[LEVEL]]", $objPaymentPlan->sLevel, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[LINK]]", $confLink, $objEmail->sBodyHtml);
		
		if(get_option('mail_method') == 'php'){
			$success = multipart_email($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
		else{
			$success = smtpEmail($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
	}
	
	// This email is the users Welcome Email, containing login details.
	function email_member_signup($objUser, $objPaymentPlan) {
		global $dbo, $adminemail, $adminname, $sSitename, $sSiteURL;
		
		$sql = "SELECT * FROM tblemailtemplates	WHERE sType = 'MEMBER_LOGIN_DETAIL'";
		$objEmail = $dbo->getobject($sql);
		
		$objEmail->sBody = str_replace("[[SITENAME]]", $sSitename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEURL]]", $sSiteURL, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEOWNER]]", $adminname, $objEmail->sBody);
		
		$objEmail->sBody = str_replace("[[FIRSTNAME]]", $objUser->sForename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[LASTNAME]]", $objUser->sSurname, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[EMAIL]]", $objUser->sEmail, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[PASSWORD]]", $objUser->sPassword, $objEmail->sBody);
		
		$objEmail->sBody = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $objPaymentPlan->sLevel, $objEmail->sBody);
		// NEW HTML FIELD FOR MULTI_PART EMAILS - MDP - 3-17-12
		$objEmail->sBodyHtml = str_replace("[[SITENAME]]", $sSitename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEURL]]", $sSiteURL, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEOWNER]]", $adminname, $objEmail->sBodyHtml);
		
		$objEmail->sBodyHtml = str_replace("[[FIRSTNAME]]", $objUser->sForename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[LASTNAME]]", $objUser->sSurname, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[EMAIL]]", $objUser->sEmail, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[PASSWORD]]", $objUser->sPassword, $objEmail->sBodyHtml);
		
		$objEmail->sBodyHtml = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $objPaymentPlan->sLevel, $objEmail->sBodyHtml);
		
		// Subject Tags
		$objEmail->sSubject = str_replace("[[SITENAME]]", $sSitename, $objEmail->sSubject);
	
		// Old Email Setup Cancelled - MDP
		//email($objUser->sEmail, $sSitename, $adminemail, $objEmail->sSubject, nl2br(stripslashes($objEmail->sBody)));
		
		// Switch to Multipart
		if(get_option('mail_method') == 'php'){
			$success = multipart_email($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
		else{
			$success = smtpEmail($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
	}
	// member Forgotten Password Email
	function email_forgot_password($objUser){
		global $chkSsettings,$dbo;
		$sql = "SELECT * FROM tblemailtemplates WHERE sType = 'MEMBER_PASSWORD_REMINDER'";
        $Result1 = $dbo->select($sql);
        $emailMsg = $dbo->getobj($Result1);
        //CHANGE PARA METERS
        $emailMsg->sBody = str_replace("[[FIRSTNAME]]", $objUser->sForename, $emailMsg->sBody);
		$emailMsg->sBody = str_replace("[[LASTNAME]]", $objUser->sSurname, $emailMsg->sBody);
        $emailMsg->sBody = str_replace("[[EMAIL]]", $objUser->sEmail, $emailMsg->sBody);
        $emailMsg->sBody = str_replace("[[PASSWORD]]", $objUser->sPassword, $emailMsg->sBody);
        $emailMsg->sBody = str_replace("[[SITENAME]]", $chkSsettings->sSitename, $emailMsg->sBody);
        $emailMsg->sBody = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $emailMsg->sBody);
        $emailMsg->sBody = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $emailMsg->sBody);
		
		//
		$emailMsg->sBodyHtml = str_replace("[[FIRSTNAME]]", $objUser->sForename, $emailMsg->sBodyHtml);
		$emailMsg->sBodyHtml = str_replace("[[LASTNAME]]", $objUser->sSurname, $emailMsg->sBodyHtml);
        $emailMsg->sBodyHtml = str_replace("[[EMAIL]]", $objUser->sEmail, $emailMsg->sBodyHtml);
        $emailMsg->sBodyHtml = str_replace("[[PASSWORD]]", $objUser->sPassword, $emailMsg->sBodyHtml);
        $emailMsg->sBodyHtml = str_replace("[[SITENAME]]", $chkSsettings->sSitename, $emailMsg->sBodyHtml);
        $emailMsg->sBodyHtml = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $emailMsg->sBodyHtml);
        $emailMsg->sBodyHtml = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $emailMsg->sBodyHtml);
		
		if(get_option('mail_method') == 'php'){
			$success = multipart_email($objUser->sEmail, $chkSsettings->sSiteOwner, $emailMsg->sSubject,$emailMsg->sBodyHtml,stripslashes($emailMsg->sBody));
		}
		else{
			$success = smtpEmail($objUser->sEmail, $chkSsettings->sSiteOwner, $emailMsg->sSubject,$emailMsg->sBodyHtml,stripslashes($emailMsg->sBody));
		}
		
	}
	
	// This email is sent, when a recurring payment cancellation is received from IPN.
	function email_member_subscription_cancelled($objUser,$processor,$subscriptionId) {
		global $dbo, $adminemail, $adminname, $sSitename, $sSiteURL;
		
		$sql = "SELECT tbluserlevels.*, tblmembershiplevels.sLevel FROM tbluserlevels INNER JOIN tblmembershiplevels ON tblmembershiplevels.nLevel_ID = tbluserlevels.nLevel_ID WHERE sTransactionNumber = '$subscriptionId';";
		$objUserLevel = $dbo->getobject($sql);
		
		$sql = "SELECT * FROM tblemailtemplates WHERE sType = 'MEMBER_SUBSCRIPTION_CANCELLED'";
		$objEmail = $dbo->getobject($sql);
		
		$objEmail->sBody = str_replace("[[SITENAME]]", $sSitename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEURL]]", $sSiteURL, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEOWNER]]", $adminname, $objEmail->sBody);
		
		$objEmail->sBody = str_replace("[[FIRSTNAME]]", $objUser->sForename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[LASTNAME]]", $objUser->sSurname, $objEmail->sBody);
		
		//$objEmail->sBody = str_replace("[[USER_ID]]", $objUser->nUser_ID, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[PAYMENT_PROCESSOR]]", $processor, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $objUserLevel->sLevel, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[MEMBERSHIP_LEVEL_EXPIRES]]", fShowDate($chkSsettings->nDateFormat,$objUserLevel->nDateExpires), $objEmail->sBody);
		
		$objEmail->sBodyHtml = str_replace("[[SITENAME]]", $sSitename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEURL]]", $sSiteURL, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEOWNER]]", $adminname, $objEmail->sBodyHtml);
		
		$objEmail->sBodyHtml = str_replace("[[FIRSTNAME]]", $objUser->sForename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[LASTNAME]]", $objUser->sSurname, $objEmail->sBodyHtml);
		
		//$objEmail->sBodyHtml = str_replace("[[USER_ID]]", $objUser->nUser_ID, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[PAYMENT_PROCESSOR]]", $processor, $objEmail->sBody);
		$objEmail->sBodyHtml = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $objUserLevel->sLevel, $objEmail->sBody);
		$objEmail->sBodyHtml = str_replace("[[MEMBERSHIP_LEVEL_EXPIRES]]", fShowDate($chkSsettings->nDateFormat,$objUserLevel->nDateExpires), $objEmail->sBody);
	
		//email($objUser->sEmail, $sSitename, $adminemail, $objEmail->sSubject, nl2br(stripslashes($objEmail->sBody)));
		//$success = multipart_email($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,nl2br(stripslashes($objEmail->sBody)));
		// Switch to Multipart
		if(get_option('mail_method') == 'php'){
			$success = multipart_email($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
		else{
			$success = smtpEmail($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
	}
	
	// This email goes out to customers, when there membership level has expired
	function email_member_expiry($userid, $levelid) {

		global $dbo, $adminemail, $adminname, $sSitename, $sSiteURL;
		
		$sql = "SELECT sForename, sSurname, sEmail FROM tblusers WHERE nUser_ID=" . $dbo->format($userid);
		$objUser = $dbo->getobject($sql);
		$sForename = $objUser->sForename;
		$sSurname = $objUser->sSurname;
		$sMemberEmail = $objUser->sEmail;
		
		$sql = "SELECT sLevel FROM tblmembershiplevels WHERE nLevel_ID=" . $dbo->format($levelid);
		$objLevel = $dbo->getobject($sql);
		$sLevel = $objLevel->sLevel;
		
		$sql = "SELECT * FROM tblemailtemplates	WHERE sType = 'MEMBER_MEMBERSHIP_EXPIRED'";
		$objEmail = $dbo->getobject($sql);
		
		$objEmail->sBody = str_replace("[[SITENAME]]", $sSitename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEURL]]", $sSiteURL, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEOWNER]]", $adminname, $objEmail->sBody);
		
		$objEmail->sBody = str_replace("[[NAME]]", $sForename . ' ' . $sSurname, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[FIRSTNAME]]", $sForename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[LASTNAME]]",$sSurname, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $sLevel, $objEmail->sBody);
		
		$objEmail->sBodyHtml = str_replace("[[SITENAME]]", $sSitename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEURL]]", $sSiteURL, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEOWNER]]", $adminname, $objEmail->sBodyHtml);
		
		$objEmail->sBodyHtml = str_replace("[[NAME]]", $sForename . ' ' . $sSurname, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[FIRSTNAME]]", $sForename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[LASTNAME]]",$sSurname, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $sLevel, $objEmail->sBodyHtml);
		
		
		$objEmail->sSubject = str_replace("[[SITENAME]]", $sSitename, $objEmail->sSubject);
		
		//email($sMemberEmail, $sSitename, $adminemail, $objEmail->sSubject, nl2br(stripslashes($objEmail->sBody)));
		//$success = multipart_email($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,nl2br(stripslashes($objEmail->sBody)));
		
		// Switch to Multipart
		if(get_option('mail_method') == 'php'){
			$success = multipart_email($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
		else{
			$success = smtpEmail($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
		
	}
	// This email goes out to warn members 7 days before expiry.
	function email_member_expiry_notice($userid, $levelid,$expireDate) {
		global $dbo, $adminemail, $adminname, $sSitename, $sSiteURL;
		
		$sql = "SELECT sForename, sSurname, sEmail FROM tblusers WHERE nUser_ID=" . $dbo->format($userid);
		$objUser = $dbo->getobject($sql);
		$sForename = $objUser->sForename;
		$sSurname = $objUser->sSurname;
		$sMemberEmail = $objUser->sEmail;
		
		$sql = "SELECT sLevel FROM tblmembershiplevels WHERE nLevel_ID=" . $dbo->format($levelid);
		$objLevel = $dbo->getobject($sql);
		$sLevel = $objLevel->sLevel;
		
		$sql = "SELECT * FROM tblemailtemplates	WHERE sType = 'MEMBER_EXPIRY_REMINDER'";
		$objEmail = $dbo->getobject($sql);
		$objEmail->sBody = str_replace("[[NAME]]", $objUser->sForename . ' ' . $objUser->sSurname, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[FIRSTNAME]]", $objUser->sForename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[LASTNAME]]", $objUser->sSurname, $objEmail->sBody);
		
		$objEmail->sBody = str_replace("[[SITENAME]]", $sSitename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEURL]]", $sSiteURL, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEOWNER]]", $adminname, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $sLevel, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[MEMBERSHIP_LEVEL_EXPIRE_DATE]]", $expireDate, $objEmail->sBody);
		
		$objEmail->sBodyHtml = str_replace("[[NAME]]", $sForename . ' ' . $sSurname, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITENAME]]", $sSitename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEURL]]", $sSiteURL, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEOWNER]]", $adminname, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $sLevel, $objEmail->sBodyHtml);
		
		
		$objEmail->sSubject = str_replace("[[SITENAME]]", $sSitename, $objEmail->sSubject);
		
		array(
		"[[FIRSTNAME]]" => "Member First Name",
		"[[LASTNAME]]" =>"Member Last Name",
		"[[NAME]]" => "Member First And Last Name",
		"[[SITENAME]]" => "Your Membership Site Name","[[SITEURL]]" => "Your Membership Site Url","[[SITEOWNER]]" => "Your Membership Site Owner Name","[[MEMBERSHIP_LEVEL_NAME]]" => "The Membership Level That Is About To Expire","[[MEMBERSHIP_LEVEL_EXPIRE_DATE]]" => "The Date The Members Access Will Expire");
		
		//email($sMemberEmail, $sSitename, $adminemail, $objEmail->sSubject, nl2br(stripslashes($objEmail->sBody)));
		//$success = multipart_email($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,nl2br(stripslashes($objEmail->sBody)));
		// Switch to Multipart
		if(get_option('mail_method') == 'php'){
			$success = multipart_email($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
		else{
			$success = smtpEmail($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
	}
	
	// This email sends a cancellation email to the user, upon cancellation, using the cancellation system.
	function email_member_cancellation($nUserLevel_ID){
		global $chkSsettings,$dbo;
		
		// Get various data for use in email tags
		$sql2 = "SELECT tbluserlevels.*, tblusers.*, tblmembershiplevels.sLevel FROM tbluserlevels
		LEFT JOIN tblusers on tblusers.nUser_ID = tbluserlevels.nUser_ID
		LEFT JOIN tblmembershiplevels on tblmembershiplevels.nLevel_ID = tbluserlevels.nLevel_ID
		WHERE nUserLevel_ID = '".$nUserLevel_ID."' ";
		
		$data = $dbo->getobject($sql2);
		$user = $data->sForename . ' ' . $data->sSurname;
			
		// Member Email 
		$sql = "SELECT * FROM tblemailtemplates WHERE sType = 'MEMBER_CANCEL_NOTICE' LIMIT 1;";
		$objEmail = $dbo->getobject($sql);
			
		// Parse Email Tags
		// Site Information
		$objEmail->sBody = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $objEmail->sBody);
		// Member Information
		$objEmail->sBody = str_replace("[[NAME]]", $user, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[FIRSTNAME]]", $data->sForename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[LASTNAME]]", $data->sSurname, $objEmail->sBody);
		// Membership Level Data
		$objEmail->sBody = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $data->sLevel, $objEmail->sBody);
		
		
		$objEmail->sBodyHtml = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $objEmail->sBodyHtml);
		
		$objEmail->sBodyHtml = str_replace("[[NAME]]", $user, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[FIRSTNAME]]", $data->sForename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[LASTNAME]]", $data->sSurname, $objEmail->sBodyHtml);
		
		$objEmail->sBodyHtml = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $data->sLevel, $objEmail->sBodyHtml);
		
		$objEmail->sSubject = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sSubject);
		
		if(get_option('mail_method') == 'php'){
			$success = multipart_email($data->sEmail, $chkSsettings->sAdminEmail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
		else{
			$success = smtpEmail($data->sEmail, $chkSsettings->sAdminEmail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
		
	}
	
	// Currently Not In Use
	function email_member_subscription_renewal($objUser) {
		global $dbo, $adminemail, $adminname, $sSitename, $sSiteURL;
		
		$sql = "SELECT * FROM tblemailtemplates WHERE sType = 'MEMBER_SUBSCRIPTION_RENEWAL'";
		$objEmail = $dbo->getobject($sql);
		$objEmail->sBody = str_replace("[[FIRSTNAME]]", $objUser->sForename, $objEmail->sBody );
		$objEmail->sBody = str_replace("[[LASTNAME]]", $objUser->sSurname, $objEmail->sBody );
		$objEmail->sBody = str_replace("[[EMAIL]]", $objUser->sEmail, $objEmail->sBody );
		$objEmail->sBody = str_replace("[[PASSWORD]]", $objUser->sPassword, $objEmail->sBody );
		$objEmail->sBody = str_replace("[[SITENAME]]", $sSitename, $objEmail->sBody );
		$objEmail->sBody = str_replace("[[SITEURL]]", $sSiteURL, $objEmail->sBody );
		$objEmail->sBody = str_replace("[[SITEOWNER]]", $adminname, $objEmail->sBody );
		
		// HTML 
		$objEmail->sBodyHtml = str_replace("[[FIRSTNAME]]", $objUser->sForename, $objEmail->sBodyHtml );
		$objEmail->sBodyHtml = str_replace("[[LASTNAME]]", $objUser->sSurname, $objEmail->sBodyHtml );
		$objEmail->sBodyHtml = str_replace("[[EMAIL]]", $objUser->sEmail, $objEmail->sBodyHtml );
		$objEmail->sBodyHtml = str_replace("[[PASSWORD]]", $objUser->sPassword, $objEmail->sBodyHtml );
		$objEmail->sBodyHtml = str_replace("[[SITENAME]]", $sSitename, $objEmail->sBodyHtml );
		$objEmail->sBodyHtml = str_replace("[[SITEURL]]", $sSiteURL, $objEmail->sBodyHtml );
		$objEmail->sBodyHtml = str_replace("[[SITEOWNER]]", $adminname, $objEmail->sBodyHtml );
		
		// Cancel Old Email
		//email($objUser->sEmail, $sSitename, $adminemail, $objEmail->sSubject, nl2br(stripslashes($objEmail->sBody ) ) );
		//Send Multipart
		//$success = multipart_email($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,nl2br(stripslashes($objEmail->sBody)));
		// Switch to Multipart
		if(get_option('mail_method') == 'php'){
			$success = multipart_email($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
		else{
			$success = smtpEmail($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
	}
	// Currently Not In Use
	function email_member_upgrade($objUser, $objPaymentPlan) {
		global $dbo, $adminemail, $adminname, $sSitename, $sSiteURL;
	
		$sql = "SELECT * FROM tblemailtemplates	WHERE sType = 'MEMBER_UPGRADE'";
		$objEmail = $dbo->getobject($sql);
		$objEmail->sBody = str_replace("[[FIRSTNAME]]", $objUser->sForename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[LASTNAME]]", $objUser->sSurname, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITENAME]]", $sSitename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEURL]]", $sSiteURL, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEOWNER]]", $adminname, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[LEVEL]]", $objPaymentPlan->sLevel, $objEmail->sBody);
		
		$objEmail->sBodyHtml = str_replace("[[FIRSTNAME]]", $objUser->sForename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[LASTNAME]]", $objUser->sSurname, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITENAME]]", $sSitename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEURL]]", $sSiteURL, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEOWNER]]", $adminname, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[LEVEL]]", $objPaymentPlan->sLevel, $objEmail->sBodyHtml);
		
		
		
		
		//email($objUser->sEmail, $sSitename, $adminemail, $objEmail->sSubject, nl2br(stripslashes($objEmail->sBody)));
		//$success = multipart_email($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,nl2br(stripslashes($objEmail->sBody)));
		// Switch to Multipart
		if(get_option('mail_method') == 'php'){
			$success = multipart_email($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
		else{
			$success = smtpEmail($objUser->sEmail, $adminemail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
	}
	
// Affilaite Emails
	function email_affiliate_signup($nUser_ID,$confLink,$objAffiliateSettings){
		global $dbo, $chkSsettings;
		
		$objAffiliate = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID = '".$nUser_ID."';");
		
		$sql = "SELECT * FROM  tblemailtemplates WHERE sType = 'AFFILIATE_WELCOME'";
		$emailMsg = $dbo->getrow($sql);
			
		$emailMsg['sSubject'] = str_replace("[[SITENAME]]", $chkSsettings->sSitename, $emailMsg['sSubject']);
			
			
			$emailMsg['sBody'] = str_replace("[[SITENAME]]", $chkSsettings->sSitename, $emailMsg['sBody']);
			$emailMsg['sBody'] = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $emailMsg['sBody']);
			$emailMsg['sBody'] = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $emailMsg['sBody']);
			
			$emailMsg['sBody'] = str_replace("[[AFFILIATE_FIRSTNAME]]", $objAffiliate->sForename, $emailMsg['sBody']);
			$emailMsg['sBody'] = str_replace("[[AFFILIATE_LASTNAME]]", $objAffiliate->sSurname, $emailMsg['sBody']);
			$emailMsg['sBody'] = str_replace("[[AFFILIATE_EMAIL]]", $objAffiliate->sEmail, $emailMsg['sBody'] );
			$emailMsg['sBody'] = str_replace("[[AFFILIATE_PASSWORD]]", $objAffiliate->sPassword, $emailMsg['sBody'] );         
			
			$emailMsg['sBody'] = str_replace("[[LINK]]", $confLink, $emailMsg['sBody']);
			$emailMsg['sBody'] = str_replace("[[COMMISSION_PERCENT]]", $objAffiliateSettings->nPercentage."%" , $emailMsg['sBody']);
			
			$emailMsg['sBodyHtml'] = str_replace("[[SITENAME]]", $chkSsettings->sSitename, $emailMsg['sBodyHtml']);
			$emailMsg['sBodyHtml'] = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $emailMsg['sBodyHtml']);
			$emailMsg['sBodyHtml'] = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $emailMsg['sBodyHtml']);
			
			$emailMsg['sBodyHtml'] = str_replace("[[AFFILIATE_FIRSTNAME]]", $objAffiliate->sForename, $emailMsg['sBodyHtml']);
			$emailMsg['sBodyHtml'] = str_replace("[[AFFILIATE_LASTNAME]]", $objAffiliate->sSurname, $emailMsg['sBodyHtml']);
			$emailMsg['sBodyHtml'] = str_replace("[[AFFILIATE_EMAIL]]", $objAffiliate->sEmail, $emailMsg['sBodyHtml'] );
			$emailMsg['sBodyHtml'] = str_replace("[[AFFILIATE_PASSWORD]]", $objAffiliate->sPassword, $emailMsg['sBodyHtml'] );         
			
			$emailMsg['sBodyHtml'] = str_replace("[[LINK]]", $confLink, $emailMsg['sBodyHtml']);
			$emailMsg['sBodyHtml'] = str_replace("[[COMMISSION_PERCENT]]", $objAffiliateSettings->nPercentage."%" , $emailMsg['sBodyHtml']);
		
			if(get_option('mail_method') == 'php'){
				$success = multipart_email($objAffiliate->sEmail, $chkSsettings->sAdminEmail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
			}
			else{
				$success = smtpEmail($objAffiliate->sEmail, $chkSsettings->sAdminEmail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
			}
		}
		
	// Email Referring Affiliate On New Signup of referred member
	function email_referral_signup($objUser, $levelName){
		global $dbo, $chkSsettings;
		
		if($objUser->nAffiliate_ID){
			// This was a referred signup. lets email the affiliate.
			$objAffiliate = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID = '".$objUser->nAffiliate_ID."';");
			
			$sql = "SELECT * FROM tblemailtemplates WHERE sType = 'AFFILIATE_NEW_SIGNUP'";
			$emailMsg = $dbo->getrow($sql);
			
			
			$emailMsg['sBody'] = str_replace("[[SITENAME]]", $sSitename, $emailMsg['sBody']);
			$emailMsg['sBody'] = str_replace("[[SITEURL]]", $sSiteURL, $emailMsg['sBody']);
			$emailMsg['sBody'] = str_replace("[[SITEOWNER]]", $adminname, $emailMsg['sBody']);
			
			$emailMsg['sBody'] = str_replace("[[MEMBER_FIRSTNAME]]", $objUser->sForename, $emailMsg['sBody']);
			$emailMsg['sBody'] = str_replace("[[MEMBER_LASTNAME]]", $objUser->sSurname, $emailMsg['sBody']);
			
			$emailMsg['sBody'] = str_replace("[[AFFILIATE_FIRSTNAME]]", $affiliate->sForename, $emailMsg['sBody']);
			$emailMsg['sBody'] = str_replace("[[AFFILIATE_LASTNAME]]", $affiliate->sSurname, $emailMsg['sBody']);
			
			$emailMsg['sBody'] = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $levelName, $emailMsg['sBody']);
			
			$emailMsg['sBodyHtml'] = str_replace("[[SITENAME]]", $sSitename, $emailMsg['sBodyHtml']);
			$emailMsg['sBodyHtml'] = str_replace("[[SITEURL]]", $sSiteURL, $emailMsg['sBodyHtml']);
			$emailMsg['sBodyHtml'] = str_replace("[[SITEOWNER]]", $adminname, $emailMsg['sBodyHtml']);
			
			$emailMsg['sBodyHtml'] = str_replace("[[MEMBER_FIRSTNAME]]", $objUser->sForename, $emailMsg['sBodyHtml']);
			$emailMsg['sBodyHtml'] = str_replace("[[MEMBER_LASTNAME]]", $objUser->sSurname, $emailMsg['sBodyHtml']);
			
			$emailMsg['sBodyHtml'] = str_replace("[[AFFILIATE_FIRSTNAME]]", $affiliate->sForename, $emailMsg['sBodyHtml']);
			$emailMsg['sBodyHtml'] = str_replace("[[AFFILIATE_LASTNAME]]", $affiliate->sSurname, $emailMsg['sBodyHtml']);
			$emailMsg['sBodyHtml'] = str_replace("[[AFFILIATE_COMMISSION]]", $currency_symbol . number_format($commission, 2), $emailMsg['sBodyHtml']);
			$emailMsg['sBodyHtml'] = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $levelName, $emailMsg['sBodyHtml']);
			
			if(get_option('mail_method') == 'php'){
				$success = multipart_email($objAffiliate->sEmail, $chkSsettings->sAdminEmail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
			}
			else{
				$success = smtpEmail($objAffiliate->sEmail, $chkSsettings->sAdminEmail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
			}
		}
	}
	
	function email_affiliate_sale($objUser,$affiliate,$commission,$levelName){
		global $dbo, $adminemail, $adminname, $sSitename, $sSiteURL;
		//$objAffiliate is the affiliate getting a commission from the $objUser sale
		$sql = "SELECT * FROM  tblemailtemplates WHERE sType = 'AFFILIATE_NEW_SALE'";
		$emailMsg = $dbo->getrow($sql);
		
		$emailMsg['sBody'] = str_replace("[[SITENAME]]", $sSitename, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[SITEURL]]", $sSiteURL, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[SITEOWNER]]", $adminname, $emailMsg['sBody']);
		
		$emailMsg['sBody'] = str_replace("[[MEMBER_FIRSTNAME]]", $objUser->sForename, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[MEMBER_LASTNAME]]", $objUser->sSurname, $emailMsg['sBody']);
		
		$emailMsg['sBody'] = str_replace("[[AFFILIATE_FIRSTNAME]]", $affiliate->sForename, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[AFFILIATE_LASTNAME]]", $affiliate->sSurname, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[AFFILIATE_COMMISSION]]", $currency_symbol . number_format($commission, 2), $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $levelName, $emailMsg['sBody']);
		
		$emailMsg['sBodyHtml'] = str_replace("[[SITENAME]]", $sSitename, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[SITEURL]]", $sSiteURL, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[SITEOWNER]]", $adminname, $emailMsg['sBodyHtml']);
		
		$emailMsg['sBodyHtml'] = str_replace("[[MEMBER_FIRSTNAME]]", $objUser->sForename, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[MEMBER_LASTNAME]]", $objUser->sSurname, $emailMsg['sBodyHtml']);
		
		$emailMsg['sBodyHtml'] = str_replace("[[AFFILIATE_FIRSTNAME]]", $affiliate->sForename, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[AFFILIATE_LASTNAME]]", $affiliate->sSurname, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[AFFILIATE_COMMISSION]]", $currency_symbol . number_format($commission, 2), $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $levelName, $emailMsg['sBodyHtml']);
		
		$success = (get_option('mail_method') == 'php')? 
		multipart_email($objAffiliate->sEmail, $adminemail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']))
		: smtpEmail($objAffiliate->sEmail, $adminemail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
	}

// Admin emails

	function email_admin_signup($objUser, $objPaymentPlan) {
		global $dbo, $adminemail, $adminname, $sSitename, $sSiteURL;
		
		// Additional user info for email
		$additional_info = 'Additional Information:' . "\n\n" . 'Email: ' . $objUser->sEmail . "\n";
		$additional_info .= 'Level Joined: ' . get_level_name_by_payment_plan($objPaymentPlan->nPaymentPlan_ID) . "\n";
		
		// Get custom fields of user if the user has any
		$fields = '';
		$objCustomFieldSettings = $dbo->select("SELECT * FROM tblcustomfieldsettings ORDER BY nSortOrder, sCustomFieldName");
		while ($row = $dbo->getobj($objCustomFieldSettings)) {
			if ($row->nDisplay) {
				$customfield = 'sCustomField' . $row->nCustomFieldSetting_ID;
				$fields .= $row->sCustomFieldName . ": " . $objUser->$customfield . "\n";
			}
		}
		
		if ($fields != '') {
			$additional_info .= "\n" . 'Custom Fields:' . "\n\n" . $fields;
		}
		
		$sql = "SELECT * FROM tblemailtemplates WHERE sType = 'ADMIN_NEW_SUBSCRIPTION'";
		$emailMsg = $dbo->getrow($sql);
		$emailMsg['sBody'] = str_replace("[[ADMINNAME]]", $adminname, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[FIRSTNAME]]", $objUser->sForename, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[LASTNAME]]", $objUser->sSurname, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[SITENAME]]", $sSitename, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[SITEURL]]", $sSiteURL, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[SITEOWNER]]", $adminname, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[LEVEL]]", $objPaymentPlan->sLevel, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[ADDITIONAL]]", $additional_info, $emailMsg['sBody']);
		
		$emailMsg['sBodyHtml'] = str_replace("[[ADMINNAME]]", $adminname, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[FIRSTNAME]]", $objUser->sForename, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[LASTNAME]]", $objUser->sSurname, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[SITENAME]]", $sSitename, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[SITEURL]]", $sSiteURL, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[SITEOWNER]]", $adminname, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[LEVEL]]", $objPaymentPlan->sLevel, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[ADDITIONAL]]", $additional_info, $emailMsg['sBodyHtml']);
		
		
		//email($adminemail, $sSitename, $adminemail, $emailMsg['sSubject'], nl2br(stripslashes($emailMsg['sBody'])));
		//$success = multipart_email($adminemail, $adminemail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],nl2br(stripslashes($emailMsg['sBody'])));
		if(get_option('mail_method') == 'php'){
				$success = multipart_email($adminemail, $adminemail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
			}
			else{
				$success = smtpEmail($adminemail, $adminemail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
			}
		}
	// Not In Use
	function email_admin_upgrade($objUser, $objPaymentPlan) {
		global $dbo, $adminemail, $adminname, $sSitename, $sSiteURL;
		
		$sql = "SELECT * FROM tblemailtemplates WHERE sType = 'ADMIN_UPGRADE'";
		$emailMsg = $dbo->getrow($sql);
		$emailMsg['sBody'] = str_replace("[[ADMINNAME]]", $adminname, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[FIRSTNAME]]", $objUser->sForename, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[LASTNAME]]", $objUser->sSurname, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[SITENAME]]", $sSitename, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[SITEURL]]", $sSiteURL, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[SITEOWNER]]", $adminname, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[LEVEL]]", $objPaymentPlan->sLevel, $emailMsg['sBody']);
		
		$emailMsg['sBodyHtml'] = str_replace("[[ADMINNAME]]", $adminname, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[FIRSTNAME]]", $objUser->sForename, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[LASTNAME]]", $objUser->sSurname, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[SITENAME]]", $sSitename, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[SITEURL]]", $sSiteURL, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[SITEOWNER]]", $adminname, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[LEVEL]]", $objPaymentPlan->sLevel, $emailMsg['sBodyHtml']);
		
		
		//email($adminemail, $sSitename, $adminemail, $emailMsg['sSubject'], nl2br(stripslashes($emailMsg['sBody'])));
		//$success = multipart_email($adminemail, $adminemail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],nl2br(stripslashes($emailMsg['sBody'])));
		if(get_option('mail_method') == 'php'){
				$success = multipart_email($adminemail, $adminemail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
			}
			else{
				$success = smtpEmail($adminemail, $adminemail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
			}
		}
		
	function email_security_processorchange($data,$admin){
		global $dbo, $adminemail, $adminname, $sSitename, $sSiteURL;
		
		$sql = "SELECT * FROM tblemailtemplates WHERE sType = 'SECURITY_PROCESSOR_CHANGE'";
		$emailMsg = $dbo->getrow($sql);
		
		$emailMsg['sBody'] = str_replace("[[SITENAME]]", $sSitename, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[SITEURL]]", $sSiteURL, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[SITEOWNER]]", $adminname, $emailMsg['sBody']);
		
		$emailMsg['sBody'] = str_replace("[[ADMIN_NAME]]", $admin->sForename.' '.$admin->sSurname, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[ADMIN_FIRSTNAME]]", $admin->sForename, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[ADMIN_LASTNAME]]", $admin->sSurname, $emailMsg['sBody']);
		
		$emailMsg['sBody'] = str_replace("[[ADMIN_IP]]", "<a href='http://www.ip-tracker.org/locator/ip-lookup.php?ip=".$admin->ip."'>$admin->ip</a>", $emailMsg['sBody']);
		
		$emailMsg['sBody'] = str_replace("[[PROCESSOR_NAME]]", $data['displayname'], $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[PROCESSOR_ID]]", $data['newid'], $emailMsg['sBody']);
		
		
		$emailMsg['sBodyHtml'] = str_replace("[[SITENAME]]", $sSitename, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[SITEURL]]", $sSiteURL, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[SITEOWNER]]", $adminname, $emailMsg['sBodyHtml']);
		
		$emailMsg['sBodyHtml'] = str_replace("[[ADMIN_NAME]]", $admin->sForename.' '.$admin->sSurname, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[ADMIN_FIRSTNAME]]", $admin->sForename, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[ADMIN_LASTNAME]]", $admin->sSurname, $emailMsg['sBodyHtml']);
		
		$emailMsg['sBodyHtml'] = str_replace("[[ADMIN_IP]]", "<a href='http://www.ip-tracker.org/locator/ip-lookup.php?ip=".$admin->ip."'>$admin->ip</a>", $emailMsg['sBodyHtml']);
		
		$emailMsg['sBodyHtml'] = str_replace("[[PROCESSOR_NAME]]", $data['displayname'], $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[PROCESSOR_ID]]", $data['newid'], $emailMsg['sBodyHtml']);
		
		if(get_option('mail_method') == 'php'){
				$success = multipart_email($adminemail, $adminemail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
			}
			else{
				$success = smtpEmail($adminemail, $adminemail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
			}
		}
		
	function email_admin_cancel_notice($nUserLevel_ID,$nCancellation_ID){
		global $dbo,$chkSsettings;
		
		// Get various data for use in email tags
		$sql2 = "SELECT tbluserlevels.*, tblusers.*, tblmembershiplevels.sLevel FROM tbluserlevels
		LEFT JOIN tblusers on tblusers.nUser_ID = tbluserlevels.nUser_ID
		LEFT JOIN tblmembershiplevels on tblmembershiplevels.nLevel_ID = tbluserlevels.nLevel_ID
		WHERE nUserLevel_ID = '".$nUserLevel_ID."' ";
		
		$data = $dbo->getobject($sql2);
		$user = $data->sForename . ' ' . $data->sSurname;
		
		// Get The Id and comments from the cancel request.
		$sql = "SELECT sComment FROM tblcancellations WHERE nCancellation_ID = '".$nCancellation_ID."';";
		$cancelComment = $dbo->getval($sql);
		
		
		$sql = "SELECT * FROM tblemailtemplates WHERE sType = 'ADMIN_CANCEL_NOTICE' LIMIT 1;";
		$objEmail = $dbo->getobject($sql);
			
		// Parse Email Tags
		// Site Information
		$objEmail->sBody = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $objEmail->sBody);
		// Member Information
		$objEmail->sBody = str_replace("[[NAME]]", $user, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[FIRSTNAME]]", $data->sForename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[LASTNAME]]", $data->sSurname, $objEmail->sBody);
		// Membership Level Data
		$objEmail->sBody = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $data->sLevel, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[COMMENT]]", $cancelComent, $objEmail->sBody);
		
		
		$objEmail->sBodyHtml = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[NAME]]", $user, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[FIRSTNAME]]", $data->sForename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[LASTNAME]]", $data->sSurname, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $data->sLevel, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[COMMENT]]", $cancelComent, $objEmail->sBodyHtml);
		
		
		$objEmail->sSubject = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sSubject);
		
		if(get_option('mail_method') == 'php'){
				$success = 
				multipart_email($chkSsettings->sAdminEmail, $chkSsettings->sSupportEmail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
		else{
			$success = smtpEmail($chkSsettings->sAdminEmail, $chkSsettings->sSupportEmail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
	}
	function email_admin_cancel_request($nUserLevel_ID,$nCancellation_ID){
		global $dbo,$chkSsettings;
		
		// Get various data for use in email tags
		$sql2 = "SELECT tbluserlevels.*, tblusers.*, tblmembershiplevels.sLevel FROM tbluserlevels
		LEFT JOIN tblusers on tblusers.nUser_ID = tbluserlevels.nUser_ID
		LEFT JOIN tblmembershiplevels on tblmembershiplevels.nLevel_ID = tbluserlevels.nLevel_ID
		WHERE nUserLevel_ID = '".$nUserLevel_ID."' ";
		
		$data = $dbo->getobject($sql2);
		$user = $data->sForename . ' ' . $data->sSurname;
		
		// Get The Id and comments from the cancel request.
		$sql = "SELECT sComment FROM tblcancellations WHERE nCancellation_ID = '".$nCancellation_ID."';";
		$cancelComment = $dbo->getval($sql);
		
		
		$sql = "SELECT * FROM tblemailtemplates WHERE sType = 'ADMIN_NEW_CANCELLATION' LIMIT 1;";
		$objEmail = $dbo->getobject($sql);
			
		// Parse Email Tags
		// Site Information
		$objEmail->sBody = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $objEmail->sBody);
		// Member Information
		$objEmail->sBody = str_replace("[[NAME]]", $user, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[FIRSTNAME]]", $data->sForename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[LASTNAME]]", $data->sSurname, $objEmail->sBody);
		// Membership Level Data
		$objEmail->sBody = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $data->sLevel, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[COMMENT]]", $cancelComment, $objEmail->sBody);
		
		$objEmail->sBodyHtml = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $objEmail->sBodyHtml);
		
		$objEmail->sBodyHtml = str_replace("[[NAME]]", $user, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[FIRSTNAME]]", $data->sForename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[LASTNAME]]", $data->sSurname, $objEmail->sBodyHtml);
		
		$objEmail->sBodyHtml = str_replace("[[MEMBERSHIP_LEVEL_NAME]]", $data->sLevel, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[COMMENT]]", $cancelComment, $objEmail->sBodyHtml);
		
		
		$objEmail->sSubject = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sSubject);
		
		if(get_option('mail_method') == 'php'){
				$success = 
				multipart_email($chkSsettings->sAdminEmail, $chkSsettings->sSupportEmail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
		else{
			$success = smtpEmail($chkSsettings->sAdminEmail, $chkSsettings->sSupportEmail, $objEmail->sSubject,$objEmail->sBodyHtml,stripslashes($objEmail->sBody));
		}
	}
	// Guest Contact Us Form
	function email_admin_contact($name,$email,$message){
		global $dbo,$chkSsettings;
		$sql = "SELECT * FROM tblemailtemplates WHERE sType = 'ADMIN_CONTACT'";
        $Result1 = $dbo->select($sql);
        $emailMsg = $dbo->getassoc($Result1);
		
		//CHANGE PARA METERS
        $emailMsg['sBody'] = str_replace("[[NAME]]", $name, $emailMsg['sBody']);
        $emailMsg['sBody'] = str_replace("[[EMAIL]]", $email, $emailMsg['sBody']);
        $emailMsg['sBody'] = str_replace("[[MESSAGE]]", $message, $emailMsg['sBody']);
        $emailMsg['sBody'] = str_replace("[[SITENAME]]", $chkSsettings->sSitename, $emailMsg['sBody']);
        $emailMsg['sBody'] = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $emailMsg['sBody']);
        $emailMsg['sBody'] = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $emailMsg['sBody']);
			
		$emailMsg['sBodyHtml'] = str_replace("[[NAME]]", $name, $emailMsg['sBodyHtml']);
        $emailMsg['sBodyHtml'] = str_replace("[[EMAIL]]", $email, $emailMsg['sBodyHtml']);
        $emailMsg['sBodyHtml'] = str_replace("[[MESSAGE]]", $message, $emailMsg['sBodyHtml']);
        $emailMsg['sBodyHtml'] = str_replace("[[SITENAME]]", $chkSsettings->sSitename, $emailMsg['sBodyHtml']);
        $emailMsg['sBodyHtml'] = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $emailMsg['sBodyHtml']);
        $emailMsg['sBodyHtml'] = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $emailMsg['sBodyHtml']);
		
		if(get_option('mail_method') == 'php'){
			$success = multipart_email($chkSsettings->sSupportEmail,$chkSsettings->sAdminEmail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
		}
		else{
		$success = smtpEmail($chkSsettings->sSupportEmail,$chkSsettings->sAdminEmail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
		}
		return $success;
	}
	
	// Members Area Contact Form
	function email_admin_member_contact($objUser,$message){
		global $dbo,$chkSsettings;
		
		$sql = "SELECT * FROM  tblemailtemplates WHERE sType = 'ADMIN_SUPPORT'";
		$rs = $dbo->select($sql);
		$emailMsg = $dbo->getassoc($rs);
			
		//CHANGE PARA METERS
        $emailMsg['sBody'] = str_replace("[[FIRSTNAME]]", $objUser->sForename, $emailMsg['sBody']);
		$emailMsg['sBody'] = str_replace("[[LASTNAME]]", $objUser->sSurname, $emailMsg['sBody']);
        $emailMsg['sBody'] = str_replace("[[EMAIL]]", $objUser->sEmail, $emailMsg['sBody']);
        $emailMsg['sBody'] = str_replace("[[MESSAGE]]", $message, $emailMsg['sBody']);
        $emailMsg['sBody'] = str_replace("[[SITENAME]]", $chkSsettings->sSitename, $emailMsg['sBody']);
        $emailMsg['sBody'] = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $emailMsg['sBody']);
        $emailMsg['sBody'] = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $emailMsg['sBody']);
			
		$emailMsg['sBodyHtml'] = str_replace("[[FIRSTNAME]]", $objUser->sForename, $emailMsg['sBodyHtml']);
		$emailMsg['sBodyHtml'] = str_replace("[[LASTNAME]]", $objUser->sSurname, $emailMsg['sBodyHtml']);
        $emailMsg['sBodyHtml'] = str_replace("[[EMAIL]]", $objUser->sEmail, $emailMsg['sBodyHtml']);
        $emailMsg['sBodyHtml'] = str_replace("[[MESSAGE]]", $message, $emailMsg['sBodyHtml']);
        $emailMsg['sBodyHtml'] = str_replace("[[SITENAME]]", $chkSsettings->sSitename, $emailMsg['sBodyHtml']);
        $emailMsg['sBodyHtml'] = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $emailMsg['sBodyHtml']);
        $emailMsg['sBodyHtml'] = str_replace("[[SITEOWNER]]", $chkSsettings->sSiteOwner, $emailMsg['sBodyHtml']);
		
		if(get_option('mail_method') == 'php'){
			$success = multipart_email($chkSsettings->sSupportEmail,$chkSsettings->sAdminEmail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
		}
		else{
			$success = smtpEmail($chkSsettings->sSupportEmail,$chkSsettings->sAdminEmail, $emailMsg['sSubject'],$emailMsg['sBodyHtml'],stripslashes($emailMsg['sBody']));
		}
		return $success;
	}
	
?>