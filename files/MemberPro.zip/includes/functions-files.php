<?php

	// ========================
	
	// FRONT END FUNCTIONS
	
	// ========================
	
	
	
	function displayFileEmbedCode($matches, $location = "") {
	
		
	
		global $sSiteURL;
	
		
	
		$files = array();
	
	
	
		foreach ($matches as $match) {
	
			// Get File ID
	
			preg_match('/\d+/', $match, $found);
	
			$file_id = $found[0];
	
			// Text for link
	
			$string = preg_match('/TEXT=(\"|&quot;).+(\"|&quot;)/', $match, $text);
	
			if (preg_match("/&quot;/", $match) == 1) {
	
				$text1 = ($string == 1) ? str_replace("TEXT=&quot;", "", substr($text[0], 0, -6)) : "Click Here To Download";
	
			} else {
	
				$text1 = ($string == 1) ? str_replace("TEXT=\"", "", substr($text[0], 0, -1)) : "Click Here To Download";
	
			}
	
			
	
			$output = 		'<a href="' . $sSiteURL . '/' . $location . 'fileprotect.php?id=' . $file_id . '">' . $text1 . '</a>';
	
			
	
			$files[] = $output;
	
		}
	
		
	
		return $files;
	}
	
	// Deliver File ... With Resume Support.
	function deliver_file ($objFile, $file, $contenttype = 'application/octet-stream',$stream = 0) {
		global $dbo;
		
		//error_log("Starting File Delivery System ...");
		
		//- turn off compression on the server
		if(function_exists('apache_setenv')){apache_setenv('no-gzip', 1);}
		@ini_set('zlib.output_compression', 'Off');
		
		
		// Avoid sending errors to the client
		// we don't want to corrupt the file
		//@error_reporting(0);
		
		// Pull File Information
		$remote = ($objFile->sURL == "") ? 0 : 1;
		$filesize = $objFile->nSize;
		$realfilesize = filesize($file);
		//error_log("Stored File Size = $filesize AND Actual Local File Size = $realfilesize");
		
		
		//error_log("Checking for a range");
	
		//check if http_range is sent by download manager / browser
		if (isset($_SERVER['HTTP_RANGE'])){ 
			// IIS/Some Apache versions
			//error_log('found $_SERVER http rage ...');
			$range = $_SERVER['HTTP_RANGE'];
		}
		
		// Lets see if we can pull them from Apache.
		else if ((function_exists(apache_request_headers)) && $apache = apache_request_headers()) { 
		// Try Apache again
		  $headers = array();
		  foreach ($apache as $header => $val) {
			  
			  $headers[strtolower($header)] = $val;
		  }
		  if (isset($headers['range'])) $range = $headers['range'];
		  else $range = FALSE; // We can't get the header/there isn't one set
		}
		
		 // We can't get the header/there isn't one set
		else {$range = FALSE;}
		
		
		// Get the data range requested (if any)
		if ($range) {
		  //error_log('using received range ... '.$range);
		  $partial = true;
		  list($param,$range) = explode('=',$range);
		  if (strtolower(trim($param)) != 'bytes') { 
			// Bad request - range unit is not 'bytes'
			//error_log('range unit is not bytes');
			header("HTTP/1.1 400 Invalid Request");
			exit;
		  }
		  $range = explode(',',$range);
		  $range = explode('-',$range[0]); // We only deal with the first requested range
		  if (count($range) != 2) {
			   // Bad request - 'bytes' parameter is not valid
			   header("HTTP/1.1 400 Invalid Request");
			   //error_log('bytes not valid');
			exit;
		  }
		  if ($range[0] === '') { 
			// First number missing, return last $range[1] bytes
			//error_log('// First number missing, return last $range[1] bytes');
			$end = $filesize - 1;
			$start = $end - intval($range[0]);
		  } else if ($range[1] === '') { 
		  // Second number missing, return from byte $range[0] to end
		  //error_log('// Second number missing, return from byte $range[0] to end');
			$start = intval($range[0]);
		   // $end = $filesize - 1;
		   $end = $filesize;
			//error_log("Start = $start, End = $end");
		  } else { 
		  // Both numbers present, return specific range
		  //error_log("Range Is Good - Return Specific Range");
			$start = intval($range[0]);
			$end = intval($range[1]);
			if ($end >= $filesize || (!$start && (!$end || $end == ($filesize - 1)))){ $partial = false;} // Invalid range/whole file specified, return whole file
		  } 
		  $length = $end - $start + 1;
		  //error_log("End - Start = Length = $length");
		  //error_log("Length var set to $length");
		}
		else {
			$partial = false;
			//error_log("No Proper Range Requested");
		}
		
		// Send standard headers
	   header("Pragma: public");
	   header("Expires: 0");
	   header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	   header("Cache-Control: private", false);
	   
		// This sets the file mime type
		header("Content-Type: $contenttype");
		header("Content-Length: $filesize");
		//header('Content-Disposition: attachment; filename="'.basename($file).'"');
		//header('Accept-Ranges: bytes');
		
			
		//Lets Check If This Is A Resumable File (local files only)
			
		if(!$remote){
				// This Makes The File Resume-able
				//error_log('Resume Support Enabled.');
				header('Accept-Ranges: bytes');
				}
		
		// set appropriate headers for attachment or streamed file
		if ($stream) {
			// Streaming Will Allow Pdf Downloads Striaght To The Browser.
			header('Content-Disposition: inline;');
			header('Content-Transfer-Encoding: binary');   
			}
		else {
			// This Will Force The File Download Dialog Box.
			//error_log('forcing download');
			header('Content-Disposition: attachment; filename="'.basename($file).'"');
			}
			
		
		// This is a partial request
		if ($partial) {
				
			//error_log('Running Partial Download');
				
			// Set Resumable Headers
			header('HTTP/1.1 206 Partial Content');
			//header("Content-Length: $length");
			////error_log("content Length set to $length");
			header("Content-Range: bytes $start-$end/$filesize");
			//error_log("header('Content-Range: bytes $start-$end/$filesize');");
				
				
			// If File Cannot Be Opened - Send 500 Error And Die Out.
			if (!$fp = fopen($file, 'rb')) {
				// Error out if we can't read the file
				header("HTTP/1.1 500 Internal Server Error");
				echo "<h1>500 Internal Server Error</h1>";
				exit;
			}
				
			// Jump To The Requested Start/Resume Point
			if ($start) {fseek($fp,$start);}
				
			while ($length) {
					
				// Read in blocks of 8KB so we don't chew up memory on the server
				$read = ($length > 8192) ? 8192 : $length;
				print(fread($fp,$read));
				$length -= $read;
				// Update Download Stats Only If End Of File Reached.
				if(feof($fp)){
					$dl = $objFile->nDownloads;
					$dl++;
					$dbo->update("UPDATE tblfiles set nDownloads='".$dl."' WHERE nFile_ID='".$objFile->nFile_ID."'");
				}
			}
			//error_log('executed fread($fp,'.$read.')');
			fclose($fp);
		}
		else {
				//error_log('is full request. Size = '.intval($filesize));
				
				$fh = fopen($file, "rb") or die("Could not open file: " . $file . "\n");
				@set_time_limit(0);
				
				while (!feof($fh)){
					print(fread($fh, 1024*8));
					ob_flush();
					flush();
				}
				fclose($fh);
				//error_log('file pushed successfully');
				// File Downloaded Successfully
				$dl = $objFile->nDownloads;
				$dl++;
				$dbo->update("UPDATE tblfiles set nDownloads='".$dl."' WHERE nFile_ID='".$objFile->nFile_ID."'");
				
			}
			
		// Exit here to avoid accidentally sending extra content on the end of the file
		exit;
	}
	
	// ========================
	
	// ADMIN FUNCTIONS
	
	// ========================
	
	
	
	include_once($chkSsettings->sRootPath.'/admin/mime.php');
	
	define('FILE_UPLOAD_PATH', $chkSsettings->sRootPath . '/admin/assets');



	// Declare accepted file extensions for video
	
	$extensions = array('flv');
	
	
	
	function getDirListing($path) {
	
		$path = FILE_UPLOAD_PATH . $path;
	
		$f = array();
	
		$d = array();
	
		$dir_handle = @opendir($path);
	
		while ($file = readdir($dir_handle))
	
		{
	
			if ((is_file($path . '/' . $file)) && (substr($file,1) != '.') && ($file != 'index.php')) {
	
				$f[] = $file;
	
			} elseif(($file != '.') && ($file != '..') && (is_dir($path . '/' . $file))) {
	
				$d[] = $file;
	
			}
	
		
	
		}
	
		
	
		return array('file' => $f, 'dir' => $d);
	}
	
	
	
	function getDbFilesListing($path) {
	
		global $dbo;
	
		$r = array();
	
		$sql = sprintf("SELECT nFile_ID, sFilename, nSize FROM tblfiles WHERE sPath = '%s'", $dbo->format($path));
	
		if ($rs = $dbo->select($sql)) {
	
			while($file = $dbo->getobj($rs)) {
	
				$r[] = $file->sFilename;
	
			}
	
		}
	
		
	
		return $r;
	}
	
	
	
	function addRemoteFileToDb($url) {
	
		require_once('functions-curl.php');
	
		global $dbo;
		$bError = false;
		$errmsg = '';
		//, $extensions;
	
		// Lets do some verification on the remote file ...
		
		// Lets see if it looks like a url...
		if(preg_match('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $url)){
			
			// Ok Looks Like A valid Url, Lets Open It!
			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_NOBODY, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HEADER, true);
			$data = curl_exec($ch);
			curl_close($ch);
			
			if ($data === false) {$bError = true; $errmsg = 'Failed To Open URL:';}
			else{
				$fileLength = 0;
				$status = 0;
				
				if (preg_match('/^HTTP\/1\.[01] (\d\d\d)/', $data, $matches)) {$status = (int)$matches[1];}
				if (preg_match('/Content-Length: (\d+)/', $data, $matches)) {$fileLength = (int)$matches[1];}
				
				
				if($status != 200){
						$httpStatus = http_status_codes($status);
						$bError = true;
						$errmsg = 'Error: '.intval($status).' '.$httpStatus;
						}
				
			}
		}
		else{$bError = true;$errmsg = 'Url Is Not Properly Formatted.';}
		
		
		if($bError == true){header("Location: file_management_add.php?err=$errmsg");exit;}
		
	
		$urlArray = parse_url($url);
	
		$urlArray = explode("/", $urlArray['path']);
	
		$urlFile = array_reverse($urlArray);
	
		$urlFile = $urlFile[0];
	
		$type = get_type(strtolower(substr($urlFile, strrpos($urlFile, '.')+1)));
	
		$extension = strtolower(substr($urlFile, strrpos($urlFile, '.')+1));
	
		
	
		//if (in_array($extension, $extensions)) {
	
			//$sql = sprintf("INSERT INTO tblfiles (sFilename, sURL, sType) 
	
			//VALUES('%s', '%s', '%s');", $dbo->format($urlFile), $dbo->format($url), $dbo->format($type));
	
			
			
			$sql = "INSERT INTO tblfiles(sFilename,sURL,sType,nSize)
			VALUES('".$dbo->format($urlFile)."','".$dbo->format($url)."','".$dbo->format($type)."','".$fileLength."');";
			//die($sql);
			$dbo->insert($sql);
			return true;
	
		//} else {
	
		//	return false;
	
		//}
	
	}



	function addFilesToDb($path, $recursively = true) {
	
		global $dbo;
	
		$count = 0;
	
		$dbfiles = getDbFilesListing($path);
	
		$list = getDirListing($path);
	
		$files = $list['file'];
	
		$folders = $list['dir'];
	
		$newfiles = array_diff($files, $dbfiles);
	
		$s = substr($path, strlen($path)-1,1);
	
		foreach ($newfiles as $file) {
	
			$size = (($s == '/') || ($s == '\\')) ? filesize(FILE_UPLOAD_PATH . $path . $file) : filesize(FILE_UPLOAD_PATH . $path . '/' . $file);
	
			$type = get_type(strtolower(substr($file, strrpos($file, '.')+1)));
	
			$sql = sprintf("INSERT INTO tblfiles (sTitle,sFilename, sPath, sType, nSize) VALUES('%s','%s', '%s', '%s', '%s');", $dbo->format($file), $dbo->format($file), $dbo->format($path), $dbo->format($type), $dbo->format($size));
			$dbo->insert($sql);  	
	
			$count++;
	
		} 
	
		if ($recursively) {
	
			foreach ($folders as $dir) {
	
				if (($dir != '.') && ($dir != '..')) {
	
					
	
					
	
					if (($s == '/') || ($s == '\\')) {
	
						$count+= addFilesToDb($path . $dir);
	
					} else {
	
						$count+= addFilesToDb($path . '/' . $dir);
	
					}
	
				}
	
			}
	
		}
	
		
	
		return $count;
}



	function removeFilesFromDb() {
	
		global $dbo;
	
		$count = 0;
	
		$sql = "SELECT nFile_ID, sFilename, sPath FROM tblfiles";
	
	
		if ($rs = $dbo->select($sql)) {
	
			while($file = $dbo->getobj($rs)) {
	
				if (strlen(utf8_decode($file->sPath)) == 1) {
					$path = sprintf("%s/%s", FILE_UPLOAD_PATH, utf8_decode($file->sFilename));
	
				} else {
	
					$path = sprintf("%s%s/%s", FILE_UPLOAD_PATH, utf8_decode($file->sPath), utf8_decode($file->sFilename));
	
				}
	
				if (!is_file($path)) {
	
					$sql = sprintf("DELETE FROM tblfiles WHERE nFile_ID = %s", $dbo->format($file->nFile_ID));
	
					$dbo->select($sql);	
	
					$count++;
	
				}
	
				
	
			}
	
		}
	
		return $count;
	
		
	
	}


?>