<?php

function generateTreeFolder($sel='',$disabled='')
{
		global $dbo;			
		$result_cat0=$dbo->select("select * from tbldirectories where nLevel_ID='0'  order by nSortOrder ASC , sDirectoryName ASC,  nDirectory_ID ASC ");
		$option="";
		
		if ($result_cat0 !== false) {
			while($row_cat0=$dbo->getobj($result_cat0))
			{
			    $dir = ucwords($row_cat0->sDirectoryName);
	    	    $dir = (strpos(strtolower($dir), "directory") === false) ? $dir . " Folder" :        $dir;
				if($sel==$row_cat0->nDirectory_ID) {
					$option=$option."<option selected=\"selected\"  value='{$row_cat0->nDirectory_ID}' >{$dir}</option>";
				} else { 
					$option=$option."<option value='{$row_cat0->nDirectory_ID}' >{$dir}</option>";
				}
					
				$result_cat1=$dbo->select("select * from tbldirectories where nLevel_ID='1' and nParent_ID='{$row_cat0->nDirectory_ID}' order by nSortOrder ASC ,sDirectoryName ASC,  nDirectory_ID ASC ");
				
				if ($result_cat1 !== false) {
					while($row_cat1=$dbo->getobj($result_cat1))
					{
					    $dir = ucwords($row_cat1->sDirectoryName);
		   			    $dir = (strpos(strtolower($dir), "directory") === false) ? $dir . " Folder" :        $dir;
						if($sel==$row_cat1->nDirectory_ID) {
							$option=$option."<option  selected=\"selected\" value='{$row_cat1->nDirectory_ID}'>&nbsp;&nbsp;&nbsp;&nbsp;{$dir}</option>";
						} else {
							$option=$option."<option  value='{$row_cat1->nDirectory_ID}'>&nbsp;&nbsp;&nbsp;&nbsp;{$dir}</option>";
						} 
						
						$result_cat2=$dbo->select("select * from tbldirectories where nLevel_ID='2' and nParent_ID='{$row_cat1->nDirectory_ID}' order by nSortOrder ASC ,sDirectoryName ASC,  nDirectory_ID ASC ");
						if ($result_cat2 !== false) {
							while($row_cat2=$dbo->getobj($result_cat2))
							{
								$dir = ucwords($row_cat2->sDirectoryName);
			   	   				$dir = (strpos(strtolower($dir), "directory") === false) ? $dir . " Folder" :        $dir;
								if($sel==$row_cat2->nDirectory_ID) {
									$option=$option."<option {$disabled}  selected=\"selected\" value='{$row_cat2->nDirectory_ID}'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{$dir}</option>";
								} else {
									$option=$option."<option  {$disabled} value='{$row_cat2->nDirectory_ID}'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{$dir}</option>";
								} 
							}
						}
					}
				}
			}
		}
		
		
			return $option;
	}
	
function generateTreeFolderList($sel='',$disabled='')
{
		global $dbo;
		
		$qs = '';
		$qs .= (isset($_GET['view']))?'&view='.$_GET['view']:'';
					
		$result_cat0=$dbo->select("select * from tbldirectories where nLevel_ID='0'  order by nSortOrder ASC , sDirectoryName ASC,  nDirectory_ID ASC ");
		$list = "<ul id='folder-list'>";
		
		if ($result_cat0 !== false) {
			while($row_cat0=$dbo->getobj($result_cat0))
			{
			    $result_cat1=$dbo->select("select * from tbldirectories where nLevel_ID='1' and nParent_ID='{$row_cat0->nDirectory_ID}' 
				order by nSortOrder ASC ,sDirectoryName ASC,  nDirectory_ID ASC ");
				
				if($result_cat1 !== false){
					$hassubfolder = 1;
				}
				
				$dir = ucwords($row_cat0->sDirectoryName);
	    	    $dir = (strpos(strtolower($dir), "directory") === false) ? $dir  :  $dir;
				
				if($sel == $row_cat0->nDirectory_ID) $list=$list.'<li> '.$dir ;
				else $list .='<li> <a href="page_management.php?did='.$row_cat0->nDirectory_ID.$qs.'">'.$dir.'</a>' ; 
				
				
				if ($result_cat1 !== false) {
					
					$list .= '<ul>';
					while($row_cat1=$dbo->getobj($result_cat1))
					{
					    $result_cat2=$dbo->select("select * from tbldirectories where nLevel_ID='2' and nParent_ID='{$row_cat1->nDirectory_ID}' order by nSortOrder ASC ,sDirectoryName ASC,  nDirectory_ID ASC ");
						
						$dir = ucwords($row_cat1->sDirectoryName);
		   			    $dir = (strpos(strtolower($dir), "directory") === false) ? $dir  :  $dir;
						
						
						
						if($sel == $row_cat1->nDirectory_ID) $list .='<li> '.$dir ;
						else $list .='<li> <a href="page_management.php?did='.$row_cat1->nDirectory_ID.$qs.'">'.$dir.'</a>' ; 
						
						if ($result_cat2 !== false) {
							
							$list .='<ul>';
							//die(var_dump($dbo->nr($result_cat2)));
							while($row_cat2=$dbo->getobj($result_cat2))
							{
								$dir = ucwords($row_cat2->sDirectoryName);
			   	   				$dir = (strpos(strtolower($dir), "directory") === false) ? $dir . " Folder" :        $dir;
								
								if($sel == $row_cat2->nDirectory_ID) $list .='<li> '.$dir ;
								else $list .='<li> <a href="page_management.php?did='.$row_cat2->nDirectory_ID.$qs.'">'.$dir.'</a>';
							}
							
							$list .='</ul>';
						}
						$list .= '</li>';
					}
					$list .= '</ul>';
				}
				$list .='</li>';
			}
		}
		
		
			return $list;
	}
	
	
function getFolders()
{
		global $dbo;			
		$result_cat0=$dbo->select("SELECT *,(SELECT COUNT(nPage_ID) FROM tblpages WHERE tblpages.nDirectory_ID = tbldirectories.nDirectory_ID) AS pagecount 
		FROM tbldirectories 
		WHERE nLevel_ID='0'  
		ORDER BY nSortOrder ASC ,sDirectoryName ASC,  nDirectory_ID ASC ");
		$option="";
		$i=0;
		while($row_cat0=$dbo->getobj($result_cat0))
		{
		    $dir = ucwords($row_cat0->sDirectoryName);
    	  //  $dir = (strpos(strtolower($dir), "directory") === false) ? $dir . " Folder" :        $dir;
			
			$option[$i]['sDirectoryName']=$dir;
			$option[$i]['nDirectory_ID']=$row_cat0->nDirectory_ID;
			$option[$i]['nLevel_ID']='0';
			$option[$i]['bDisplay']=$row_cat0->bDisplay;
			$option[$i]['nSortOrder']=$row_cat0->nSortOrder;
			$option[$i]['pagecount']=$row_cat0->pagecount;
			$option[$i]['nParent_ID']=$row_cat0->nParent_ID;
			
			$result_cat1=$dbo->select("select *,(SELECT COUNT(nPage_ID) FROM tblpages WHERE tblpages.nDirectory_ID = tbldirectories.nDirectory_ID) AS pagecount from tbldirectories where nLevel_ID='1' and nParent_ID='{$row_cat0->nDirectory_ID}' order by nSortOrder ASC ,sDirectoryName ASC,  nDirectory_ID ASC ");
			if(!empty($result_cat1))
			while($row_cat1=$dbo->getobj($result_cat1))
			{
				    $dir = ucwords($row_cat1->sDirectoryName);
    			//    $dir = (strpos(strtolower($dir), "directory") === false) ? $dir . " Folder" :        $dir;
					$i++;	
    			   	$option[$i]['sDirectoryName']=$dir;
					$option[$i]['nDirectory_ID']=$row_cat1->nDirectory_ID;
					$option[$i]['nLevel_ID']='1';
					$option[$i]['bDisplay']=$row_cat1->bDisplay;
					$option[$i]['nSortOrder']=$row_cat1->nSortOrder;
    			    $option[$i]['pagecount']=$row_cat1->pagecount;
    			    $option[$i]['nParent_ID']=$row_cat1->nParent_ID;
					
					$result_cat2=$dbo->select("select *,(SELECT COUNT(nPage_ID) FROM tblpages WHERE tblpages.nDirectory_ID = tbldirectories.nDirectory_ID) AS pagecount from tbldirectories where nLevel_ID='2' and nParent_ID='{$row_cat1->nDirectory_ID}' order by nSortOrder ASC , sDirectoryName ASC, nDirectory_ID ASC ");
					if(!empty($result_cat2))
					while($row_cat2=$dbo->getobj($result_cat2))
					{
						
						$dir = ucwords($row_cat2->sDirectoryName);
    	   			//	$dir = (strpos(strtolower($dir), "directory") === false) ? $dir . " Folder" :        $dir;
    	   				$i++;
						$option[$i]['sDirectoryName']=$dir;
						$option[$i]['nDirectory_ID']=$row_cat2->nDirectory_ID;
						$option[$i]['nLevel_ID']='2';
						$option[$i]['bDisplay']=$row_cat2->bDisplay;
						$option[$i]['nSortOrder']=$row_cat2->nSortOrder;
						$option[$i]['pagecount']=$row_cat2->pagecount;
						$option[$i]['nParent_ID']=$row_cat2->nParent_ID;
							
					}
					
				
			}
					
			$i++;
				
		}
		
		
			return $option;
	}
// V 2.4
function getFolderNameById($id){
	global $dbo;
	$sql = "SELECT sDirectoryName FROM tbldirectories WHERE nDirectory_ID = $id LIMIT 1;";
	$dir = $dbo->getobject($sql);
	//die(var_dump($dir));
	return ucwords($dir->sDirectoryName);}
?>