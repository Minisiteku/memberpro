<?php
// Formatting functions - to standardize how HTML is outputted.

// make_link() - return a hyperlink to something, within the site
function make_link($url, $linktext = false, $target = false, $extras = false)
{
	return sprintf("<a href=\"%s\"%s%s>%s</a>",
		$url,
		($target ? " target=\"$target\"" : ''),
		($extras ? " $extras" : ''),
		($linktext ? $linktext : $url)
	);
}

// print_link() - echo a hyperlink to something, within the site
function print_link($url, $linktext = false, $target = false, $extras = false)
{
	echo make_link($url, $linktext, $target, $extras);
}

// make_email() - return a mailto hyperlink to something, within the site
function make_email($email, $linktext = false)
{
	return sprintf("<a href=\"mailto:%s\">%s</a>",
		$email,
		($linktext ? $linktext : $email)
	);
}

// print_email() - echo a hyperlink to something, within the site
function print_email($email, $linktext = false)
{
	echo make_email($email, $linktext);
}
// Version 3.0.10
function storeHtmlToDb($html){
	global $dbo;
	$sContent = $html;
	$sContent = preg_replace('/^\s*<\?xml .*\?>\s*\r?\n/', '', $sContent);
	
	$sContent = $dbo->format($sContent, 'no_tag_strip');
	// Docode HTML entities - v3
	$sContent = htmlspecialchars_decode($sContent);
	
	return $sContent;
}
function readHtmlFromDb($html){
	
	return htmlspecialchars_decode($html);
	
	
}
?>