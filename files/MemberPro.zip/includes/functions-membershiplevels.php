<?php
function get_level_name_by_payment_plan ($nPaymentPlan_ID) {
	global $dbo;
	$sql = "SELECT sLevel FROM tblmembershiplevels M 
	INNER JOIN tblpaymentplans P ON P.nMembershipLevel_ID = M.nLevel_ID
	WHERE P.nPaymentPlan_ID = $nPaymentPlan_ID
	";
	$sLevel = $dbo->getval($sql);
	if ($sLevel) {
		return $sLevel;
	} else {
		return '';
	}
}

function get_level_name_by_level_id ($nLevel_ID) {
	global $dbo;
	$sql = "SELECT sLevel FROM tblmembershiplevels WHERE nLevel_ID=" . $dbo->format($nLevel_ID);
	$sLevel = $dbo->getval($sql);
	if ($sLevel) {
		return $sLevel;
	} else {
		return '';
	}
}
?>