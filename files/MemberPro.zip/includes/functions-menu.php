<?php

function getMenu() {

    global $dbo;

    //main folder(lvl0)
    $sql = "SELECT * FROM tbldirectories WHERE nDirectory_ID = 0";

    $result_cat0 = $dbo->select ($sql);
// lets Check and see if we get a result ... DUH - MDP 4-26-12
    if(!$result_cat0){die('Main Directory Missing! Contact Support');}
//
    $option = "";
    $i = 0;

    while ( $row_cat0 = $dbo->getobj ( $result_cat0 ) ) {
        $dir = ucwords ( $row_cat0->sDirectoryName );

        $option [$i] ['sDirectoryName'] = $dir;
        $option [$i] ['nDirectory_ID'] = $row_cat0->nDirectory_ID;
        $option [$i] ['nLevel_ID'] = '0';
        $option [$i] ['nSortOrder'] = $row_cat0->nSortOrder;
        $option [$i] ['nParent_ID'] = $row_cat0->nParent_ID;

        //get pages in the main folder(lvl0)
        $sql = "SELECT * FROM tblpages
				WHERE nDirectory_ID = " . $row_cat0->nDirectory_ID . " AND nDisplay = 1 AND sNavBarLocation = 'top' 
				ORDER by nSortOrder ASC, sFileName ASC, nPage_ID ASC";
        $result_pages = $dbo->select ($sql);

        $l = 0;
        if (! empty ( $result_pages ))
            while ( $row_pages = $dbo->getobj ( $result_pages ) ) {
                $page = ucwords ( $row_pages->sPageName );
                $option [$i] ['pages'] [$l] ['sPageName'] = $page;
                $option [$i] ['pages'] [$l] ['sFileName'] = $row_pages->sFileName;
                $option [$i] ['pages'] [$l] ['nDirectory_ID'] = $row_pages->nDirectory_ID;
                $option [$i] ['pages'] [$l] ['nSortOrder'] = $row_pages->nSortOrder;

                $l ++;
            }

        //get folder childs(lvl1) of the main folder(lvl0)
        $sql = "SELECT * FROM tbldirectories
				WHERE nLevel_ID = 1 AND nParent_ID = " . $row_cat0->nDirectory_ID . " AND bDisplay = 1 
				ORDER BY nSortOrder ASC, sDirectoryName ASC, nDirectory_ID ASC";
        $result_cat1 = $dbo->select ($sql);

        $j = 0;

        if (! empty ( $result_cat1 ))
            while ( $row_cat1 = $dbo->getobj ( $result_cat1 ) ) {
                $dir = ucwords ( $row_cat1->sDirectoryName );

                $option [$i] ['child'] [$j] ['sDirectoryName'] = $dir;
                $option [$i] ['child'] [$j] ['nDirectory_ID'] = $row_cat1->nDirectory_ID;
                $option [$i] ['child'] [$j] ['nLevel_ID'] = '1';
                $option [$i] ['child'] [$j] ['nSortOrder'] = $row_cat1->nSortOrder;
                $option [$i] ['child'] [$j] ['nParent_ID'] = $row_cat1->nParent_ID;

                //get pages in the folder(lvl1)
                $sql = "SELECT * FROM tblpages
						WHERE nDirectory_ID = " . $row_cat1->nDirectory_ID . " AND nDisplay = 1 AND sNavBarLocation = 'top'
						ORDER by nSortOrder ASC, sFileName ASC, nPage_ID ASC";
                $result_pages = $dbo->select ($sql);

                $l = 0;
                if (! empty ( $result_pages ))
                    while ( $row_pages = $dbo->getobj ( $result_pages ) ) {
                        $page = ucwords ( $row_pages->sPageName );
                        $option [$i] ['child'] [$j] ['pages'] [$l] ['sPageName'] = $page;
                        $option [$i] ['child'] [$j] ['pages'] [$l] ['sFileName'] = $row_pages->sFileName;
                        $option [$i] ['child'] [$j] ['pages'] [$l] ['nDirectory_ID'] = $row_pages->nDirectory_ID;
                        $option [$i] ['child'] [$j] ['pages'] [$l] ['nSortOrder'] = $row_pages->nSortOrder;

                        $l ++;
                    }

                //get childs folder(lvl2) of the folders(lvl1)
                $sql = "SELECT * FROM tbldirectories
						WHERE nLevel_ID = 2 AND nParent_ID = " . $row_cat1->nDirectory_ID . " AND bDisplay = 1 
						ORDER BY nSortOrder ASC, sDirectoryName ASC, nDirectory_ID ASC";
                $result_cat2 = $dbo->select ($sql);

                $k = 0;

                if (! empty ( $result_cat2 ))
                    while ( $row_cat2 = $dbo->getobj ( $result_cat2 ) ) {

                        $dir = ucwords ( $row_cat2->sDirectoryName );

                        $option [$i] ['child'] [$j] ['child'] [$k] ['sDirectoryName'] = $dir;
                        $option [$i] ['child'] [$j] ['child'] [$k] ['nDirectory_ID'] = $row_cat2->nDirectory_ID;
                        $option [$i] ['child'] [$j] ['child'] [$k] ['nLevel_ID'] = '2';
                        $option [$i] ['child'] [$j] ['child'] [$k] ['nSortOrder'] = $row_cat2->nSortOrder;
                        $option [$i] ['child'] [$j] ['child'] [$k] ['nParent_ID'] = $row_cat2->nParent_ID;

                        //get pages in the folders(lvl2)
                        $sql = "SELECT * FROM tblpages
								WHERE nDirectory_ID = " . $row_cat2->nDirectory_ID . " AND nDisplay = 1 AND sNavBarLocation = 'top'
								ORDER by nSortOrder ASC, sFileName ASC, nPage_ID ASC";
                        $result_pages = $dbo->select ($sql);

                        $l = 0;

                        if (! empty ( $result_pages ))
                            while ( $row_pages = $dbo->getobj ( $result_pages ) ) {
                                $page = ucwords ( $row_pages->sPageName );
                                $option [$i] ['child'] [$j] ['child'] [$k] ['pages'] [$l] ['sPageName'] = $page;
                                $option [$i] ['child'] [$j] ['child'] [$k] ['pages'] [$l] ['sFileName'] = $row_pages->sFileName;
                                $option [$i] ['child'] [$j] ['child'] [$k] ['pages'] [$l] ['nDirectory_ID'] = $row_pages->nDirectory_ID;
                                $option [$i] ['child'] [$j] ['child'] [$k] ['pages'] [$l] ['nSortOrder'] = $row_pages->nSortOrder;

                                $l ++;
                            }

                        $k ++;

                    }
                $j ++;

            }

        $i ++;

    }

    //echo "<pre>";
    //print_r($option);
    //echo "</pre>";
    return $option;
}

function getMenuLoggedUsers($userId) {
    global $dbo;
    $nNow = date("Ymd");
    //get user level
    $sql = "SELECT nLevel_ID FROM tbluserlevels WHERE nUser_ID = " . $dbo->format($userId).";";
    $rs = $dbo->select ( $sql );
    if (! empty ( $rs ))

        while ( $rw = $dbo->getobj ( $rs ) ) {
            $userLevel [] = $rw->nLevel_ID;
        }

    $userLevel = @implode ( '\',\'', $userLevel );

    // member folder (level 0)
    $sql = "SELECT * FROM tbldirectories WHERE nDirectory_ID = 1";

    $result_cat0 = $dbo->select ( $sql );

    $option = '';
    $i = 0;

    if (! empty ( $result_cat0 ))
        while ( $row_cat0 = $dbo->getobj ( $result_cat0 ) ) {
            $dir = ucwords ( $row_cat0->sDirectoryName );

            $option [$i] ['sDirectoryName'] = $dir;
            $option [$i] ['nDirectory_ID'] = $row_cat0->nDirectory_ID;
            $option [$i] ['nLevel_ID'] = '0';
            $option [$i] ['nSortOrder'] = $row_cat0->nSortOrder;
            $option [$i] ['nParent_ID'] = $row_cat0->nParent_ID;

            //get pages in the member folder (level 0)
            $sql = "SELECT * FROM tblpages
			WHERE nDirectory_ID = " . $row_cat0->nDirectory_ID . " AND nDisplay=1 AND sNavBarLocation = 'top'
			ORDER by nSortOrder ASC, sFileName ASC, nPage_ID ASC";
            $result_pages = $dbo->select ( $sql );

            $l = 0;
            if (! empty ( $result_pages ))
                while ( $row_pages = $dbo->getobj ( $result_pages ) ) {

                    //get pages level and check select only the pages that has the same level as the user
                    $sql6 = "SELECT nLevel_ID FROM tblpagelevels
							WHERE nPage_ID = " . $row_pages->nPage_ID . " AND nLevel_ID in ('$userLevel')";
                    //print $sql6;
                    $nr6 = $dbo->num_rows ( $sql6 );

                    if ( ($nr6 != 0 || ($row_pages->cre == '0')) && (isActive($row_pages, $userId))) {

                        // Dynamic Page.. show Nov 2009 instead of usual menu item name but month and year
                        // must be dynamically generated according to the user's join date of the level that the
                        // page is in
                        if($row_pages->nDynamicPage)
                            $page = getDynamicPageName($row_pages, $userId);
                        else
                            $page = ucwords ( $row_pages->sPageName );
                        $option [$i] ['pages'] [$l] ['sPageName'] = $page;
                        $option [$i] ['pages'] [$l] ['sFileName'] = $row_pages->sFileName;
                        $option [$i] ['pages'] [$l] ['nDirectory_ID'] = $row_pages->nDirectory_ID;
                        $option [$i] ['pages'] [$l] ['nSortOrder'] = $row_pages->nSortOrder;
                    }

                    $l ++;
                }

            //get folder childs(lvl1) of the main folder(lvl0)
            $sql = "SELECT * FROM tbldirectories
					WHERE nLevel_ID = 1 AND nParent_ID = " . $row_cat0->nDirectory_ID . " AND bDisplay = 1 
					ORDER BY nSortOrder ASC, sDirectoryName ASC, nDirectory_ID ASC";

            $result_cat1 = $dbo->select ($sql);
            $j = 0;
            if (! empty ( $result_cat1 ))
                while ( $row_cat1 = $dbo->getobj ( $result_cat1 ) ) {
                    $dir = ucwords ( $row_cat1->sDirectoryName );

                    $option [$i] ['child'] [$j] ['sDirectoryName'] = $dir;
                    $option [$i] ['child'] [$j] ['nDirectory_ID'] = $row_cat1->nDirectory_ID;
                    $option [$i] ['child'] [$j] ['nLevel_ID'] = '1';
                    $option [$i] ['child'] [$j] ['nSortOrder'] = $row_cat1->nSortOrder;
                    $option [$i] ['child'] [$j] ['nParent_ID'] = $row_cat1->nParent_ID;

                    //get pages in the folder(lvl1)
                    $sql = "SELECT * FROM tblpages
    			    		WHERE nDirectory_ID = " . $row_cat1->nDirectory_ID . " AND nDisplay = 1 AND sNavBarLocation = 'top'
							ORDER BY nSortOrder ASC, sFileName ASC, nPage_ID ASC";

                    $result_pages = $dbo->select ( $sql );

                    $l = 0;
                    if (! empty ( $result_pages ))
                        while ( $row_pages = $dbo->getobj ( $result_pages ) ) {

                            //get pages level and select only the pages that has the same level as the user
                            $sql6 = "SELECT nLevel_ID FROM tblpagelevels
									WHERE nPage_ID = " . $row_pages->nPage_ID . " AND nLevel_ID in ('$userLevel')";

                            $nr6 = $dbo->num_rows ( $sql6 );

                            if ( ($nr6 != 0 || ($row_pages->cre == '0')) && (isActive($row_pages, $userId)) ) {
                                // Dynamic Page.. show Nov 2009 instead of usual menu item name but month and year
                                // must be dynamically generated according to the user's join date of the level that the
                                // page is in
                                if($row_pages->nDynamicPage)
                                    $page = getDynamicPageName($row_pages, $userId);
                                else
                                    $page = ucwords ( $row_pages->sPageName );
                                $option [$i] ['child'] [$j] ['pages'] [$l] ['sPageName'] = $page;
                                $option [$i] ['child'] [$j] ['pages'] [$l] ['sFileName'] = $row_pages->sFileName;
                                $option [$i] ['child'] [$j] ['pages'] [$l] ['nDirectory_ID'] = $row_pages->nDirectory_ID;
                                $option [$i] ['child'] [$j] ['pages'] [$l] ['nSortOrder'] = $row_pages->nSortOrder;
                            }

                            $l ++;
                        }

                    //get childs folder(lvl2) of the folders(lvl1)
                    $sql = "SELECT * FROM tbldirectories
					WHERE nLevel_ID = 2 AND nParent_ID = " . $row_cat1->nDirectory_ID . " AND bDisplay=1 
					ORDER BY nSortOrder ASC, sDirectoryName ASC, nDirectory_ID ASC";
                    $result_cat2 = $dbo->select ( $sql );

                    $k = 0;

                    if (! empty ( $result_cat2 ))
                        while ( $row_cat2 = $dbo->getobj ( $result_cat2 ) ) {

                            $dir = ucwords ( $row_cat2->sDirectoryName );

                            $option [$i] ['child'] [$j] ['child'] [$k] ['sDirectoryName'] = $dir;
                            $option [$i] ['child'] [$j] ['child'] [$k] ['nDirectory_ID'] = $row_cat2->nDirectory_ID;
                            $option [$i] ['child'] [$j] ['child'] [$k] ['nLevel_ID'] = '2';
                            $option [$i] ['child'] [$j] ['child'] [$k] ['nSortOrder'] = $row_cat2->nSortOrder;
                            $option [$i] ['child'] [$j] ['child'] [$k] ['nParent_ID'] = $row_cat2->nParent_ID;

                            //get pages in the folders(lvl2)
                            $sql = "SELECT * FROM tblpages
									WHERE nDirectory_ID = " . $row_cat2->nDirectory_ID . " AND nDisplay = 1 AND sNavBarLocation = 'top'
									ORDER by nSortOrder ASC, sFileName ASC, nPage_ID ASC";
                            $result_pages = $dbo->select ($sql);

                            $l = 0;
                            if (! empty ( $result_pages ))
                                while ( $row_pages = $dbo->getobj ( $result_pages ) ) {
                                    //get pages level and check select only the pages that has the same level as the user
                                    $sql6 = "SELECT nLevel_ID FROM tblpagelevels WHERE nPage_ID = " . $row_pages->nPage_ID . " AND nLevel_ID IN ('$userLevel')";
                                    $nr6 = $dbo->num_rows ( $sql6 );

                                    if ( ($nr6 != 0 || ($row_pages->cre == '0')) && (isActive($row_pages, $userId)) ) {
                                        // Dynamic Page.. show Nov 2009 instead of usual menu item name but month and year
                                        // must be dynamically generated according to the user's join date of the level that the
                                        // page is in
                                        if($row_pages->nDynamicPage)
                                            $page = getDynamicPageName($row_pages, $userId);
                                        else
                                            $page = ucwords ( $row_pages->sPageName );
                                        $option [$i] ['child'] [$j] ['child'] [$k] ['pages'] [$l] ['sPageName'] = $page;
                                        $option [$i] ['child'] [$j] ['child'] [$k] ['pages'] [$l] ['sFileName'] = $row_pages->sFileName;
                                        $option [$i] ['child'] [$j] ['child'] [$k] ['pages'] [$l] ['nDirectory_ID'] = $row_pages->nDirectory_ID;
                                        $option [$i] ['child'] [$j] ['child'] [$k] ['pages'] [$l] ['nSortOrder'] = $row_pages->nSortOrder;
                                    }

                                    $l ++;
                                }

                            $k ++;

                        }
                    $j ++;

                }

            $i ++;

        }

    //echo "<pre>";
    //print_r ( $option );
    //echo "</pre>";
    return $option;
}

// Builds menu ready for display
function build_menu() {

    global $menu, $objTemplateSettings, $language;

    // Level 1
    if (count($menu[0]['pages']) != 0)
    {
        $printmenu = "";
        foreach ($menu[0]['pages'] as $page)
        {
			$link = '<a href="index.php?page=' . $page['sFileName'] . '">' . $page['sPageName'] . '</a>';
			// Lets Check For Login Page.
			// If Logged In, Change To Logout. - MDP - 3-10-2013
			if($page['sFileName'] == 'login' && isset($_SESSION['user']['nUser_ID'])){
				$link = '<a href="member/logout.php">' . $language['logout'] . '</a>';
			}
			
			 $printmenu .= $objTemplateSettings->nHeaderTextBold ? "<li><strong>" . $link . "</strong></li>" : "<li>" . $link . "</li>";
        }
    }

    // Check if Level 1 has sub levels
    if (count($menu[0]['child']) != 0)
    {
        foreach ($menu[0]['child'] as $level2)
        {
            $has_children = false;

            if (count($level2['child']) != 0)
            {
                foreach ($level2['child'] as $v3)
                {
                    if (count($v3['pages']) != 0)
                    {
                        $has_children = true;
                        break;
                    }
                }
            }

            // Level 2 check
            if (count($level2['pages']) != 0 || (count ($level2 ['child']) != 0 && $has_children == true))
            {
                // Level 2 Folders
                $link = '<a href="#">' . $level2 ['sDirectoryName'] . '</a>';
                $printmenu .= ($objTemplateSettings->nHeaderTextBold) ? '<li><strong>' . $link . '</strong>' : '<li>' . $link;
                $printmenu .= '<ul>';

                // Level 2 Pages
                if (count ($level2['pages']) != 0)
                {
                    foreach ($level2['pages'] as $page )
                    {
                        $link = '<a href="index.php?page=' . $page ['sFileName'] . '">' . $page ['sPageName'] . '</a>';
                        $printmenu .= ($objTemplateSettings->nHeaderTextBold) ? '<li><strong>' . $link . '</strong></li>' : '<li>' . $link . '</li>';
                    }
                }

                // Level 3 Check
                if (count($level2['child']) != 0)
                    foreach ($level2['child'] as $level3 )
                    {
                        // Level 3 Folders
                        if (count ($level3 ['pages']) != 0)
                        {
                            $link = '<a href="#">' . $level3 ['sDirectoryName'] . '</a>';
                            $printmenu .= ($objTemplateSettings->nHeaderTextBold) ? '<li><strong>' . $link . '</strong>' : '<li>' . $link;
                            $printmenu .= '<ul>';

                            // Level 3 Pages
                            foreach ( $level3 ['pages'] as $page )
                            {
                                $link = '<a href="index.php?page=' . $page ['sFileName'] . '">' . $page ['sPageName'] . '</a>';
                                $printmenu .= ($objTemplateSettings->nHeaderTextBold) ? '<li><strong>' . $link . '</strong></li>' : '<li>' . $link . '</li>';
                            }

                            $printmenu .= '</ul>';
                        }

                    }

                $printmenu .= '</ul>';
            }
        }
    }

    // 	Add logout link for members
    if (($_SESSION['user']['nUser_ID']) && (strpos($_SERVER['REQUEST_URI'], '/member/') !== FALSE) ) {
        $printmenu = $printmenu . '<li>';
        if ($objTemplateSettings->nHeaderTextBold)
            $printmenu = $printmenu . '<strong>';
        $printmenu = $printmenu . '<a href="logout.php">' . $language['logout'] . '</a>';
        if ($objTemplateSettings->nHeaderTextBold)
            $printmenu = $printmenu . '</strong>';
        $printmenu = $printmenu . '</li>';
    }

    return $printmenu;
}

function getDynamicPageName ($row_pages, $userId) {

    global $dbo;

    //get the id of the free level
    //$nFreeLevel_ID = $dbo->getval ("SELECT nLevel_ID FROM tblmembershiplevels WHERE sLevel='Free'");

    #############################################################################################################################################3
    ## code below is bugged. Sql Statement not logical and only grabs the highest memberlevel, and not all member levels - MDP - may 15 2012
    ## // Get the level id that this page is in
    ## $sql7 = "SELECT MAX(nLevel_ID) AS nLevel_ID FROM tblpagelevels WHERE nPage_ID = " . $row_pages->nPage_ID . " LIMIT 1";
    ## $nLevel_ID = $dbo->getval($sql7);
    ## ------
    ## New Code uses Inner join To get All Pages
    $sql17 = "SELECT tblpagelevels.nLevel_ID, nDateActive
	FROM tblpagelevels
	INNER JOIN tbluserlevels ON tbluserlevels.nLevel_ID = tblpagelevels.nLevel_ID
	AND tbluserlevels.nUser_ID =".$userId." WHERE nPage_ID = ".$row_pages->nPage_ID.";";
    $activeData = $dbo->getobject($sql17);
    //die($sql17);
    //while($data = $dbo->getobject($sql17)){$pagelevels[] = $data->nLevel_ID;}
    ##
    ## All Membership levels Permitted To View This Page is now stored in $pagelevels[

    ## Code Below Obsolete. Already got active date in Join Statement Above ...
    //$nDateActive = $dbo->getval("SELECT nDateActive FROM tbluserlevels WHERE nLevel_ID=$nLevel_ID AND nUser_ID=" . $dbo->format($userId));
    $nDateActive = $activeData->nDateActive;

    // Get the date of nDateActive + drip feed days of the page
    $nDateActiveDay = substr($nDateActive, 6, 2);
    $nDateActiveMonth = substr($nDateActive, 4, 2);
    $nDateActiveYear = substr($nDateActive, 0, 4);
    $nStartDate = date('Ymd', mktime(0, 0, 0, $nDateActiveMonth, $nDateActiveDay + $row_pages->nAccessDays, $nDateActiveYear));
    // Get number of days between today and our start date above
    $nDays = (strtotime(date("Ymd")) - strtotime($nStartDate))  / (60*60*24);
    // Get number of months that have elapsed since those days (taking into account that 30 days = 1 month)
    $nMonths = round($nDays / 30);
    // Find out what month/year it was at that time
    $sDateString = date('M Y', strtotime("- $nMonths Months"));

    return $sDateString;}

function isActive($objPage, $nUser_ID) {
    global $dbo;

    $today = date(Ymd);
    $nAccessDays = $objPage->nAccessDays;
    $nAccessDaysInSeconds = $nAccessDays * (60*60*24);
    $user_levels = get_user_level_privileges();
    $objUser = get_user_by_id($nUser_ID);

    $nJoinDate = $objUser->nJoinDate;
    $nUnavailableForJoinedAfter = empty($objPage->nUnavailableForJoinedAfter) ? "99999999" : $objPage->nUnavailableForJoinedAfter;
    $nUnavailableForJoinedAfter = str_replace("-", "", $nUnavailableForJoinedAfter);

    // Page level details
    $sql = sprintf("SELECT COUNT(*) as nCount FROM tblpagelevels, tbluserlevels WHERE nPage_ID = %s AND tblpagelevels.nLevel_ID=tbluserlevels.nLevel_ID
	AND tbluserlevels.nUser_ID={$nUser_ID}  
	AND (UNIX_TIMESTAMP($today) - UNIX_TIMESTAMP(tbluserlevels.nDateActive))>=$nAccessDaysInSeconds 
	AND tblpagelevels.nLevel_ID IN ('%s') ", $dbo->format($objPage->nPage_ID), $user_levels);

    $objPageLevels = $dbo->getobject($sql);

    if ( ($objPageLevels->nCount || ($objPage->cre == 0) || ($objUser->nAdmin)) AND ($nJoinDate < $nUnavailableForJoinedAfter))
        return true;
    else
        return false;

}
?>