<?php
// Version 3.0 Method Of Sending Posts
function send_user_notify($data, $action, $url = "NONE") {
	global $chkSsettings;
	if($url == 'NONE'){$url = $chkSsettings->HTTPPostURL;}
	
		// Lets Create the 
		
		$objUser = unserialize($data['user']);
		$objPaymentPlan = unserialize($data['payment_plan']);
		if($action == 'add'){
			$poststring = '';
			foreach($objUser as $k=>$v){$poststring .= $k.'='.$v;}
		}
		if($action == 'email_verified'){
			$poststring = '';
			foreach($objUser as $k=>$v){$poststring .= '&'.$k.'='.$v;}
			$poststring .='&action=email_verified';
		}
	$post_url = $url;
	/*$user_id = $objUser->nUser_ID;
	$username = urlencode($objUser->sEmail);
	$password = urlencode($objUser->sPassword);
	$forename = urlencode($objUser->sForename);
	$surname = urlencode($objUser->sSurname);
	$itemnumber = urlencode($objPaymentPlan->sItemNumber);
	$itemname = urlencode(get_level_name_by_payment_plan($objPaymentPlan->nPaymentPlan_ID));
	*/

	//$fields = "user_id=$user_id&username=$username&password=$password&forename=$forename&surname=$surname&itemname=$itemname&itemnumber=$itemnumber&type=$type&action=$action"; 

	//open connection
	$ch = curl_init();
	//set the url, number of POST vars, POST data
	curl_setopt($ch,CURLOPT_URL,$post_url);
	curl_setopt($ch,CURLOPT_POST,1);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$poststring);
	//curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	
	//execute post
	$result = curl_exec($ch);
	//die($result);
	//close connection
	curl_close($ch);
	}	
?>