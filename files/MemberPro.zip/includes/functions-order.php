<?php

function order_rows($row_id,$order_type)
{
	global $dbo;
	//test if there is any order set up	
	$result=$dbo->select("SELECT COUNT(nLevel_ID) as nr FROM tblmembershiplevels where nOrder!='0'");
	$check=$dbo->getobj($result);
	
	//the member level i wanna change
	$sql="SELECT nOrder,sLevel FROM  tblmembershiplevels WHERE nLevel_ID='".$dbo->format($row_id)."'" ;
	$rs_=$dbo->select($sql);
	if(!empty($rs_))
		$row_=$dbo->getobj($rs_);	
		
	$my_id=$dbo->format($row_id);
	$my_sLevel=$row_->sLevel;	
	$my_order=$row_->nOrder;
	
	
	if($check->nr!=0)
	{
		$sql="SELECT nLevel_ID,nOrder FROM  tblmembershiplevels WHERE nOrder<'".$my_order."' ORDER BY nOrder ASC , sLevel ASC";
		$sql2="SELECT nLevel_ID,nOrder FROM  tblmembershiplevels WHERE nOrder>'".$my_order."' ORDER BY nOrder ASC , sLevel ASC";	
	}
	else {
		$sql="SELECT nLevel_ID,nOrder FROM  tblmembershiplevels WHERE sLevel<'".$my_sLevel."' ORDER BY nOrder ASC , sLevel ASC";
		$sql2="SELECT nLevel_ID,nOrder FROM  tblmembershiplevels WHERE sLevel>'".$my_sLevel."' ORDER BY nOrder ASC , sLevel ASC";	
	}
	
	$rs_=$dbo->select($sql);
	$rs2_=$dbo->select($sql2);
	
	
	if(!empty($rs_))
		while($row_=$dbo->getobj($rs_))
			$id1[]=$row_->nLevel_ID;
			
		
	if(!empty($rs2_))
		while($row2_=$dbo->getobj($rs2_))
			$id2[]=$row2_->nLevel_ID;		
			
						
	if($order_type=='up'){		
			if(sizeof($id1)!=0)
			foreach ($id1 as $key=>$value){
				//if it is not the last one
				if($key+1!=sizeof($id1))
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".$key."' WHERE nLevel_ID='".$value."'");
				else 
				{
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".$key."' WHERE nLevel_ID='".$my_id."'");
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".($key+1)."' WHERE nLevel_ID='".$value."'");
				}				
			}
			if(sizeof($id2)!=0)
			foreach ($id2 as $key2=>$value2){
			//if it is not the last one				
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".($key+2+$key2)."' WHERE nLevel_ID='".$value2."'");				
			}
			
	}
		
		if($order_type=='down'){	
			if(sizeof($id1)!=0)	
			foreach ($id1 as $key=>$value){				
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".$key."' WHERE nLevel_ID='".$value."'");				
			}
			if(sizeof($id2)!=0)
			foreach ($id2 as $key2=>$value2){
				//if it is the first one
				if($key2==0)
				{
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".($key+1)."' WHERE nLevel_ID='".$value2."'");
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".($key+2)."' WHERE nLevel_ID='".$my_id."'");
				}
				else 
					$dbo->update("UPDATE tblmembershiplevels set nOrder='".($key+2+$key2)."' WHERE nLevel_ID='".$value2."'");
				
			}
			
	}}
	
function order_page_rows($row_id,$did,$order_type)
{
	global $dbo;
	//test if there is any order set up	
	$result=$dbo->select("SELECT COUNT(nPage_ID) as nr FROM tblpages where nSortOrder!='0' AND nDirectory_ID = '$did'");
	$check=$dbo->getobj($result);
	
	//the member level i wanna change
	$sql="SELECT nSortOrder,nPage_ID FROM  tblpages WHERE nPage_ID='".$dbo->format($row_id)."' AND nDirectory_ID = '$did'" ;
	//die($sql);
	$rs_=$dbo->select($sql);
	if(!empty($rs_))
		$row_=$dbo->getobj($rs_);	
		
	$my_id=$dbo->format($row_id);
	$my_nPage_ID=$row_->nPage_ID;	
	$my_order=$row_->nSortOrder;
	
	
	if($check->nr!=0)
	{
		$sql="SELECT nPage_ID,nSortOrder FROM  tblpages WHERE nSortOrder<'".$my_order."' AND nDirectory_ID = '$did' ORDER BY nSortOrder ASC , nPage_ID ASC";
		$sql2="SELECT nPage_ID,nSortOrder FROM  tblpages WHERE nSortOrder>'".$my_order."' AND nDirectory_ID = '$did' ORDER BY nSortOrder ASC , nPage_ID ASC";	
	}
	else {
		$sql="SELECT nPage_ID,nSortOrder FROM  tblpages WHERE nPage_ID<'".$my_nPage_ID."' AND nDirectory_ID = '$did' ORDER BY nSortOrder ASC , nPage_ID ASC";
		$sql2="SELECT nPage_ID,nSortOrder FROM  tblpages WHERE nPage_ID>'".$my_nPage_ID."' AND nDirectory_ID = '$did' ORDER BY nSortOrder ASC , nPage_ID ASC";	
	}
	
	$rs_=$dbo->select($sql);
	$rs2_=$dbo->select($sql2);
	
	
	if(!empty($rs_))
		while($row_=$dbo->getobj($rs_))
			$id1[]=$row_->nPage_ID;
			
		
	if(!empty($rs2_))
		while($row2_=$dbo->getobj($rs2_))
			$id2[]=$row2_->nPage_ID;		
			
						
	if($order_type=='up'){		
			if(sizeof($id1)!=0)
			foreach ($id1 as $key=>$value){
				//if it is not the last one
				if($key+1!=sizeof($id1))
					$dbo->update("UPDATE tblpages set nSortOrder='".$key."' WHERE nPage_ID='".$value."'");
				else 
				{
					$dbo->update("UPDATE tblpages set nSortOrder='".$key."' WHERE nPage_ID='".$my_id."'");
					$dbo->update("UPDATE tblpages set nSortOrder='".($key+1)."' WHERE nPage_ID='".$value."'");
				}				
			}
			if(sizeof($id2)!=0)
			foreach ($id2 as $key2=>$value2){
			//if it is not the last one				
					$dbo->update("UPDATE tblpages set nSortOrder='".($key+2+$key2)."' WHERE nPage_ID='".$value2."'");				
			}
			
	}
		
		if($order_type=='down'){	
			if(sizeof($id1)!=0)	
			foreach ($id1 as $key=>$value){				
					$dbo->update("UPDATE tblpages set nSortOrder='".$key."' WHERE nPage_ID='".$value."'");				
			}
			if(sizeof($id2)!=0)
			foreach ($id2 as $key2=>$value2){
				//if it is the first one
				if($key2==0)
				{
					$dbo->update("UPDATE tblpages set nSortOrder='".($key+1)."' WHERE nPage_ID='".$value2."'");
					$dbo->update("UPDATE tblpages set nSortOrder='".($key+2)."' WHERE nPage_ID='".$my_id."'");
				}
				else 
					$dbo->update("UPDATE tblpages set nSortOrder='".($key+2+$key2)."' WHERE nPage_ID='".$value2."'");
				
			}
			
	}}
	
function reorder_pages_onDelete($delid,$deldid,$delsort){
	global $dbo;
	$sql = "SELECT nPage_ID,nSortOrder FROM tblpages WHERE nDirectory_ID = '$delid' AND nSortOrder > $delsort ORDER BY nSortOrder ASC";
	while($row = $dbo->getobject($sql)){
		$newsort = $row->nSortOrder -1;
		$dbo->update("Update tblpages SET nSortOrder = '$newsort' WHERE nPage_ID = '".$row->nPage_ID."' LIMIT 1;");
		}
	}