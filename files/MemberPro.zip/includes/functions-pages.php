<?php  
// Get php page contents
	function get_page($sFilename) {
		ob_start();
		require($sFilename);
		return ob_get_clean();
	}
	function isFreePage($nPage_ID) {
		global $dbo;
		$nFreeLevel_ID = $dbo->getval ("SELECT nLevel_ID FROM tblmembershiplevels WHERE sLevel='Free'");
		$result = $dbo->select("SELECT 1 FROM tblpagelevels WHERE nPage_ID=$nPage_ID AND nLevel_ID=$nFreeLevel_ID LIMIT 1");
		return $result;
	}
	function does_page_exist($file_name = '', $page_id = 0){
		global $dbo;
		// Run a query against the database table.
		$sql = "SELECT nPage_ID FROM tblpages WHERE sFileName = '$file_name';";
		// Lets check to see if this is a new page, or a previously created page.
		if($page_id != 0){
			// Setting New Page Name for Previously Created Page.
			// Lets ensure we dont trigger a false positice by finding the page we are editing
			$sql = "SELECT nPage_ID FROM tblpages WHERE sFileName = '$file_name' AND nPage_ID !='".$page_id."';";
			}
		$page_exist_sql = $dbo->getrow($sql);
	
		// Test if the returned row contains a numerical value - if so, then the page already exists.
		$page_exist = (is_numeric($page_exist_sql['nPage_ID']) ? true : false);
	
		// Free the mysql resource.
		unset($page_exist_sql);
	
		// Return the boolean value.
		return $page_exist;
	}
	
	function usePageLevels($pagedir){
			global $dbo;
			// Setup Page Right
			// No Rights For Main Directory Pages. returns false
			
			// Main Directory: Id = 0, Parent Id = -1
			// Members  Directory: Id = 1, Parent Id = -1 returns true
			
			if($pagedir == '0'){return false;}
			elseif($pagedir == '1'){return true;}
			
			// Main Directories Processed.
			// Sub Directories Left
			
			// Lets Get The Direct Parent.
			$parent = $dbo->getval("SELECT nParent_ID FROM tbldirectories WHERE nDirectory_ID = '".$pagedir."' ");
			
			if($parent == '0'){return false;}
			elseif($parent == '1'){return true;}
			
			// Sub Directories Processed.
			// Second Level Sub Directories Left
			
			$subparent = $dbo->getval("SELECT nParent_ID FROM tbldirectories WHERE nDirectory_ID = '".$parent."' ");
			
			if($subparent == '0'){return false;}
			else{return true;}
		}

?>