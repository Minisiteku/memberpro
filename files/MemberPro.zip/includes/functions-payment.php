<?php
function get_payment_plan_by_item_number($nItemNumber, $sProcessorName) {
	global $dbo;
	$sql 	= sprintf("SELECT P1.*, P3.sLevel FROM (tblpaymentplans P1 " 
    		. "INNER JOIN tblpaymentprocessors P2 ON P1.nPaymentProcessor_ID = P2.nPaymentProcessor_ID) "
    		. "INNER JOIN tblmembershiplevels P3 ON P1.nMembershipLevel_ID = P3.nLevel_ID "
    		. "WHERE P1.sItemNumber='%s' AND P2.sProcessorName='%s'", $dbo->format($nItemNumber), $dbo->format($sProcessorName));
    $objPaymentPlan = $dbo->getobject($sql);
    return $objPaymentPlan;   }

function get_payment_plan_by_id($nPaymentPlan_ID) {
	global $dbo;
	$sql 	= sprintf("SELECT P1.*, P3.sLevel FROM (tblpaymentplans P1 " 
    		. "INNER JOIN tblpaymentprocessors P2 ON P1.nPaymentProcessor_ID = P2.nPaymentProcessor_ID) "
    		. "INNER JOIN tblmembershiplevels P3 ON P1.nMembershipLevel_ID = P3.nLevel_ID "
    		. "WHERE P1.nPaymentPlan_ID=%s", $dbo->format($nPaymentPlan_ID));
    $objPaymentPlan = $dbo->getobject($sql);
    return $objPaymentPlan;}

function get_user_account_expiration_date($objUser, $objPaymentPlan) {
	if ($objUser->nActive)
    	$expdate = get_expiry_date_days($objPaymentPlan->nRegularPeriod, $objPaymentPlan->sRegularPeriod, $objUser->nDateExpires);
    else
    	$expdate = get_expiry_date_days($objPaymentPlan->nRegularPeriod, $objPaymentPlan->sRegularPeriod);
   
    return $expdate;}

function activate_user_account($nUser_ID) {
	global $dbo;
	$sql = sprintf("UPDATE tblusers SET nActive=1, sPaymentStatus='Paid' WHERE nUser_ID = %s",$dbo->format($nUser_ID));                
	$dbo->update($sql);	
	if($dbo->error){die("<p class='error'>".$dbo->error."</p>");}}

function set_user_account_expiration_date($nUser_ID, $sExpDate) {
	global $dbo;
	$sql = sprintf("UPDATE tblusers SET nDateExpires = %s WHERE nUser_ID = %s", $sExpDate, $nUser_ID);
    $dbo->update($sql);
	if($dbo->error){die("<p class='error'>".$dbo->error."</p>");}}

function get_user_account_subscription_period($objUser, $objPaymentPlan) {
	if ($objUser->nActive)
    	$sExpDate = get_expiry_date_days($objPaymentPlan->nRegularPeriod, $objPaymentPlan->sRegularPeriod, $objUser->nDateExpires);
    else
    	$sExpDate = get_expiry_date_days($objPaymentPlan->nRegularPeriod, $objPaymentPlan->sRegularPeriod);
    return $sExpDate;   }

	function add_new_signup($objUser, $objPaymentPlan, $nTransaction_ID, $bPayment = false) {
		global $dbo;
		$levelId = add_level($objUser, $objPaymentPlan, $nTransaction_ID, $bPayment);
		
		//error_log('added level, ');
		if (!$objUser->nActive) {
			activate_user_account($objUser->nUser_ID);
			
			// Send email to administrators
			email_admin_signup($objUser, $objPaymentPlan);
				
			// Send login details to the  member
			//error_log('activated account, sent email to admin');
			email_member_signup($objUser, $objPaymentPlan);
			//error_log('sent email to member');
		}
		if ($objUser->nConfirmed == '0') {
			
			// CONFIRMATION TABLE - Stores Inormation to be completed later by either email confirmation, ipn completion, or admin confirmation.
			// This is used for Free processor Via email confirm link.
			// We also create a confirm for paid members as well, as confirmation of payment received.
			// This later can be more of a session storage engine for upgrading, or reactivating membership levels.
					
			// Lets Check For An Existing Confirm Code.
			$sql = "SELECT * FROM tbluserconfirm WHERE nUser_ID = '$objUser->nUser_ID' AND nPaymentPlan_ID = '$objPaymentPlan->nPaymentPlan_ID' AND nConfirmStatus = '0';";
			$res = $dbo->select($sql);
	
			if($dbo->nr($res)){
						
				$confRow = $dbo->getobj($res);
				
				// Update The Conf Record
				$sql = "UPDATE `tbluserconfirm` SET 
				`nConfirmTime` = '".time()."',
				`sConfirmIp` = '".$_SERVER['REMOTE_ADDR']."',
				`nConfirmStatus` = '1',
				`nConfirmMethod` = '2' 
				WHERE `nConfirm_ID` ='".$confRow->nConfirm_ID."';";
				
				$dbo->update($sql);
						
						
			}
			else{
				
				// Add The Confirm Entry
				$sql = "
				INSERT INTO `tbluserconfirm` (
				`nConfirm_ID` ,
				`nUser_ID` ,
				`nAffiliate` ,
				`nPaymentPlan_ID` ,
				`nSignupTime` ,
				`sSignupIp` ,
				`nConfirmTime` ,
				`sConfirmIp` ,
				`nConfirmStatus` ,
				`nConfirmMethod`)
				VALUES (
				NULL , '".$objUser->nUser_ID."', '0', '".$_SESSION['validated']['objPaymentPlan']->nPaymentPlan_ID."', '".time()."', '".$_SERVER['REMOTE_ADDR']."', 
				'".time()."', '".$_SERVER['REMOTE_ADDR']."', '1', '2');";
							
				$dbo->insert($sql);
			}
			/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			
			
			
			$sql = "UPDATE tblusers SET nConfirmed = '1' WHERE nUser_ID = '$objUser->nUser_ID' ;";
			$dbo->update($sql);
			
			// Send email to administrators
			email_admin_signup($objUser, $objPaymentPlan);
				
			// Send login details to the  member
			//error_log('activated account, sent email to admin');
			email_member_signup($objUser, $objPaymentPlan);
			//error_log('sent email to member');
		}
		return $levelId;
	}

function add_new_payment($objUser, $objPaymentPlan, $nAmount,$sCurrencySymbol,$nTransaction_ID) {
	add_level($objUser, $objPaymentPlan, $nTransaction_ID, true);
	$nCommission = getAffiliateCommission($nAmount, $objUser->nAffiliate_ID); // Calculate affiliate commission amount
    addAffiliatesPayments($objUser->nAffiliate_ID, $objUser, $nCommission, get_level_name_by_payment_plan($objPaymentPlan->nPaymentPlan_ID), $sCurrencySymbol, $nTransaction_ID);}
?>