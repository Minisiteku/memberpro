<?php

function add_transaction ( $data, $transactiontype_id, $processor ) {
	
	global $dbo;
	
	// Transaction Number is Passed As $data['transid']. This can be confusing.
	// Start to pass it as $data['transnumber']
	if(isset($data['transnumber'])){$data['transid'] = $data['transnumber'];}
	
	// Clickbank reports as pennies.
	if(strtolower($processor) == 'clickbank') {
		if(strpos($data['amount'],".") === false) $data['amount'] = $data['amount']/100;
	}
	
	// For Anything Other than a new transaction we should be checking to see if a related transaction exists.
	
	// If refund
	if($transactiontype_id == 2){
		// Need To Look For A Sale To Match The refund
		$sql = "SELECT nTransactionType_ID FROM tbltransactions WHERE sTransactionNumber = '".$data['transid']."' AND nTransactionType_ID = '1' LIMIT 1;";
		if(!$dbo->num_rows($sql) || $dbo->num_rows($sql) == "0"){
			// No Sale Found
			error_log('EMP: Refund Called On Non Existent Transaction');
			exit;
			}
		// Sale Found ...
		// Lets make sure there isnt a refund already for this transaction
			$sql = "SELECT nTransactionType_ID FROM tbltransactions WHERE sTransactionNumber = '".$data['transid']."' AND nTransactionType_ID = '2' LIMIT 1;";
			if($dbo->num_rows($sql) == "1"){
			error_log('EMP: Refund Called On Already Refunded Transaction');
			exit;
			}
		}
	
	$sql = "
    INSERT INTO tbltransactions (
    nTransactionType_ID,
    sTransactionNumber,
    sUserEmail,
    sUserForename,
    sUserSurname,
    sAffEmail,
    sAffForename,
    sAffSurname,
    sProcessor,
    nSaleAmount,
    nCommissionAmount,
	nUser_ID) 
    VALUES (
    '" . $transactiontype_id . "',
    '" . $data['transid'] . "', 
    '" . $data['email'] . "',
    '" . $data['firstname'] . "', 
    '" . $data['lastname'] . "', 
    '" . $data['aff_email'] . "',
    '" . $data['aff_firstname'] . "',
    '" . $data['aff_lastname'] . "',
    '" . $processor . "',
    '" . $data['amount'] . "',
    '" . $data['payout'] . "',
	'" . $data['userid'] . "'
	);";
    if(!$trans_ID = $dbo->insert($sql)) error_log("Failed To Add Transaction: ".$dbo->error);
	return $trans_ID;			
 }

?>