<?php

	function insert_user (
		$sForename, $sSurname, $sAddr1, $sAddr2 = '', $sAddr3 = '', $sTown = '', $sCounty = '', 
		$sPostcode = '', $sCountry = '', $sEmail, $sTelephone = '', $sMobile = '', 
		$sPaypalEmail, $sPassword, $sCustomField1, $sCustomField2, $sCustomField3, 
		$sCustomField4, $sCustomField5, $sCustomField6, $sCustomField7, $sCustomField8, 
		$sCustomField9, $sCustomField10, $nAffiliate_ID = 0
		) {
			
		global $dbo;
		$objAffiliateSettings = $dbo->getrow("SELECT * FROM tblaffiliatesettings");
		// Date & Time
		$today = date("Ymd");
		$time = date("g:i a");  
		$aff = ($objAffiliateSettings->nAutoEnroll == 1) ? 1:0;
		// Insert user into database
		$sql = "
		INSERT INTO tblusers (
		sForename,
		sSurname,
		sAddr1,
		sAddr2,
		sAddr3,
		sTown,
		sCounty,
		sPostcode,
		sCountry,
		sEmail,
		sTelephone,
		sMobile,
		nJoinDate,
		sJoinTime,
		sPaypalEmail,
		sPassword,
		nActive,
		nAffiliate,
		nAffiliate_ID,
		sPaymentStatus,
		sCustomField1,
		sCustomField2,
		sCustomField3,
		sCustomField4,
		sCustomField5,
		sCustomField6,
		sCustomField7,
		sCustomField8,
		sCustomField9,
		sCustomField10
		) VALUES (
		'" . $dbo->format($sForename) . "',
		'" . $dbo->format($sSurname) . "',
		'" . $dbo->format($sAddr1) . "',
		'" . $dbo->format($sAddr2) . "',
		'" . $dbo->format($sAddr3) . "',
		'" . $dbo->format($sTown) . "',
		'" . $dbo->format($sCounty) . "',
		'" . $dbo->format($sPostcode) . "',
		'" . $dbo->format($sCountry) . "',
		'" . $dbo->format($sEmail) . "',
		'" . $dbo->format($sTelephone) . "',
		'" . $dbo->format($sMobile) . "',
		'$today',
		'$time',
		'" . $dbo->format($sPaypalEmail) . "',
		'" . $dbo->format($sPassword) . "',
		0,
		$aff,
		'" . $dbo->format($nAffiliate_ID) . "',
		'',
		'" . $dbo->format($sCustomField1) . "',
		'" . $dbo->format($sCustomField2) . "',
		'" . $dbo->format($sCustomField3) . "',
		'" . $dbo->format($sCustomField4) . "',
		'" . $dbo->format($sCustomField5) . "',
		'" . $dbo->format($sCustomField6) . "',
		'" . $dbo->format($sCustomField7) . "',
		'" . $dbo->format($sCustomField8) . "',
		'" . $dbo->format($sCustomField9) . "',
		'" . $dbo->format($sCustomField10) . "'
		)";
		
		//$res10 = mysql_query($sql)or die('query failed');
		
		$nUser_ID = $dbo->insert($sql);
		$objUser = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID = '$nUser_ID'");
		$objUser->ip = $_SERVER['REMOTE_ADDR'];
			// Hook
			//die(var_dump($nUser_ID));
		pluginClass::action("user_Added",$objUser);
		// Return nUser_ID
		return $nUser_ID;}
	
	// Version 3 - Will Replace The Above Soon.
	
	// Adds A New User Into The Database.
	// Accepts an object with the user data and the referring affiliate id, if applicable
	function add_user($objUser,$nAffiliate_ID = 0){
		// Load Our Database Object.
		
		global $dbo;
		// Get Affiliate Settings
		$objAffiliateSettings = $dbo->getobject("SELECT * FROM tblaffiliatesettings");
		
		// Define Affiliate Status Based On Auto Enroll Setting. 
		$affstatus = ($objAffiliateSettings->nAutoEnroll == 1) ? '1':'0';
		
		// Date & Time
		$today = date("Ymd");
		$time = date("g:i a");  
		
		// Insert user into database
		$sql = "
		INSERT INTO tblusers (sForename,sSurname,sAddr1,sAddr2,sAddr3,sTown,sCounty,sPostcode,sCountry,sEmail,sTelephone,sMobile,nJoinDate,sJoinTime,sPaypalEmail,sPassword,nActive,nAffiliate,nAffiliate_ID,sPaymentStatus,sCustomField1,sCustomField2,sCustomField3,sCustomField4,sCustomField5,sCustomField6,sCustomField7,sCustomField8,sCustomField9,sCustomField10)
		VALUES (
		'" . $dbo->format($objUser->sForename) . "',
		'" . $dbo->format($objUser->sSurname) . "',
		'" . $dbo->format($objUser->sAddr1) . "',
		'" . $dbo->format($objUser->sAddr2) . "',
		'" . $dbo->format($objUser->sAddr3) . "',
		'" . $dbo->format($objUser->sTown) . "',
		'" . $dbo->format($objUser->sCounty) . "',
		'" . $dbo->format($objUser->sPostcode) . "',
		'" . $dbo->format($objUser->sCountry) . "',
		'" . $dbo->format($objUser->sEmail) . "',
		'" . $dbo->format($objUser->sTelephone) . "',
		'" . $dbo->format($objUser->sMobile) . "',
		'$today',
		'$time',
		'" . $dbo->format($objUser->sPaypalEmail) . "',
		'" . $dbo->format($objUser->sPassword) . "',
		0,
		$affstatus,
		'" . $dbo->format($nAffiliate_ID) . "',
		'',
		'" . $dbo->format($objUser->sCustomField1) . "',
		'" . $dbo->format($objUser->sCustomField2) . "',
		'" . $dbo->format($objUser->sCustomField3) . "',
		'" . $dbo->format($objUser->sCustomField4) . "',
		'" . $dbo->format($objUser->sCustomField5) . "',
		'" . $dbo->format($objUser->sCustomField6) . "',
		'" . $dbo->format($objUser->sCustomField7) . "',
		'" . $dbo->format($objUser->sCustomField8) . "',
		'" . $dbo->format($objUser->sCustomField9) . "',
		'" . $dbo->format($objUser->sCustomField10) . "'
		)";
		
		//$res10 = mysql_query($sql)or die('query failed');
		
		$nUser_ID = $dbo->insert($sql);
		$objUser = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID = '$nUser_ID'");
		$objUser->ip = $_SERVER['REMOTE_ADDR'];
			// Hook
			//die(var_dump($nUser_ID));
		pluginClass::action("user_Added",$objUser);
		// Return nUser_ID
		return $nUser_ID;	
		
	}
	
	function delete_user($id){
		global $dbo;
		// Get the User
	
		$delUser = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID = ".$dbo->format($id).";");
	
		// Delete Member
	
		$dbo->delete("DELETE FROM tblusers WHERE nUser_ID = '" . $dbo->format($_POST['id']) . "' AND nUser_ID != 1 LIMIT 1;");
		
		// Delete cancellations, if applicable
		$sql = "DELETE FROM tblcancellations WHERE nUser_ID = '" . $dbo->format($_POST['id']) . "' AND nUser_ID != 1 LIMIT 1;";
		$dbo->delete($sql);
		
		// Delete User Levels
		$sql = "DELETE FROM tbluserlevels WHERE nUser_ID = '" . $dbo->format($_POST['id']) . "' AND nUser_ID != 1 LIMIT 1;";
		$dbo->delete($sql);
		
		$sql = "DELETE FROM tbluserlogins WHERE nUser_ID = '" . $dbo->format($_POST['id']) . "' AND nUser_ID != 1 LIMIT 1;";
		$dbo->delete($sql);
	
			// Hook
	
		pluginClass::action("userDeleted",$delUser);
				
		}
	
	function set_user_level_privileges($nUser_ID) {
		global $dbo;
		
		$today = date("Ymd");
		
		// Get user levels which are still active
		// Inactive levels have nDateCancelled greater than 0 and have nDateExpires prior to today's date
		//$sql = "SELECT nLevel_ID FROM tbluserlevels WHERE nUser_ID = " . $dbo->format($nUser_ID) . " AND nActive = 1 AND nDateCancelled = 0 OR (nDateExpires > $today AND nDateCancelled > 0) ";
		$sql = "SELECT nLevel_ID FROM tbluserlevels WHERE nUser_ID = " . $dbo->format($nUser_ID) . " AND nActive = 1";
		$rs = $dbo->select ( $sql );
		if (! empty ( $rs )) {
			while ( $rw = $dbo->getobj ( $rs ) ) {
				$userLevel [] = $rw->nLevel_ID;
			}
		}
		$userLevel = @implode ( '\',\'', $userLevel );
		//check if the user is a paid user 
		
	
		//get the id of the free level
		$sqlFreeLevel = "SELECT nLevel_ID FROM tblmembershiplevels WHERE sLevel='Free'";
		$rsFreeLevel = $dbo->select ( $sqlFreeLevel );
		if (! empty ( $rsFreeLevel )) {
			$rwFreeLevel = $dbo->getobj ( $rsFreeLevel );
			$FreeLevelID = $rwFreeLevel->nLevel_ID;
			//$userLevel .= "','" . $FreeLevelID;
		}
		
		$_SESSION['user_levels'] = $userLevel;}
	
	function get_user_level_privileges() {return $_SESSION['user_levels'];}
	
	function get_firstlast( $name ) {
		if ( !isset( $name ) ) {
			return;
		}
		else {
			$aName = explode( " ", $name );
			$user['firstname'] = $aName[0];
			$user['lastname'] = "";
			$i = 1;
			for ( ; $i < count( $aName ); ++$i )
			{
				$user['lastname'] .= $aName[$i]." ";
			}
			$user['lastname'] = substr( $user['lastname'], 0, -1 );
			return $user;
		}}
	
	function get_user( $email ) {
		global $dbo;
		$sql = "SELECT * FROM tblusers WHERE sEmail='" . $dbo->format($email) . "'";
		$user = $dbo->getrow( $sql );
		$user['sEmail'] = isset( $user['sEmail'] ) ? $user['sEmail'] : "";
		return $user;}
	
	function get_user_by_id ( $user_id ) {
		global $dbo;
		$sql = "SELECT * FROM tblusers WHERE nUser_ID='" . $dbo->format($user_id) . "'";
		$user = $dbo->getobject( $sql );
		return $user;}
		
	function get_user_name_by_id($user_id){
		global $dbo;
		$sql = "SELECT sForename, sSurname FROM tblusers WHERE nUser_ID='" . $dbo->format($user_id) . "'";
		$user = $dbo->getobject( $sql );
		return $user->sForename.' '.$user->sSurname;}
	
	function get_user_by_email ( $email ) {
		global $dbo;
		$sql = "SELECT * FROM tblusers WHERE sEmail='" . $dbo->format($email) . "'";
		$user = $dbo->getobject( $sql );
		return $user;}
		
	function get_userid_by_email ( $email ) {
		global $dbo;
		$sql = "SELECT nUser_ID FROM tblusers WHERE sEmail='" . $dbo->format($email) . "'";
		$result = $dbo->select( $sql );
		$row = $dbo->getassoc($result);
		return $row[0];}
	
	function add_level($objUser, $objPaymentPlan, $sTransactionNumber, $bPayment = false) {
		global $dbo;
		//$handle = fopen(dirname(__FILE__).'New-Level-EXPIRELOG.log', "a+");
		$errlog = "";    
		$nNow = date("Ymd");
		$nDateExpires = $nNow;
		$bAdd =  true;
		
		$sql = sprintf("SELECT COUNT(*) as nCount , MAX(nDateExpires) nDateExpires FROM tbluserlevels WHERE nUser_ID = %s AND nLevel_ID = %s", $dbo->format($objUser->nUser_ID), $dbo->format($objPaymentPlan->nMembershipLevel_ID));
		$objLevel = $dbo->getobject($sql);
		if ($objLevel->nCount > 0) {
			$errlog .="Count is greter than one.\n\r";
			$errlog .="$sql \n\r";
			
			if ($objLevel->nDateExpires > $nNow) {
				$nDateExpires = $objLevel->nDateExpires;
			}
		} 
				
		$sql = sprintf("SELECT * FROM tbluserlevels WHERE nUser_ID = %s AND nLevel_ID = %s AND sTransactionNumber = '%s'", $dbo->format($objUser->nUser_ID), $dbo->format($objPaymentPlan->nMembershipLevel_ID), $dbo->format($sTransactionNumber));
		$result = $dbo->getrow($sql);
		$errlog .= $sql."\n";
		if ($result === false) {
			$errlog .="Result is false, go through the ist \n\r";
			if (($objPaymentPlan->nTrial1Period > 0) && (($objPaymentPlan->nTrialAmount1 == 0) || ($bPayment))) {
				$errlog .="running first set of conditions \n\r";
				$nPeriod = $objPaymentPlan->nTrial1Period;
				$sPeriod = $objPaymentPlan->sTrial1Period;	
			} elseif (($bPayment) || ($objPaymentPlan->nRegularAmount == 0)) {
				$errlog .="running second set of conditions \n\r";
				$nPeriod = $objPaymentPlan->nRegularPeriod;
				$sPeriod = $objPaymentPlan->sRegularPeriod;
			} else {
				$bAdd = false;
				$errlog .="set badd to false \n\r";
			}
			if ($bAdd) {
				//die(var_dump($objPaymentPlan));
				$errlog .="badd is true \n\r";
				$errlog .="expire is $nPeriod, $sPeriod \n\r";
				$nDateExpires = date('Y-m-d');
				$errlog .="today is $nDateExpires \n\r";
				
				
				$nExpirationDate = get_expiry_date_days($nPeriod, $sPeriod);
				
				// If Expire = 19691231 Lets Assume Future And Change To 20380101
								
								if($nExpirationDate == 19700101){$nExpirationDate = 20380101;}
				
				
				$errlog .="expire date is $nExpirationDate \n\r";
				// Insert row
				$nPaymentCounter = $bPayment ? 1 : 0;
				$today = date("Ymd");
				$sql = sprintf("INSERT INTO tbluserlevels
				(nUser_ID,nLevel_ID,nPaymentPlan_ID,sTransactionNumber,nDateExpires,nPaymentCounter,nCoupon_ID,nDateActive) 
							  VALUES (%s, %s, %s, '%s', %s, %s, %s, $today)",
						  $dbo->format($objUser->nUser_ID), 
						  $dbo->format($objPaymentPlan->nMembershipLevel_ID), 
						  $dbo->format($objPaymentPlan->nPaymentPlan_ID), 
						  $dbo->format($sTransactionNumber),
						  $nExpirationDate,
						  $dbo->format($nPaymentCounter),
						  isset($objPaymentPlan->nCoupon_ID) ? $objPaymentPlan->nCoupon_ID : 0);
				$returnLevelId = $dbo->insert($sql);
			}
		} else {
			$errlog .="Result is true \n\r";
			$nPaymentCounter = $result['nPaymentCounter'];
			switch ($nPaymentCounter) {
				case 0:
					$errlog .="case is 0 \n\r";
					if (($objPaymentPlan->nTrial1Period > 0) || (($objPaymentPlan->nTrialAmount1 == 0) || ($bPayment))) {
						$errlog .="condition 1 \n\r";
						$nPeriod = $objPaymentPlan->nTrial1Period;
						$sPeriod = $objPaymentPlan->sTrial1Period;	
					} elseif (($bPayment) || ($objPaymentPlan->nRegularAmount == 0)) {
						$errlog .="condition 2 \n\r";
						$nPeriod = $objPaymentPlan->nRegularPeriod;
						$sPeriod = $objPaymentPlan->sRegularPeriod;
					} else {
						$errlog .="badd is false \n\r";
						$bAdd = false;
					}
					break;
				case 1:
					$errlog .="case is 1 \n\r";
					if ((($objPaymentPlan->nTrial1Period > 0) && ($objPaymentPlan->nTrial2Period > 0))  && (($objPaymentPlan->nTrialAmount2 == 0) || ($bPayment))) {
						$errlog .="condition 1 \n\r";
						$nPeriod = $objPaymentPlan->nTrial2Period;
						$sPeriod = $objPaymentPlan->sTrial2Period;	
					} elseif (($bPayment) || ($objPaymentPlan->nRegularAmount == 0)) {
						$errlog .="condition 2 \n\r";
						$errlog .="Expire Params $objPaymentPlan->nExpirePeriod $objPaymentPlan->sExpirePeriod; \n\r";
						$nPeriod = $objPaymentPlan->nRegularPeriod;
						$sPeriod = $objPaymentPlan->sRegularPeriod;
					} else {
						$errlog .="badd is false \n\r";
						$bAdd = false;
					}
					break;	
				default:
					$errlog .="case is default \n\r";
					if (($bPayment) || ($objPaymentPlan->nRegularAmount == 0)) {
						$errlog .="condition 1 \n\r";
						$nPeriod = $objPaymentPlan->nRegularPeriod;
						$sPeriod = $objPaymentPlan->sRegularPeriod;
					} else {
						$bAdd = false;
						$errlog .="badd is false \n\r";
					}
					break;		
			};
			if ($bAdd) {
				$errlog .="add is true, adding record ... other expire date $nDateExpires \n\r";
				$nExpirationDate = get_expiry_date_days($nPeriod, $sPeriod);
				$sql = "
				UPDATE tbluserlevels SET 
				nDateExpires = '$nExpirationDate' ".
				($bPayment ? 
				", nPaymentCounter = nPaymentCounter + 1 " 
				: " ") . 
				" WHERE sTransactionNumber = '".$dbo->format($sTransactionNumber)."'";
				
				$dbo->update($sql);
				$returnLevelId = $result->nUserLevel_ID;
			}
			return $returnLevelId;
		}
		
		// Add HTTP Post
		// Send username/password(md5)/forename/surname/item_name/user_id
		send_post($objUser, $objPaymentPlan);
		
		// Update user level access 
		set_user_level_privileges($objUser->nUser_ID);
		// Hook
		$objUser->nLevel_ID = $objPaymentPlan->nMembershipLevel_ID;
		pluginClass::action("user_AddLevel",$objUser);
		//fwrite($handle,$errlog);
		//fclose($handle);
	}
	/**
	Removes the membership Level From The User
	*/
	function cancel_level($nTransaction_ID, $bRefund = false) {
		global $dbo;
		//V2 - Set cancel date To determine if user level was active. On refund It Set CAncel date to crazy long time ago.
		//$today = $bRefund ? "19000101" : date("Ymd"); 
		$today = date("Ymd");
		// V3 will use an nActive field instead, lol.
		
		($bRefund) ? $active = '0' : $active = '1';
		
		$sql = "UPDATE tbluserlevels SET nDateCancelled = $today, nActive = '$active' WHERE sTransactionNumber = '$nTransaction_ID'";
		$dbo->update($sql);
		if($dbo->error){die("<p class='error'>".$dbo->error."</p>");}
			
		// Add HTTP Post
		$sql = "SELECT nUser_ID, nPaymentPlan_ID FROM tbluserlevels WHERE sTransactionNumber='$nTransaction_ID' LIMIT 1";
		$objUserLevels = $dbo->getobject($sql);
		$objPaymentPlan = $dbo->getobject("SELECT * FROM tblpaymentplans WHERE nPaymentPlan_ID={$objUserLevels->nPaymentPlan_ID}");
		$objUser = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID={$objUserLevels->nUser_ID}");
		
		send_post($objUser, $objPaymentPlan, 'cancelled');
		// Hook
		pluginClass::action("user_CancelLevel");
		}
	/**
	/**
	Processes the User Auto Cancellation System
	*/
	function user_auto_cancel_level($nUserLevel_ID) {
		global $dbo, $chkSsettings;
		$today = date("Ymd");
		
		$sql = "UPDATE tbluserlevels SET nDateCancelled = $today, nActive = 0 WHERE nUserLevel_ID = '$nUserLevel_ID' LIMIT 1;";
		$dbo->update($sql);
		if($dbo->error){die("<p class='error'>".$dbo->error."</p>");}
		
		// Send Emails
		email_member_cancellation($nUserLevel_ID);
			
		// Admin Email
		email_admin_cancel_notice($nUserLevel_ID);
			
		// Add HTTP Post
		//$sql = "SELECT nUser_ID, nPaymentPlan_ID FROM tbluserlevels WHERE sTransactionNumber='$nTransaction_ID' LIMIT 1";
		//$objUserLevels = $dbo->getobject($sql);
		//$objPaymentPlan = $dbo->getobject("SELECT * FROM tblpaymentplans WHERE nPaymentPlan_ID={$objUserLevels->nPaymentPlan_ID}");
		//$objUser = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID={$objUserLevels->nUser_ID}");
		
		//send_post($objUser, $objPaymentPlan, 'cancelled');
		}
	
	/**
	 * Calculates date after given period of time (1 days, 7 months, 20 minutes etc) 
	 *
	 * @param integer $nCount Number of intervals
	 * @param string $sPeriod Type of interval ('day', 'month', 'year')
	 * @param string $sExpiryDate Date till acount is valid
	 * @return string Date in yearmonthday format
	 */
	function get_expiry_date_days( $nCount, $sPeriod = 'Days', $sExpiryDate = null  ) {
		if($nCount == 0){return '20380101';}
		
		if (is_null($sExpiryDate)) {
			return date('Ymd', strtotime('+' . $nCount . ' ' . $sPeriod));
		} else {
			$sNow = date('Ymd');
			if ($sExpiryDate > $sNow) {
				return date('Ymd', strtotime('+' . $nCount . ' ' . $sPeriod, strtotime($sExpiryDate)));
			} else {
				return date('Ymd', strtotime('+' . $nCount . ' ' . $sPeriod));
			}
		}
	   }

?>