<?php

// ========================

// FRONT END FUNCTIONS

// ========================
function displayVideoEmbedCode($matches, $location = "",$splashfile,$splashpath) {
	global $sSiteURL;
	$videos = array();

	foreach ($matches as $k=>$match) {

		// Get Video ID
		preg_match('/\d+/', $match, $found);

		$video_id = $found[0];

		// Should The Video Autoplay?

		$autoplay = preg_match('/AUTOPLAY/', $match);

		// Video Height

		$height = preg_match('/HEIGHT=\d+/', $match, $heightvar);

		$heightvar1 = ($height == 1) ? str_replace("HEIGHT=", "", $heightvar[0]) : "480";

		// Video Width

		$width = preg_match('/WIDTH=\d+/', $match, $widthvar);

		$widthvar1 = ($width == 1) ? str_replace("WIDTH=", "", $widthvar[0]) : "640";

		$output = '<div align="center">';
		
		
		// Flow Player Code
		$output .= '<a href="' . $sSiteURL . '/' . $location . 'videoprotect.php?id=' . $video_id . '" style="display:block;width:' . $widthvar1 . 'px;height:' . $heightvar1 . 'px" id="player' . $video_id . '">';
		
		// Use Splash Screen
		if(!$autoplay){
			// DO we have one, or need to use default?
			if(!$splashfile[$video_id] || $splashfile == '' || $autoplay ==1){
				// using default
				$output .='<img src="'.$splashpath.'default.jpg'.'" alt="Play Video" />';
			}	
			else{
				$output .='<img src="'.$splashpath.$splashfile[$video_id].'" alt="Errors With Video" />';
				
			}
		}
		
		$output .='</a></div>';
		
		// Built Script call
		$autoBool = ($autoplay) ? 'true' : 'false';
		$output .='<script>$f("player' . $video_id . '", { src:"' . $sSiteURL . '/js/flowplayer/flowplayer-3.2.8.swf",';
		$output .= ''."wmode: 'transparent',".'clip: { autoPlay: '.$autoBool.' }}';

		$output .=')</script>';

		$videos[] = $output;

	}
	

	return $videos;
	}



// ========================

// ADMIN FUNCTIONS

// ========================



define('VIDEO_UPLOAD_PATH','assets');

// Declare accepted file extensions for video

$extensions = array('flv','mov','m4v','mp4','avi','ogv');


function getVideoDirListing($path) {

	$path = VIDEO_UPLOAD_PATH . $path;

	$f = array();

	$d = array();

	$dir_handle = opendir($path) or die('failed to open '.$path);

	while ($file = readdir($dir_handle))

	{
		if ((is_file($path . '/' . $file)) && (substr($file,1) != '.') && ($file != 'index.php')) {

			$f[] = $file;

		} elseif(($file != '.') && ($file != '..') && (is_dir($path . '/' . $file))) {

			$d[] = $file;

		}

	

	}

	

	return array('file' => $f, 'dir' => $d);}



function getDbVideosListing($path) {

	global $dbo;

	$r = array();

	$sql = sprintf("SELECT sFilename FROM tblvideos WHERE sPath = '%s'", $dbo->format($path));

	if ($rs = $dbo->select($sql)) {

		while($file = $dbo->getobj($rs)) {

			$r[] = $file->sFilename;

		}

	}

	

	return $r;}



function addRemoteVideoToDb($url) {
	global $dbo, $extensions;
	$url = trim($url);
	$urlArray = parse_url($url);
	$urlArray = explode("/", $urlArray['path']);
	$urlFile = array_reverse($urlArray);
	$urlFile = $urlFile[0];

	$type = get_type(strtolower(substr($urlFile, strrpos($urlFile, '.')+1)));

	$extension = strtolower(substr($urlFile, strrpos($urlFile, '.')+1));

	$id = 0;

	if (in_array($extension, $extensions)) {

		$sql = sprintf("INSERT INTO tblvideos (sFilename, sURL, sType) 

		VALUES('%s', '%s', '%s');", $dbo->format($urlFile), $dbo->format($url), $dbo->format($type));
		$id = $dbo->insert($sql);
	}
	return $id;}



function addVideosToDb($path, $recursively = true) {

	global $dbo, $extensions;

	$count = 0;

	$dbfiles = getDbVideosListing($path);

	$list = getVideoDirListing($path);
	//die(var_dump($list));

	$files = $list['file'];

	$folders = $list['dir'];

	$newfiles = array_diff($files, $dbfiles);

	$s = substr($path, strlen($path)-1,1);

	foreach ($newfiles as $file) {
		//die(strtolower(substr($file, strrpos($file, '.')+1)));
		if(!function_exists('get_type')){die('no function');}
		$type = get_type(strtolower(substr($file, strrpos($file, '.')+1)));
		$extension = strtolower(substr($file, strrpos($file, '.')+1));
		if (in_array($extension, $extensions)) {

		$sql = sprintf("INSERT INTO tblvideos (sFilename, sPath, sType) 

			VALUES('%s', '%s', '%s');", $dbo->format($file), $dbo->format($path), $dbo->format($type));
		$dbo->insert($sql);

		$count++;

		}  	

	} 
	if ($recursively) {

		foreach ($folders as $dir) {

			if (($dir != '.') && ($dir != '..')) {

				

				

				if (($s == '/') || ($s == '\\')) {

					$count+= addVideosToDb($path . $dir);

				} else {

					$count+= addVideosToDb($path . '/' . $dir);

				}

			}

		}

	}

	return $count;}



function removeVideosFromDb() {

	global $dbo;

	$count = 0;
	// Add Is Null To Run Sync On Local Files Only ... Duh ... MDP 10-19-12
	$sql = "SELECT nVideo_ID, sFilename, sPath FROM tblvideos WHERE sURL IS NULL";

	if ($rs = $dbo->select($sql)) {

		while($file = $dbo->getobj($rs)) {

			if (strlen(utf8_decode($file->sPath)) == 1) {

				$path = sprintf("%s/%s", VIDEO_UPLOAD_PATH, utf8_decode($file->sFilename));

			} else {

				$path = sprintf("%s%s/%s", VIDEO_UPLOAD_PATH, utf8_decode($file->sPath), utf8_decode($file->sFilename));

			}

			if (!is_file($path)) {

				$sql = sprintf("DELETE FROM tblvideos WHERE nVideo_ID = %s", $dbo->format($file->nVideo_ID));

				$dbo->select($sql);	

				$count++;

			}

			

		}

	}

	return $count;

	
}

?>