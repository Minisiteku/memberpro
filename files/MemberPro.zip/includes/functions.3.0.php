<?php
// Get Release Version From Easy Member Pro Site.
	function currentversion(){
		// Gets the Current Version From THe Remote Server, and sets a cookie to check against.
		
		if($_COOKIE['currentVersion']){return $_COOKIE['currentVersion'];}
		else{
			// Check for Most Recent Version of EMP
			$url = "http://licensing.easymemberpro.com/current-version.php";
			$ch = curl_init();    // initialize curl handle
			curl_setopt($ch, CURLOPT_URL,$url); // set url to post to
			curl_setopt($ch, CURLOPT_FAILONERROR, 1);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);// allow redirects
			curl_setopt($ch, CURLOPT_RETURNTRANSFER,1); // return into a variable
			curl_setopt($ch, CURLOPT_TIMEOUT, 3); // times out after 4s
			//curl_setopt($ch, CURLOPT_POST, 1); // set POST method
			//curl_setopt($ch, CURLOPT_POSTFIELDS, "url=index%3Dbooks&field-keywords=PHP+MYSQL"); // add POST fields
			$result = curl_exec($ch); // run the whole process
			curl_close($ch);
			setcookie("currentVersion", $result, time()+60*60*24);  
			return $result;
		}
	}
	function checkversion(){
		global $DEVOPTS;
		// Version Update Check - MDP - 5-13-2012
		
		$newversion = currentversion(); // Get The Current Version from Easymemberpro.com
		$currentversion = get_emp_version();
		$upgradeUrl = (isset($DEVOPTS['SOFTWAREURL']))?
		$DEVOPTS['SOFTWAREURL']:'http://www.easymemberpro.com/member/index.php?page=v3';
		
		$upgradeMessage = "
		<a href='".$upgradeUrl."' target=\"_new\">Upgrade to Version $newversion Now!</a>";
		
		return(version_compare($newversion,$currentversion) == 1)?$upgradeMessage:false;
	}
	
// Member cancellation system
	function admin_cancel_level($nUserLevel_ID,$nCancellation_ID) {
		global $dbo, $chkSsettings;
		$today = date("Ymd");
		
		// Lets grab some data
		$sql = "SELECT * FROM tblcancellations WHERE nCancellation_ID = $nCancellation_ID";
		$canceldata = $dbo->getobject($sql);
		
		// Cancel The member Level
		$sql = "UPDATE tbluserlevels SET nDateCancelled = $today, nActive = 0 WHERE nUserLevel_ID = '".$nUserLevel_ID."' LIMIT 1;";
		$dbo->update($sql);
		if($dbo->error) die("<p class='error'>".$dbo->error."</p>");
		
		// Update The Cancellation Request
		$sql = "UPDATE `tblcancellations` SET `nProcess_date` = '".time()."',`nProcess_type` = '0',`nStatus` = '1' WHERE `nCancellation_ID` =".$nCancellation_ID." LIMIT 1 ;";
		$dbo->update($sql);
		if($dbo->error) die("<p class='error'>".$dbo->error."</p>");
		
		// Send Emails
			// Member Email
		// Get various data for use in email tags
		$sql2 = "SELECT tbluserlevels.*, tblusers.*, tblmembershiplevels.sLevel FROM tbluserlevels
		LEFT JOIN tblusers on tblusers.nUser_ID = tbluserlevels.nUser_ID
		LEFT JOIN tblmembershiplevels on tblmembershiplevels.nLevel_ID = tbluserlevels.nLevel_ID
		WHERE nUserLevel_ID = '".$nUserLevel_ID."' ";
		
		$data = $dbo->getobject($sql2);
		$user = $data->sForename . ' ' . $data->sSurname;
		
		$sql = "SELECT * FROM tblemailtemplates WHERE sType = 'MEMBER_CANCEL_NOTICE' LIMIT 1;";
		$objEmail = $dbo->getobject($sql);
		
		// Parse Email Tags
		// Site Information
		$objEmail->sBody = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[OWNER]]", $chkSsettings->sSiteOwner, $objEmail->sBody);
		// Member Information
		$objEmail->sBody = str_replace("[[NAME]]", $user, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[FORENAME]]", $data->sForename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SURNAME]]", $data->sSurname, $objEmail->sBody);
		// Membership Level Data
		$objEmail->sBody = str_replace("[[MEMBER_LEVEL]]", $data->sLevel, $objEmail->sBody);
		
		
		$objEmail->sBodyHtml = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[OWNER]]", $chkSsettings->sSiteOwner, $objEmail->sBodyHtml);
		
		$objEmail->sBodyHtml = str_replace("[[NAME]]", $user, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[FORENAME]]", $data->sForename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SURNAME]]", $data->sSurname, $objEmail->sBodyHtml);
		
		$objEmail->sBodyHtml = str_replace("[[MEMBER_LEVEL]]", $data->sLevel, $objEmail->sBodyHtml);
		
		
		$objEmail->sSubject = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sSubject);
			
		$success = multipart_email($data->sEmail, $chkSsettings->sSupportEmail, $objEmail->sSubject, $objEmail->sBodyHtml, $objEmail->sBody);
		//die($success);	
			// Admin Email
		//die($data->sForename . ' ' . $data->sSurname);
		
		$sql = "SELECT * FROM tblemailtemplates WHERE sType = 'ADMIN_CANCEL_NOTICE' LIMIT 1;";
		$objEmail = $dbo->getobject($sql);
			
		// Parse Email Tags
		// Site Information
		$objEmail->sBody = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[OWNER]]", $chkSsettings->sSiteOwner, $objEmail->sBody);
		// Member Information
		$objEmail->sBody = str_replace("[[NAME]]", $user, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[FORENAME]]", $data->sForename, $objEmail->sBody);
		$objEmail->sBody = str_replace("[[SURNAME]]", $data->sSurname, $objEmail->sBody);
		// Membership Level Data
		$objEmail->sBody = str_replace("[[MEMBER_LEVEL]]", $data->sLevel, $objEmail->sBody);
		
		
		$objEmail->sBodyHtml = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SITEURL]]", $chkSsettings->sSiteURL, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[OWNER]]", $chkSsettings->sSiteOwner, $objEmail->sBodyHtml);
		
		$objEmail->sBodyHtml = str_replace("[[NAME]]", $user, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[FORENAME]]", $data->sForename, $objEmail->sBodyHtml);
		$objEmail->sBodyHtml = str_replace("[[SURNAME]]", $data->sSurname, $objEmail->sBodyHtml);
		
		$objEmail->sBodyHtml = str_replace("[[MEMBER_LEVEL]]", $data->sLevel, $objEmail->sBodyHtml);
		
		
		$objEmail->sSubject = str_replace("[[SITENAME]]", $chkSsettings->sSiteName, $objEmail->sSubject);
			
			
		multipart_email($chkSsettings->sAdminEmail, $chkSsettings->sSupportEmail, $objEmail->sSubject, $objEmail->sBodyHtml, $objEmail->sBody);
		
		// Hook
		$obj = object;
		$obj->nUser_ID = $canceldata->nUser_ID;
		$obj->nLevel_ID = $canceldata->nLevel_ID;
		pluginClass::action("user_CancelLevel",$obj);
			
		// Add HTTP Post
		//$sql = "SELECT nUser_ID, nPaymentPlan_ID FROM tbluserlevels WHERE sTransactionNumber='$nTransaction_ID' LIMIT 1";
		//$objUserLevels = $dbo->getobject($sql);
		//$objPaymentPlan = $dbo->getobject("SELECT * FROM tblpaymentplans WHERE nPaymentPlan_ID={$objUserLevels->nPaymentPlan_ID}");
		//$objUser = $dbo->getobject("SELECT * FROM tblusers WHERE nUser_ID={$objUserLevels->nUser_ID}");
		
		//send_post($objUser, $objPaymentPlan, 'cancelled');
		}
	
function add_option($k,$v){
	global $dbo;
	$sql = "INSERT INTO `tbloptions` (`sName` ,`sValue`)VALUES ('$k', '$v');";
	if($dbo->insert($sql)){
		// Update The Session
		$_SESSION['options'][$k] = $v;
		return true;}
	else{return false;}
	}
function update_option($k,$v){
	global $dbo;
	//die('here');
	$sql = "UPDATE `tbloptions` SET `sValue` = '$v' WHERE `sName` = '$k' LIMIT 1 ;";
	//die($sql);
	//die(var_dump(mysql_query($sql)));
	if($dbo->update($sql)){
		//die($sql);
		// Update The Session
		$_SESSION['options'][$k] = $v;
		return true;
		
	}
	else{return false;}
}
function remove_option($k){
	global $dbo;
	$sql = "DELETE FROM `tbloptions` WHERE `sName` = '$k' LIMIT 1";
	if($dbo->delete($sql)){unset($_SESSION['options'][$k]);return true;}
	else{return false;}
	}
function get_option($k){
	global $dbo;
	$sql = "SELECT `svalue` FROM tbloptions WHERE `sName` = '$k' LIMIT 1;";
	return ($_SESSION['options'][$k])?$_SESSION['options'][$k]:$dbo->getval($sql);
	}
function is_option($k){
	global $dbo;
	$sql = "SELECT `sname` FROM tbloptions WHERE `sName` = '$k' LIMIT 1;";
	return ($dbo->num_rows($sql) == 1)?true:false;
	
}
?>