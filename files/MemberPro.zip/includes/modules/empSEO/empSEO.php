<?php
	// This is an EMP system module.
	if( !defined( "INEMP" ) ){header("HTTP/1.0 403 Forbidden");die();}
	
	class empSEO extends plugin {
	
		function __construct(){
			global $dbo;
			
			add_action('page_new_Success',array(&$this,'updateSEOMeta'));
			add_action('page_edit_Success',array(&$this,'updateSEOMeta'));
			
			add_filter('page_new_bottom',array(&$this,'displaySEOBox'));
			add_filter('page_edit_bottom',array(&$this,'displaySEOBox'));
			
			add_filter('main_template',array(&$this,'setSEOTags'));
			add_filter('member_template',array(&$this,'setSEOTags'));
			
			add_filter('page_edit_page_query',array(&$this,'addMetaToQuery'));
		
			// Check If The Meta Table Exists
			$meta = $dbo->getval('select 1 from `tblpagemeta`;');
	
			if(!$meta)
			{
				$sql = "CREATE TABLE IF NOT EXISTS `tblpagemeta` (
  				`nMeta_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  				`nPage_ID` bigint(20) NOT NULL,
  				`sMetaKey` varchar(255) CHARACTER SET latin1 NOT NULL,
  				`sMetaValue` longtext COLLATE utf8_unicode_ci NOT NULL,
  				PRIMARY KEY (`nMeta_ID`),
  				KEY `Main Query` (`nPage_ID`,`sMetaKey`))
				ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci 
				COMMENT='This Table Allows You To Attach Additional Attributes To The Page Table.' 
				AUTO_INCREMENT=1 ;";
				$dbo->create($sql);
			}
		}
		
		private function getMetaData($id)
		{
			global $dbo;
			$meta = new stdClass;
			$sql = "SELECT sMetaKey,sMetaValue FROM tblpagemeta WHERE nPage_ID = '$id' AND `sMetaKey` LIKE 'empseo_%'";
			$res = $dbo->select($sql);
			if(!empty($res))
			{
				while($row = $dbo->getobj($res))
				{
					$meta->{$row->sMetaKey} = $row->sMetaValue;
				}
			}
			
			return $meta;
		}
		
		private function generateDescription($content, $max=100, $append='&hellip;')
		{
    		if (strlen($text) <= $max) return $text;

			$replacements = array(
				'|<br /><br />|' => ' ',
				'|&nbsp;|' => ' ',
				'|&rsquo;|' => '\'',
				'|&lsquo;|' => '\'',
				'|&ldquo;|' => '"',
				'|&rdquo;|' => '"',
			);
		
			$patterns = array_keys($replacements);
			$replacements = array_values($replacements);


			$content = preg_replace($patterns, $replacements, $content); // convert double newlines to spaces
			$content = strip_tags($content); // remove any html.  we *only* want text
			$out = substr($content, 0, $max);
			if (strpos($content, ' ') === false) return $out.$append;
			return preg_replace('/(\W)&(\W)/', '$1&amp;$2', (preg_replace('/\W+$/', ' ', preg_replace('/\w+$/', '', $out)))) . $append;
	}
		
		function displaySEOBox($content)
		{
			global $dbo, $rw1;
			// $rw1 comes from the edit page screen.
			$objPage = $rw1;
			
			if(is_object($objPage)){$objMeta = $this->getMetaData($objPage->nPage_ID);}
			
			ob_start() ?>
			<br />
			<table width="100%" border="0" cellpadding="0" cellspacing="1" class="gridtable">
			  
			  <tr>
				<td colspan="2" class="gridheader">EMP SEO Options</td>
			  </tr>
			  <tr>
				<td class="gridrow2">SEO Title</td>
				<td class="gridrow2"><input name="empseo_title" type="text" id="empseo_title" value="<?php echo (isset($objMeta->empseo_title))?$objMeta->empseo_title:'' ?>" size="62" />
				  <br />
				Most search engines use a maximum of 60 chars for the title. </td>
			  </tr>
			  <tr>
				<td class="gridrow2">SEO Description</td>
				<td class="gridrow2"><label for="seo_description"></label>
				<textarea name="empseo_description" id="empseo_description" cols="45" rows="3" class="mceNoEditor"><?php echo (isset($objMeta->empseo_description))?$objMeta->empseo_description:'' ?></textarea>     
				<br />
				Most search engines use a maximum of 160 chars for the description. </td>
			  </tr>
			  <tr>
				<td class="gridrow2">SEO Keywords (comma separated):</td>
				<td class="gridrow2"><label for="empseo_keywords"></label>
				<input name="empseo_keywords" type="text" id="seo_keywords" value="<?php echo (isset($objMeta->empseo_keywords))?$objMeta->empseo_keywords:'' ?>" size="62" /></td>
			  </tr>
			</table>
			<?php
			
			return $content.ob_get_clean();
		}
		
		function updateSEOMeta($objPage)
		{
			global $dbo;
			
			$objMeta = $this->getMetaData($objPage->nPage_ID);
			if(isset($_POST)){
				foreach($_POST as $k => $v){
					if($k == 'empseo_title' || $k == 'empseo_description' || $k == 'empseo_keywords'){
						
						//die("INSERT INTO `tblpagemeta` (`nPage_ID` ,`sMetaKey` ,`sMetaValue`)VALUES ('{$objPage->nPage_ID}', '$k', '{$dbo->format($v)}');");
						if(isset($objMeta->$k)){$dbo->update("UPDATE tblpagemeta SET sMetaValue = '$v' WHERE sMetaKey = '$k' AND nPage_ID = '{$objPage->nPage_ID}';");}
						else{
							if(!$dbo->insert("INSERT INTO `tblpagemeta` (`nPage_ID` ,`sMetaKey` ,`sMetaValue`)VALUES ('{$objPage->nPage_ID}', '$k', '{$dbo->format($v)}');")){die($dbo->error);}
							}
						
						
					}
				}
			}
		}
		
		function setSEOTags($template)
		{
			global $objPage,$content;	//We should be able to grab this from the index.php page code.
			$meta = $this->getMetaData($objPage->nPage_ID);
			
			$subsitutes = array(
			'[[EMPSEO_TITLE]]' => (!empty($meta->empseo_title)) ? $meta->empseo_title : $sSitename ,
			'[[EMPSEO_DESCRIPTION]]' => (!empty($meta->empseo_description)) ? $meta->empseo_description:$this->generateDescription($content,'50'),
			'[[EMPSEO_KEYWORDS]]' => (!empty($meta->empseo_keywords)) ? $meta->empseo_keywords : '');
			
			foreach ($subsitutes as $k => $v) {
				$template = str_replace($k, $v, $template);
			}
			
			return $template;
		}
		
		
	}
	$empSEO = new empSEO;

?>