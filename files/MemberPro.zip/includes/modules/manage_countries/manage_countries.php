<?php
	class manage_countries
	{
		
		function __construct()
		{
			add_filter('admin_menu_settings_general',array(&$this,'addmenu'));
			add_filter('admin_head',array(&$this,'addjs'));
			
			add_action('admin_actions',array(&$this,'ajax_actions'));
			
			add_page(get_class($this),'settings');
			
			// Check The table
			
			global $dbo;
			// Lets look for the sort column
			$sql = "Show columns from tblcountries like 'sort';";
			if($dbo->num_rows($sql) ==0){
			
				$sql = "ALTER TABLE `tblcountries` ADD `sort` INT NOT NULL DEFAULT '0';";
				$dbo->exec($sql);
				
				// Update The Sort by id for first time.
				$sql = "UPDATE `tblcountries` SET `sort` = id;";
				$dbo->update($sql);
	
			}
		}
		
		function addmenu($content)
		{
			$content.='<li> <a href="expanded.php?plugin=manage_countries&page=settings" target="_top">
			<img src="../includes/modules/manage_countries/images/globe_icon.png" /> &nbsp;Countries</a></li>';
			
			return $content;
		}
		
		function addjs($content){
			
			ob_start();
			?>
			<link type="text/css" rel="stylesheet" href="../common/css/jqueryui/redmond/jquery-ui-1.8.24.custom.css">
   			<script language="javascript" src="../js/jquery-ui-1.8.24.custom.min.js"></script>
   			<?php
   			return $content.ob_get_clean();
		}
		
		public static function settings()
		{
			global $dbo;
			require_once('management.php');
		}
		
		function ajax_actions()
		{
			global $dbo;
			if($_POST){
				//die(var_dump($_POST));
				if($_POST['act'] == 'edit_country'){
					
					$sql = "UPDATE tblcountries SET country_name = '".$dbo->format($_POST['country_name'])."' WHERE country_code = '".$dbo->format($_POST['country_code'])."';";
					$dbo->update($sql);
					//die($sql);
					header("Location: ".$_SERVER['HTTP_REFERER'].$_SERVER['QUERY_STRING']);
				}
				if($_POST['act'] == 'resort'){
					foreach($_POST['list'] as $k => $v){
						$sql = "UPDATE tblcountries SET sort = '$k' WHERE country_code = '".str_replace('country_','',$v)."';";
						$dbo->update($sql);
					}
					echo 'List Updated Successfully';	
				}
			}
		}	
	}
$manage_countries = new manage_countries;
?>