<?php
	
	$sql = 'SELECT * FROM tblcountries ORDER BY `sort` ASC;';
	$res = $dbo->select($sql);
	
	
	//die($sql);
	//die(var_dump($dbo->nr($res)));
	
	
	?>
	<style>
	.dragndrop{
		margin-bottom:5px;
		height:20px;
		padding:5px;
		border:thin #000 solid;
		background: url("../common/images/header.gif") repeat-x scroll 0 0 #E6E6E6;
		color:#445588;
		font-weight:bold;
		cursor:move;	
		
		
	}
	</style>
    <script language="javascript" src="../js/jquery-ui-1.8.24.custom.min.js"></script>
	<script language="javascript">
	$(document).ready(function(){
		$('#sort_container').sortable({
        	opacity: 0.6,
        	cursor: 'move',
			update: function(event, ui) {
				var countryOrder = $(this).sortable('toArray');
				//console.log(fruitOrder);
				var url = 'expanded.php?plugin=manage_countries&page=settings';
				var post = {};
				post['list'] = countryOrder;
				post['act'] = 'resort';
				$.ajax({
					type: "POST",
					url: "actions.php?type=country",
					data: post,
					success:function (data)
					{$("#sort_message").html('<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>'+data+'</div>');
					}
				});
			}
		});
	});
	
	function editCountry(CC){
		
		$('#'+CC+"_display").hide();
		$('#'+CC+"_edit").show();
		
	}
</script>
<h1>Manage Country Lists</h1>
<p>This page allows you to setup the order of your country list, and also change the display name of your countries.</p>
<p>To arrange the order of your countries, simply click on a country and drag it to the location in while you prefer it to appear in the drop down lists.</p>
	<div id="sort_message"></div><br>
<br>

	<div id="sort_container">
	<?php
	while($row = $dbo->getobj($res)){
		?>
		<div id="country_<?php echo $row->country_code ?>" class="dragndrop">
			<span style="width:20px; margin-right:5px;float:right"><a href="javascript:editCountry('<?php echo $row->country_code ?>');">Edit</a></span>
			<span id="<?php echo $row->country_code ?>_display"><?php echo $row->country_name ?></span>
			<span id="<?php echo $row->country_code ?>_edit" style="display:none">
				<form action="actions.php" method="post">
					<input type="text" name="country_name" value="<?php echo $row->country_name ?>" /> <input name="" type="submit" value="Save"/>
					<input type="hidden" name="act" value="edit_country" />
					<input type="hidden" name="country_code" value="<?php echo $row->country_code ?>" />
				</form>
			</span>
		</div>
		<?php
		}
	?>
	
</div>