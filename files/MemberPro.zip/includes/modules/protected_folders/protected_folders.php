<?php
	/*
	Plugin Name: Protected Folders
	Plugin URI: 
	Description: This plugin will allow you to Protect any folder on the same domain as EMP.
	Author: Michael Price
	Version: 1.2
	Author URI: http://easymemberpro.com/
	*/
	#########################################################################
	### Easy Member Pro - Protected Folders Integration Plugin
	### Copyright 2012 Michael Price & Kim Standerline - Cash Money Marketers
	#########################################################################
	class protected_folders extends plugin {
		function __construct()
		{
			add_filter('admin_menu_content',array(&$this,'addmenu'));
			add_filter('admin_head',array(&$this,'addjs'));
			
			add_action('user_LoginSuccess',array(&$this,'dropcookies'));
			add_action('user_Logout',array(&$this,'clearcookies'));
			
			add_page(get_class($this),'settings');
			add_activate(get_class($this),'init');
			add_deactivate(get_class($this),'deactivate');
			add_delete(get_class($this),'delete');
			
			// This is basically an Installer.
			// From here you can run database operations ect ...
			global $dbo;
			$sql = "CREATE TABLE IF NOT EXISTS `protectedfolders` (
			`nId` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
			`sTitle` VARCHAR( 255 ) NOT NULL ,
			`sPath` VARCHAR( 255 ) NOT NULL ,
			`sUrl` VARCHAR( 255 ) NOT NULL ,
			`sMethod` VARCHAR( 255 ) NOT NULL ,
			`sFolderLevels` VARCHAR( 255 ) NOT NULL) 
			ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
			
			$dbo->create($sql);
			
		}
		// 
		
		static function deactivate()
		{
			// This is basically an Uninstaller.
			// From here you can run database operations ect ...
			global $dbo;
			$sql= "SELECT * from protectedfolders";
			$res = $dbo->select($sql);
			
			if($dbo->nr($res)){
				while ($row = $dbo->getobj($res)){
					
					// Remove The HtAccess Data
					$htcontent = @file_get_contents('../'.$row->sPath.'/.htaccess');
		
					$delim = '### Easy Member Pro Access';
					$msg = '';
					// remove the htaccess rules
		
					// Break it down into pieces 0= before EMP acesss 1= emp access rules 2= after emp access
					$str = explode($delim,$htcontent);
					//die(var_dump($str));
					// Update Emp Access rules
					$str[1] = "";
		
					// Put the File back together
					$newht = '';
					// Clear Blank Chunks
					foreach($str as $v){
						if($v!=''){$newht .= $v;}
					}
		
		
					$handle = @fopen('../'.$_POST['sFolderPath'].'/.htaccess','w');
					fwrite($handle,$newht);
					fclose($handle);
				}
			}
			return;
		}
			
		static function delete(){
			// This is basically an Uninstaller.
			// From here you can run database operations ect ...
			global $dbo;
			$sql = "DROP TABLE `protectedfolders`;";
			$dbo->drop($sql);
			return;
		}
			
		static private function getlevellist($levelcsv)
		{
			
			global $dbo;
			
			$sql = "SELECT sLevel FROM tblmembershiplevels WHERE nLevel_ID IN ($levelcsv); ";
			
			$rs = $dbo->select($sql);
			$select = '';
			
			if($dbo->nr($rs) > 1){
				
				while($row = $dbo->getobj($rs)) $select .= $row->sLevel.', ';
				
				// remove the last comma
				$select = substr_replace($select ,"",-1);
				$select = substr_replace($select ,"",-1);
				
			}
			else{
				$row = $dbo->getobj($rs);
				$select .=$row->sLevel;
			}
			
			return $select;
		}
		//
			
		static function addmenu()
		{
			return '<li> <a href="expanded.php?plugin=protected_folders&page=settings" target="_top">
			<img src="../includes/modules/protected_folders/images/menu-icon.png" /> &nbsp;Folder Protection</a></li>';
		}
		
		static function addjs($content)
		{
			ob_start();
			?>
			<script type="text/javascript">
			function show(id){
				document.getElementById(id).style.display = 'block';
				}
			</script>
			<?php
			$code=  ob_get_clean();
			return $content.$code;
		}
		
		static function dropcookies($objUser)
		{
			global $dbo,$chkSsetings;
			// Lets Set Cookies for Protected Folder Access
			// Get User ID
			// Get levels for user
			$query = "SELECT nLevel_ID FROM tbluserlevels WHERE nUser_ID='$objUser->nUser_ID' AND nActive = '1'";
			
			$res = $dbo->select($query);
			$user_levels = '';
			if($dbo->nr($res) > 0) while ($row = $dbo->getobj($res)) $user_levels .= $row->nLevel_ID . ',';
			else $user_levels = '0,';
			
			if(!$user_levels || $user_levels == '') $user_levels = '0,';
			// remove extra,
			$user_levels = substr($user_levels, 0, -1);
			$levelarray = explode(',',$user_levels);
			
			$siteDomain = str_replace('http://','',$chkSsettings->sSiteURL);
			// Strip the www to ensure cookie is read from both domains.
			$cookieDomain = str_replace('www.','',$siteDomain);
			// Set Protected Folders Cookie
			$sql = "SELECT * FROM protectedfolders";
			$result = $dbo->select($sql);
			if($dbo->nr($result)){
				while($row = $dbo->getobj($result)){
					$folderlevel = explode(',',$row->sFolderLevels);
					//die(var_dump($folderlevel));
					if(array_intersect($folderlevel,$levelarray)){
						// member has access to this folder, set the cookie
						setcookie($row->sTitle, '1', time()+3600*24,'/',$cookieDomain);
					}
				}
			}
		}
		
		static function clearcookies($objUser)
		{
			global $dbo;
			// Lets Set Cookies for Protected Folder Access
			// Get User ID
			
			// Get levels for user
			$query = "SELECT nLevel_ID FROM tbluserlevels WHERE nUser_ID='$objUser->nUser_ID' AND nActive = '1'";
			//die($query);
			$res = $dbo->select($query);
			$user_levels = '';
			if($dbo->nr($res) > 0){
				//die(var_dump($result2));
				while ($row = $dbo->getobj($res)) {$user_levels .= $row->nLevel_ID . ',';}
			}
			else{$user_levels = '0,';}
			if(!$user_levels || $user_levels == ''){$user_levels = '0,';}
			// remove extra,
			$user_levels = substr($user_levels, 0, -1);
			$levelarray = explode(',',$user_levels);
			
			$siteDomain = str_replace('http://','',$chkSsettings->sSiteURL);
			// Strip the www to ensure cookie is read from both domains.
			$cookieDomain = str_replace('www.','',$siteDomain);
			
			// Destroy Protected Folders Cookie
			$sql = "SELECT * FROM protectedfolders";
			$result = $dbo->select($sql);
			if($dbo->nr($result)){
				while($row = $dbo->getobj($result)){
					$folderlevel = explode(',',$row->sFolderLevels);
					if(array_intersect($folderlevel,$levelarray)) setcookie($row->sTitle, '1', time()-3600,'/',$cookieDomain);	
					}
				}
			}
			
		static function settings()
		{
			global $dbo,$chkSsettings;
	
			if(isset($_POST['add_protected']) && $_POST['add_protected'] == '1'){
				/// Add New Protected Folder
				
				$err = 0;
				if($_POST['sFolderName'] == ''){
					$err++;
					$eT = 1;$eTmsg = 'You Must Enter A Display Name';
				}
				else{
					// Lets check to see if the folder name already exists
					$name = $_POST['sFolderName'];
					$sql = "SELECT * FROM protectedfolders WHERE sTitle = '$name';";
					$res = $dbo->select($sql);
					//die($sql);
					$result = $dbo->getobj($res);
					$nr = $dbo->nr($result);
					//die(var_dump($nr));
					if($nr !=0){
						$eTmsg .='A Protected Folder With This Name Already Exists.';
						$err++;
					}
				}
					
				if($_POST['sFolderPath'] == ''){
					$ePmsg .='You Must Enter The Path To Your Folder.<br />';
					$err++;
					$eP = 1;
				}
				else{
					// Removing trailing / if applicable
					if(substr($_POST['sFolderPath'], -1) == '/') {$_POST['sFolderPath'] = substr($_POST['sFolderPath'], 0, -1);}
		
					// Lets check for a valid folder path
					$handle = fopen($_POST['sFolderPath'].'/.htaccess','a');
					if($handle == false){
						$ePmsg .='Folder Not Found. Please check the file path and try again.<br />';
						$err++;
						//die(var_dump($handle));
					}
				}
					
				if(!$_POST['nFolderLevels'] || $_POST['nFolderLevels'] == ''){
					$eLmsg .='You Must Choose At Least One Membership Level.';
					$err++;
					$eL = 1;
				}
					
				if($_POST['sFolderUrl'] == ''){
					$eUmsg .='You Must Enter The Folder Url.';
					$err++;
					$eU = 1;
				}
				
				$levelsString = implode(",", $_POST['nFolderLevels']);
				
				if($err == 0){
					$sql = "INSERT INTO `protectedfolders` (`nId` ,`sTitle` ,`sPath` ,`sUrl` ,`sMethod` ,`sFolderLevels`)
					VALUES (NULL , '".$_POST['sFolderName']."', '".$_POST['sFolderPath']."', '".$_POST['sFolderUrl']."', '".$_POST['sMethod']."', '$levelsString');";
					$result = $dbo->insert($sql) or die($dbo->error);
					
					//
					// Create the htaccess file
					//$handle = fopen('../'.$_POST['sFolderPath'].'/.htaccess','a') or die('failed to open');
					$msg = "### Easy Member Pro Access\nRewriteEngine On\nRewriteBase /\nRewriteCond %{HTTP_COOKIE} !".$_POST['sFolderName']."=1 [NC]\nRewriteRule .* ".$chkSsettings->sSiteURL."/index.php?page=login [L]\n### End Easy Member Pro Access";
					fwrite($handle,$msg);
					fclose($handle);
				}
				else{
					$_SESSION['err']['eUmsg'] = $eUmsg;
					$_SESSION['err']['ePmsg'] = $ePmsg;
					$_SESSION['err']['eNmsg'] = $eNmsg;
					$_SESSION['err']['eLmsg'] = $eLmsg;
					$_SESSION['err']['eNmsg'] = $eNmsg;
					$_SESSION['err']['eTmsg'] = $eTmsg;
					foreach($_POST as $k=>$v){$_SESSION['form'][$k] = $v;}
					$errmsg = 'Please Correct The Errors Below.';
					//die(var_dump($_SESSION['err']));
					header("Location: ".$_SERVER['HTTP_REFERER']."&errmsg=$errmsg");exit;}
			
		}
			elseif(isset($_POST['edit_protected']) && $_POST['edit_protected'] == '1'){
				$err = 0;
				if(!$_POST['id'] or $_POST['id'] == ''){
					$errmsg .='Unable to Edit Folder. Folder Id Missing';
					$err++;
				}
				if(!$_POST['nFolderLevels'] || $_POST['nFolderLevels'] == ''){
					$eLmsg .='You Must Choose At Least One Membership Level.';
					$err++;
					$eL = 1;
				}
				if($_POST['sFolderName'] == ''){
					$err++;
					$eT = 1;$eTmsg = 'You Must Enter A Display Name';
				}
				else{
					// Lets check to see if the folder name already exists
					$name = $_POST['sFolderName'];
					$sql = "SELECT * FROM protectedfolders WHERE sTitle = '$name' AND nId !=".$_POST['id'].";";
					//die($sql);
					$result = $dbo->select($sql);
					$nr = $dbo->nr($result);
					//die(var_dump($nr));
					if($nr !=0){
						$eTmsg .='A Protected Folder With This Name Already Exists.';
						$err++;
						$eT = 1;
						}
					}
					
				if($_POST['sFolderPath'] == ''){
					$ePmsg .='You Must Enter The Path To Your Folder.<br />';
					$err++;
					$eP = 1;
				}
				else{
					// Removing trailing / if applicable
					if(substr($_POST['sFolderPath'], -1) == '/') {$_POST['sFolderPath'] = substr($_POST['sFolderPath'], 0, -1);}
					// Lets check for a valid folder path
					$handle = @fopen($_POST['sFolderPath'].'/.htaccess','r');
					if($handle == false){
						$ePmsg .='Folder Not Found. Please check the file path and try again.<br />';
						$err++;
						$eP = 1;
					}
					else fclose($handle);
				}
					
				if($_POST['sFolderUrl'] == ''){
					$eUmsg .='You Must Enter The Folder Url.';
					$err++;
					$eU = 1;
				}
				
				$levelsString = implode(",", $_POST['nFolderLevels']);
				
				// Get current folder data
				$sql = "SELECT * FROM protectedfolders WHERE `nId` ='".$_POST['id']."' LIMIT 1 ;";
				$curres = $dbo->select($sql);
				
				if($dbo->nr($curres)){$curfolder = $dbo->getobj($curres);}
				
				
				if($err == 0){
					$sql = "UPDATE `protectedfolders` SET 
					`sTitle` = '".$dbo->format($_POST['sFolderName'])."',
					`sPath` = '".$dbo->format($_POST['sFolderPath'])."',
					`sUrl` = '".$_POST['sFolderUrl']."',
					`sFolderLevels` = '$levelsString' 
					WHERE `nId` ='".$_POST['id']."' LIMIT 1 ;";
					
					$result = $dbo->update($sql) or die($dbo->error);
					$editht = 0;
					// Check to see if htaccess needs to be edited.
					if($curfolder->sTitle != $_POST['sFolderName']){$editht = 1;}
					
					if($editht == 1){
						// Edit the htaccess file
						// Remove The HtAccess Data
						$htcontent = file_get_contents($_POST['sFolderPath'].'/.htaccess') or die('failed to open../'.$_POST['sFolderPath'].'/.htaccess');
						//while (!feof($handle)){$htcontent .=fread($fh, $objFile->nSize);}
		
						$delim = '### Easy Member Pro Access';
						$msg = '';
						// remove the htaccess rules
		
						// Break it down into pieces 0= before EMP acesss 1= emp access rules 2= after emp access
						$str = explode($delim,$htcontent);
						//die(var_dump($str));
						// Update Emp Access rules
						$str[1] = "### Easy Member Pro Access\nRewriteEngine On\nRewriteBase /\nRewriteCond %{HTTP_COOKIE} !".$_POST['sFolderName']."=1 [NC]\nRewriteRule .* ".$chkSsettings->sSiteURL."/index.php?page=login [L]\n### Easy Member Pro Access";
						
						// Put the File back together
						$newht = '';
						// Clear Blank Chunks
						foreach($str as $v){
							if($v!='') $newht .= $v; 
						}
		
		
						$handle = fopen('../'.$_POST['sFolderPath'].'/.htaccess','w');
						fwrite($handle,$newht);
						fclose($handle);
						$msg = 'Protected Folder Edited Successfully!';
						
						header("Location: expanded.php?plugin=protected_folders&page=settings&msg=$msg");
						
					}
		 
				}
				else{
					$_SESSION['err']['eUmsg'] = $eUmsg;
					$_SESSION['err']['ePmsg'] = $ePmsg;
					$_SESSION['err']['eNmsg'] = $eNmsg;
					$_SESSION['err']['eLmsg'] = $eLmsg;
					$_SESSION['err']['eNmsg'] = $eNmsg;
					$_SESSION['err']['eTmsg'] = $eTmsg;
					
					foreach($_POST as $k=>$v) $_SESSION['form'][$k] = $v;
					
					$errmsg = 'Please Correct The Errors Below.';
					
					header("Location: ".$_SERVER['HTTP_REFERER']."&errmsg=$errmsg");
					exit;
				}
			}
			else{
				if(isset($_GET['act']) && $_GET['act'] == 'delete'){
					$err = 0;
					if(!$_GET['id'] or $_GET['id'] == ''){
						$errmsg .='Unable to Delete Folder. Folder Id Missing<br />';
						header("Location: protected_folders.php?errmsg=$errmsg");
					}
					else{
						// Lets get the folder data
						$result = $dbo->select("SELECT * FROM `protectedfolders` WHERE `nId` = ".$_GET['id']." LIMIT 1");
						
						if($dbo->nr($result)) $objFolder = $dbo->getobj($result);
						else {$errmsg .='Folder Not Found!<br />';header("Location: protected_folders.php?errmsg=$errmsg");}
						
						// Remove The Folder From THe Database
						$result = $dbo->delete("DELETE FROM `protectedfolders` WHERE `nId` = ".$_GET['id']." LIMIT 1");
						
						// Remove The HtAccess Data
						if(file_exists($objFolder->sPath.'/.htaccess')){
							
							$htcontent = file_get_contents();
							$delim = '### Easy Member Pro Access';
							$msg = '';
							
							// Break it down into pieces 0= before EMP acesss 1= emp access rules 2= after emp access
							$str = explode($delim,$htcontent);
				
							// Clear Out Emp Access rules
							$str[1] = '';
				
							// Put the File back together
							$newht = $str[0].$str[1].$str[2];
							$handle = fopen('../'.$folder['sPath'].'/.htaccess','w');
							fwrite($handle,$newht);
							fclose($handle);	
						}
						
						?>
						<div class="notify-success"><div class="notify-close, success-close" onClick="closeNotify(this)"></div>Folder Protection Removed Successfully! </div>
						<a href="expanded.php?plugin=<?php echo $_GET['plugin'] ?>" >Click Here To Continue</a>
						
						<?php
					}
				}
			}
			
			// Lets Load Pages
			$newfolder = 'none';
			$act = 'add_protected';
			$acttext = 'Add New';
			
			if(isset($_GET['act']) && $_GET['act'] == 'edit'){
				$act = 'edit_protected';
				$acttext = 'Edit';
				$sql = "SELECT * FROM `protectedfolders` WHERE `nId` = '".$dbo->format($_GET['id'])."' LIMIT 1 ";
				$res = $dbo->select($sql);
				if($dbo->nr($res)){$folder = $dbo->getobj($res);}
				
			}
	
			// If an Error Message is Set, Keep The Add Form Visible
			if(isset($_GET['errmsg']) || $act == 'edit_protected') $newfolder = 'block'; ?>
			
			<div id="newprotectedfolder" style="display:<?php echo $newfolder  ?>;">
			
			<form action="" method="post">
					  <?php if(isset($_GET['errmsg']) && $_GET['errmsg'] !=''){echo $_GET['errmsg'];} ?>
					  <table class="gridTable" border="0" width="100%" cellspacing="0" cellpadding="0" id="newprotectedfolder">
						<tr>
						  <td>
							<table border="0" width="100%" cellspacing="1" cellpadding="0">
								<tr >
									<td colspan="2" class="gridheader"><?php echo $acttext ?> Protected Folder</td>
								</tr>
							  <tr >
							  <td width="189" class="gridrow2">Display Name</td>
							  <td width="551" class="gridrow2"><label for="sFolderName"></label>
								  <input name="sFolderName" type="text" id="sFolderName" style="width:200px;" value="<?php if($_SESSION['form']['sFolderName'])echo $_SESSION['form']['sFolderName']; else echo $folder->sTitle; ?>" size="400">
								  <?php echo $_SESSION['err']['eTmsg'] ?></td>
							</tr>
							  <tr>
							  <td class="gridrow2">Folder Path</td>
							  <td class="gridrow2"><input type="text" name="sFolderPath" id="sFolderPath" style="width:200px;" value="<?php echo (isset($folder->sPath))?$folder->sPath:$chkSsettings->sRootPath.'/' ?>">
								  <?php echo $_SESSION['err']['ePmsg'] ?></td>
							</tr>
							  <tr>
							  <td class="gridrow2">Folder Url</td>
							  <td class="gridrow2"><input name="sFolderUrl" type="text" id="sFolderUrl" style="width:400px;" value="<?php echo (isset($folder->sUrl))?$folder->sUrl:'' ?>" size="400">
								  <?php echo $_SESSION['err']['eUmsg'] ?></td>
							</tr>
							  <tr>
							  <td class="gridrow2">Protect Method</td>
							  <td class="gridrow2">Rewrite (cookie based)
								  <input name="sMethod" type="hidden" id="sMethod" value="Rewrite"></td>
							</tr>
							  <tr>
							  <td class="gridrow2">Access Rights</td>
							  <td class="gridrow2">
							  <?php
								$sql = "SELECT * FROM tblmembershiplevels  WHERE nActive='1' ORDER BY nOrder ASC , sLevel ASC";
								$rs = $dbo->select($sql);
								$access = explode(',',$folder->sFolderLevels);
								$opt = '';
		
								if (!empty($rs))
									while ($row = $dbo->getobj($rs)) {
										$selected = '';
										if(in_array($row->nLevel_ID,$access)) $selected = 'selected';
										
										$opt .= "<option value='" . $row->nLevel_ID . "'".$selected.">" . $row->sLevel . "</option>";
								}
	?>
								  <select name="nFolderLevels[]" multiple="multiple" id="nFolderLevels[]">
								  <?php echo $opt ?>
								</select>
								  <?php echo $_SESSION['err']['eLmsg'] ?></td>
							</tr>
							  <tr>
							  <td colspan="2" class="gridrow2"><input type="submit" name="button" id="button" value="<?php echo $acttext ?> Protection">
								  <input name="<?php echo $act ?>" type="hidden" id="<?php echo $act ?>" value="1">
								  <?php if($act == 'edit_protected'){
							?>
								  <input name="id" type="hidden" id="id" value="<?php echo $_GET['id'];?>">
								  <?php
							} ?>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</form>
		  </div>
		  
		  <table class="gridTable" border="0" width="100%" cellspacing="0" cellpadding="0">
			<tr>
					  <td><table border="0" width="100%" cellspacing="1" cellpadding="0">
						  <tr>
						  <td colspan="6" class="gridheader">Protected Folders <a href="javascript:void(0)" onClick="show('newprotectedfolder')" > <img  style="margin-bottom:-9px;" src="images/folder_add.png" alt="Add Folder" title="Add Folder" border="0"/> </a></td>
						</tr>
						  
						<?php
						$sql = "SELECT * FROM protectedfolders";
						$result = $dbo->select($sql);
						
						if(!$dbo->nr($result)){?>
							<tr>
								<td class="gridrow2" colspan="6">No Protected Folders</td>
							</tr>
						  <?php
							}
						else{ ?>
						
						<tr>
						  <td class="gridrow2">Name</td>
						  <td class="gridrow2">Url</td>
						  <td class="gridrow2">Path</td>
						  <td class="gridrow2">Protection Type</td>
						  <td class="gridrow2">Levels</td>
						  <td class="gridrow2">Actions</td>
						</tr>
						
						<?php
						  while($row = $dbo->getobj($result)){
							?>
						  <tr>
						  <td class="gridrow2"><?php echo $row->sTitle ?></td>
						  <td class="gridrow2"><a href="<?php echo $row->sUrl ?>" target="_blank"><?php echo $row->sUrl ?></a></td>
						  <td class="gridrow2"><?php echo $row->sPath ?></td>
						  <td class="gridrow2"><?php echo $row->sMethod ?></td>
						  <td class="gridrow2"><?php echo self::getlevellist($row->sFolderLevels) ?></td>
						  <td class="gridrow2"><a href="<?php echo $_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']?>&act=edit&id=<?php echo $row->nId?>"><img src="images/edit.gif" width="16" height="16" alt="Edit"></a> <a href="<?php echo $_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']?>&act=delete&id=<?php echo $row->nId?>" onClick="return confirm('Are you sure you want to remove protection from this folder?')"><img src="images/delete.gif" width="16" height="16" alt="Delete"></a></td>
						</tr>
						  <?php  
							  }
						}
						?>
						  <tr>
						  <td class="gridfooter" colspan="6">&nbsp;</td>
						</tr>
						</table></td>
					</tr>
		  </table>
			
			<?php
			}
			
	}
	$protected_folders = new protected_folders();
?>