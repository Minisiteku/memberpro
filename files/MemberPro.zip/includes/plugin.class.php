<?php
 // This bit checks if we are currently
 // running inside our website. It prevents
 // from overly curious people to launch 
 // this php file from outside of our script
 if( !defined( "INEMP" ) ){header("HTTP/1.0 403 Forbidden");die();}
 

 // This is the parent class for all plugins
 // It contains a private constructor, that
 // basically makes sure we won't have any
 // instances of our static classes. Making
 // them completely static.
 class plugin{private function __construct(){}}
 
 // This is the actual plugin class.
 class pluginClass{  
  
  // This will be the list of active plugins
  // $actions[$checkpoint][$plugin][$funct]
  static protected $plugins = array();
  static protected $actions = array();
  static protected $systemplugins = array();
  static protected $filters = array();
  static protected $pages = array();
  static protected $activate = array();
  static protected $deactivate = array();
  static protected $delete = array();

  // Again, we don't want any instances 
  // of our static class.
  public function __construct(){}
  
  static function initialize(){
  global $dbo,$chkSsettings;
   
   $list = array();   
   // Populate the list of directories to check against
   if ( ($directoryHandle = opendir( $chkSsettings->sRootPath . '/plugins/' )) == true ) {
       while (($file = readdir( $directoryHandle )) !== false) {
        // Make sure we're not dealing with a file or a link to the parent directory
           if( is_dir( $chkSsettings->sRootPath . '/plugins/' . $file ) && ($file == '.' || $file == '..') !== true )
            array_push( $list, $file );
       }
   }
   
   
   // Get the plugin list from MySQL.
   
   // Connect to mysql
   // We select all the plugins from our database
   // Each plugin has it's name stored, and whether
   // it is active or not (active = 0 or 1)
   $newResult = array();
   $res = $dbo->select( 'SELECT * FROM tblplugins');
   while($result = $dbo->getobj($res)){$newResult[$result->sName] = $result->nActive;}
   // Include the active plugins
   foreach( $list as $plugin ){
    if($newResult[$plugin] == "1"){self::load($plugin);}
   }
   //die(var_dump($newResult));
   
   // Lets Include System Modules ;) as of 3.0.7
   $modlist = array();
   // Populate the list of modules to include
   if ( ($directoryHandle = opendir( $chkSsettings->sRootPath . '/includes/modules/' )) == true ) {
       while (($file = readdir( $directoryHandle )) !== false) {
        // Make sure we ARE dealing with a file and NOT a Link to a parent (. or ..)
           if( is_dir( $chkSsettings->sRootPath . '/includes/modules/' . $file ) && $file != '.' && $file != '..') array_push( $modlist, $file );
		   
		  	
       }
   }
   //die(var_dump($modlist));
   foreach( $modlist as $module ) self::load_module($module);
   
   
   
   
  }
  
  // Internal Functions
  private function getRemoteVersion($url){
		//die($url);
		// Curl is the preferred method of remote files
		if(function_exists('curl_init')){
			
			$ch = curl_init();
			$timeout = 5;
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			//curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			$data = curl_exec($ch);
			curl_close($ch);
			return $data;
			
		}
		else{
			
			return file_get_contents($url);
			
		}
	}
  
  static public function get_page($plugin){
	  	return pluginClass::$pages[$plugin];
	  }
  static public function get_activate($plugin){return pluginClass::$activate;}
  static public function get_deactivate($plugin){
	  	return pluginClass::$deactivate;
	  }
  static public function get_delete($plugin){
	  	return pluginClass::$delete;
	  }
  
  static public function load($plugin){
   
   global $chkSsettings;
   require_once( $chkSsettings->sRootPath . "/plugins/$plugin/$plugin.php" );
  
   array_push( pluginClass::$plugins, $plugin );
  }
  
  // Module System - 3.0.7
  static public function load_module($module){
   
   global $chkSsettings;
   
   require_once( $chkSsettings->sRootPath . "/includes/modules/$module/$module.php" );
  
   array_push( pluginClass::$plugins, $module );
  }
  
  
  static function add_action($checkpoint,$funct){self::$actions[$checkpoint][] = $funct;}
  static function add_filter($checkpoint,$funct){self::$filters[$checkpoint][] = $funct;}
  static function add_page($plugin,$funct){self::$pages[$plugin] = $funct;}
  static function add_activate($plugin,$funct){self::$activate[$plugin] = $funct;}
  static function add_deactivate($plugin,$funct){self::$deactivate[$plugin] = $funct;}
  static function add_delete($plugin,$funct){self::$delete[$plugin] = $funct;}
  
	// Hook the active plugins at a checkpoint.
	static function action($checkpoint,$args = array()){
		if(self::$actions[$checkpoint]){
			foreach(self::$actions[$checkpoint] as $funct) {
				if (is_callable($funct)) {
			 		call_user_func($funct,$args);
				}
			}
		}
	}
	static function filter($checkpoint,$content = '',$args = ''){
		if(pluginClass::$filters && !empty(pluginClass::$filters)){
			if(isset(self::$filters[$checkpoint]) && !empty(self::$filters[$checkpoint])){
					foreach(self::$filters[$checkpoint] as $funct) {
						if (is_callable($funct)) {
							$content = call_user_func($funct,$content,$args);
						}
					}
				}
			//foreach(pluginClass::$filters as $plugin) {
				// command above was placed here, inside the commented out foreach.
				// this caused filter to run more than one time, causing duplicate added content.
			//}
		}
		return $content;
	}
	
	
	// Plugin Management Functions
	public function get_plugin_data($file) {
		// We don't need to write to the file, so just open for reading.
		$fp = fopen( $file, 'r' );
		// Pull only the first 8kiB of the file in.
		$file_data = fread( $fp, 8192 );
		// PHP will close file handle, but we are good citizens.
		fclose( $fp );
		// Make sure we catch CR-only line endings.
		$file_data = str_replace( "\r", "\n", $file_data );
	
		$default_headers = array(
			'Name' => 'Plugin Name',
			'PluginURI' => 'Plugin URI',
			'Version' => 'Version',
			'VersionURI' => 'Version URI',
			'VersionDownloadURI' => 'Download URI',
			'Description' => 'Description',
			'Author' => 'Author',
			'AuthorURI' => 'Author URI',
			
		);
	
		$all_headers = $default_headers;
	
		foreach ( $all_headers as $field => $regex ) {
			if ( preg_match( '/^[ \t\/*#@]*' . preg_quote( $regex, '/' ) . ':(.*)$/mi', $file_data, $match ) && $match[1] )
				{$all_headers[ $field ] = trim(preg_replace("/\s*(?:\*\/|\?>).*/", '', $match[1]));}
			else{unset($all_headers[ $field ]);}
		}
	
		return $all_headers;
	}
	
	public function has_plugin_data($file){
		// This function checks to make sure that we have a Proper Header Requiring The Name Attribute.
		// We don't need to write to the file, so just open for reading.
		$fp = fopen( $file, 'r' );
		// Pull only the first 8kiB of the file in.
		$file_data = fread( $fp, 8192 );
		// PHP will close file handle, but we are good citizens.
		fclose( $fp );
		// Make sure we catch CR-only line endings.
		$file_data = str_replace( "\r", "\n", $file_data );
		if(preg_match( '/^[ \t\/*#@]*' . preg_quote( 'Plugin Name', '/' ) . ':(.*)$/mi', $file_data)){return true;}
		return false;
	}
	
	public function inDB($name){
		global $dbo;
		return $dbo->num_rows("SELECT * from tblplugins WHERE sName = '$name';"); 
	}
	
	public function addtoDB($name,$opts = ''){
		global $dbo;
		return $dbo->insert("INSERT INTO `tblplugins` (`sName` ,`nActive` ,`sOptions`)VALUES ('$name', '0', '$opts');");
	}
	
	public function removefromDB($plugin){
		global $dbo;
		
		$sql = "DELETE FROM tblplugins WHERE sName = '".$dbo->format($_GET['plugin'])."';";
		$dbo->delete($sql);
		
		return;
		
		
	}
	
	/* Returns New Version Number On Update and False on Current*/
	public function updateAvailable($plugin,$cur,$url){
		
		// Grab The Current Version Number From Provide URL
		// Only Check Every 24 Hours
		
		// If checked recently, return the cookied version
		// data is stored in cookie, serialized
		// empPlugin_pluginname
		
		// Cookie Expires in 24 hours. So only update on non existant cookie.
		if(isset($_COOKIE['empPlugin_'.$plugin])){
			$cookieData = unserialize($_COOKIE['empPlugin_'.$plugin]);
			$remote_version = $cookieData['remote_version'];
			if(version_compare($remoteVersion,$cur,'>')){
				// We Have New Version
				return $remoteVersion;
			}
			else{return false;}
		}
		else{
			if(!isset($url) || $url == '')return false;
			
			$remoteVersion = $this->getRemoteVersion($url);
			
			$cookieData = array();
			$cookieData['remote_version'] = $remoteVersion;
			$cookiestring = serialize($cookieData);
			setcookie('empPlugin_'.$plugin,$cookiestring,60*60*24);
			
			//die(var_dump($remoteVersion));
			if(version_compare($remoteVersion,$cur,'>')){
				// We Have New Version
				return $remoteVersion;
			}
			else return false;
		}
	}
 }
 ?>