<?php
require($chkSsettings->sRootPath.'/includes/plugin.class.php');
// Initialize our plugin engine
$PLUGINS = new pluginClass;

$PLUGINS->initialize();

function add_action($checkpoint,$funct){
	global $PLUGINS;
	$PLUGINS->add_action($checkpoint,$funct);
	
	}
function add_filter($checkpoint,$funct){
	global $PLUGINS;
	$PLUGINS->add_filter($checkpoint,$funct);
	
	}
function add_page($plugin,$funct){
	global $PLUGINS;
	$PLUGINS->add_page($plugin,$funct);
	}

function add_activate($plugin,$funct){
	global $PLUGINS;
	$PLUGINS->add_activate($plugin,$funct);
	}
function add_deactivate($plugin,$funct){
	global $PLUGINS;
	$PLUGINS->add_deactivate($plugin,$funct);
	}
function add_delete($plugin,$funct){
	global $PLUGINS;
	$PLUGINS->add_delete($plugin,$funct);
	}


?>