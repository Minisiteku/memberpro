// .po file like language pack
plupload.addI18n({
	'Select files' : 'Vyberte soubory',
	'Add files to the upload queue and click the start button.' : 'Přidejte soubory do fronty a pak spusťte nahrávání.',
	'Filename' : 'Název souboru',
	'Status' : 'Status',
	'Size' : 'Velikost',
	'Add Files' : 'Přidat soubory',
	'Stop current upload' : 'Zastavit nahrávání',
	'Start uploading queue' : 'Spustit frontu nahrávání',
	'Drag files here.' : 'Sem přetáhněte soubory.',
	'Start Upload': 'Spustit nahrávání',
	'Uploaded %d/%d files': 'Nahráno %d/%d souborů'
});