<?php
function debug( )
{
    ksort( $_REQUEST );
    echo "<table width='350px' border='1'>";
    foreach ( $_REQUEST as $key=>$val )
    {
        echo "<tr><td style='left-align:right; padding-right:10px'>";
        echo $key;
        echo "</td><td>";
        echo $val;
        echo "&nbsp;</td></tr>";
    }
    echo "</table><br>";
    exit( );}

// Return expiry date n months from now in YYYYMMDD format
function getExpiryDate( $nPaypalMonths=1 ) {
    return date('Ymd', strtotime('+' . $nPaypalMonths . ' month'));}

?>
