<?php
	class Secure{
		
		protected $salt = '';
		
		public function __construct($salt){$this->setSalt($salt);}
		
		protected function setSalt($salt){$this->salt = $salt;}
		
		protected function addRedirect($type){
			
			if($type == 'user'){
				$pieces = explode('page=',$_SERVER['QUERY_STRING']);
				$expieces = explode('&',$pieces[1]);
				$refpage =  $expieces[0];
				if($refpage != '' && $refpage !='home') $refcode = '&redirect='.$refpage;
			}
			else{
				//Admin Redirect
				$refpage = basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);
				$qs = $_SERVER['QUERY_STRING'];
				//die($refpage);
				if($refpage != '' && $refpage !='home.php' && $refpage !='admin'){
					$refcode = '?redirect='.urlencode($refpage);
					if($qs && $qs !=''){$refcode = '?redirect='.urlencode($refpage.'?'.$qs);}
				}
			}
			return $refcode;
		}
		
		protected function set_UAC($nUser_ID,$type = 'user'){
			global $dbo;
		
			if($type == 'user'){
				// Used To Store All Active Member Level Access Control
				$userLevel = array();
				
				$today = date("Ymd");
				
				// Get user levels which are still active
				// Inactive levels have nDateCancelled greater than 0 and have nDateExpires prior to today's date
				//$sql = "SELECT nLevel_ID FROM tbluserlevels WHERE nUser_ID = " . $dbo->format($nUser_ID) . " AND nActive = 1 AND nDateCancelled = 0 OR (nDateExpires > $today AND nDateCancelled > 0) ";
				
				// 3.0.6 - Above Comment is No Good! This should really run off of active or inactive only.
				// Cron Processing Decides whether or not to set an expired or cancelled membership to Inactive.
		
				$sql = "SELECT nLevel_ID FROM tbluserlevels WHERE nUser_ID = " . $dbo->format($nUser_ID) . " AND nActive = '1'";
				$rs = $dbo->select($sql);
				if (! empty ( $rs )) {while ( $rw = $dbo->getobj($rs)) {$userLevel[] = $rw->nLevel_ID;}}
				$userLevel = @implode ( '\',\'', $userLevel );
				//check if the user is a paid user 
		
				$_SESSION['user']['ACL'] = $userLevel;
			}
		}
		
		public function setAuth($type,$objUser){
			global $dbo;
			// Lets reset the session[type] variable as old coding sets this as a string with the email on session[user]
			$_SESSION[$type] = array();
			$sess_id = md5($this->salt."-".$objUser->sPassword);
			$_SESSION[$type]["session_id"] = $sess_id;
			$_SESSION[$type]['nUser_ID'] = $objUser->nUser_ID;
			
			//session_regenerate_id(TRUE); // Prevent Session Fixation
			$_SESSION[$type]['LAST_ACTIVITY'] = time(); // Used For Session Expire
			setcookie('LAST_ACTIVITY', time()); 
			// Lets Do Login Log.
			function get_user_browser(){
				$u_agent = $_SERVER['HTTP_USER_AGENT'];
				$ub = '';
				if(preg_match('/MSIE/i',$u_agent))
				{
					$ub = "ie";
				}
				elseif(preg_match('/Firefox/i',$u_agent))
				{
					$ub = "firefox";
				}
				elseif(preg_match('/Safari/i',$u_agent))
				{
					$ub = "safari";
				}
				elseif(preg_match('/Chrome/i',$u_agent))
				{
					$ub = "chrome";
				}
				elseif(preg_match('/Flock/i',$u_agent))
				{
					$ub = "flock";
				}
				elseif(preg_match('/Opera/i',$u_agent))
				{
					$ub = "opera";
				}
			   
				return $ub;}
			
			$sql = "INSERT INTO `tbl".$type."logins` (`nId` ,`nUser_ID` ,`nTimestamp` ,`sIp`,`sBrowser`)
				VALUES (NULL , '".$objUser->nUser_ID."', '".time()."', '".$_SERVER['REMOTE_ADDR']."','".get_user_browser()."');";
				$res = $dbo->insert($sql);
			}
		
		public function checkAuth($type = 'user',$redirect = true){
			global $dbo,$chkSsettings;
			
			$refcode = $this->addRedirect($type);
			if($type == 'user'){$login = $chkSsettings->sSiteURL.'/index.php?page=login'.$refcode;}
			elseif($type == 'admin'){$login = $chkSsettings->sSiteURL.'/admin/index.php'.$refcode;}
			//die($login);
			if($_SESSION[$type]['nUser_ID']){
					$sql = "SELECT sValue FROM tbloptions WHERE sName = 'session_timeout_active'";
					$sto = $dbo->getval($sql);
					if($sto == '1'){
						// Check For Timeout. Option Returns Minutes /////////////////////////////////////////////////////////////////////
						// $timeout is in seconds.
						$opt = $dbo->getval("SELECT sValue FROM tbloptions WHERE sName = 'security_timeout'");
						if(!$opt){$opt = 20;}
						$timeout = intval($opt)*60;
						$timeout = $timeout + 60;
						if(time() - $_SESSION[$type]['LAST_ACTIVITY'] > $timeout){
							// Last Request Was Longer Than Timeout Period. Kill Session
							$this->unsetAuth($type);
							
							if($redirect){
								// Check for existing query vars
								$append = (strpos($login,'?') !== false)?'&':'?';
								
								if($type == 'admin'){header("Location:$login".$append."warn=Your Session Has Expired Due To Inactivity.<br /> Please Login Again.");exit;}
								
								header("Location:$login".$append."warn=Your Session Has Expired Due To Inactivity.<br /> Please Login Again.");exit;}
							else{return false;}
						}
					/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					}
					
					
					$sql = "SELECT * FROM tblusers where nUser_ID = '".$_SESSION[$type]['nUser_ID']."' AND nActive = '1'";
					if($type == 'admin'){$sql .=" AND nAdmin = '1'";}
					$objUser = $dbo->getobject($sql);
					
					if($dbo->nr() == 1){
						// Check the Salt
						if($_SESSION[$type]['session_id'] != md5($this->salt."-".$objUser->sPassword)){
						// Failed Salt Verification! This could be due to admin changing the salt, or hijack attempt;
						unset($_SESSION[$type]);
						if($redirect){header("Location:$login");exit;}
						else{return false;}
						
						}
						else{
							// Update The Timeout Period
							$_SESSION[$type]['LAST_ACTIVITY'] = time(); // Used For Session Expire
							setcookie('LAST_ACTIVITY', time());
							return true;
							// (Re)Set ACL
							$this->set_UAC($_SESSION[$type]['nUser_ID'],$type);
						}
					}
					else{
						if($redirect){header("Location:$login");exit;}
						else{return false;}
					}
				}
			else{
				
				if($redirect){header("Location:$login");exit;}
				else{return false;}
				
				}
		}
		
		public function get_ACL($nUser_ID,$type = 'user'){
			
			if($type == 'user'){return $_SESSION[$type]['ACL'];}
			
		}
		
		public function unsetAuth($type = 'user'){
			unset($_SESSION[$type]);
			return;
		}
		
		public function getLicenseDetails($key,$force = false){
			global $dbo;
			
			$sql = "SELECT * FROM tbloptions WHERE sName = 'licenseData';";
			$res = $dbo->select($sql);
			// Data stored as json in database.
			if($force === TRUE) $updateData = 1;
			else{
				if($dbo->nr > 0){
					$row = $dbo->getobj($res);
					$licenseData = json_decode($row->sValue);
					
					if($licenseData->updated + (60*60*24) < time()){
						// details not updated in more than 24 hours
						$updateData = '1';
					}
				}
				else{$updateData = '1';}
			}
			
			
			if($updateData == '1'){
				
				if(!$dbo->nr($res)) {
					$dbo->insert("INSERT INTO `tbloptions` (`sName` ,`sValue`)VALUES ('licenseData', '');");
				}
				
				// 
				$url = "http://licensing.easymemberpro.com/remote.php?cmd=DATA&key=$key";
				$ch = curl_init();    // initialize curl handle
				curl_setopt($ch, CURLOPT_URL,$url); // set url to post to
				curl_setopt($ch, CURLOPT_FAILONERROR, 1);
				curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);// allow redirects
				curl_setopt($ch, CURLOPT_RETURNTRANSFER,1); // return into a variable
				curl_setopt($ch, CURLOPT_TIMEOUT, 3); // times out after 4s
				//curl_setopt($ch, CURLOPT_POST, 1); // set POST method
				//curl_setopt($ch, CURLOPT_POSTFIELDS, "url=index%3Dbooks&field-keywords=PHP+MYSQL"); // add POST fields
				$result = curl_exec($ch); // run the whole process
				curl_close($ch);
				
				$licenseData = json_decode($result);
				
				$licenseData->updated = time();
				
				$sql = "UPDATE tbloptions SET sValue = '".json_encode($licenseData)."' WHERE sName = 'licenseData';";
				$dbo->update($sql);
				
				return $licenseData;
			}
			else return $licenseData;
	}
		
	}
?>