<?php
	if (!file_exists("conn_data.php")){header("location:install/index.php");exit;}
	include_once('conn.php');
	include_once('functions.php');
	
	
	#########################################################################################
	### Load Up Template Stuff ##############################################################
	#########################################################################################
	// This is a temporary solution for a new template option.
	// This option came about by removing the images from the default template, to prevent overwriting default templates that has images added later.
	if(!is_option('default_template_head_bg')){add_option('default_template_head_bg','#333399');}
	
	// Lets Set Language Setting // Added by MDP 1-1-12
	require_once("languages/".strtolower($objTemplateSettings->sLanguageFile).".php");
	////////////////////////////////////////////////////////// 
	$headerNavAlign = $objTemplateSettings->sHeaderNavAlign;
	$headerNavAlign = (empty($headerNavAlign)) ? 'right' : $headerNavAlign;
	$headerTextBold = ($objTemplateSettings->nHeaderTextBold) ? 'bold' : 'normal';
	$footerNavAlign = (empty($objTemplateSettings->sFooterNavAlign)) ? 'right' : $objTemplateSettings->sFooterNavAlign;
	$footerTextBold = ($objTemplateSettings->nFooterTextBold) ? 'bold' : 'normal';
	$affiliate_link = (!empty($chkSsettings->sEMPAffiliateLink)) ? $chkSsettings->sEMPAffiliateLink : 'http://www.easymemberpro.com/';
	$menu = getMenu();
	$menu = pluginClass::filter("main_menu",$menu);
	$content = '';
	######################################################################################
	### Affiliate Coding #################################################################
	######################################################################################
	
	
	
	
	if($_GET['mp']){set_marketplace($_GET['mp']);}
	
	$marketplace = get_marketplace_processor($_GET['mp']);
	
	if ( isset($_GET['afid']) ){
		// Check If MarketPlace. If So Store Affiliate Into Another Variable
		// Until A Marketplace Product Has Been Confirmed.
		// This is important!! We do not want to pay a commission for Both
		// The In House Affiliate System AND an External Market Place.
		if($marketplace == true){
		
			// ASSIGN AFFILIATE ID TO SESSION
			if ( isset($_GET['afid']) ) $_SESSION['inHouseAffiliateId'] = $_GET['afid'];
	
	 	}
		else{
			// Assign In House Affiliate Cookie.
			$_SESSION['emp-afid'] = $_GET['afid'];
			emp_setcookie(
			'emp-afid', 
			$_GET['afid'], 
			($chkSsettings->nCookieNeverExpires==1 ? 7776000 : ($chkSsettings->nCookieExpiry > 0 ? $chkSsettings->nCookieExpiry*86400 : 7776000)));
		}
			
		
		
	}
	######################################################################################
	
	// Assign coupon code to session
	if (isset($_GET['coupon'])) {$_SESSION['sCouponCode'] = $dbo->format($_GET['coupon']);}
	
	// Test that the 'page' parameter exists, if not, then default to 'home'.
	$page_name = $dbo->format(isset($_GET['page']) ? $_GET['page'] : 'home');
	// Get the page data from the database table.
	
	$sql = "SELECT * FROM tblpages WHERE sFileName = '$page_name'
	AND nPage_ID NOT IN (SELECT nPage_ID FROM tblpagelevels P INNER JOIN tblmembershiplevels M ON M.nLevel_ID = P.nLevel_ID) LIMIT 1"; 
	
	$objPage = $dbo->getobject($sql);
	
	// No Page Found, Or Is Member Page.
	if(!$objPage){header("Location: index.php");exit;}
	
	if ($page_name == 'home' && $objPage->nDisplay == 0) {$page_content =  '<span class="red"><b>' . $language['page_is_being_updated'] . '</b></span>';}
	else {
		// Check if the page data contains the page contents.
		if ($objPage->sContent != '') $page_content =  str_replace("{%uid%}", $uid, stripslashes($objPage->sContent));
	}
		
	// Remove Join Page text for steps 2 and 3
	if ($_GET['page'] == 'join' && isset($_GET['step']) && ($_GET['step'] == '2' || $_GET['step'] == '3' )) {$page_content = '';}
	
	// Import PHP page that matches the page name
	if (file_exists($page_name . '.php')) {
		
		ob_start();
		include($page_name . '.php');
		$page = ob_get_clean();
		
		//$default_content = get_string_between($page, '<!--CONTENT[START]-->', '<!--CONTENT[FINISH]-->');
		// Replace what's in the files with what's in the database sContent field
		//$page_content = str_replace($default_content, $page, $page_content);
		
		          	
		if ($page_name == 'home' && $objPage->nDisplay == 0) {$page_content = $page_content;}
		else {$page_content .= $page;}
		
	}
	
	// Added substitution for video embed code
	$splashpath = 'common/images/splash/';
	$pattern = '/\[\[\s?video\s\d+(\sAUTOPLAY)?(\s(HEIGHT|WIDTH)=\d+)?(\s(HEIGHT|WIDTH)=\d+)?\s?\]\]/';
	$matches = array();
	$videos = array();
	if (preg_match_all($pattern, $page_content, $matches) ) {
			
		// Get The Ids of the videos
		$n = 0;
		$ids = array();
		foreach ($matches as $match) {
			// Get Video ID
			foreach($match as $v){
				$n++;
				preg_match('/\d+/', $v, $found);
				if($found[0] !=NULL) $ids[$n] = $found[0];
			}
			
		}
			
		foreach($ids as $v){
			// Lets Do Some Error Checking ...
			// get the video info from db/
			$objFile = $dbo->getobject("SELECT * FROM tblvideos WHERE nVideo_ID=" . $v);
			// Did we find in th database?
			if($objFile){
				// We have the video - Lets continue
				// Check that this file can be viewed by non-members
				if ($objFile->nMemberOnly) {
					// SESSION CHECK
					//old method
					//if ($_SESSION['sUsername'] == '') {$splash[$v] = 'memberonly.jpg';}
					if(!$secure->checkAuth('user',false)){$splash[$v] = 'memberonly.jpg';}	
				}
					
				// Lets check to see if we can open the file.
				$remote = ($objFile->sURL == "") ? 0 : 1;
				$path       = ($remote == 1) ? $objFile->sURL : $sSiteURL . "/admin/assets/";
				$fileName   = $objFile->sFileName;
				// Subfolder detection //////////////////////////////////////////
				if($remote == 0 ) $path = ($objFile->sPath !=='/')? $path.$objFile->sPath.'/' : $path;
					
				$dirFile    = ($remote) ? $path : $path . $fileName;
				$extension = $objFile->sType;
					
				$fh = fopen($dirFile, "rb");
				if($fh) fclose($fh);
				else $splash[$v] = 'failedtoopen.jpg';
			}
			else{$splash[$v] = 'notfound.jpg';}
		}
		
		
		$videos = displayVideoEmbedCode($matches[0],'',$splash,$splashpath);
		$page_content = str_replace($matches[0], $videos, $page_content);
	}
	
	// Added substitution for file embed code	                
	$pattern = '/\[\[\s?file\s\d+(\sTEXT=(\"|&quot;).+(\"|&quot;))?\s?\]\]/';
	$matches = array();
	$files = array();
	if (preg_match_all($pattern, $page_content, $matches) ) {
		$files = displayFileEmbedCode($matches[0]);
		$page_content = str_replace($matches[0], $files, $page_content);
	}
	
	// Run Filter Hook
	$page_content = pluginClass::filter("main_content",$page_content);
	
	// Get layout template
	ob_start();
	
	if(file_exists(TEMPLATEPATH.'template.php')) require(TEMPLATEPATH.'template.php');
	elseif(file_exists(TEMPLATEPATH.'template.html')) require(TEMPLATEPATH.'template.html');
	else die('ERROR: Template Not Found');

	$template = ob_get_clean();
	
	// CLICKBANK FOOTER DETECTION V3.0.9
	$useCbFooter = 0;
	$cbFooterOption = get_option('cbFooterOption');
	if($cbFooterOption == '1') $useCbFooter = 1;
	elseif ($cbFooterOption == '2' && $_GET['mp'] == 'cb') $useCbFooter = 1;

	// Substitution
	$headimg = getimagesize($objTemplateSettings->headerpath);
	$subsitutes = array(
		'[[TITLE]]' => (empty($objPage->sPageTitle)) ? $sSitename : $objPage->sPageTitle,
		'[[METATAGS]]' => stripslashes($chkSsettings->sMetaTags),
		'[[GOOGLEWEBMASTER]]' => stripslashes($chkSsettings->sGoogleWebmaster),
		'[[GOOGLEANALYTICS]]' => stripslashes($chkSsettings->sGoogleAnalytics),
		'[[SCRIPTS]]' => '<script type="text/javascript" src="common/load-code.php?script=jq,validate,hover,menus,fplayer,emp"></script>',
		'[[JAVASCRIPT]]' => stripslashes($chkSsettings->sJavascript),
		'[[BODY_BG_COLOR]]' => $objTemplateSettings->bodybackground,
		'[[BODY_BG_IMG]]' => 'layout/'.TEMPLATEFOLDER.'/images/bg.jpg',
		'[[MENU_TEXT_COLOR]]' => $objTemplateSettings->mtextcolor,
		'[[MENU_HOVER_COLOR]]' => $objTemplateSettings->mhovercolor,
		'[[SITE_NAME]]' => $chkSsettings->sSiteName,
		'[[HEAD_IMG_HEIGHT]]'=> $headimg[1],
		'[[TABLE_WIDTH]]' => ($objTemplateSettings->headimgwidth + 0),
		'[[TABLE_BORDER]]' => ($objTemplateSettings->nHideBorder ) ? '' : 'style="border: 1px solid #000000;"',
		'[[HEADER_PATH]]' => $objTemplateSettings->headerpath,
		'[[TOP_COLOR]]' => $objTemplateSettings->mbackcolor,
		'[[HEADER_BG_COLOR]]' => get_option(TEMPLATEFOLDER.'_template_head_bg'),
		'[[HEADER_BG_COLOR_1]]' => $objTemplateSettings->mbackcolor,
		'[[HEADER_NAV_ALIGN]]' => $headerNavAlign,
		'[[TOP_MENU]]' => build_menu(),
		'[[LOGGED_OUT_MESSAGE]]' => ( isset($_GET['act']) && $_GET['act'] == 'logs') ? '<span class="success">' . $language['logged_out'] . '</span><br /><br />' : '',
		'[[CONTENT]]' => $page_content,
		'[[FOOTER_WIDTH]]' => ($objTemplateSettings->headimgwidth + 2),
		'[[FOOTER_GRAPHIC]]' => (!$objTemplateSettings->nHideFooterGraphic) ? '<tr><td valign="top"><img src="' . $objTemplateSettings->footerpath .'" width="' . $objTemplateSettings->headimgwidth . '" /></td></tr>' : '',
		'[[FOOTER_TOP]]' => (!$objTemplateSettings->nHideFooterNav) ? '<tr><td height="41" valign="middle" bgcolor="' . $objTemplateSettings->btmcolor1 . '" class="whitenav" style="font-weight: ' . $footerTextBold . '; text-align: ' . $footerNavAlign . '; padding-left:15px; padding-right:15px;">' : '',
		'[[FOOTER_MENU]]' => display_footer_menu(),
		'[[FOOTER_BOTTOM]]' => (!$objTemplateSettings->nHideFooterNav) ? '</td></tr>' : '',
		'[[POWERED_BY]]' => (!$objTemplateSettings->nHidePoweredByLink) ? $language['powered_by'] . ' <a href="' . $affiliate_link . '" target="_blank">EasyMemberPro - ' . $language['membership_software'] . '</a>' : '',
		'[[CLICKBANK_FOOTER]]'=> ($useCbFooter == 1)?get_option('cbFooterScript'):''
	);
	
	foreach ($subsitutes as $k => $v) $template = str_replace($k, $v, $template);
	
	// Add javascript for jquery error messages
	$jqueryerrors = "
	<script language=\"javascript\">
	errEqualTo='&nbsp;" . $language['errors_same_value'] . "';
	errRequired='&nbsp;" . $language['errors_mandatory'] . "';
	errRemote='';
	errEmail='&nbsp;" . $language['errors_valid_email'] . "';
	errUrl='';
	errDate='';
	errDateISO='';
	errNumber='';
	errDigits='';
	errLinkv='';
	errCreditCard='';				
	errAccept='';
	errMaxLength='';
	errMinLength='&nbsp;" . $language['errors_6chars'] . "';
	errRangeLength='';
	errRangeValue='';
	errMaxValue='';
	errMinValue='';
	</script>
	";
	
	$template = str_replace("</body>", "$jqueryerrors\n\n</body>", $template);
	
	$template = pluginClass::filter("main_template",$template);
	
	echo $template;

	function display_footer_menu() {
	
		global $dbo, $objTemplateSettings, $footerNavAlign, $footerTextBold, $chkSsettings;
	
		$display_footer = '';
		
		if (!$objTemplateSettings->nHideFooterNav) {
			
			$c = 0;
				
			$sql = "SELECT * FROM tblpages WHERE nDirectory_ID = 0 AND nDisplay = 1 AND sNavBarLocation = 'bottom'";
					
			// Check if hiding affiliate page
			$sql1 = "SELECT nHideAffiliateProgram FROM tblaffiliatesettings";
			$bHideAffiliateProgram = $dbo->getval($sql1);
			if ($bHideAffiliateProgram) $sql = $sql . " AND sFileName!='affiliates'";
					
			$sql = $sql . " ORDER BY nSortOrder ASC";
					
			$me = $dbo->select($sql);
					
			if ($me !== false) {
				$navcnt = $dbo->nr($me);
				while ($men = $dbo->getobj($me)) {
					$c++;	
					$display_footer .= '<a href="index.php?page=' . $men->sFileName . '" class="white">' . $men->sPageName . '</a> ';
					if ($navcnt != $c) $display_footer .= ' | ';
				}
			}
		}
		$display_footer = pluginClass::filter("main_footer",$display_footer);
		return $display_footer;
	}
	
?>